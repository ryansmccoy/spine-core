# Capture Spine Permissions Model

> Role-Based Access Control (RBAC) with Resource-Level Permissions

**Version:** 1.0  
**Last Updated:** January 27, 2026

---

## Table of Contents

1. [Overview](#1-overview)
2. [Roles](#2-roles)
3. [Permissions](#3-permissions)
4. [Resource Ownership](#4-resource-ownership)
5. [Sharing Model](#5-sharing-model)
6. [Team Permissions](#6-team-permissions)
7. [Implementation](#7-implementation)
8. [API Endpoint Security](#8-api-endpoint-security)

---

## 1. Overview

Capture Spine uses a layered permission system:

```
┌─────────────────────────────────────────────────────────────┐
│                    Permission Layers                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Role-Based (Global)                                     │
│     └── What actions can this user type perform?            │
│                                                             │
│  2. Ownership (Resource)                                    │
│     └── Does the user own this resource?                    │
│                                                             │
│  3. Sharing (Explicit)                                      │
│     └── Has access been explicitly granted?                 │
│                                                             │
│  4. Team (Organizational)                                   │
│     └── Is user a member of a team with access?             │
│                                                             │
│  5. Visibility (Public)                                     │
│     └── Is the resource publicly accessible?                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Roles

### 2.1 System Roles

| Role | Description | Typical User |
|------|-------------|--------------|
| `viewer` | Read-only access | Guest, trial user |
| `user` | Standard access | Regular user |
| `power_user` | Advanced features | Power user, developer |
| `admin` | Administrative access | Team admin |
| `super_admin` | Full system access | Platform owner |

### 2.2 Role Hierarchy

```
super_admin
    ↓ inherits
  admin
    ↓ inherits
power_user
    ↓ inherits
   user
    ↓ inherits
  viewer
```

### 2.3 Role Definitions

```yaml
viewer:
  description: "Read-only access to shared content"
  permissions:
    - records:read
    - feeds:read
    - profile:read
  restrictions:
    - Cannot create content
    - Cannot modify anything
    - No API access

user:
  description: "Standard user with personal workspace"
  inherits: viewer
  permissions:
    - records:star
    - records:read_state
    - alerts:create_own
    - alerts:read_own
    - alerts:update_own
    - alerts:delete_own
    - collections:create_own
    - collections:read_own
    - collections:update_own
    - collections:delete_own
    - profile:update
    - messages:send
    - messages:read_own

power_user:
  description: "Advanced user with feed creation"
  inherits: user
  permissions:
    - feeds:create
    - feeds:update_own
    - feeds:delete_own
    - groups:create
    - groups:update_own
    - groups:delete_own
    - api_keys:create_own
    - api_keys:read_own
    - api_keys:delete_own
    - webhooks:create_own
    - webhooks:update_own
    - webhooks:delete_own

admin:
  description: "Team/organization administrator"
  inherits: power_user
  permissions:
    - users:read
    - users:create
    - users:update
    - users:disable
    - feeds:read_all
    - feeds:update_all
    - alerts:read_all
    - settings:read
    - settings:update
    - audit:read
    - team:manage_members
    - team:manage_settings

super_admin:
  description: "Full system access"
  inherits: admin
  permissions:
    - "*:*"  # All permissions
    - users:delete
    - system:configure
    - system:backup
    - roles:manage
```

---

## 3. Permissions

### 3.1 Permission Format

Permissions follow the pattern: `resource:action` or `resource:action:scope`

```
Examples:
  feeds:read          - Read any feed (user has access to)
  feeds:create        - Create new feeds
  feeds:update_own    - Update feeds user owns
  feeds:update_all    - Update any feed (admin)
  feeds:delete_own    - Delete own feeds
  users:manage        - Full user management
```

### 3.2 Permission Catalog

#### Content Permissions

| Permission | Description | Roles |
|------------|-------------|-------|
| `records:read` | View records | viewer+ |
| `records:star` | Star/bookmark records | user+ |
| `records:read_state` | Mark read/unread | user+ |
| `records:annotate` | Add highlights/notes | user+ |
| `records:comment` | Add comments | user+ |
| `records:share` | Share with others | user+ |
| `records:delete` | Delete records | admin+ |

#### Feed Permissions

| Permission | Description | Roles |
|------------|-------------|-------|
| `feeds:read` | View feeds | viewer+ |
| `feeds:create` | Create new feeds | power_user+ |
| `feeds:update_own` | Edit own feeds | power_user+ |
| `feeds:update_all` | Edit any feed | admin+ |
| `feeds:delete_own` | Delete own feeds | power_user+ |
| `feeds:delete_all` | Delete any feed | admin+ |
| `feeds:share` | Share feeds | power_user+ |

#### Alert Permissions

| Permission | Description | Roles |
|------------|-------------|-------|
| `alerts:read_own` | View own alerts | user+ |
| `alerts:read_all` | View all alerts | admin+ |
| `alerts:create_own` | Create alerts | user+ |
| `alerts:update_own` | Edit own alerts | user+ |
| `alerts:delete_own` | Delete own alerts | user+ |
| `alerts:manage_all` | Manage any alert | admin+ |

#### User Permissions

| Permission | Description | Roles |
|------------|-------------|-------|
| `profile:read` | View own profile | viewer+ |
| `profile:update` | Edit own profile | user+ |
| `users:read` | View other users | admin+ |
| `users:create` | Create users | admin+ |
| `users:update` | Edit other users | admin+ |
| `users:disable` | Disable accounts | admin+ |
| `users:delete` | Delete accounts | super_admin |
| `users:impersonate` | Log in as user | super_admin |

#### System Permissions

| Permission | Description | Roles |
|------------|-------------|-------|
| `settings:read` | View system settings | admin+ |
| `settings:update` | Modify settings | admin+ |
| `audit:read` | View audit logs | admin+ |
| `system:configure` | System configuration | super_admin |
| `system:backup` | Backup/restore | super_admin |
| `roles:manage` | Manage role definitions | super_admin |

---

## 4. Resource Ownership

### 4.1 Ownership Model

Every user-created resource has an `owner_user_id`:

```sql
-- Feed ownership
SELECT * FROM feeds WHERE feed_id = $1;
-- Returns: {feed_id, name, ..., user_id, ...}
--                                ↑
--                           Owner user

-- Check ownership
SELECT EXISTS(
    SELECT 1 FROM feeds 
    WHERE feed_id = $1 AND user_id = $2
);
```

### 4.2 Ownership Rules

| Rule | Description |
|------|-------------|
| **Creation** | Creator becomes owner |
| **Transfer** | Owner can transfer to another user |
| **Deletion** | Only owner or admin can delete |
| **Orphan** | When owner deleted, resources transfer to admin or delete |

### 4.3 System Resources

Some resources have no owner (system-wide):
- System feeds (shared news sources)
- Default settings
- System notifications

```sql
-- System feed (no owner)
INSERT INTO feeds (name, user_id, is_shared) 
VALUES ('SEC EDGAR', NULL, true);
```

---

## 5. Sharing Model

### 5.1 Share Types

| Type | Description | Example |
|------|-------------|---------|
| **User Share** | Share with specific user | "Share feed with john@example.com" |
| **Team Share** | Share with entire team | "Share with Engineering team" |
| **Link Share** | Anyone with link | "Create shareable link" |
| **Public** | Visible to all users | "Make collection public" |

### 5.2 Permission Levels

| Level | Can Read | Can Edit | Can Share | Can Delete |
|-------|----------|----------|-----------|------------|
| `view` | ✅ | ❌ | ❌ | ❌ |
| `edit` | ✅ | ✅ | ❌ | ❌ |
| `admin` | ✅ | ✅ | ✅ | ✅ |

### 5.3 Share Schema

```sql
CREATE TABLE permission_grants (
    grant_id UUID PRIMARY KEY,
    
    -- What is being shared
    resource_type TEXT NOT NULL,  -- 'feed', 'collection', 'alert'
    resource_id UUID NOT NULL,
    
    -- Who is sharing
    grantor_user_id UUID NOT NULL,
    
    -- Who receives access
    grantee_type TEXT NOT NULL,   -- 'user', 'team', 'link', 'public'
    grantee_id UUID,              -- NULL for 'link' or 'public'
    
    -- Access level
    permission_level TEXT NOT NULL,  -- 'view', 'edit', 'admin'
    
    -- Link share specific
    link_token TEXT,              -- For link shares
    link_password_hash TEXT,      -- Optional password protection
    
    -- Expiration
    expires_at TIMESTAMPTZ,
    
    -- Audit
    created_at TIMESTAMPTZ DEFAULT NOW(),
    revoked_at TIMESTAMPTZ,
    revoked_by UUID
);
```

### 5.4 Permission Check Flow

```python
def can_access(user_id: UUID, resource_type: str, resource_id: UUID, 
               required_permission: str) -> bool:
    """
    Check if user can access a resource with required permission level.
    
    Flow:
    1. Super admin? → ALLOW
    2. Owner? → ALLOW
    3. Admin + admin permission? → ALLOW
    4. Explicit share with sufficient level? → ALLOW
    5. Team member + team share with sufficient level? → ALLOW
    6. Public resource + view permission? → ALLOW
    7. → DENY
    """
    
    user = get_user(user_id)
    
    # 1. Super admin bypass
    if user.role == 'super_admin':
        return True
    
    # 2. Check ownership
    resource = get_resource(resource_type, resource_id)
    if resource.user_id == user_id:
        return True
    
    # 3. Admin with manage permission
    if user.role == 'admin' and has_role_permission(user.role, f"{resource_type}:manage_all"):
        return True
    
    # 4. Explicit user share
    grant = get_permission_grant(
        resource_type=resource_type,
        resource_id=resource_id,
        grantee_type='user',
        grantee_id=user_id
    )
    if grant and permission_level_sufficient(grant.permission_level, required_permission):
        return True
    
    # 5. Team share
    user_teams = get_user_teams(user_id)
    for team_id in user_teams:
        grant = get_permission_grant(
            resource_type=resource_type,
            resource_id=resource_id,
            grantee_type='team',
            grantee_id=team_id
        )
        if grant and permission_level_sufficient(grant.permission_level, required_permission):
            return True
    
    # 6. Public resource (view only)
    if resource.visibility == 'public' and required_permission == 'view':
        return True
    
    # 7. Deny
    return False
```

---

## 6. Team Permissions

### 6.1 Team Roles

| Role | Description | Permissions |
|------|-------------|-------------|
| `owner` | Team owner | Full control, billing, delete team |
| `admin` | Team admin | Manage members, settings |
| `member` | Regular member | Use team resources |
| `guest` | Limited guest | View-only access |

### 6.2 Team Role Permissions

```yaml
team_roles:
  owner:
    permissions:
      - team:delete
      - team:transfer
      - team:billing
      - team:settings
      - team:members:*
      - team:resources:*
      
  admin:
    permissions:
      - team:settings
      - team:members:invite
      - team:members:remove
      - team:members:update_role  # except owner
      - team:resources:*
      
  member:
    permissions:
      - team:members:read
      - team:resources:read
      - team:resources:create
      - team:resources:update_own
      
  guest:
    permissions:
      - team:members:read
      - team:resources:read
```

### 6.3 Team Resource Access

```sql
-- Check if user can access team resource
SELECT EXISTS(
    SELECT 1 
    FROM team_members tm
    JOIN feeds f ON f.team_id = tm.team_id
    WHERE tm.user_id = $1 
      AND f.feed_id = $2
      AND tm.role IN ('owner', 'admin', 'member')
);
```

---

## 7. Implementation

### 7.1 Permission Decorator (Python/FastAPI)

```python
from functools import wraps
from typing import Optional, List
from fastapi import HTTPException, Depends

def require_permission(*permissions: str):
    """
    Decorator to require permissions for an endpoint.
    
    Usage:
        @router.post("/feeds")
        @require_permission("feeds:create")
        async def create_feed(...)
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
            for permission in permissions:
                if not user_has_permission(current_user, permission):
                    raise HTTPException(
                        status_code=403,
                        detail=f"Permission denied: {permission}"
                    )
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator


def require_resource_access(
    resource_type: str,
    id_param: str = "id",
    permission: str = "view"
):
    """
    Decorator to check resource-level access.
    
    Usage:
        @router.put("/feeds/{feed_id}")
        @require_resource_access("feed", "feed_id", "edit")
        async def update_feed(feed_id: UUID, ...)
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
            resource_id = kwargs.get(id_param)
            if not resource_id:
                raise HTTPException(400, f"Missing {id_param}")
            
            if not can_access_resource(
                current_user.user_id, 
                resource_type, 
                resource_id, 
                permission
            ):
                raise HTTPException(403, "Access denied")
            
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator
```

### 7.2 Permission Check Service

```python
class PermissionService:
    """Service for checking permissions."""
    
    def __init__(self, db: Database):
        self.db = db
        self._role_permissions = self._load_role_permissions()
    
    def user_has_permission(self, user: User, permission: str) -> bool:
        """Check if user has a global permission via their role."""
        if user.role == 'super_admin':
            return True
        
        role_perms = self._role_permissions.get(user.role, [])
        
        # Check exact match
        if permission in role_perms:
            return True
        
        # Check wildcard (e.g., "feeds:*" matches "feeds:create")
        resource, action = permission.split(':')
        if f"{resource}:*" in role_perms:
            return True
        
        return False
    
    async def can_access_resource(
        self, 
        user_id: UUID, 
        resource_type: str, 
        resource_id: UUID,
        required_level: str = 'view'
    ) -> bool:
        """Check if user can access a specific resource."""
        
        user = await self.db.get_user(user_id)
        
        # Super admin
        if user.role == 'super_admin':
            return True
        
        # Get resource
        resource = await self.db.get_resource(resource_type, resource_id)
        if not resource:
            return False
        
        # Owner check
        if resource.user_id == user_id:
            return True
        
        # Admin with manage_all permission
        if self.user_has_permission(user, f"{resource_type}:manage_all"):
            return True
        
        # Check explicit grants
        grants = await self.db.get_permission_grants(
            resource_type=resource_type,
            resource_id=resource_id,
            grantee_id=user_id
        )
        
        for grant in grants:
            if self._level_sufficient(grant.permission_level, required_level):
                return True
        
        # Check team grants
        user_teams = await self.db.get_user_teams(user_id)
        for team_id in user_teams:
            team_grants = await self.db.get_permission_grants(
                resource_type=resource_type,
                resource_id=resource_id,
                grantee_type='team',
                grantee_id=team_id
            )
            for grant in team_grants:
                if self._level_sufficient(grant.permission_level, required_level):
                    return True
        
        # Check public visibility
        if resource.visibility == 'public' and required_level == 'view':
            return True
        
        return False
    
    def _level_sufficient(self, granted: str, required: str) -> bool:
        """Check if granted level is sufficient for required level."""
        levels = {'view': 1, 'edit': 2, 'admin': 3}
        return levels.get(granted, 0) >= levels.get(required, 0)
```

### 7.3 Database Row-Level Security

```sql
-- Enable RLS
ALTER TABLE feeds ENABLE ROW LEVEL SECURITY;

-- Policy: Users see their own feeds + shared + public
CREATE POLICY feeds_select ON feeds FOR SELECT
USING (
    -- Owner
    user_id = current_setting('app.user_id')::uuid
    -- Or system feed
    OR user_id IS NULL
    -- Or shared with user
    OR EXISTS (
        SELECT 1 FROM permission_grants pg
        WHERE pg.resource_type = 'feed'
          AND pg.resource_id = feeds.feed_id
          AND pg.grantee_type = 'user'
          AND pg.grantee_id = current_setting('app.user_id')::uuid
          AND pg.revoked_at IS NULL
          AND (pg.expires_at IS NULL OR pg.expires_at > NOW())
    )
    -- Or shared with user's team
    OR EXISTS (
        SELECT 1 FROM permission_grants pg
        JOIN team_members tm ON tm.team_id = pg.grantee_id::uuid
        WHERE pg.resource_type = 'feed'
          AND pg.resource_id = feeds.feed_id
          AND pg.grantee_type = 'team'
          AND tm.user_id = current_setting('app.user_id')::uuid
          AND pg.revoked_at IS NULL
    )
    -- Or public
    OR visibility = 'public'
);

-- Policy: Users can only update their own feeds
CREATE POLICY feeds_update ON feeds FOR UPDATE
USING (
    user_id = current_setting('app.user_id')::uuid
    OR EXISTS (
        SELECT 1 FROM permission_grants pg
        WHERE pg.resource_type = 'feed'
          AND pg.resource_id = feeds.feed_id
          AND pg.grantee_id = current_setting('app.user_id')::uuid
          AND pg.permission_level IN ('edit', 'admin')
          AND pg.revoked_at IS NULL
    )
);

-- Policy: Only owners can delete
CREATE POLICY feeds_delete ON feeds FOR DELETE
USING (
    user_id = current_setting('app.user_id')::uuid
);
```

### 7.4 Frontend Permission Hook

```typescript
// hooks/usePermission.ts
import { useUser } from './useUser';

type Permission = 
  | 'feeds:create'
  | 'feeds:update_own'
  | 'alerts:create_own'
  | 'users:manage'
  // ... etc

const ROLE_PERMISSIONS: Record<string, Permission[]> = {
  viewer: ['records:read', 'feeds:read'],
  user: ['records:read', 'feeds:read', 'records:star', 'alerts:create_own'],
  power_user: ['feeds:create', 'feeds:update_own', 'api_keys:create_own'],
  admin: ['users:read', 'users:manage', 'settings:read'],
  super_admin: ['*:*'],
};

export function usePermission() {
  const { user } = useUser();
  
  const hasPermission = (permission: Permission): boolean => {
    if (!user) return false;
    if (user.role === 'super_admin') return true;
    
    // Check inherited permissions
    const roleHierarchy = ['viewer', 'user', 'power_user', 'admin'];
    const userRoleIndex = roleHierarchy.indexOf(user.role);
    
    for (let i = 0; i <= userRoleIndex; i++) {
      const role = roleHierarchy[i];
      if (ROLE_PERMISSIONS[role]?.includes(permission)) {
        return true;
      }
    }
    
    return false;
  };
  
  const canAccess = async (
    resourceType: string,
    resourceId: string,
    level: 'view' | 'edit' | 'admin' = 'view'
  ): Promise<boolean> => {
    // Call API to check resource-level permission
    const response = await fetch(
      `/api/permissions/check?resource=${resourceType}&id=${resourceId}&level=${level}`
    );
    return response.ok;
  };
  
  return { hasPermission, canAccess };
}

// Usage in component
function FeedActions({ feed }) {
  const { hasPermission, canAccess } = usePermission();
  const [canEdit, setCanEdit] = useState(false);
  
  useEffect(() => {
    canAccess('feed', feed.id, 'edit').then(setCanEdit);
  }, [feed.id]);
  
  return (
    <div>
      {canEdit && <Button onClick={handleEdit}>Edit</Button>}
      {hasPermission('feeds:delete_own') && canEdit && (
        <Button onClick={handleDelete}>Delete</Button>
      )}
    </div>
  );
}
```

---

## 8. API Endpoint Security

### 8.1 Endpoint Permission Matrix

| Endpoint | Method | Permission | Resource Check |
|----------|--------|------------|----------------|
| `/feeds` | GET | `feeds:read` | Filter by access |
| `/feeds` | POST | `feeds:create` | - |
| `/feeds/:id` | GET | `feeds:read` | ✅ view |
| `/feeds/:id` | PUT | `feeds:update_own` | ✅ edit |
| `/feeds/:id` | DELETE | `feeds:delete_own` | ✅ admin/owner |
| `/feeds/:id/share` | POST | `feeds:share` | ✅ admin/owner |
| `/users` | GET | `users:read` | - |
| `/users/:id` | PUT | `users:update` | - |
| `/settings` | GET | `settings:read` | - |
| `/settings` | PUT | `settings:update` | - |

### 8.2 Audit Logging

All permission checks are logged:

```python
async def log_access_attempt(
    user_id: UUID,
    resource_type: str,
    resource_id: UUID,
    action: str,
    granted: bool,
    reason: str
):
    await db.execute("""
        INSERT INTO security_audit 
        (user_id, event_type, event_category, severity, resource_type, resource_id, details)
        VALUES ($1, $2, 'access', $3, $4, $5, $6)
    """, 
        user_id,
        'permission_check',
        'info' if granted else 'warning',
        resource_type,
        resource_id,
        {'action': action, 'granted': granted, 'reason': reason}
    )
```

---

## Summary

The Capture Spine permission system provides:

1. **Role-Based Access** - Global permissions based on user role
2. **Ownership** - Full control over own resources
3. **Sharing** - Flexible sharing with users, teams, or public
4. **Team Permissions** - Organizational access control
5. **Resource-Level** - Fine-grained access checks
6. **Audit Trail** - Complete logging of access attempts

This model balances simplicity (roles) with flexibility (sharing) while maintaining security (audit, RLS).
