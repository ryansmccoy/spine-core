# Capture Spine Security Manifesto

> Our commitment to security-first development and data protection.

**Version:** 1.0  
**Last Updated:** January 27, 2026  
**Status:** Living Document

---

## Table of Contents

1. [Core Security Principles](#1-core-security-principles)
2. [Authentication](#2-authentication)
3. [Authorization & Permissions](#3-authorization--permissions)
4. [Data Protection](#4-data-protection)
5. [Session Management](#5-session-management)
6. [API Security](#6-api-security)
7. [Input Validation](#7-input-validation)
8. [Audit & Logging](#8-audit--logging)
9. [Multi-User Security](#9-multi-user-security)
10. [Infrastructure Security](#10-infrastructure-security)
11. [Incident Response](#11-incident-response)
12. [Compliance Checklist](#12-compliance-checklist)

---

## 1. Core Security Principles

### 1.1 Defense in Depth
- Never rely on a single security control
- Layer multiple security measures at each level
- Assume any single layer can be bypassed

### 1.2 Principle of Least Privilege
- Users get minimum permissions needed for their role
- Services run with minimum required access
- API keys are scoped to specific operations
- Database connections use role-specific credentials

### 1.3 Secure by Default
- All features disabled until explicitly enabled
- Conservative default settings
- Require explicit opt-in for risky operations
- New users start with minimal permissions

### 1.4 Zero Trust Architecture
- Verify every request, every time
- Never trust internal or external networks implicitly
- Authenticate and authorize all API calls
- Validate all data regardless of source

### 1.5 Transparency & Auditability
- Log all security-relevant events
- Users can see their security posture
- Admins can audit any user's activity
- No hidden backdoors or admin overrides

---

## 2. Authentication

### 2.1 Password Requirements

```yaml
password_policy:
  minimum_length: 12
  maximum_length: 128
  require_uppercase: true
  require_lowercase: true
  require_digit: true
  require_special: false  # Encourages longer passphrases
  prevent_common_passwords: true
  prevent_user_info_in_password: true
  history_count: 5  # Cannot reuse last 5 passwords
  max_age_days: 0  # No forced rotation (NIST 800-63B)
```

### 2.2 Password Storage
- **Algorithm:** bcrypt with cost factor ≥ 12
- **Alternative:** Argon2id (preferred for new implementations)
- **NEVER:** Store plaintext, MD5, SHA1, unsalted hashes
- Hash on server side only (client sends over TLS)

```python
# Correct: bcrypt with proper cost
import bcrypt
password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(rounds=12))

# Correct: Argon2id (preferred)
from argon2 import PasswordHasher
ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4)
password_hash = ph.hash(password)
```

### 2.3 Multi-Factor Authentication (MFA)

| Method | Security Level | When Required |
|--------|---------------|---------------|
| TOTP (Authenticator App) | High | Admin accounts, API access |
| Email OTP | Medium | Fallback, low-sensitivity actions |
| SMS OTP | Low | Emergency recovery only |
| Hardware Key (WebAuthn) | Highest | Optional, encouraged |

**MFA Policies:**
- Mandatory for admin role users
- Mandatory for API key generation
- Required after password reset
- Required for sensitive operations (delete account, export data)

### 2.4 Account Lockout

```yaml
lockout_policy:
  failed_attempts_before_lockout: 5
  lockout_duration_minutes: 15
  reset_counter_after_minutes: 60
  permanent_lockout_after_attempts: 20
  notify_user_on_lockout: true
  notify_admin_on_suspicious: true
```

### 2.5 Password Reset

**Secure Reset Flow:**
1. User requests reset → Generate cryptographically random token
2. Store hashed token (not plaintext) with expiry (1 hour max)
3. Send one-way link via email (HTTPS only)
4. Token is single-use, invalidate after use or expiry
5. Invalidate all active sessions after reset
6. Notify user of password change via email

**NEVER:**
- Send password via email
- Allow reset via "security questions" alone
- Keep reset tokens valid indefinitely
- Send token in URL query string in emails (use path parameter)

---

## 3. Authorization & Permissions

### 3.1 Role-Based Access Control (RBAC)

```yaml
roles:
  viewer:
    description: Read-only access
    permissions:
      - records:read
      - feeds:read
      - profile:read
      
  user:
    description: Standard user
    inherits: viewer
    permissions:
      - records:star
      - records:read_state
      - alerts:manage_own
      - profile:update
      - messages:send
      
  power_user:
    description: Advanced user
    inherits: user
    permissions:
      - feeds:create
      - feeds:update_own
      - groups:manage
      - api_keys:create_own
      
  admin:
    description: Full administrative access
    inherits: power_user
    permissions:
      - users:manage
      - feeds:manage_all
      - settings:manage
      - audit:read
      - system:manage
      
  super_admin:
    description: System owner
    inherits: admin
    permissions:
      - roles:manage
      - security:override
      - data:export_all
      - system:destroy
```

### 3.2 Permission Checks

**ALWAYS check permissions at:**
1. API route/endpoint level (first line of defense)
2. Service/business logic level (authoritative check)
3. Database level (row-level security where possible)

```python
# API endpoint
@router.delete("/feeds/{feed_id}")
@require_permission("feeds:delete")  # Decorator check
async def delete_feed(feed_id: UUID, current_user: User):
    feed = await feed_service.get(feed_id)
    
    # Service level check
    if feed.user_id != current_user.user_id and not current_user.has_permission("feeds:manage_all"):
        raise HTTPException(403, "Cannot delete another user's feed")
    
    await feed_service.delete(feed_id)
```

### 3.3 Resource Ownership

- Every user-created resource has a `user_id` owner
- Owners have full control over their resources
- Sharing creates explicit permission grants
- Admins can access but ownership remains

### 3.4 Permission Grants (Sharing)

```sql
CREATE TABLE permission_grants (
    grant_id UUID PRIMARY KEY,
    resource_type TEXT NOT NULL,  -- 'feed', 'group', 'article'
    resource_id UUID NOT NULL,
    grantor_user_id UUID REFERENCES users(user_id),
    grantee_user_id UUID REFERENCES users(user_id),
    permission_level TEXT NOT NULL,  -- 'view', 'edit', 'admin'
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(resource_type, resource_id, grantee_user_id)
);
```

---

## 4. Data Protection

### 4.1 Data Classification

| Classification | Examples | Protection |
|---------------|----------|------------|
| **Public** | Feed titles, article summaries | No encryption needed |
| **Internal** | User preferences, read states | Encrypted at rest |
| **Confidential** | User emails, session data | Encrypted, access logged |
| **Restricted** | Passwords, MFA secrets, API keys | Encrypted, hashed, strict access |

### 4.2 Encryption Standards

**At Rest:**
- Database: AES-256 encryption (PostgreSQL pgcrypto or disk-level)
- Backups: Encrypted before transfer
- Secrets: Stored in dedicated secrets manager (not in code or env vars)

**In Transit:**
- TLS 1.3 minimum (TLS 1.2 with strong ciphers acceptable)
- HTTPS everywhere (no HTTP endpoints)
- Certificate pinning for mobile apps

**Sensitive Fields:**
```python
# Fields requiring additional encryption
ENCRYPTED_FIELDS = [
    'users.password_hash',      # Hashed, not encrypted
    'user_mfa.totp_secret',     # AES-256 encrypted
    'api_keys.key_hash',        # Hashed, not encrypted
    'sessions.refresh_token_hash',  # Hashed
]
```

### 4.3 Data Retention

```yaml
retention_policy:
  sessions:
    active: "30 days"
    revoked: "90 days"
    
  audit_logs:
    security_events: "2 years"
    access_logs: "90 days"
    
  user_data:
    on_deletion: "30 days grace, then purge"
    backups: "90 days"
    
  records:
    default: "forever"
    user_configurable: true
```

### 4.4 Data Deletion (GDPR/CCPA)

**User Data Export:**
- Machine-readable format (JSON)
- Includes all user-created content
- Available within 30 days of request

**Account Deletion:**
- Soft delete with 30-day recovery window
- Hard delete removes all personal data
- Anonymize activity logs (keep events, remove user reference)
- Remove from backups within 90 days

---

## 5. Session Management

### 5.1 Token Architecture

```yaml
tokens:
  access_token:
    type: JWT
    lifetime: 15 minutes
    storage: Memory only (never localStorage)
    refresh: Silent background refresh
    
  refresh_token:
    type: Opaque random string
    lifetime: 30 days
    storage: HttpOnly, Secure cookie
    rotation: On every use
    
  mfa_token:
    type: Short-lived JWT
    lifetime: 5 minutes
    purpose: Bridge between password and MFA verification
```

### 5.2 Session Security

**Cookie Settings:**
```python
SESSION_COOKIE_CONFIG = {
    'httponly': True,      # JavaScript cannot access
    'secure': True,        # HTTPS only
    'samesite': 'Lax',     # CSRF protection
    'domain': '.example.com',  # Scope to domain
    'path': '/',
    'max_age': 30 * 24 * 60 * 60,  # 30 days
}
```

**Session Tracking:**
- Store device fingerprint, IP, user agent
- Alert user on new device login
- Allow users to view/revoke sessions
- Auto-expire inactive sessions (7 days)

### 5.3 Session Invalidation

Invalidate all sessions when:
- Password changed
- MFA enabled/disabled
- Account locked
- User requests "sign out everywhere"
- Suspicious activity detected

---

## 6. API Security

### 6.1 API Key Management

```yaml
api_key_policy:
  format: "csp_live_[32 random bytes hex]"  # Prefix for easy identification
  storage: Hash only (SHA-256)
  scopes:
    - read:feeds
    - write:feeds
    - read:records
    - admin:users
  expiration:
    default: 1 year
    maximum: 2 years
    never_expire: admin_only
  rate_limits:
    default: 100/minute
    burst: 200/minute
    configurable: true
```

### 6.2 Rate Limiting

```yaml
rate_limits:
  anonymous:
    limit: 10/minute
    
  authenticated:
    limit: 100/minute
    
  api_key:
    limit: 1000/minute
    
  endpoints:
    /auth/login:
      limit: 5/minute
      window: 15 minutes
      
    /auth/password-reset:
      limit: 3/hour
      
    /api/feeds:
      limit: 50/minute
```

### 6.3 CORS Policy

```python
CORS_CONFIG = {
    'allow_origins': [
        'https://app.capturespin.com',
        'https://localhost:3000',  # Dev only
    ],
    'allow_methods': ['GET', 'POST', 'PUT', 'DELETE'],
    'allow_headers': ['Authorization', 'Content-Type'],
    'allow_credentials': True,
    'max_age': 86400,  # Cache preflight for 24 hours
}
```

### 6.4 Request Validation

- Validate Content-Type header
- Enforce maximum request body size (10MB)
- Validate all path parameters and query strings
- Reject unexpected fields in JSON bodies
- Sanitize file uploads (type, size, content scanning)

---

## 7. Input Validation

### 7.1 Validation Rules

**ALWAYS validate:**
- Type (string, number, UUID, etc.)
- Length (min, max)
- Format (email, URL, date)
- Range (numeric bounds)
- Allowed values (enums)
- Business rules

```python
from pydantic import BaseModel, Field, validator
from typing import Optional
import re

class CreateFeedRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    url: str = Field(..., max_length=2000)
    feed_type: str = Field(..., pattern="^(rss|api|index)$")
    poll_interval: int = Field(3600, ge=60, le=86400)
    
    @validator('url')
    def validate_url(cls, v):
        if not v.startswith(('http://', 'https://')):
            raise ValueError('URL must start with http:// or https://')
        return v
    
    @validator('name')
    def sanitize_name(cls, v):
        # Remove any potential XSS
        return re.sub(r'[<>"\']', '', v)
```

### 7.2 SQL Injection Prevention

**ALWAYS use parameterized queries:**
```python
# CORRECT: Parameterized query
cursor.execute(
    "SELECT * FROM users WHERE email = %s",
    (user_email,)
)

# NEVER: String concatenation
cursor.execute(f"SELECT * FROM users WHERE email = '{user_email}'")  # VULNERABLE!
```

### 7.3 XSS Prevention

**Output Encoding:**
- HTML encode user content in HTML context
- JavaScript encode in JS context
- URL encode in URL context
- Use framework auto-escaping (React JSX)

**Content Security Policy:**
```
Content-Security-Policy: 
  default-src 'self';
  script-src 'self';
  style-src 'self' 'unsafe-inline';
  img-src 'self' data: https:;
  font-src 'self';
  connect-src 'self' https://api.capturespin.com;
  frame-ancestors 'none';
```

---

## 8. Audit & Logging

### 8.1 Security Events to Log

| Event | Severity | Data Logged |
|-------|----------|-------------|
| Login success | Info | User ID, IP, device |
| Login failure | Warning | Email, IP, reason |
| Password change | Warning | User ID, IP |
| MFA enabled/disabled | Warning | User ID, method |
| Permission denied | Warning | User ID, resource, action |
| Session revoked | Info | User ID, session ID, reason |
| API key created | Info | User ID, key prefix, scopes |
| Admin action | Warning | Admin ID, target, action |
| Data export | Warning | User ID, data types |
| Account locked | Critical | User ID, reason |
| Suspicious activity | Critical | User ID, IP, details |

### 8.2 Log Format

```json
{
  "timestamp": "2026-01-27T10:30:00Z",
  "event_type": "auth.login_failed",
  "severity": "warning",
  "user_id": null,
  "email": "attempted@example.com",
  "ip_address": "192.168.1.100",
  "user_agent": "Mozilla/5.0...",
  "details": {
    "reason": "invalid_password",
    "attempt_count": 3
  },
  "request_id": "req_abc123"
}
```

### 8.3 Log Protection

- Logs are append-only
- No sensitive data in logs (passwords, tokens)
- Mask PII where possible (email → j***@example.com)
- Centralized log aggregation
- Tamper detection on critical logs
- Retention policy enforced

---

## 9. Multi-User Security

### 9.1 Tenant Isolation

Even in single-tenant deployment, enforce:
- User A cannot see User B's feeds (unless shared)
- User A cannot modify User B's resources
- User A's API key cannot access User B's data
- Admin access is audited

### 9.2 Sharing Security

```sql
-- Sharing creates explicit, auditable permission
CREATE TABLE shares (
    share_id UUID PRIMARY KEY,
    resource_type TEXT NOT NULL,
    resource_id UUID NOT NULL,
    owner_user_id UUID NOT NULL,
    shared_with_user_id UUID NOT NULL,
    permission TEXT NOT NULL,  -- 'view', 'edit', 'admin'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

-- Indexes for fast permission checks
CREATE INDEX idx_shares_resource ON shares(resource_type, resource_id);
CREATE INDEX idx_shares_grantee ON shares(shared_with_user_id);
```

### 9.3 Team/Organization Security

```yaml
organization_security:
  membership:
    - Explicit invitation required
    - Admin approval for join requests
    - Owner can remove members
    
  permissions:
    - Org-level roles (owner, admin, member, guest)
    - Resource-level overrides
    - Inheritance from org to resources
    
  data:
    - Org resources isolated from personal
    - Member departure: transfer or delete resources
    - Org deletion: 30-day grace period
```

---

## 10. Infrastructure Security

### 10.1 Server Hardening

- Minimal OS installation
- Regular security updates
- Firewall: allow only necessary ports
- Disable root SSH login
- SSH key authentication only
- No unnecessary services running

### 10.2 Database Security

```sql
-- Use role-based access
CREATE ROLE app_reader WITH LOGIN PASSWORD 'xxx';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO app_reader;

CREATE ROLE app_writer WITH LOGIN PASSWORD 'xxx';
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_writer;

-- Row-level security
ALTER TABLE feeds ENABLE ROW LEVEL SECURITY;

CREATE POLICY feeds_user_isolation ON feeds
    USING (user_id = current_setting('app.current_user_id')::uuid 
           OR is_shared = true);
```

### 10.3 Secrets Management

**DO NOT store secrets in:**
- Source code
- Environment variables (for production)
- Configuration files

**DO store secrets in:**
- Dedicated secrets manager (HashiCorp Vault, AWS Secrets Manager)
- Kubernetes Secrets (encrypted at rest)
- Encrypted environment-specific config

---

## 11. Incident Response

### 11.1 Incident Classification

| Severity | Example | Response Time |
|----------|---------|---------------|
| P1 Critical | Active breach, data exfiltration | < 1 hour |
| P2 High | Vulnerability exploited, service down | < 4 hours |
| P3 Medium | Suspicious activity, failed attacks | < 24 hours |
| P4 Low | Policy violation, minor issue | < 72 hours |

### 11.2 Response Procedure

1. **Detect:** Monitoring, alerting, user reports
2. **Contain:** Isolate affected systems, revoke compromised credentials
3. **Eradicate:** Remove threat, patch vulnerability
4. **Recover:** Restore services, verify integrity
5. **Learn:** Post-mortem, update procedures

### 11.3 Breach Notification

- Notify affected users within 72 hours
- Report to authorities as required (GDPR)
- Public disclosure if widespread impact
- Provide remediation steps to users

---

## 12. Compliance Checklist

### Pre-Launch Security Review

- [ ] All passwords hashed with bcrypt/Argon2
- [ ] MFA available for all users
- [ ] Session tokens properly secured
- [ ] HTTPS enforced everywhere
- [ ] CORS properly configured
- [ ] Rate limiting in place
- [ ] Input validation on all endpoints
- [ ] SQL injection tested
- [ ] XSS tested
- [ ] CSRF protection enabled
- [ ] Security headers set
- [ ] Error messages don't leak info
- [ ] Audit logging enabled
- [ ] Log aggregation configured
- [ ] Backup encryption verified
- [ ] Penetration test scheduled

### Ongoing Security Tasks

- [ ] Weekly: Review failed login reports
- [ ] Weekly: Check for new vulnerabilities in dependencies
- [ ] Monthly: Review access permissions
- [ ] Monthly: Test backup restoration
- [ ] Quarterly: Security audit
- [ ] Annually: Penetration test
- [ ] Annually: Security training for team

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-01-27 | System | Initial security manifesto |

---

*This document is a living commitment. Every team member is responsible for security.*
