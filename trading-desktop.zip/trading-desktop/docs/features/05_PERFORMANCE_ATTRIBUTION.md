# Performance Attribution (Brinson Model)

## Overview
Portfolio performance attribution using the Brinson-Fachler model to decompose returns into allocation effect, selection effect, and interaction effect. Based on Bloomberg PORT attribution and institutional portfolio analytics systems.

![Reference: Bloomberg PORT Attribution View]

---

## UI Components

### 1. Attribution Summary Header
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Performance Attribution  [MEGA CAP ▼]   Benchmark: [R2000G ▼]                                         │
├─────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Period: [MTD ▼]  From: 2025-07-01  To: 2025-08-14   Currency: [USD ▼]                                 │
├────────────────────────────────────────────────────────────────────────────────────────────────┬────────┤
│ Portfolio Return     │ Benchmark Return    │ Excess Return    │ Tracking Error    │ Information Ratio │
│      +5.42%          │      +3.18%         │     +2.24%       │     4.56%         │      0.49         │
└──────────────────────┴─────────────────────┴──────────────────┴───────────────────┴───────────────────┘
```

### 2. Attribution Effects Summary
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Attribution Effects (Brinson-Fachler)                                                                  │
├──────────────────────┬──────────────────────┬──────────────────────┬──────────────────────────────────┤
│   Allocation Effect  │   Selection Effect   │  Interaction Effect  │      Total Active Return        │
│       +0.87%         │       +1.12%         │       +0.25%         │           +2.24%                │
│       ████████       │     ███████████      │       ███            │      ██████████████████         │
└──────────────────────┴──────────────────────┴──────────────────────┴──────────────────────────────────┘
```

### 3. Sector Attribution Grid
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Sector Attribution                                                                                                        │
├───────────────┬─────────┬─────────┬─────────┬──────────┬──────────┬──────────┬──────────┬──────────┬─────────────────────┤
│ Sector        │Port Wgt │Bench Wgt│Active Wgt│Port Ret │Bench Ret │Alloc Eff │Select Eff│Inter Eff │Total Contrib        │
├───────────────┼─────────┼─────────┼─────────┼──────────┼──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│ Technology    │  47.1%  │  32.5%  │ +14.6%  │  +8.23%  │  +5.12%  │  +0.42%  │  +1.47%  │  +0.45%  │ +2.34% ████████████ │
│ Consumer Disc │  13.5%  │  15.2%  │  -1.7%  │  +2.45%  │  +3.89%  │  +0.03%  │  -0.22%  │  +0.02%  │ -0.17% █            │
│ Financials    │   8.1%  │  12.8%  │  -4.7%  │  +4.56%  │  +2.34%  │  -0.11%  │  +0.28%  │  -0.10%  │ +0.07% █            │
│ Healthcare    │   7.2%  │  14.5%  │  -7.3%  │  +1.23%  │  +4.67%  │  +0.24%  │  -0.50%  │  +0.25%  │ -0.01%              │
│ Industrials   │   5.4%  │   8.9%  │  -3.5%  │  +3.45%  │  +2.12%  │  -0.05%  │  +0.12%  │  -0.05%  │ +0.02% █            │
│ Energy        │   4.2%  │   5.6%  │  -1.4%  │  -2.34%  │  -1.56%  │  +0.02%  │  -0.03%  │  +0.01%  │  0.00%              │
│ Materials     │   3.8%  │   4.2%  │  -0.4%  │  +1.89%  │  +2.45%  │  +0.01%  │  -0.02%  │  +0.00%  │ -0.01%              │
│ Utilities     │   2.1%  │   3.8%  │  -1.7%  │  +0.45%  │  +1.23%  │  +0.01%  │  -0.03%  │  +0.01%  │ -0.01%              │
│ Real Estate   │   1.8%  │   2.5%  │  -0.7%  │  -1.23%  │  -0.89%  │  +0.01%  │  -0.01%  │  +0.00%  │  0.00%              │
│ Comm Services │   6.8%  │   0.0%  │  +6.8%  │  +6.78%  │   N/A    │  +0.29%  │   N/A    │   N/A    │ +0.01% █            │
├───────────────┼─────────┼─────────┼─────────┼──────────┼──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│ TOTAL         │ 100.0%  │ 100.0%  │   0.0%  │  +5.42%  │  +3.18%  │  +0.87%  │  +1.12%  │  +0.25%  │ +2.24%              │
└───────────────┴─────────┴─────────┴─────────┴──────────┴──────────┴──────────┴──────────┴──────────┴─────────────────────┘
```

### 4. Attribution Waterfall Chart
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Attribution Waterfall                                                                                        │
├───────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                              │
│  +6.0% │                                                                           ┌─────┐                   │
│        │                                                           ┌─────┐         │     │                   │
│  +5.0% │                                           ┌─────┐         │     │         │ 5.42│ Portfolio         │
│        │                           ┌─────┐         │     │         │     │         │     │ Return            │
│  +4.0% │               ┌─────┐     │     │         │     │         │     │         │     │                   │
│        │   ┌─────┐     │     │     │ 4.30│         │ 4.55│         │     │         │     │                   │
│  +3.0% │   │     │     │     │     │     │         │     │         │     │         │     │                   │
│        │   │ 3.18│     │ 4.05│     │     │         │     │         │     │         │     │                   │
│  +2.0% │   │     │     │     │     │     │         │     │         │     │         │     │                   │
│        │   │     │     │     │     │     │         │     │         │     │         │     │                   │
│  +1.0% │   │     │     │     │     │     │         │     │         │     │         │     │                   │
│        │   │Bench│     │Alloc│     │Sel  │         │Inter│         │     │         │     │                   │
│   0.0% │───┴─────┴─────┴─────┴─────┴─────┴─────────┴─────┴─────────┴─────┴─────────┴─────┴───                │
│        │  Benchmark  Allocation  Selection  Interaction  Portfolio                                           │
│        │   Return      +0.87%     +1.12%      +0.25%      Return                                             │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Security-Level Attribution
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Top Security Contributors                                                                                   │
├────────┬─────────┬─────────┬─────────┬──────────┬──────────┬───────────────────────────────────────────────┤
│Security│Port Wgt │Bench Wgt│Port Ret │Bench Ret │Contrib   │ Visual                                        │
├────────┼─────────┼─────────┼─────────┼──────────┼──────────┼───────────────────────────────────────────────┤
│ NVDA   │  12.5%  │   4.2%  │ +15.6%  │  +5.1%   │ +0.89%   │ ████████████████████████████████████████████ │
│ META   │   6.9%  │   2.1%  │ +12.3%  │  +5.1%   │ +0.42%   │ ████████████████████                         │
│ AAPL   │  10.2%  │   8.5%  │  +6.8%  │  +5.1%   │ +0.18%   │ █████████                                    │
│ MSFT   │   9.9%  │   7.2%  │  +5.2%  │  +5.1%   │ +0.01%   │ █                                            │
│ GOOGL  │   7.5%  │   4.5%  │  +4.1%  │  +5.1%   │ -0.08%   │ ████                                         │
│ AMZN   │   8.1%  │   6.8%  │  +2.5%  │  +3.9%   │ -0.11%   │ █████                                        │
│ TSLA   │   5.3%  │   2.1%  │  -4.2%  │  +3.9%   │ -0.43%   │ █████████████████████                        │
└────────┴─────────┴─────────┴─────────┴──────────┴──────────┴───────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/AttributionPage.tsx

interface AttributionPageProps {
  portfolioId: string;
}

<AttributionPage>
  <AttributionHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <PeriodSelector />
    <CurrencySelector />
  </AttributionHeader>
  
  <AttributionSummaryBar 
    portfolioReturn={data.portfolioReturn}
    benchmarkReturn={data.benchmarkReturn}
    excessReturn={data.excessReturn}
    trackingError={data.trackingError}
    informationRatio={data.informationRatio}
  />
  
  <EffectsSummary
    allocationEffect={data.allocationEffect}
    selectionEffect={data.selectionEffect}
    interactionEffect={data.interactionEffect}
    totalActive={data.excessReturn}
  />
  
  <Tabs>
    <Tab label="Sector Attribution">
      <SectorAttributionGrid sectors={data.sectorAttribution} />
    </Tab>
    <Tab label="Waterfall">
      <AttributionWaterfall data={data} />
    </Tab>
    <Tab label="Security Attribution">
      <SecurityAttributionGrid securities={data.securityAttribution} />
    </Tab>
    <Tab label="Time Series">
      <CumulativeAttributionChart data={data.timeSeries} />
    </Tab>
  </Tabs>
</AttributionPage>
```

### Attribution Data Types
```typescript
interface BrinsonAttribution {
  portfolioId: string;
  benchmarkId: string;
  periodStart: Date;
  periodEnd: Date;
  
  // Returns
  portfolioReturn: number;
  benchmarkReturn: number;
  excessReturn: number;
  
  // Attribution Effects
  allocationEffect: number;
  selectionEffect: number;
  interactionEffect: number;
  
  // Risk Metrics
  trackingError: number;
  informationRatio: number;
  
  // Sector Breakdown
  sectorAttribution: SectorAttribution[];
  
  // Security Breakdown
  securityAttribution: SecurityAttribution[];
}

interface SectorAttribution {
  sector: string;
  
  // Weights
  portfolioWeight: number;
  benchmarkWeight: number;
  activeWeight: number;
  
  // Returns
  portfolioReturn: number;
  benchmarkReturn: number;
  
  // Effects
  allocationEffect: number;
  selectionEffect: number;
  interactionEffect: number;
  totalContribution: number;
}

interface SecurityAttribution {
  symbol: string;
  name: string;
  sector: string;
  
  portfolioWeight: number;
  benchmarkWeight: number;
  activeWeight: number;
  
  portfolioReturn: number;
  benchmarkReturn: number | null;  // null if not in benchmark
  
  contribution: number;
}
```

### Brinson Attribution Calculator
```typescript
/**
 * Calculate Brinson-Fachler attribution effects
 * 
 * Allocation Effect = (wp - wb) × (Rb - RB)
 * Selection Effect = wb × (Rp - Rb)
 * Interaction Effect = (wp - wb) × (Rp - Rb)
 * 
 * Where:
 * wp = Portfolio weight for sector
 * wb = Benchmark weight for sector
 * Rp = Portfolio return for sector
 * Rb = Benchmark return for sector
 * RB = Total benchmark return
 */
function calculateBrinsonAttribution(
  sectorData: {
    sector: string;
    portfolioWeight: number;
    benchmarkWeight: number;
    portfolioReturn: number;
    benchmarkReturn: number;
  }[],
  totalBenchmarkReturn: number
): SectorAttribution[] {
  return sectorData.map(s => {
    const activeWeight = s.portfolioWeight - s.benchmarkWeight;
    const sectorExcess = s.portfolioReturn - s.benchmarkReturn;
    const benchmarkExcess = s.benchmarkReturn - totalBenchmarkReturn;
    
    // Brinson-Fachler decomposition
    const allocationEffect = activeWeight * benchmarkExcess;
    const selectionEffect = s.benchmarkWeight * sectorExcess;
    const interactionEffect = activeWeight * sectorExcess;
    
    return {
      sector: s.sector,
      portfolioWeight: s.portfolioWeight,
      benchmarkWeight: s.benchmarkWeight,
      activeWeight,
      portfolioReturn: s.portfolioReturn,
      benchmarkReturn: s.benchmarkReturn,
      allocationEffect,
      selectionEffect,
      interactionEffect,
      totalContribution: allocationEffect + selectionEffect + interactionEffect,
    };
  });
}
```

### Attribution Waterfall Chart
```typescript
function AttributionWaterfall({ data }: { data: BrinsonAttribution }) {
  const waterfallData = [
    {
      name: 'Benchmark Return',
      value: data.benchmarkReturn,
      fill: '#6b7280',
      isSubtotal: false,
    },
    {
      name: 'Allocation',
      value: data.allocationEffect,
      fill: data.allocationEffect >= 0 ? '#22c55e' : '#ef4444',
      isSubtotal: false,
    },
    {
      name: 'Selection',
      value: data.selectionEffect,
      fill: data.selectionEffect >= 0 ? '#22c55e' : '#ef4444',
      isSubtotal: false,
    },
    {
      name: 'Interaction',
      value: data.interactionEffect,
      fill: data.interactionEffect >= 0 ? '#22c55e' : '#ef4444',
      isSubtotal: false,
    },
    {
      name: 'Portfolio Return',
      value: data.portfolioReturn,
      fill: '#3b82f6',
      isSubtotal: true,
    },
  ];
  
  // Calculate cumulative values for waterfall positioning
  let cumulative = 0;
  const processedData = waterfallData.map(item => {
    if (item.isSubtotal) {
      return { ...item, start: 0, end: item.value };
    }
    const start = cumulative;
    cumulative += item.value;
    return { ...item, start, end: cumulative };
  });
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={processedData}>
        <XAxis dataKey="name" stroke="#9ca3af" />
        <YAxis 
          tickFormatter={(v) => `${(v * 100).toFixed(1)}%`}
          stroke="#9ca3af"
        />
        <Tooltip 
          formatter={(value: number) => `${(value * 100).toFixed(2)}%`}
        />
        <Bar dataKey="value" fill="#8884d8">
          {processedData.map((entry, index) => (
            <Cell 
              key={index} 
              fill={entry.fill}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
```

### Sector Attribution Grid
```typescript
const sectorColumns: ColumnDef<SectorAttribution>[] = [
  { header: 'Sector', accessorKey: 'sector' },
  {
    header: 'Port Wgt',
    accessorKey: 'portfolioWeight',
    cell: ({ row }) => formatPercent(row.original.portfolioWeight),
  },
  {
    header: 'Bench Wgt',
    accessorKey: 'benchmarkWeight',
    cell: ({ row }) => formatPercent(row.original.benchmarkWeight),
  },
  {
    header: 'Active Wgt',
    accessorKey: 'activeWeight',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.activeWeight >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {row.original.activeWeight >= 0 ? '+' : ''}
        {formatPercent(row.original.activeWeight)}
      </span>
    ),
  },
  {
    header: 'Port Ret',
    accessorKey: 'portfolioReturn',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.portfolioReturn >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {formatPercent(row.original.portfolioReturn, { showSign: true })}
      </span>
    ),
  },
  {
    header: 'Bench Ret',
    accessorKey: 'benchmarkReturn',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.benchmarkReturn >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {formatPercent(row.original.benchmarkReturn, { showSign: true })}
      </span>
    ),
  },
  {
    header: 'Alloc',
    accessorKey: 'allocationEffect',
    cell: ({ row }) => <EffectCell value={row.original.allocationEffect} />,
  },
  {
    header: 'Select',
    accessorKey: 'selectionEffect',
    cell: ({ row }) => <EffectCell value={row.original.selectionEffect} />,
  },
  {
    header: 'Inter',
    accessorKey: 'interactionEffect',
    cell: ({ row }) => <EffectCell value={row.original.interactionEffect} />,
  },
  {
    header: 'Total',
    accessorKey: 'totalContribution',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <span className={clsx(
          'font-mono w-16',
          row.original.totalContribution >= 0 ? 'text-green-400' : 'text-red-400'
        )}>
          {formatPercent(row.original.totalContribution, { showSign: true })}
        </span>
        <ContributionBar value={row.original.totalContribution} maxValue={0.03} />
      </div>
    ),
  },
];

function EffectCell({ value }: { value: number }) {
  return (
    <span className={clsx(
      'font-mono text-xs',
      value >= 0 ? 'text-green-400' : 'text-red-400'
    )}>
      {value >= 0 ? '+' : ''}{formatPercent(value)}
    </span>
  );
}

function ContributionBar({ value, maxValue }: { value: number; maxValue: number }) {
  const width = Math.min(Math.abs(value) / maxValue * 100, 100);
  return (
    <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
      <div 
        className={clsx(
          'h-full rounded-full',
          value >= 0 ? 'bg-green-500' : 'bg-red-500'
        )}
        style={{ width: `${width}%` }}
      />
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/attribution")

@router.get("/{portfolio_id}")
async def get_attribution(
    portfolio_id: str,
    benchmark_id: str,
    period: Literal['MTD', 'QTD', 'YTD', '1Y', 'Custom'] = 'MTD',
    start_date: date | None = None,
    end_date: date | None = None,
    level: Literal['sector', 'industry', 'security'] = 'sector'
) -> BrinsonAttributionResponse:
    """Calculate Brinson attribution for portfolio."""
    pass

@router.get("/{portfolio_id}/time-series")
async def get_attribution_time_series(
    portfolio_id: str,
    benchmark_id: str,
    period: str = 'MTD',
    frequency: Literal['daily', 'weekly', 'monthly'] = 'daily'
) -> list[AttributionTimePoint]:
    """Get cumulative attribution over time."""
    pass

@router.get("/{portfolio_id}/securities")
async def get_security_attribution(
    portfolio_id: str,
    benchmark_id: str,
    period: str = 'MTD',
    top_n: int = 20
) -> list[SecurityAttribution]:
    """Get security-level attribution."""
    pass
```

### Pydantic Models
```python
class SectorAttribution(BaseModel):
    sector: str
    
    portfolio_weight: Decimal
    benchmark_weight: Decimal
    active_weight: Decimal
    
    portfolio_return: Decimal
    benchmark_return: Decimal
    
    allocation_effect: Decimal
    selection_effect: Decimal
    interaction_effect: Decimal
    total_contribution: Decimal

class BrinsonAttributionResponse(BaseModel):
    portfolio_id: str
    benchmark_id: str
    period_start: date
    period_end: date
    
    portfolio_return: Decimal
    benchmark_return: Decimal
    excess_return: Decimal
    
    allocation_effect: Decimal
    selection_effect: Decimal
    interaction_effect: Decimal
    
    tracking_error: Decimal | None
    information_ratio: Decimal | None
    
    sector_attribution: list[SectorAttribution]

class AttributionTimePoint(BaseModel):
    date: date
    
    cumulative_portfolio_return: Decimal
    cumulative_benchmark_return: Decimal
    cumulative_excess_return: Decimal
    
    cumulative_allocation: Decimal
    cumulative_selection: Decimal
    cumulative_interaction: Decimal
```

### Attribution Service
```python
from decimal import Decimal
from collections import defaultdict

class BrinsonAttributionService:
    async def calculate_attribution(
        self,
        portfolio_id: str,
        benchmark_id: str,
        start_date: date,
        end_date: date
    ) -> BrinsonAttributionResponse:
        """
        Calculate Brinson-Fachler attribution.
        
        Formulas:
        - Allocation Effect = (Wp - Wb) × (Rb - RB)
        - Selection Effect = Wb × (Rp - Rb)
        - Interaction Effect = (Wp - Wb) × (Rp - Rb)
        
        Where:
        - Wp = Portfolio weight for sector
        - Wb = Benchmark weight for sector  
        - Rp = Portfolio return for sector
        - Rb = Benchmark return for sector
        - RB = Total benchmark return
        """
        
        # Get portfolio and benchmark constituents
        portfolio_holdings = await self._get_holdings(portfolio_id, start_date, end_date)
        benchmark_holdings = await self._get_benchmark_constituents(benchmark_id, start_date, end_date)
        
        # Aggregate by sector
        portfolio_sectors = self._aggregate_by_sector(portfolio_holdings)
        benchmark_sectors = self._aggregate_by_sector(benchmark_holdings)
        
        # Calculate total returns
        total_portfolio_return = sum(s['weight'] * s['return'] for s in portfolio_sectors.values())
        total_benchmark_return = sum(s['weight'] * s['return'] for s in benchmark_sectors.values())
        
        # Calculate attribution for each sector
        all_sectors = set(portfolio_sectors.keys()) | set(benchmark_sectors.keys())
        
        sector_attribution = []
        total_allocation = Decimal(0)
        total_selection = Decimal(0)
        total_interaction = Decimal(0)
        
        for sector in all_sectors:
            port = portfolio_sectors.get(sector, {'weight': Decimal(0), 'return': Decimal(0)})
            bench = benchmark_sectors.get(sector, {'weight': Decimal(0), 'return': Decimal(0)})
            
            wp = port['weight']
            wb = bench['weight']
            rp = port['return']
            rb = bench['return']
            
            active_weight = wp - wb
            sector_excess = rp - rb
            benchmark_excess = rb - total_benchmark_return
            
            # Brinson-Fachler decomposition
            allocation = active_weight * benchmark_excess
            selection = wb * sector_excess
            interaction = active_weight * sector_excess
            
            total_allocation += allocation
            total_selection += selection
            total_interaction += interaction
            
            sector_attribution.append(SectorAttribution(
                sector=sector,
                portfolio_weight=wp,
                benchmark_weight=wb,
                active_weight=active_weight,
                portfolio_return=rp,
                benchmark_return=rb,
                allocation_effect=allocation,
                selection_effect=selection,
                interaction_effect=interaction,
                total_contribution=allocation + selection + interaction
            ))
        
        # Sort by total contribution
        sector_attribution.sort(key=lambda x: x.total_contribution, reverse=True)
        
        return BrinsonAttributionResponse(
            portfolio_id=portfolio_id,
            benchmark_id=benchmark_id,
            period_start=start_date,
            period_end=end_date,
            portfolio_return=total_portfolio_return,
            benchmark_return=total_benchmark_return,
            excess_return=total_portfolio_return - total_benchmark_return,
            allocation_effect=total_allocation,
            selection_effect=total_selection,
            interaction_effect=total_interaction,
            sector_attribution=sector_attribution
        )
    
    def _aggregate_by_sector(
        self, 
        holdings: list[dict]
    ) -> dict[str, dict]:
        """Aggregate holdings by sector."""
        sectors = defaultdict(lambda: {'weight': Decimal(0), 'return': Decimal(0), 'holdings': []})
        
        for h in holdings:
            sector = h['sector'] or 'Unclassified'
            sectors[sector]['holdings'].append(h)
            sectors[sector]['weight'] += h['weight']
        
        # Calculate sector returns as weighted average of holdings
        for sector, data in sectors.items():
            if data['weight'] > 0:
                sector_return = sum(
                    h['weight'] / data['weight'] * h['return'] 
                    for h in data['holdings']
                )
                data['return'] = sector_return
        
        return dict(sectors)
```

---

## SQL Schema

```sql
-- Pre-calculated attribution results (for performance)
CREATE TABLE attribution_results (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    calculation_level VARCHAR(20) NOT NULL,  -- 'sector', 'industry', 'security'
    
    -- Total returns
    portfolio_return DECIMAL(12,8),
    benchmark_return DECIMAL(12,8),
    excess_return DECIMAL(12,8),
    
    -- Attribution effects
    allocation_effect DECIMAL(12,8),
    selection_effect DECIMAL(12,8),
    interaction_effect DECIMAL(12,8),
    
    -- Risk metrics
    tracking_error DECIMAL(12,8),
    information_ratio DECIMAL(12,8),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, benchmark_id, period_start, period_end, calculation_level),
    INDEX idx_attribution_portfolio (portfolio_id, period_end DESC)
);

-- Sector-level attribution breakdown
CREATE TABLE attribution_sector (
    id BIGSERIAL PRIMARY KEY,
    attribution_id BIGINT NOT NULL REFERENCES attribution_results(id),
    sector VARCHAR(50) NOT NULL,
    
    portfolio_weight DECIMAL(10,8),
    benchmark_weight DECIMAL(10,8),
    active_weight DECIMAL(10,8),
    
    portfolio_return DECIMAL(12,8),
    benchmark_return DECIMAL(12,8),
    
    allocation_effect DECIMAL(12,8),
    selection_effect DECIMAL(12,8),
    interaction_effect DECIMAL(12,8),
    total_contribution DECIMAL(12,8),
    
    INDEX idx_sector_attribution (attribution_id)
);

-- Security-level attribution
CREATE TABLE attribution_security (
    id BIGSERIAL PRIMARY KEY,
    attribution_id BIGINT NOT NULL REFERENCES attribution_results(id),
    security_id UUID NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    sector VARCHAR(50),
    
    portfolio_weight DECIMAL(10,8),
    benchmark_weight DECIMAL(10,8),
    active_weight DECIMAL(10,8),
    
    portfolio_return DECIMAL(12,8),
    benchmark_return DECIMAL(12,8),
    
    contribution DECIMAL(12,8),
    
    INDEX idx_security_attribution (attribution_id)
);

-- Daily attribution time series
CREATE TABLE attribution_daily (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    
    -- Daily values
    portfolio_return DECIMAL(12,8),
    benchmark_return DECIMAL(12,8),
    
    allocation_effect DECIMAL(12,8),
    selection_effect DECIMAL(12,8),
    interaction_effect DECIMAL(12,8),
    
    -- Cumulative values (from period start)
    cumulative_portfolio DECIMAL(12,8),
    cumulative_benchmark DECIMAL(12,8),
    cumulative_allocation DECIMAL(12,8),
    cumulative_selection DECIMAL(12,8),
    cumulative_interaction DECIMAL(12,8),
    
    UNIQUE (portfolio_id, benchmark_id, as_of_date),
    INDEX idx_attribution_daily (portfolio_id, benchmark_id, as_of_date DESC)
);

-- Benchmark constituents
CREATE TABLE benchmark_constituents (
    id BIGSERIAL PRIMARY KEY,
    benchmark_id UUID NOT NULL,
    effective_date DATE NOT NULL,
    security_id UUID NOT NULL,
    weight DECIMAL(10,8) NOT NULL,
    sector VARCHAR(50),
    
    UNIQUE (benchmark_id, effective_date, security_id),
    INDEX idx_benchmark_date (benchmark_id, effective_date)
);
```

---

## Key Calculations

### 1. Brinson-Fachler Model
```
Total Active Return = Σ (Allocation + Selection + Interaction) for all sectors

Allocation Effect = (Wp - Wb) × (Rb - RB)
  - Measures value added from sector over/underweights
  - Positive when overweight sectors that outperformed benchmark

Selection Effect = Wb × (Rp - Rb)
  - Measures value added from security selection within sectors
  - Positive when portfolio securities outperform sector benchmark

Interaction Effect = (Wp - Wb) × (Rp - Rb)
  - Measures combined effect of allocation and selection
  - Positive when overweight sectors with good selection
```

### 2. Information Ratio
```
Information Ratio = (Portfolio Return - Benchmark Return) / Tracking Error

Tracking Error = StdDev(Portfolio Returns - Benchmark Returns) × √252
```

### 3. Security Contribution
```
Security Contribution = Weight × (Security Return - Benchmark Return)
```
