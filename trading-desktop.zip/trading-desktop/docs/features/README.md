# Bloomberg-Style Trading Terminal Feature Documentation

## Overview
This directory contains comprehensive documentation for implementing Bloomberg-style portfolio analytics and trading features in the capture-spine-basic application.

## Feature Documents

### Trading & Execution
| Document | Description | Bloomberg Equivalent |
|----------|-------------|---------------------|
| [01_TRADEBOOK_STRATEGY_ANALYZER.md](01_TRADEBOOK_STRATEGY_ANALYZER.md) | Algorithmic execution monitoring, predictive analytics, VWAP tracking | EMSX Tradebook |
| [02_LOW_TOUCH_OMS.md](02_LOW_TOUCH_OMS.md) | Order management system, routing rules, benchmark tracking | Horizon Trader |
| [03_BASKET_TRADING.md](03_BASKET_TRADING.md) | Multi-order basket execution, sector P&L aggregation | Program Trading |

### Portfolio Analytics
| Document | Description | Bloomberg Equivalent |
|----------|-------------|---------------------|
| [04_PORT_HOLDINGS.md](04_PORT_HOLDINGS.md) | Holdings view, contribution to return, intraday performance | PORT Holdings |
| [05_PERFORMANCE_ATTRIBUTION.md](05_PERFORMANCE_ATTRIBUTION.md) | Brinson-Fachler sector/security attribution | PORT Attribution |
| [06_FACTOR_ATTRIBUTION.md](06_FACTOR_ATTRIBUTION.md) | Multi-factor return decomposition, factor exposures | PORT Factor |
| [07_RISK_ANALYTICS.md](07_RISK_ANALYTICS.md) | VaR, stress testing, risk decomposition | PORT Risk / Barra |

---

## Architecture Overview

### Frontend Stack
```
React 19 + TypeScript + Vite + Tailwind CSS
├── Components
│   ├── Grids (TanStack Table)
│   ├── Charts (Recharts)
│   └── Real-time updates (WebSocket)
├── State Management
│   ├── React Query for server state
│   └── Zustand for UI state
└── API Layer
    ├── Type-safe API client
    └── WebSocket subscriptions
```

### Backend Stack (Python FastAPI)
```
FastAPI + SQLAlchemy + PostgreSQL
├── REST API Endpoints
├── WebSocket Streams
├── Pydantic Models
└── Background Tasks
    ├── Risk calculations
    ├── Attribution calculations
    └── Real-time price updates
```

### Data Flow
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Frontend   │────▶│  FastAPI    │────▶│  PostgreSQL │
│  (React)    │◀────│  Backend    │◀────│  Database   │
└─────────────┘     └─────────────┘     └─────────────┘
      │                    │                    │
      │                    ▼                    │
      │            ┌─────────────┐              │
      └───────────▶│  WebSocket  │◀─────────────┘
                   │   Stream    │
                   └─────────────┘
```

---

## Common Patterns

### 1. Bloomberg Color Scheme
```typescript
const colors = {
  background: '#1a1a2e',      // Dark navy
  surface: '#252536',         // Slightly lighter
  surfaceHover: '#2d2d43',    // Hover state
  border: '#3d3d5c',          // Borders
  
  // Text
  textPrimary: '#ffffff',     // White
  textSecondary: '#9ca3af',   // Gray
  textMuted: '#6b7280',       // Darker gray
  
  // Accent
  positive: '#22c55e',        // Green
  negative: '#ef4444',        // Red
  accent: '#3b82f6',          // Blue
  warning: '#f59e0b',         // Orange
};
```

### 2. Grid Styling
```typescript
const gridClasses = {
  header: 'bg-[#252536] text-gray-400 text-xs uppercase tracking-wider',
  row: 'hover:bg-[#2d2d43] border-b border-gray-800',
  cell: 'px-2 py-1 text-sm',
  cellNumeric: 'text-right font-mono',
};
```

### 3. P&L Display
```typescript
function PnLCell({ value, format = 'currency' }: Props) {
  const formatted = format === 'currency' 
    ? formatCurrency(value) 
    : formatPercent(value);
    
  return (
    <span className={clsx(
      'font-mono',
      value >= 0 ? 'text-green-400' : 'text-red-400'
    )}>
      {value >= 0 ? '+' : ''}{formatted}
    </span>
  );
}
```

### 4. Real-time Updates
```typescript
function useRealtimeData<T>(
  endpoint: string,
  initialData: T,
  transform?: (data: any) => T
) {
  const [data, setData] = useState<T>(initialData);
  
  useEffect(() => {
    const ws = new WebSocket(`/ws/${endpoint}`);
    
    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      setData(prev => transform ? transform(update) : { ...prev, ...update });
    };
    
    return () => ws.close();
  }, [endpoint]);
  
  return data;
}
```

---

## Database Schema Summary

### Core Tables
| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `portfolios` | Portfolio definitions | portfolio_id, name, benchmark_id |
| `portfolio_positions` | Current holdings | portfolio_id, security_id, quantity |
| `securities` | Security master | security_id, symbol, name, sector |
| `orders` | Order management | order_id, symbol, side, quantity, status |
| `executions` | Trade executions | execution_id, order_id, price, quantity |

### Analytics Tables
| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `position_snapshots` | Historical positions | portfolio_id, date, market_value |
| `portfolio_returns` | Return time series | portfolio_id, date, daily_return |
| `attribution_results` | Attribution cache | portfolio_id, period, allocation_effect |
| `portfolio_risk` | Risk metrics | portfolio_id, date, var_95, tracking_error |

### Risk Model Tables
| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `risk_factors` | Factor definitions | model_id, factor_id, category |
| `factor_returns` | Factor return series | factor_id, date, daily_return |
| `security_factor_exposures` | Factor exposures | security_id, factor_id, exposure |

---

## API Endpoint Summary

### Trading APIs
```
POST   /api/v1/orders                  Create order
GET    /api/v1/orders/{order_id}       Get order details
PATCH  /api/v1/orders/{order_id}       Modify order
DELETE /api/v1/orders/{order_id}       Cancel order
GET    /api/v1/orders/{order_id}/executions  Get executions

POST   /api/v1/baskets                 Create basket
POST   /api/v1/baskets/{id}/route      Route basket orders
```

### Portfolio APIs
```
GET    /api/v1/portfolio/{id}/holdings     Get holdings
GET    /api/v1/portfolio/{id}/summary      Get summary
GET    /api/v1/portfolio/{id}/intraday     Get intraday performance
GET    /api/v1/portfolio/{id}/contributors  Get top contributors
```

### Analytics APIs
```
GET    /api/v1/attribution/{id}            Brinson attribution
GET    /api/v1/factor-attribution/{id}     Factor attribution
GET    /api/v1/risk/{id}/summary           Risk metrics
GET    /api/v1/risk/{id}/stress-tests      Stress test results
GET    /api/v1/risk/{id}/decomposition     Risk breakdown
```

### WebSocket Streams
```
/ws/portfolio/{id}/stream      Real-time portfolio updates
/ws/orders/stream              Order status updates
/ws/prices/stream              Price updates
```

---

## Getting Started

1. **Read the API schemas**: Start with `src/api/schemas/trading.ts` for type definitions
2. **Review mock API**: See `src/api/mockTradingApi.ts` for data generation patterns
3. **Pick a feature**: Choose a feature document and implement following the patterns
4. **Build incrementally**: Start with basic grid, add real-time updates, then charts

---

## Key Libraries

| Library | Purpose | Documentation |
|---------|---------|---------------|
| `@tanstack/react-table` | Data grids | https://tanstack.com/table |
| `recharts` | Charts | https://recharts.org |
| `@tanstack/react-query` | Server state | https://tanstack.com/query |
| `zustand` | Client state | https://github.com/pmndrs/zustand |
| `clsx` | Class names | https://github.com/lukeed/clsx |
| `date-fns` | Date formatting | https://date-fns.org |
