# Basket Trading & Multi-Order Management

## Overview
Program trading interface for managing baskets of orders with aggregate P&L tracking, sector allocation, and bulk order routing. Based on portfolio/basket trading systems.

![Reference: Basket Trading Interface]

---

## UI Components

### 1. Basket Header Bar
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ Source: [Current Book ▼]    Book: [T0B2NAIVE        ]          [Feedback]      │
├─────────────────────────────────────────────────────────────────────────────────┤
│ Basket Parent: [Active ▼]   Sector: [None ▼]                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Basket Summary Grid
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│    │Route │ID  │% Filled│Leaves│% Route│Notional│Total P&L│Real P&L│Unreal P&L│Real bps│Benchmark│P/L Notification│
├────┼──────┼────┼────────┼──────┼───────┼────────┼─────────┼────────┼──────────┼────────┼─────────┼────────────────┤
│ ▸ TEST ABC_2│   │100.0% │ 0   │ 2,943│ -      │ 100,042.01│32.17 PD│Close 34,420.04│-52,450.26│ 3     │              │
│   BUY     25│TEST ABC│1.61│100.0%│  -  │  0.41│  5,267.39│ -30.50│  5,997.39│ -8.74 Close│ 34,335.05│  7.66 7,603  │
│   SELL    25│TEST ABC│1.78│100.0%│  -  │ 11.21│-205,955.9│-1,210.00│-194,745.95│-34.39 PD │Close 350,595│ -40.28 -64│
└────┴──────┴────┴────────┴──────┴───────┴────────┴─────────┴────────┴──────────┴────────┴─────────┴────────────────┘
```

**Key Columns:**
- Side indicator (BUY/SELL with color)
- Route status
- Security identifier
- Fill percentage
- Leaves (remaining quantity)
- Route percentage
- Notional value
- Total P&L
- Realized P&L
- Unrealized P&L
- Slippage in basis points
- Benchmark reference
- Cumulative P&L vs arrival

### 3. Basket Detail (By Sector)
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Basket Detail  [Active ▼]      Sector: [None ▼]                                                              │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│    │Route │Security│Status│Account│% Filled│Leaves│% Route│Total P&L│Real P&L│Unreal P&L│Total bps│Real bps│Benchmark Val│
├────┼──────┼────────┼──────┼───────┼────────┼──────┼───────┼─────────┼────────┼──────────┼─────────┼────────┼─────────────┤
│ ⚪ Materials  │ 1│ DD   │ PART │ TOBIN │100.0% │ 0.01│ -     │ -90.00  │ -90.00 │   --     │ -13.23  │        │  68.0500    │
│ ⚪ Consumer D │ 7│ TOBIN│ PART │ TOBIN │100.0%│100.0%│-55,280.46│ -55,280.46│-74.05│   --     │         │  0.00       │
│ ⚪ BUY        │ 3│      │      │       │       │      │ 10,099.43│ -2,000.00│19.065│ 6.25     │         │ 292.7100    │
│              │  │ AMZN │ PART │ TOBIN │100.0%│100.0%│ -2,699.97│ -2,699.97│ -52.10│         │         │  51.7400    │
│              │  │ OMCSA│ PART │ TOBIN │100.0%│100.0%│ -5,650.00│ -5,650.01│ -351.81│         │         │  1.1200     │
│              │  │ FOXA │ PART │ TOBIN │100.0%│100.0%│-66,029.91│-66,029.91│-171.04│         │         │   --        │
│ ⚪ SELL       │  │      │      │       │       │      │-13,331.73│         │        │         │         │             │
└────┴──────┴────────┴──────┴───────┴────────┴──────┴─────────┴─────────┴────────┴─────────┴────────┴─────────────┘
```

### 4. Routed Orders Panel
```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ Routed Orders  [Selected Rsk ▼]  Basket Val: [None ▼]                                  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│    │           │Status  │Security│ Side │  Qty   │LMT Price│% Filled│Leaves│Account│Type│TIF│Destination│
├────┼───────────┼────────┼────────┼──────┼────────┼─────────┼────────┼──────┼───────┼────┼───┼───────────┤
│ ⚪ 2014050B_0│    7    │ROUTED  │      │       │ 24,750  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│ ⚪ BUY       │    7    │ROUTED  │ AMZN │  BUY  │  7,500  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│ ⚪ BUY       │         │ROUTED  │ AMZN │  BUY  │  7,500  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│              │         │ROUTED  │ FOXA │  BUY  │  1,500  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│              │         │ROUTED  │ FOXA │  BUY  │  1,500  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│              │         │ROUTED  │ OMCSA│  BUY  │    750  │  MKT   │       │      │TOBIN│DAY│ GSCO       │
│ ⚪ SELL      │         │ROUTED  │      │ SELL  │ 17,250  │  MKT   │       │      │TOBIN│DAY│ CITI       │
└────┴───────────┴────────┴────────┴──────┴────────┴─────────┴────────┴──────┴───────┴────┴───┴───────────┘
```

### 5. Activity Log
```
┌──────────────────────────────────────────────────────────────────────────────┐
│ Activity Log │ Help Desk │ Allocations                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│ [Timestamp entries showing order creation, routing, fills, etc.]            │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/BasketTradingPage.tsx

interface BasketTradingPageProps {
  basketId?: string;
}

<BasketTradingPage>
  <BasketHeader>
    <SourceSelector />
    <BookSelector />
    <SectorFilter />
  </BasketHeader>
  
  <BasketSummaryGrid basket={basket} />
  
  <Tabs>
    <Tab label="Basket Detail">
      <BasketDetailGrid orders={orders} groupBy="sector" />
    </Tab>
    <Tab label="Routed Orders">
      <RoutedOrdersGrid routes={routes} />
    </Tab>
    <Tab label="Activity Log">
      <ActivityLog basketId={basketId} />
    </Tab>
    <Tab label="Allocations">
      <AllocationPanel basketId={basketId} />
    </Tab>
  </Tabs>
</BasketTradingPage>
```

### Basket Summary Component
```typescript
interface BasketSummary {
  basketId: string;
  name: string;
  totalNotional: number;
  
  // Aggregates
  buyNotional: number;
  sellNotional: number;
  netNotional: number;
  
  // P&L
  totalPnL: number;
  realizedPnL: number;
  unrealizedPnL: number;
  
  // Execution metrics
  fillPercentage: number;
  leavesNotional: number;
  
  // Benchmark slippage
  arrivalSlippageBps: number;
  vwapSlippageBps: number;
  
  // Breakdown by side
  buySide: BasketSideSummary;
  sellSide: BasketSideSummary;
}

interface BasketSideSummary {
  orderCount: number;
  totalQuantity: number;
  filledQuantity: number;
  notional: number;
  realizedPnL: number;
  unrealizedPnL: number;
  avgSlippageBps: number;
}
```

### Sector Grouping
```typescript
function groupOrdersBySector(orders: BasketOrder[]): Map<string, BasketOrder[]> {
  return orders.reduce((groups, order) => {
    const sector = order.sector || 'Unclassified';
    const existing = groups.get(sector) || [];
    groups.set(sector, [...existing, order]);
    return groups;
  }, new Map<string, BasketOrder[]>());
}

function BasketDetailGrid({ orders, groupBy }: Props) {
  const grouped = useMemo(() => {
    switch (groupBy) {
      case 'sector':
        return groupOrdersBySector(orders);
      case 'side':
        return groupOrdersBySide(orders);
      default:
        return new Map([['All', orders]]);
    }
  }, [orders, groupBy]);
  
  return (
    <div className="space-y-2">
      {Array.from(grouped.entries()).map(([group, groupOrders]) => (
        <CollapsibleSection key={group} title={group} summary={calculateGroupSummary(groupOrders)}>
          <OrderTable orders={groupOrders} />
        </CollapsibleSection>
      ))}
    </div>
  );
}
```

### Real-time P&L Updates
```typescript
function useBasketPnL(basketId: string) {
  const [pnl, setPnL] = useState<BasketPnL | null>(null);
  
  useEffect(() => {
    const ws = new WebSocket(`/ws/baskets/${basketId}/pnl`);
    
    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      setPnL(prev => ({
        ...prev,
        ...update,
        // Flash logic
        realizedPnLChanged: update.realizedPnL !== prev?.realizedPnL,
        unrealizedPnLChanged: update.unrealizedPnL !== prev?.unrealizedPnL,
      }));
    };
    
    return () => ws.close();
  }, [basketId]);
  
  return pnl;
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter
from typing import Literal

router = APIRouter(prefix="/api/v1/baskets")

@router.get("/")
async def list_baskets(
    status: Literal['active', 'completed', 'cancelled'] | None = None,
    from_date: date | None = None
) -> list[BasketSummary]:
    """List all baskets."""
    pass

@router.post("/")
async def create_basket(basket: CreateBasketRequest) -> Basket:
    """Create a new basket from orders."""
    pass

@router.get("/{basket_id}")
async def get_basket(basket_id: str) -> BasketDetail:
    """Get basket with all orders and P&L."""
    pass

@router.get("/{basket_id}/orders")
async def get_basket_orders(
    basket_id: str,
    group_by: Literal['sector', 'side', 'none'] = 'none'
) -> list[BasketOrder]:
    """Get orders in basket."""
    pass

@router.post("/{basket_id}/orders")
async def add_orders_to_basket(
    basket_id: str,
    orders: list[str]  # order IDs
) -> Basket:
    """Add orders to basket."""
    pass

@router.post("/{basket_id}/route")
async def route_basket(
    basket_id: str,
    routing: BasketRoutingRequest
) -> list[RoutedOrder]:
    """Route basket orders to destination."""
    pass

@router.get("/{basket_id}/pnl")
async def get_basket_pnl(basket_id: str) -> BasketPnL:
    """Get current basket P&L."""
    pass

@router.websocket("/ws/{basket_id}/stream")
async def basket_stream(websocket: WebSocket, basket_id: str):
    """Real-time basket updates."""
    pass
```

### Pydantic Models
```python
class BasketOrder(BaseModel):
    order_id: str
    basket_id: str
    symbol: str
    side: Literal['BUY', 'SELL']
    quantity: int
    filled_quantity: int
    avg_fill_price: Decimal | None
    
    # Grouping
    sector: str | None
    industry: str | None
    
    # Routing
    route_status: str
    destination: str | None
    account: str
    
    # P&L
    notional: Decimal
    realized_pnl: Decimal
    unrealized_pnl: Decimal
    total_pnl: Decimal
    
    # Slippage
    benchmark_price: Decimal | None
    slippage_bps: Decimal | None

class BasketSummary(BaseModel):
    basket_id: str
    name: str
    created_at: datetime
    status: str
    
    order_count: int
    buy_count: int
    sell_count: int
    
    total_notional: Decimal
    net_notional: Decimal
    
    fill_percentage: Decimal
    leaves_notional: Decimal
    
    total_pnl: Decimal
    realized_pnl: Decimal
    unrealized_pnl: Decimal
    
    arrival_slippage_bps: Decimal
    vwap_slippage_bps: Decimal

class BasketPnL(BaseModel):
    basket_id: str
    timestamp: datetime
    
    # Aggregate P&L
    total_pnl: Decimal
    realized_pnl: Decimal
    unrealized_pnl: Decimal
    
    # By side
    buy_pnl: Decimal
    sell_pnl: Decimal
    
    # By sector
    sector_pnl: dict[str, Decimal]
    
    # Slippage
    total_slippage_bps: Decimal
    
    # Changes since last update
    pnl_change: Decimal
    slippage_change: Decimal

class BasketRoutingRequest(BaseModel):
    destination: str
    algo: str | None
    urgency: Literal['LOW', 'MEDIUM', 'HIGH'] | None
    
    # Which orders to route
    order_ids: list[str] | None  # None = all orders
    
    # Routing parameters
    split_by_account: bool = False
    max_notional_per_order: Decimal | None
```

### Basket Service
```python
class BasketService:
    async def calculate_basket_pnl(self, basket_id: str) -> BasketPnL:
        orders = await self.get_basket_orders(basket_id)
        
        total_pnl = Decimal(0)
        realized_pnl = Decimal(0)
        unrealized_pnl = Decimal(0)
        sector_pnl = defaultdict(Decimal)
        
        for order in orders:
            executions = await self.get_executions(order.order_id)
            current_price = await self.get_current_price(order.symbol)
            
            # Realized P&L from executed trades
            for exec in executions:
                cost = exec.quantity * exec.price
                market_value = exec.quantity * current_price
                
                if order.side == 'BUY':
                    realized = market_value - cost
                else:
                    realized = cost - market_value
                
                realized_pnl += realized
            
            # Unrealized P&L from remaining position
            remaining = order.quantity - order.filled_quantity
            if remaining > 0:
                arrival = order.arrival_price or order.limit_price
                if arrival:
                    if order.side == 'BUY':
                        unrealized = remaining * (current_price - arrival)
                    else:
                        unrealized = remaining * (arrival - current_price)
                    unrealized_pnl += unrealized
            
            sector_pnl[order.sector] += order.realized_pnl + order.unrealized_pnl
        
        return BasketPnL(
            basket_id=basket_id,
            timestamp=datetime.utcnow(),
            total_pnl=realized_pnl + unrealized_pnl,
            realized_pnl=realized_pnl,
            unrealized_pnl=unrealized_pnl,
            sector_pnl=dict(sector_pnl),
            ...
        )
```

---

## SQL Schema

```sql
-- Baskets
CREATE TABLE baskets (
    basket_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    
    status VARCHAR(20) DEFAULT 'ACTIVE',
    book VARCHAR(50),
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    
    created_by VARCHAR(50),
    portfolio_id UUID,
    
    INDEX idx_baskets_status (status),
    INDEX idx_baskets_created (created_at DESC)
);

-- Basket-Order relationship
CREATE TABLE basket_orders (
    id BIGSERIAL PRIMARY KEY,
    basket_id UUID NOT NULL REFERENCES baskets(basket_id),
    order_id UUID NOT NULL REFERENCES orders(order_id),
    
    -- Sequence/priority within basket
    sequence_number INTEGER,
    
    -- Grouping metadata
    sector VARCHAR(50),
    sub_sector VARCHAR(50),
    
    -- Weighting
    target_weight DECIMAL(8,6),
    current_weight DECIMAL(8,6),
    
    added_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (basket_id, order_id),
    INDEX idx_basket_orders_basket (basket_id),
    INDEX idx_basket_orders_order (order_id)
);

-- Basket snapshots (for historical P&L)
CREATE TABLE basket_snapshots (
    id BIGSERIAL PRIMARY KEY,
    basket_id UUID NOT NULL REFERENCES baskets(basket_id),
    snapshot_time TIMESTAMP NOT NULL DEFAULT NOW(),
    
    -- Aggregates at snapshot time
    order_count INTEGER,
    total_notional DECIMAL(18,4),
    net_notional DECIMAL(18,4),
    
    fill_percentage DECIMAL(8,6),
    leaves_notional DECIMAL(18,4),
    
    -- P&L at snapshot
    total_pnl DECIMAL(18,4),
    realized_pnl DECIMAL(18,4),
    unrealized_pnl DECIMAL(18,4),
    
    -- Slippage
    arrival_slippage_bps DECIMAL(10,4),
    vwap_slippage_bps DECIMAL(10,4),
    
    INDEX idx_basket_snapshots (basket_id, snapshot_time DESC)
);

-- Sector aggregates (materialized for performance)
CREATE TABLE basket_sector_summary (
    id BIGSERIAL PRIMARY KEY,
    basket_id UUID NOT NULL REFERENCES baskets(basket_id),
    sector VARCHAR(50) NOT NULL,
    
    order_count INTEGER,
    buy_notional DECIMAL(18,4),
    sell_notional DECIMAL(18,4),
    net_notional DECIMAL(18,4),
    
    realized_pnl DECIMAL(18,4),
    unrealized_pnl DECIMAL(18,4),
    
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (basket_id, sector),
    INDEX idx_basket_sector (basket_id)
);
```

---

## Key Features

### 1. Color-Coded P&L
```typescript
function PnLCell({ value, showSign = true }: { value: number; showSign?: boolean }) {
  const isPositive = value >= 0;
  const formatted = showSign 
    ? (isPositive ? '+' : '') + formatCurrency(value)
    : formatCurrency(Math.abs(value));
  
  return (
    <span className={clsx(
      'font-mono',
      isPositive ? 'text-green-400' : 'text-red-400'
    )}>
      {formatted}
    </span>
  );
}
```

### 2. Collapsible Sector Groups
```typescript
function SectorGroup({ sector, orders, summary }: Props) {
  const [isExpanded, setIsExpanded] = useState(true);
  
  return (
    <div className="border-b border-gray-700">
      <div 
        className="flex items-center gap-2 px-2 py-1 bg-[#252536] cursor-pointer hover:bg-[#2d2d43]"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <ChevronRight className={clsx('h-4 w-4 transition-transform', isExpanded && 'rotate-90')} />
        <span className="h-3 w-3 rounded-full bg-gray-500" />
        <span className="text-white font-medium">{sector}</span>
        <span className="text-gray-400 text-xs">{orders.length} orders</span>
        <div className="ml-auto flex items-center gap-4 text-xs">
          <span className="text-gray-400">Notional: {formatCurrency(summary.notional)}</span>
          <PnLCell value={summary.totalPnL} />
        </div>
      </div>
      {isExpanded && (
        <div className="bg-[#1a1a2e]">
          {orders.map(order => <OrderRow key={order.orderId} order={order} />)}
        </div>
      )}
    </div>
  );
}
```

### 3. Bulk Actions
```typescript
function BasketActions({ basketId, selectedOrders }: Props) {
  return (
    <div className="flex items-center gap-2">
      <button 
        onClick={() => routeOrders(basketId, selectedOrders, 'GSCO')}
        className="px-3 py-1 bg-blue-600 text-white text-xs rounded"
      >
        Route to GS
      </button>
      <button 
        onClick={() => routeOrders(basketId, selectedOrders, 'CITI')}
        className="px-3 py-1 bg-blue-600 text-white text-xs rounded"
      >
        Route to Citi
      </button>
      <button 
        onClick={() => cancelOrders(basketId, selectedOrders)}
        className="px-3 py-1 bg-red-600 text-white text-xs rounded"
      >
        Cancel Selected
      </button>
    </div>
  );
}
```
