# Portfolio Characteristics & Fundamentals

## Overview
Aggregate portfolio characteristics view showing fundamental metrics (P/E, dividend yield, beta, etc.) compared to benchmark, with sector-level breakdown. Based on Bloomberg PORT Characteristics tab.

![Reference: PORT Characteristics Tab]

---

## UI Components

### 1. Portfolio Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                            │
├────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │[Characteristics]│ VaR │ Tracking Error/Volatility │ Scenarios │ Performance │   │
├────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Main View │ Summary │ Cash Flows │ Liquidity Risk │ Key Rates                                         │
├────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [STRATEGIC GROWTH ▼]  vs [SPX ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18               │
└────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Characteristics Summary Grid
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ ○ Date  ○ Trend  ○ Risk Model                                          ▸ Combined                   │
├────────────────────────┬──────────┬──────────┬──────────┬────────────────────────────────────────────┤
│ Characteristic         │  Port    │  Bmk     │  +/-     │                                            │
├────────────────────────┼──────────┼──────────┼──────────┼────────────────────────────────────────────┤
│ Wgt                    │  100.00  │  100.00  │   0.00   │                                            │
│ Market Value           │ 37.92MM  │ 3.80MM   │ 37.92MM  │                                            │
│ Implied Volatility     │          │          │          │                                            │
│ Equity                 │          │          │          │                                            │
│ Dividend Yield         │   2.07   │   2.00   │   0.07   │                                            │
│ Price to Earnings R... │  19.50   │  21.42   │  -1.92   │ ◀─── Underweight expensive stocks          │
│ Price to Cash Flow     │  14.99   │  17.09   │  -3.01   │                                            │
│ Total Debt to Common   │ 201.21   │ 216.69   │ -15.48   │                                            │
│ Beta                   │   1.07   │   0.99   │   0.08   │                                            │
│ Current Ratio          │   1.36   │   1.25   │   0.11   │                                            │
└────────────────────────┴──────────┴──────────┴──────────┴────────────────────────────────────────────┘
```

### 3. Top 10 by Characteristic
```
┌────────────────────────────────────────────────────────────┐
│ Top 10            ▸ Price to Earnings Ra...                │
├─────────────────────────────────────┬──────────────────────┤
│ Instrument                          │ Value                │
├─────────────────────────────────────┼──────────────────────┤
│ CONDUENT INC                        │ 36.21                │
│ CALIFORNIA WATER SERVICE            │ 28.62                │
│ HOME DEPOT INC                      │ 27.90                │
│ MICROSOFT CORP                      │ 27.47                │
│ WATTS WATER TECHNOLOGIES            │ 27.28                │
│ DR PEPPER SNAPPLE GROUP             │ 27.15                │
│ WAL-MART STORES INC                 │ 24.34                │
│ PEPSICO INC                         │ 23.54                │
│ PROCTER & GAMBLE CO/THE             │ 21.59                │
│ AETNA INC                           │ 21.11                │
└─────────────────────────────────────┴──────────────────────┘
```

### 4. Sector Comparison Chart
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Price to Earnings Ratio (P/E) by Sector                                        [Portfolio] [Benchmark]│
├───────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                      │
│ Consumer Staples        ████████████████████████████████████  │ ████████████████████████████████████ │
│                                                                                                      │
│ Consumer Discretionary  ████████████████████████████████      │ ████████████████████████████████████ │
│                                                                                                      │
│ Health Care             ██████████████████████████████        │ ██████████████████████████████████   │
│                                                                                                      │
│ Industrials             ████████████████████████████          │ ██████████████████████████████████   │
│                                                                                                      │
│ Utilities               █████████████████████████             │ █████████████████████████            │
│                                                                                                      │
│ Energy                  ████████████████████                  │ ████████████████████                 │
│                                                                                                      │
│ Information Technology  █████████████████████████████████████ │ ██████████████████████████████████   │
│                                                                                                      │
│ Telecommunication Svc   ████████████████████████              │ █████████████████████████            │
│                                                                                                      │
│ Financials              ████████████████████████████████      │ ████████████████████████████████████ │
│                                                                                                      │
│ Materials               █████████████████████                 │ ████████████████████████             │
│                                                                                                      │
│ Real Estate             ███████████████████████████████       │ ██████████████████████████████       │
│                                                                                                      │
│ Not Classified          █████████████                         │                                      │
│                                                                                                      │
│                         0        5       10       15       20       25       30       35             │
└───────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/PortfolioCharacteristicsPage.tsx

<PortfolioCharacteristicsPage>
  <CharacteristicsHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <GroupBySelector options={['GICS Sectors', 'Industry', 'Country']} />
    <CurrencySelector />
    <DateSelector />
  </CharacteristicsHeader>
  
  <div className="grid grid-cols-2 gap-4">
    <CharacteristicsSummaryGrid 
      characteristics={data.characteristics}
      portfolio={portfolio}
      benchmark={benchmark}
    />
    <div>
      <SectorComparisonChart 
        data={data.sectorBreakdown}
        metric={selectedMetric}
      />
      <Top10List 
        holdings={data.topHoldings}
        metric={selectedMetric}
      />
    </div>
  </div>
</PortfolioCharacteristicsPage>
```

### Characteristics Types
```typescript
interface PortfolioCharacteristic {
  name: string;
  displayName: string;
  category: 'valuation' | 'profitability' | 'risk' | 'liquidity' | 'growth';
  
  portfolioValue: number | null;
  benchmarkValue: number | null;
  difference: number | null;
  
  format: 'number' | 'percent' | 'currency' | 'ratio';
  decimals: number;
}

interface CharacteristicsSummary {
  portfolioId: string;
  benchmarkId: string;
  asOfDate: Date;
  
  characteristics: PortfolioCharacteristic[];
  
  // Aggregated at security level for drill-down
  securityCharacteristics: SecurityCharacteristic[];
}

interface SecurityCharacteristic {
  symbol: string;
  name: string;
  sector: string;
  weight: number;
  
  // Individual metrics
  peRatio: number | null;
  pbRatio: number | null;
  dividendYield: number | null;
  beta: number | null;
  marketCap: number;
  
  // Additional fundamentals
  debtToEquity: number | null;
  currentRatio: number | null;
  roe: number | null;
  revenueGrowth: number | null;
}

interface SectorCharacteristic {
  sector: string;
  
  portfolioWeight: number;
  benchmarkWeight: number;
  
  portfolioValue: number;  // Weighted average for sector
  benchmarkValue: number;
}
```

### Characteristics Calculator
```typescript
/**
 * Calculate weighted average characteristic for portfolio
 */
function calculateWeightedCharacteristic(
  holdings: SecurityCharacteristic[],
  metric: keyof SecurityCharacteristic
): number | null {
  const validHoldings = holdings.filter(h => h[metric] !== null);
  
  if (validHoldings.length === 0) return null;
  
  const totalWeight = validHoldings.reduce((sum, h) => sum + h.weight, 0);
  
  const weightedSum = validHoldings.reduce((sum, h) => {
    return sum + (h.weight / totalWeight) * (h[metric] as number);
  }, 0);
  
  return weightedSum;
}

/**
 * Calculate characteristic by sector
 */
function calculateSectorCharacteristics(
  holdings: SecurityCharacteristic[],
  metric: keyof SecurityCharacteristic
): SectorCharacteristic[] {
  const sectors = new Map<string, SecurityCharacteristic[]>();
  
  holdings.forEach(h => {
    const existing = sectors.get(h.sector) || [];
    sectors.set(h.sector, [...existing, h]);
  });
  
  return Array.from(sectors.entries()).map(([sector, sectorHoldings]) => ({
    sector,
    portfolioWeight: sectorHoldings.reduce((sum, h) => sum + h.weight, 0),
    portfolioValue: calculateWeightedCharacteristic(sectorHoldings, metric) || 0,
    benchmarkWeight: 0,  // Filled from benchmark data
    benchmarkValue: 0,
  }));
}
```

### Sector Comparison Chart Component
```typescript
function SectorComparisonChart({ 
  data, 
  metric 
}: { 
  data: SectorCharacteristic[]; 
  metric: string;
}) {
  const sortedData = useMemo(() => 
    [...data].sort((a, b) => b.portfolioValue - a.portfolioValue),
    [data]
  );
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={sortedData} layout="vertical" margin={{ left: 150 }}>
        <XAxis type="number" stroke="#9ca3af" />
        <YAxis 
          type="category" 
          dataKey="sector" 
          stroke="#9ca3af"
          width={140}
        />
        <Tooltip 
          formatter={(value: number) => value.toFixed(2)}
          contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}
        />
        <Legend />
        <Bar 
          dataKey="portfolioValue" 
          fill="#f59e0b" 
          name="Portfolio"
          barSize={12}
        />
        <Bar 
          dataKey="benchmarkValue" 
          fill="#3b82f6" 
          name="Benchmark"
          barSize={12}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
```

### Characteristics Grid
```typescript
const characteristicsColumns: ColumnDef<PortfolioCharacteristic>[] = [
  {
    header: 'Characteristic',
    accessorKey: 'displayName',
    cell: ({ row }) => (
      <span className="text-white">{row.original.displayName}</span>
    ),
  },
  {
    header: 'Port',
    accessorKey: 'portfolioValue',
    cell: ({ row }) => (
      <span className="font-mono text-right">
        {formatCharacteristic(row.original.portfolioValue, row.original.format)}
      </span>
    ),
  },
  {
    header: 'Bmk',
    accessorKey: 'benchmarkValue',
    cell: ({ row }) => (
      <span className="font-mono text-right text-gray-400">
        {formatCharacteristic(row.original.benchmarkValue, row.original.format)}
      </span>
    ),
  },
  {
    header: '+/-',
    accessorKey: 'difference',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono text-right',
        row.original.difference && row.original.difference > 0 
          ? 'text-green-400' 
          : 'text-red-400'
      )}>
        {row.original.difference !== null 
          ? (row.original.difference > 0 ? '+' : '') + 
            formatCharacteristic(row.original.difference, row.original.format)
          : '-'
        }
      </span>
    ),
  },
];

function formatCharacteristic(value: number | null, format: string): string {
  if (value === null) return '-';
  
  switch (format) {
    case 'percent':
      return `${value.toFixed(2)}%`;
    case 'currency':
      return formatCurrency(value);
    case 'ratio':
    case 'number':
    default:
      return value.toFixed(2);
  }
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/characteristics")

@router.get("/{portfolio_id}")
async def get_portfolio_characteristics(
    portfolio_id: str,
    benchmark_id: str | None = None,
    as_of_date: date | None = None,
    group_by: Literal['sector', 'industry', 'country'] = 'sector'
) -> CharacteristicsResponse:
    """Get portfolio characteristics with benchmark comparison."""
    pass

@router.get("/{portfolio_id}/securities")
async def get_security_characteristics(
    portfolio_id: str,
    metric: str | None = None,
    sort_by: str = 'weight',
    sort_desc: bool = True,
    top_n: int | None = None
) -> list[SecurityCharacteristic]:
    """Get security-level characteristics."""
    pass

@router.get("/{portfolio_id}/sectors")
async def get_sector_characteristics(
    portfolio_id: str,
    benchmark_id: str | None = None,
    metric: str = 'pe_ratio'
) -> list[SectorCharacteristic]:
    """Get sector-level characteristic comparison."""
    pass

@router.get("/{portfolio_id}/trend")
async def get_characteristics_trend(
    portfolio_id: str,
    metric: str,
    start_date: date,
    end_date: date
) -> list[CharacteristicTimePoint]:
    """Get characteristic values over time."""
    pass
```

### Pydantic Models
```python
class PortfolioCharacteristic(BaseModel):
    name: str
    display_name: str
    category: str
    
    portfolio_value: Decimal | None
    benchmark_value: Decimal | None
    difference: Decimal | None
    
    format: str
    decimals: int = 2

class CharacteristicsResponse(BaseModel):
    portfolio_id: str
    benchmark_id: str | None
    as_of_date: date
    
    # Summary metrics
    characteristics: list[PortfolioCharacteristic]
    
    # Top/bottom holdings by selected metric
    top_holdings: list[SecurityCharacteristic]
    bottom_holdings: list[SecurityCharacteristic]

class SecurityCharacteristic(BaseModel):
    symbol: str
    name: str
    sector: str
    weight: Decimal
    
    pe_ratio: Decimal | None
    pb_ratio: Decimal | None
    ps_ratio: Decimal | None
    dividend_yield: Decimal | None
    beta: Decimal | None
    market_cap: Decimal
    
    debt_to_equity: Decimal | None
    current_ratio: Decimal | None
    roe: Decimal | None
    roa: Decimal | None
    revenue_growth: Decimal | None
    earnings_growth: Decimal | None

class SectorCharacteristic(BaseModel):
    sector: str
    
    portfolio_weight: Decimal
    benchmark_weight: Decimal | None
    
    portfolio_value: Decimal
    benchmark_value: Decimal | None
```

### Characteristics Service
```python
class CharacteristicsService:
    # Standard characteristics to calculate
    CHARACTERISTICS = [
        ('pe_ratio', 'Price to Earnings Ratio', 'valuation'),
        ('pb_ratio', 'Price to Book Ratio', 'valuation'),
        ('ps_ratio', 'Price to Sales Ratio', 'valuation'),
        ('dividend_yield', 'Dividend Yield', 'income'),
        ('beta', 'Beta', 'risk'),
        ('market_cap', 'Market Value', 'size'),
        ('debt_to_equity', 'Total Debt to Common', 'leverage'),
        ('current_ratio', 'Current Ratio', 'liquidity'),
        ('roe', 'Return on Equity', 'profitability'),
        ('revenue_growth', 'Revenue Growth (YoY)', 'growth'),
    ]
    
    async def get_portfolio_characteristics(
        self,
        portfolio_id: str,
        benchmark_id: str | None,
        as_of_date: date
    ) -> CharacteristicsResponse:
        """Calculate weighted average characteristics."""
        
        # Get portfolio holdings with fundamentals
        holdings = await self._get_holdings_with_fundamentals(portfolio_id, as_of_date)
        
        # Get benchmark constituents if provided
        benchmark_holdings = None
        if benchmark_id:
            benchmark_holdings = await self._get_benchmark_fundamentals(benchmark_id, as_of_date)
        
        characteristics = []
        
        for metric, display_name, category in self.CHARACTERISTICS:
            port_value = self._calculate_weighted_avg(holdings, metric)
            bench_value = self._calculate_weighted_avg(benchmark_holdings, metric) if benchmark_holdings else None
            
            difference = None
            if port_value is not None and bench_value is not None:
                difference = port_value - bench_value
            
            characteristics.append(PortfolioCharacteristic(
                name=metric,
                display_name=display_name,
                category=category,
                portfolio_value=port_value,
                benchmark_value=bench_value,
                difference=difference,
                format='percent' if metric == 'dividend_yield' else 'ratio'
            ))
        
        return CharacteristicsResponse(
            portfolio_id=portfolio_id,
            benchmark_id=benchmark_id,
            as_of_date=as_of_date,
            characteristics=characteristics,
            top_holdings=sorted(holdings, key=lambda h: h.pe_ratio or 0, reverse=True)[:10],
            bottom_holdings=sorted(holdings, key=lambda h: h.pe_ratio or float('inf'))[:10]
        )
    
    def _calculate_weighted_avg(
        self, 
        holdings: list[dict] | None, 
        metric: str
    ) -> Decimal | None:
        """Calculate weighted average of a metric."""
        if not holdings:
            return None
        
        valid = [(h['weight'], h[metric]) for h in holdings if h.get(metric) is not None]
        
        if not valid:
            return None
        
        total_weight = sum(w for w, _ in valid)
        if total_weight == 0:
            return None
        
        weighted_sum = sum(w * v for w, v in valid)
        return Decimal(str(weighted_sum / total_weight))
```

---

## SQL Schema

```sql
-- Security fundamentals (refreshed daily from data provider)
CREATE TABLE security_fundamentals (
    id BIGSERIAL PRIMARY KEY,
    security_id UUID NOT NULL REFERENCES securities(security_id),
    as_of_date DATE NOT NULL,
    
    -- Valuation
    pe_ratio DECIMAL(12,4),
    pe_ratio_forward DECIMAL(12,4),
    pb_ratio DECIMAL(12,4),
    ps_ratio DECIMAL(12,4),
    pcf_ratio DECIMAL(12,4),  -- Price to Cash Flow
    ev_ebitda DECIMAL(12,4),
    
    -- Income
    dividend_yield DECIMAL(8,4),
    dividend_payout_ratio DECIMAL(8,4),
    
    -- Risk
    beta DECIMAL(8,4),
    volatility_60d DECIMAL(8,4),
    volatility_252d DECIMAL(8,4),
    
    -- Size
    market_cap DECIMAL(18,2),
    enterprise_value DECIMAL(18,2),
    shares_outstanding DECIMAL(18,2),
    
    -- Leverage
    debt_to_equity DECIMAL(12,4),
    debt_to_assets DECIMAL(8,4),
    interest_coverage DECIMAL(12,4),
    
    -- Liquidity
    current_ratio DECIMAL(8,4),
    quick_ratio DECIMAL(8,4),
    
    -- Profitability
    roe DECIMAL(8,4),
    roa DECIMAL(8,4),
    roic DECIMAL(8,4),
    gross_margin DECIMAL(8,4),
    operating_margin DECIMAL(8,4),
    net_margin DECIMAL(8,4),
    
    -- Growth
    revenue_growth_yoy DECIMAL(8,4),
    earnings_growth_yoy DECIMAL(8,4),
    
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (security_id, as_of_date),
    INDEX idx_fundamentals_date (as_of_date),
    INDEX idx_fundamentals_security (security_id, as_of_date DESC)
);

-- Portfolio characteristics snapshots
CREATE TABLE portfolio_characteristics (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    
    -- Calculated weighted averages
    pe_ratio DECIMAL(12,4),
    pb_ratio DECIMAL(12,4),
    ps_ratio DECIMAL(12,4),
    dividend_yield DECIMAL(8,4),
    beta DECIMAL(8,4),
    market_cap_weighted DECIMAL(18,2),
    debt_to_equity DECIMAL(12,4),
    current_ratio DECIMAL(8,4),
    roe DECIMAL(8,4),
    revenue_growth DECIMAL(8,4),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, as_of_date),
    INDEX idx_port_char (portfolio_id, as_of_date DESC)
);

-- Sector-level characteristics
CREATE TABLE portfolio_sector_characteristics (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    sector VARCHAR(50) NOT NULL,
    
    holdings_count INTEGER,
    weight DECIMAL(10,8),
    
    pe_ratio DECIMAL(12,4),
    dividend_yield DECIMAL(8,4),
    beta DECIMAL(8,4),
    
    UNIQUE (portfolio_id, as_of_date, sector),
    INDEX idx_sector_char (portfolio_id, as_of_date)
);
```

---

## Key Metrics Reference

| Metric | Formula | Interpretation |
|--------|---------|----------------|
| **P/E Ratio** | Price / EPS | Higher = more expensive |
| **P/B Ratio** | Price / Book Value per Share | Higher = premium to assets |
| **Dividend Yield** | Annual Dividend / Price | Higher = more income |
| **Beta** | Cov(Ri, Rm) / Var(Rm) | >1 = more volatile than market |
| **Debt/Equity** | Total Debt / Shareholders' Equity | Higher = more leveraged |
| **Current Ratio** | Current Assets / Current Liabilities | >1 = can cover short-term debts |
| **ROE** | Net Income / Shareholders' Equity | Higher = more profitable |
