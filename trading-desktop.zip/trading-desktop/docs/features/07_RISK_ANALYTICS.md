# Risk Analytics & Management

## Overview
Comprehensive portfolio risk analytics including factor risk decomposition, VaR/CVaR calculations, stress testing, and scenario analysis. Based on Barra/MSCI risk models, Bloomberg PORT risk analytics, and institutional risk management systems.

![Reference: Risk Analytics Dashboard]

---

## UI Components

### 1. Risk Summary Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio Risk Analytics  [MEGA CAP ▼]   Model: [Barra USE4 ▼]   Benchmark: [R2000G ▼]                  │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ As of: 2025-08-14   Horizon: [1D ▼]  [5D] [10D] [21D]   Confidence: [95% ▼]  [99%]                       │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Key Risk Metrics Dashboard
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Risk Summary                                                                                               │
├──────────────────────┬──────────────────────┬──────────────────────┬──────────────────────┬────────────────┤
│    Total Risk        │    Active Risk       │    Tracking Error    │    VaR (95%)         │ Max Drawdown   │
│      18.5%           │      6.2%            │      4.8%            │     -2.1%            │    -8.3%       │
│   ████████████████   │   ██████████         │   ████████           │   ██████████         │  ████████████  │
│     Annualized       │   vs Benchmark       │    Annualized        │    1-Day             │   YTD          │
└──────────────────────┴──────────────────────┴──────────────────────┴──────────────────────┴────────────────┘
```

### 3. Risk Decomposition Table
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Risk Decomposition                                                                                                      │
├────────────────────┬──────────┬──────────┬──────────┬──────────┬──────────┬────────────────────────────────────────────┤
│ Component          │Total Risk│Active Risk│% of Total│% of Active│Marg Contr│ Distribution                              │
├────────────────────┼──────────┼──────────┼──────────┼──────────┼──────────┼────────────────────────────────────────────┤
│ Factor Risk        │  15.2%   │   5.1%   │   82.2%  │   82.3%  │          │                                            │
│ ├─ Market          │   8.5%   │   0.2%   │   45.9%  │    3.2%  │  +0.02%  │ ██████████████████████████████████████████ │
│ ├─ Style           │   6.2%   │   3.8%   │   33.5%  │   61.3%  │  +0.38%  │ ████████████████████████████████           │
│ │  ├─ Momentum     │   2.8%   │   2.1%   │   15.1%  │   33.9%  │  +0.21%  │ ██████████████████                         │
│ │  ├─ Growth       │   1.8%   │   0.9%   │    9.7%  │   14.5%  │  +0.09%  │ ████████████                               │
│ │  ├─ Value        │   1.2%   │   0.6%   │    6.5%  │    9.7%  │  +0.06%  │ ████████                                   │
│ │  └─ Volatility   │   0.4%   │   0.2%   │    2.2%  │    3.2%  │  +0.02%  │ ███                                        │
│ ├─ Industry        │   4.5%   │   1.1%   │   24.3%  │   17.7%  │  +0.11%  │ ██████████████████████████                 │
│ │  ├─ Technology   │   2.8%   │   0.8%   │   15.1%  │   12.9%  │  +0.08%  │ ██████████████████                         │
│ │  ├─ Financials   │   1.2%   │   0.2%   │    6.5%  │    3.2%  │  +0.02%  │ ████████                                   │
│ │  └─ Healthcare   │   0.5%   │   0.1%   │    2.7%  │    1.6%  │  +0.01%  │ ████                                       │
├────────────────────┼──────────┼──────────┼──────────┼──────────┼──────────┼────────────────────────────────────────────┤
│ Specific Risk      │   3.3%   │   1.1%   │   17.8%  │   17.7%  │  +0.11%  │ ████████████████████                       │
├────────────────────┼──────────┼──────────┼──────────┼──────────┼──────────┼────────────────────────────────────────────┤
│ TOTAL              │  18.5%   │   6.2%   │  100.0%  │  100.0%  │          │                                            │
└────────────────────┴──────────┴──────────┴──────────┴──────────┴──────────┴────────────────────────────────────────────┘
```

### 4. VaR Analysis
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Value at Risk (VaR) Analysis                                                                             │
├───────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                          │
│ VaR Distribution                                    │ VaR Summary                                        │
│                                                     │                                                    │
│        Expected: +0.05%                             │ Metric        │ 1-Day    │ 5-Day    │ 10-Day     │
│              ↓                                      ├───────────────┼──────────┼──────────┼────────────┤
│    ████████████████████████████████                 │ VaR (95%)     │  -2.1%   │  -4.7%   │  -6.6%     │
│  ████████████████████████████████████████           │ VaR (99%)     │  -3.0%   │  -6.7%   │  -9.5%     │
│ ██████████████████████████████████████████████      │ CVaR (95%)    │  -2.8%   │  -6.3%   │  -8.9%     │
│  ████████████████████████████████████████           │ CVaR (99%)    │  -3.8%   │  -8.5%   │ -12.0%     │
│    ████████████████████████████████                 ├───────────────┼──────────┼──────────┼────────────┤
│      ██████████████████████████                     │ $ at Risk     │          │          │            │
│        ████████████████████                         │ VaR (95%)     │ -$9.9M   │ -$22.1M  │ -$31.0M    │
│           ██████████████                            │ VaR (99%)     │ -$14.1M  │ -$31.5M  │ -$44.6M    │
│              ██████                                 │                                                    │
│ ←─────|──────────|──────────|─────→                │                                                    │
│    VaR(99%)   VaR(95%)   Expected                  │                                                    │
│    -3.0%     -2.1%      +0.05%                     │                                                    │
│                                                     │                                                    │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Stress Testing Grid
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Stress Test Scenarios                                                                                                 │
├──────────────────────────────┬───────────┬───────────┬───────────┬───────────────────────────────────────────────────┤
│ Scenario                     │Port Impact│Bench Impact│Active Imp│ P&L Distribution                                   │
├──────────────────────────────┼───────────┼───────────┼───────────┼───────────────────────────────────────────────────┤
│ 📉 2008 Financial Crisis     │   -38.2%  │   -42.5%  │   +4.3%   │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓           │
│ 📉 2020 COVID Crash          │   -28.5%  │   -31.2%  │   +2.7%   │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                      │
│ 📉 2022 Rate Shock           │   -18.3%  │   -15.8%  │   -2.5%   │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                                │
│ 📈 Tech Rally (+20%)         │   +24.5%  │   +15.2%  │   +9.3%   │ ██████████████████████████                        │
│ 📉 Tech Crash (-30%)         │   -35.2%  │   -22.8%  │  -12.4%   │ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓               │
│ 📈 Rates +100bps             │    -5.2%  │    -4.8%  │   -0.4%   │ ▓▓▓▓▓                                             │
│ 📉 Rates -100bps             │    +3.8%  │    +4.2%  │   -0.4%   │ ████                                              │
│ 📈 VIX Spike (+20pts)        │   -12.5%  │   -14.2%  │   +1.7%   │ ▓▓▓▓▓▓▓▓▓▓▓▓                                      │
│ 📉 USD +10%                  │    -2.1%  │    -1.8%  │   -0.3%   │ ▓▓                                                │
│ 🔄 Momentum Reversal         │    -8.5%  │    -3.2%  │   -5.3%   │ ▓▓▓▓▓▓▓▓                                          │
└──────────────────────────────┴───────────┴───────────┴───────────┴───────────────────────────────────────────────────┘
```

### 6. Top Risk Contributors
```
┌───────────────────────────────────────────────────────────────────────────────────────────────┐
│ Top Risk Contributors                                                                        │
├────────┬─────────┬───────────┬───────────┬───────────────────────────────────────────────────┤
│Security│ Weight  │Total Contr│Active Contr│ Risk Contribution                                │
├────────┼─────────┼───────────┼───────────┼───────────────────────────────────────────────────┤
│ NVDA   │  12.5%  │   3.2%    │   2.1%    │ ████████████████████████████████████████████████ │
│ TSLA   │   5.3%  │   2.8%    │   1.9%    │ ████████████████████████████████████████████     │
│ AAPL   │  10.2%  │   1.8%    │   0.4%    │ ████████████████████████                         │
│ META   │   6.9%  │   1.5%    │   0.9%    │ ████████████████████                             │
│ MSFT   │   9.9%  │   1.4%    │   0.3%    │ ███████████████████                              │
│ AMZN   │   8.1%  │   1.2%    │   0.5%    │ ████████████████                                 │
│ GOOGL  │   7.5%  │   1.1%    │   0.4%    │ ███████████████                                  │
│ JPM    │   4.2%  │   0.8%    │   0.2%    │ ███████████                                      │
│ V      │   3.9%  │   0.6%    │   0.1%    │ ████████                                         │
│ UNH    │   3.5%  │   0.5%    │   0.1%    │ ███████                                          │
├────────┼─────────┼───────────┼───────────┼───────────────────────────────────────────────────┤
│ Top 10 │  72.0%  │  14.9%    │   6.9%    │                                                  │
│ Other  │  28.0%  │   3.6%    │  -0.7%    │                                                  │
└────────┴─────────┴───────────┴───────────┴───────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/RiskAnalyticsPage.tsx

<RiskAnalyticsPage>
  <RiskHeader>
    <PortfolioSelector />
    <RiskModelSelector />
    <BenchmarkSelector />
    <HorizonSelector horizons={['1D', '5D', '10D', '21D']} />
    <ConfidenceSelector levels={['95%', '99%']} />
  </RiskHeader>
  
  <RiskSummaryBar 
    totalRisk={data.totalRisk}
    activeRisk={data.activeRisk}
    trackingError={data.trackingError}
    var95={data.var95}
    maxDrawdown={data.maxDrawdown}
  />
  
  <div className="grid grid-cols-2 gap-4">
    <RiskDecompositionTable decomposition={data.riskDecomposition} />
    <VaRAnalysisPanel var={data.var} />
  </div>
  
  <Tabs>
    <Tab label="Stress Testing">
      <StressTestGrid scenarios={data.stressScenarios} />
    </Tab>
    <Tab label="Risk Contributors">
      <RiskContributorsGrid contributors={data.riskContributors} />
    </Tab>
    <Tab label="Factor Exposures">
      <FactorExposureChart exposures={data.factorExposures} />
    </Tab>
    <Tab label="Historical VaR">
      <HistoricalVaRChart data={data.historicalVaR} />
    </Tab>
  </Tabs>
</RiskAnalyticsPage>
```

### Risk Data Types
```typescript
interface RiskMetrics {
  portfolioId: string;
  benchmarkId?: string;
  asOfDate: Date;
  riskModel: string;
  
  // Total risk
  totalRisk: number;  // Annualized volatility
  dailyRisk: number;  // 1-day volatility
  
  // Active risk (vs benchmark)
  activeRisk: number;
  trackingError: number;
  
  // VaR metrics
  var95_1d: number;
  var99_1d: number;
  cvar95_1d: number;
  cvar99_1d: number;
  
  // Dollar VaR
  dollarVar95: number;
  dollarVar99: number;
  
  // Other
  beta: number;
  maxDrawdown: number;
  sharpeRatio: number;
}

interface RiskDecomposition {
  component: string;
  children?: RiskDecomposition[];
  
  totalRisk: number;
  activeRisk: number;
  percentOfTotal: number;
  percentOfActive: number;
  marginalContribution: number;
}

interface VaRAnalysis {
  confidence: number;  // 0.95 or 0.99
  horizon: number;     // days
  
  var: number;         // Percentage
  varDollar: number;   // Dollar amount
  cvar: number;        // Expected shortfall
  cvarDollar: number;
  
  // Distribution
  expectedReturn: number;
  distribution: { x: number; y: number }[];
}

interface StressScenario {
  scenarioId: string;
  name: string;
  description: string;
  category: 'historical' | 'hypothetical' | 'custom';
  
  portfolioImpact: number;
  benchmarkImpact: number;
  activeImpact: number;
  
  // Factor shocks applied
  factorShocks: { factorId: string; shock: number }[];
}

interface RiskContributor {
  symbol: string;
  name: string;
  weight: number;
  
  totalContribution: number;
  activeContribution: number;
  marginalContribution: number;
  
  beta: number;
  volatility: number;
}
```

### VaR Calculation
```typescript
/**
 * Calculate parametric VaR
 * 
 * VaR = -μ + σ × Z_α
 * 
 * Where:
 * μ = Expected return
 * σ = Portfolio volatility
 * Z_α = Z-score for confidence level (1.645 for 95%, 2.326 for 99%)
 */
function calculateParametricVaR(
  expectedReturn: number,
  volatility: number,
  confidence: 0.95 | 0.99,
  horizon: number = 1
): number {
  const zScore = confidence === 0.95 ? 1.645 : 2.326;
  const scaledVol = volatility * Math.sqrt(horizon);
  const scaledReturn = expectedReturn * horizon;
  
  return -(scaledReturn - zScore * scaledVol);
}

/**
 * Calculate Conditional VaR (Expected Shortfall)
 * 
 * CVaR = E[Loss | Loss > VaR]
 */
function calculateCVaR(
  returns: number[],
  confidence: 0.95 | 0.99
): number {
  const sorted = [...returns].sort((a, b) => a - b);
  const cutoff = Math.floor(sorted.length * (1 - confidence));
  const tailReturns = sorted.slice(0, cutoff);
  
  return -tailReturns.reduce((sum, r) => sum + r, 0) / tailReturns.length;
}
```

### Risk Decomposition Component
```typescript
function RiskDecompositionTable({ decomposition }: { decomposition: RiskDecomposition[] }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['Factor Risk']));
  
  const renderRow = (item: RiskDecomposition, depth: number = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expanded.has(item.component);
    
    return (
      <Fragment key={item.component}>
        <tr className={clsx(
          'hover:bg-[#252536]',
          depth === 0 && 'bg-[#252536] font-medium'
        )}>
          <td className="px-2 py-1" style={{ paddingLeft: `${depth * 16 + 8}px` }}>
            <div className="flex items-center gap-2">
              {hasChildren && (
                <button onClick={() => toggleExpand(item.component)}>
                  <ChevronRight className={clsx('h-4 w-4', isExpanded && 'rotate-90')} />
                </button>
              )}
              {!hasChildren && depth > 0 && <span className="w-4" />}
              <span className={depth === 0 ? 'text-white' : 'text-gray-300'}>
                {item.component}
              </span>
            </div>
          </td>
          <td className="text-right px-2 py-1 font-mono">
            {formatPercent(item.totalRisk)}
          </td>
          <td className="text-right px-2 py-1 font-mono">
            {formatPercent(item.activeRisk)}
          </td>
          <td className="text-right px-2 py-1 font-mono text-gray-400">
            {formatPercent(item.percentOfTotal)}
          </td>
          <td className="text-right px-2 py-1 font-mono text-gray-400">
            {formatPercent(item.percentOfActive)}
          </td>
          <td className="text-right px-2 py-1">
            <span className={clsx(
              'font-mono text-xs',
              item.marginalContribution >= 0 ? 'text-green-400' : 'text-red-400'
            )}>
              {item.marginalContribution >= 0 ? '+' : ''}
              {formatPercent(item.marginalContribution)}
            </span>
          </td>
          <td className="px-2 py-1 w-48">
            <RiskBar value={item.totalRisk} maxValue={0.20} />
          </td>
        </tr>
        {hasChildren && isExpanded && item.children!.map(child => 
          renderRow(child, depth + 1)
        )}
      </Fragment>
    );
  };
  
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="text-gray-400 border-b border-gray-700">
          <th className="text-left px-2 py-2">Component</th>
          <th className="text-right px-2 py-2">Total Risk</th>
          <th className="text-right px-2 py-2">Active Risk</th>
          <th className="text-right px-2 py-2">% Total</th>
          <th className="text-right px-2 py-2">% Active</th>
          <th className="text-right px-2 py-2">Marg Contr</th>
          <th className="px-2 py-2">Distribution</th>
        </tr>
      </thead>
      <tbody>
        {decomposition.map(item => renderRow(item))}
      </tbody>
    </table>
  );
}
```

### Stress Testing Grid
```typescript
const stressColumns: ColumnDef<StressScenario>[] = [
  {
    header: 'Scenario',
    accessorKey: 'name',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <span className="text-lg">
          {row.original.portfolioImpact < 0 ? '📉' : '📈'}
        </span>
        <div>
          <div className="font-medium text-white">{row.original.name}</div>
          <div className="text-xs text-gray-500">{row.original.description}</div>
        </div>
      </div>
    ),
  },
  {
    header: 'Portfolio',
    accessorKey: 'portfolioImpact',
    cell: ({ row }) => <ImpactCell value={row.original.portfolioImpact} />,
  },
  {
    header: 'Benchmark',
    accessorKey: 'benchmarkImpact',
    cell: ({ row }) => <ImpactCell value={row.original.benchmarkImpact} />,
  },
  {
    header: 'Active',
    accessorKey: 'activeImpact',
    cell: ({ row }) => <ImpactCell value={row.original.activeImpact} />,
  },
  {
    header: 'P&L Impact',
    accessorKey: 'portfolioImpact',
    cell: ({ row }) => (
      <ImpactBar value={row.original.portfolioImpact} maxValue={0.50} />
    ),
  },
];

function ImpactCell({ value }: { value: number }) {
  return (
    <span className={clsx(
      'font-mono',
      value >= 0 ? 'text-green-400' : 'text-red-400'
    )}>
      {value >= 0 ? '+' : ''}{formatPercent(value)}
    </span>
  );
}

function ImpactBar({ value, maxValue }: { value: number; maxValue: number }) {
  const width = Math.min(Math.abs(value) / maxValue * 100, 100);
  return (
    <div className="w-48 h-3 bg-gray-800 rounded overflow-hidden">
      <div 
        className={clsx(
          'h-full rounded',
          value >= 0 ? 'bg-green-500' : 'bg-red-500'
        )}
        style={{ width: `${width}%` }}
      />
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/risk")

@router.get("/{portfolio_id}/summary")
async def get_risk_summary(
    portfolio_id: str,
    benchmark_id: str | None = None,
    risk_model: str = 'USE4',
    as_of_date: date | None = None
) -> RiskSummary:
    """Get portfolio risk summary."""
    pass

@router.get("/{portfolio_id}/decomposition")
async def get_risk_decomposition(
    portfolio_id: str,
    benchmark_id: str | None = None,
    risk_model: str = 'USE4'
) -> list[RiskDecomposition]:
    """Get hierarchical risk decomposition."""
    pass

@router.get("/{portfolio_id}/var")
async def get_var_analysis(
    portfolio_id: str,
    confidence: float = 0.95,
    horizon: int = 1,
    method: Literal['parametric', 'historical', 'monte_carlo'] = 'parametric'
) -> VaRAnalysis:
    """Calculate VaR and CVaR."""
    pass

@router.get("/{portfolio_id}/stress-tests")
async def get_stress_tests(
    portfolio_id: str,
    benchmark_id: str | None = None,
    scenarios: list[str] | None = None
) -> list[StressTestResult]:
    """Run stress test scenarios."""
    pass

@router.post("/{portfolio_id}/stress-tests/custom")
async def run_custom_stress_test(
    portfolio_id: str,
    scenario: CustomScenarioRequest
) -> StressTestResult:
    """Run custom stress test."""
    pass

@router.get("/{portfolio_id}/contributors")
async def get_risk_contributors(
    portfolio_id: str,
    benchmark_id: str | None = None,
    top_n: int = 20
) -> list[RiskContributor]:
    """Get top risk contributors."""
    pass
```

### Pydantic Models
```python
class RiskSummary(BaseModel):
    portfolio_id: str
    as_of_date: datetime
    risk_model: str
    
    total_risk: Decimal      # Annualized
    daily_risk: Decimal      # 1-day
    
    active_risk: Decimal | None
    tracking_error: Decimal | None
    
    var_95_1d: Decimal
    var_99_1d: Decimal
    cvar_95_1d: Decimal
    cvar_99_1d: Decimal
    
    dollar_var_95: Decimal
    dollar_var_99: Decimal
    
    beta: Decimal
    max_drawdown: Decimal
    sharpe_ratio: Decimal | None

class RiskDecomposition(BaseModel):
    component: str
    
    total_risk: Decimal
    active_risk: Decimal
    
    percent_of_total: Decimal
    percent_of_active: Decimal
    
    marginal_contribution: Decimal
    
    children: list['RiskDecomposition'] | None = None

class StressTestResult(BaseModel):
    scenario_id: str
    name: str
    description: str
    category: str
    
    portfolio_impact: Decimal
    benchmark_impact: Decimal | None
    active_impact: Decimal | None
    
    dollar_impact: Decimal
    
    factor_impacts: list[FactorImpact] | None

class FactorImpact(BaseModel):
    factor_id: str
    factor_name: str
    shock: Decimal
    contribution: Decimal
```

### Risk Service
```python
import numpy as np
from scipy import stats

class RiskService:
    async def calculate_portfolio_risk(
        self,
        portfolio_id: str,
        risk_model_id: str,
        as_of_date: date
    ) -> RiskSummary:
        """Calculate comprehensive risk metrics."""
        
        # Get portfolio weights
        weights = await self._get_portfolio_weights(portfolio_id, as_of_date)
        
        # Get factor exposures and covariance matrix
        exposures = await self.risk_model.get_portfolio_exposures(weights, risk_model_id)
        factor_cov = await self.risk_model.get_factor_covariance(risk_model_id, as_of_date)
        specific_risk = await self.risk_model.get_specific_risk(weights, risk_model_id)
        
        # Calculate total variance
        # Total Variance = X'ΩX + Σ(w_i² × σ²_specific_i)
        factor_variance = self._calculate_factor_variance(exposures, factor_cov)
        specific_variance = self._calculate_specific_variance(weights, specific_risk)
        total_variance = factor_variance + specific_variance
        
        # Annualized volatility
        daily_risk = np.sqrt(total_variance)
        annualized_risk = daily_risk * np.sqrt(252)
        
        # VaR calculations
        expected_return = await self._get_expected_return(portfolio_id)
        var_95 = self._calculate_var(expected_return, daily_risk, 0.95)
        var_99 = self._calculate_var(expected_return, daily_risk, 0.99)
        
        # CVaR (Expected Shortfall)
        cvar_95 = self._calculate_cvar(expected_return, daily_risk, 0.95)
        cvar_99 = self._calculate_cvar(expected_return, daily_risk, 0.99)
        
        # Dollar VaR
        nav = await self._get_portfolio_nav(portfolio_id)
        dollar_var_95 = var_95 * nav
        dollar_var_99 = var_99 * nav
        
        return RiskSummary(
            portfolio_id=portfolio_id,
            as_of_date=as_of_date,
            risk_model=risk_model_id,
            total_risk=annualized_risk,
            daily_risk=daily_risk,
            var_95_1d=var_95,
            var_99_1d=var_99,
            cvar_95_1d=cvar_95,
            cvar_99_1d=cvar_99,
            dollar_var_95=dollar_var_95,
            dollar_var_99=dollar_var_99,
            ...
        )
    
    def _calculate_var(
        self, 
        expected_return: float, 
        volatility: float, 
        confidence: float
    ) -> float:
        """Parametric VaR calculation."""
        z_score = stats.norm.ppf(1 - confidence)  # Negative for left tail
        return -(expected_return + z_score * volatility)
    
    def _calculate_cvar(
        self, 
        expected_return: float, 
        volatility: float, 
        confidence: float
    ) -> float:
        """
        Expected Shortfall (Conditional VaR) for normal distribution.
        CVaR = -μ + σ × φ(z) / (1-α)
        """
        z_score = stats.norm.ppf(1 - confidence)
        pdf_z = stats.norm.pdf(z_score)
        return -(expected_return - volatility * pdf_z / (1 - confidence))
    
    async def run_stress_test(
        self,
        portfolio_id: str,
        scenario: StressScenario
    ) -> StressTestResult:
        """Apply factor shocks and calculate portfolio impact."""
        
        # Get portfolio factor exposures
        exposures = await self._get_portfolio_exposures(portfolio_id)
        
        # Calculate impact
        total_impact = Decimal(0)
        factor_impacts = []
        
        for shock in scenario.factor_shocks:
            exposure = exposures.get(shock.factor_id, Decimal(0))
            contribution = exposure * shock.shock
            total_impact += contribution
            
            factor_impacts.append(FactorImpact(
                factor_id=shock.factor_id,
                factor_name=shock.factor_name,
                shock=shock.shock,
                contribution=contribution
            ))
        
        nav = await self._get_portfolio_nav(portfolio_id)
        
        return StressTestResult(
            scenario_id=scenario.scenario_id,
            name=scenario.name,
            description=scenario.description,
            category=scenario.category,
            portfolio_impact=total_impact,
            dollar_impact=total_impact * nav,
            factor_impacts=factor_impacts
        )
```

---

## SQL Schema

```sql
-- Portfolio risk metrics (daily snapshot)
CREATE TABLE portfolio_risk (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    risk_model VARCHAR(20) NOT NULL,
    as_of_date DATE NOT NULL,
    
    -- Total risk
    total_risk DECIMAL(12,8),      -- Annualized volatility
    daily_risk DECIMAL(12,8),
    
    -- Active risk
    benchmark_id UUID,
    active_risk DECIMAL(12,8),
    tracking_error DECIMAL(12,8),
    
    -- VaR metrics
    var_95_1d DECIMAL(12,8),
    var_99_1d DECIMAL(12,8),
    cvar_95_1d DECIMAL(12,8),
    cvar_99_1d DECIMAL(12,8),
    
    -- Dollar VaR
    nav DECIMAL(18,4),
    dollar_var_95 DECIMAL(18,4),
    dollar_var_99 DECIMAL(18,4),
    
    -- Other metrics
    beta DECIMAL(10,6),
    max_drawdown DECIMAL(12,8),
    sharpe_ratio DECIMAL(10,6),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, risk_model, as_of_date),
    INDEX idx_portfolio_risk (portfolio_id, as_of_date DESC)
);

-- Risk decomposition (by factor/category)
CREATE TABLE risk_decomposition (
    id BIGSERIAL PRIMARY KEY,
    portfolio_risk_id BIGINT NOT NULL REFERENCES portfolio_risk(id),
    
    component VARCHAR(50) NOT NULL,
    parent_component VARCHAR(50),
    depth INTEGER NOT NULL DEFAULT 0,
    
    total_risk DECIMAL(12,8),
    active_risk DECIMAL(12,8),
    
    percent_of_total DECIMAL(10,6),
    percent_of_active DECIMAL(10,6),
    
    marginal_contribution DECIMAL(12,8),
    
    INDEX idx_decomposition_parent (portfolio_risk_id)
);

-- Stress test scenarios (predefined)
CREATE TABLE stress_scenarios (
    scenario_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(20) NOT NULL,  -- 'historical', 'hypothetical', 'custom'
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Factor shocks for scenarios
CREATE TABLE scenario_factor_shocks (
    id BIGSERIAL PRIMARY KEY,
    scenario_id VARCHAR(50) NOT NULL REFERENCES stress_scenarios(scenario_id),
    factor_id VARCHAR(50) NOT NULL,
    
    shock_value DECIMAL(10,6) NOT NULL,  -- e.g., -0.30 for -30%
    
    INDEX idx_scenario_shocks (scenario_id)
);

-- Stress test results
CREATE TABLE stress_test_results (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    scenario_id VARCHAR(50) NOT NULL,
    as_of_date DATE NOT NULL,
    
    portfolio_impact DECIMAL(12,8),
    benchmark_impact DECIMAL(12,8),
    active_impact DECIMAL(12,8),
    
    dollar_impact DECIMAL(18,4),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, scenario_id, as_of_date),
    INDEX idx_stress_results (portfolio_id, as_of_date)
);

-- Security risk contributions
CREATE TABLE security_risk_contribution (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    risk_model VARCHAR(20) NOT NULL,
    as_of_date DATE NOT NULL,
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    weight DECIMAL(10,8),
    
    total_contribution DECIMAL(12,8),
    active_contribution DECIMAL(12,8),
    marginal_contribution DECIMAL(12,8),
    
    beta DECIMAL(10,6),
    volatility DECIMAL(12,8),
    
    INDEX idx_security_risk (portfolio_id, risk_model, as_of_date)
);
```

---

## Key Calculations

### 1. Portfolio Variance
```
Total Variance = Factor Variance + Specific Variance

Factor Variance = X'ΩX
Where:
- X = Vector of factor exposures
- Ω = Factor covariance matrix

Specific Variance = Σ(w_i² × σ²_specific_i)
Where:
- w_i = Weight of security i
- σ²_specific_i = Specific variance of security i
```

### 2. VaR (Parametric)
```
VaR_α = -μ + σ × Z_α

Where:
- μ = Expected return (typically assume 0 for 1-day)
- σ = Portfolio volatility
- Z_α = Z-score (1.645 for 95%, 2.326 for 99%)

Multi-day VaR:
VaR_n = VaR_1 × √n (square root of time rule)
```

### 3. CVaR (Expected Shortfall)
```
CVaR_α = E[Loss | Loss > VaR_α]

For normal distribution:
CVaR_α = -μ + σ × φ(Z_α) / (1-α)

Where:
- φ(z) = PDF of standard normal at z
```

### 4. Tracking Error
```
Tracking Error = StdDev(R_p - R_b) × √252

Where:
- R_p = Portfolio returns
- R_b = Benchmark returns
```

### 5. Marginal Contribution to Risk
```
MCTR_i = ∂σ_p / ∂w_i

For factor model:
MCTR_i = Cov(r_i, r_p) / σ_p

Contribution to Risk:
CTR_i = w_i × MCTR_i
```
