# Job Manager & Batch Scheduling

## Overview
Schedule and monitor batch jobs for portfolio analytics calculations: risk analytics, VaR, attribution, optimization. Track job status, view results, and manage job queues. Based on Bloomberg PORT Job Manager functionality.

![Reference: PORT Job Manager]

---

## UI Components

### 1. Job Manager Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Job Manager                                                                                                   │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [All Jobs]│[Running]│[Queued]│[Completed]│[Failed]│[Scheduled]                                               │
│                                                                                                               │
│ [ + New Job ]  [ Refresh ]  [ Clear Completed ]                     Search: [________________] [🔍]           │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Job List Table
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Job Queue                                                                                                                             │
├───────┬───────────────────────────────────────────────┬─────────────────────┬──────────────┬──────────────┬─────────────┬─────────────┤
│ ID    │ Job Name                                      │ Type                │ Status       │ Submitted    │ Duration    │ Actions     │
├───────┼───────────────────────────────────────────────┼─────────────────────┼──────────────┼──────────────┼─────────────┼─────────────┤
│ 1247  │ Risk Analytics - Mid Cap Equity               │ Risk                │ 🟢 Running   │ 10:32:15     │ 2m 45s      │ [⏸] [✕] [📋]│
│ 1246  │ Daily VaR Calculation - All Portfolios        │ VaR                 │ 🟡 Queued    │ 10:30:00     │ --          │ [▶] [✕] [📋]│
│ 1245  │ Performance Attribution - Global Equity       │ Attribution         │ 🟡 Queued    │ 10:28:30     │ --          │ [▶] [✕] [📋]│
│ 1244  │ Optimization - Conservative Income            │ Optimization        │ ✅ Complete  │ 10:15:22     │ 8m 12s      │ [📄] [🔄] [📋]│
│ 1243  │ Factor Attribution - Tech Focus Fund          │ Attribution         │ ✅ Complete  │ 10:05:00     │ 4m 33s      │ [📄] [🔄] [📋]│
│ 1242  │ Scenario Analysis - Market Stress             │ Scenarios           │ ❌ Failed    │ 09:45:00     │ 1m 02s      │ [📄] [🔄] [📋]│
│ 1241  │ Risk Analytics - Fixed Income Core            │ Risk                │ ✅ Complete  │ 09:30:00     │ 5m 18s      │ [📄] [🔄] [📋]│
├───────┴───────────────────────────────────────────────┴─────────────────────┴──────────────┴──────────────┴─────────────┴─────────────┤
│ Showing 7 of 156 jobs                                                                                     [< Prev] Page 1 of 23 [Next >]│
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3. Job Detail Panel
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Job Details: #1247 - Risk Analytics - Mid Cap Equity                                                        │
├──────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                             │
│ Status: 🟢 Running                                                                                          │
│                                                                                                             │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐   │
│ │ Progress                                                                                     68%      │   │
│ │ ████████████████████████████████████████████░░░░░░░░░░░░░░░░░░░░░░                                   │   │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                             │
│ Current Step: Calculating factor exposures (Step 3 of 5)                                                    │
│                                                                                                             │
│ Configuration:                                                                                              │
│ ┌─────────────────────────────────────┬──────────────────────────────────────────────────────────────────┐  │
│ │ Portfolio                           │ Mid Cap Equity (PORT_001)                                        │  │
│ │ Benchmark                           │ S&P 400 MidCap Index                                             │  │
│ │ Risk Model                          │ Bloomberg Risk Model                                             │  │
│ │ As Of Date                          │ 2024-02-01                                                       │  │
│ │ Requested By                        │ john.smith@company.com                                           │  │
│ │ Priority                            │ Normal                                                           │  │
│ └─────────────────────────────────────┴──────────────────────────────────────────────────────────────────┘  │
│                                                                                                             │
│ Timeline:                                                                                                   │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐   │
│ │ 10:32:15  Job submitted                                                                              │   │
│ │ 10:32:16  Job started                                                                                │   │
│ │ 10:32:45  Step 1: Loading portfolio positions (completed)                                            │   │
│ │ 10:33:22  Step 2: Retrieving market data (completed)                                                 │   │
│ │ 10:34:00  Step 3: Calculating factor exposures (in progress...)                                      │   │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                             │
│                                                     [Pause Job]  [Cancel Job]  [View Results When Complete] │
└──────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. New Job Dialog
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Create New Job                                                                                            │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                           │
│ Job Type:                                                                                                 │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ○ Risk Analytics         Calculate tracking error, factor exposures, risk decomposition              │ │
│ │ ● VaR Calculation         Monte Carlo, Historical, Parametric VaR                                    │ │
│ │ ○ Performance Attribution Brinson-Fachler attribution by sector                                      │ │
│ │ ○ Factor Attribution      Multi-factor risk attribution                                              │ │
│ │ ○ Scenario Analysis       Run stress scenarios                                                       │ │
│ │ ○ Portfolio Optimization  Mean-variance optimization                                                 │ │
│ │ ○ Liquidity Analysis      Days to liquidate, market impact                                           │ │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                           │
│ Portfolio Selection:                                                                                      │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ☑ Mid Cap Equity                    ☐ Tech Focus Fund                                                │ │
│ │ ☑ Global Equity                     ☐ Fixed Income Core                                              │ │
│ │ ☐ Conservative Income               ☐ Emerging Markets                                               │ │
│ │                                                                                    [Select All] [None]│ │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                           │
│ VaR Settings:                                                                                             │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Methods:     ☑ Monte Carlo    ☑ Historical    ☑ Parametric                                           │ │
│ │ Confidence:  [99% ▼]                                                                                 │ │
│ │ Horizon:     [1 Day ▼]                                                                               │ │
│ │ Simulations: [10,000  ]                                                                              │ │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                           │
│ Scheduling:                                                                                               │
│ ┌───────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ○ Run Immediately                                                                                    │ │
│ │ ● Schedule for: [2024-02-02] [06:00] [AM ▼] [EST ▼]                                                  │ │
│ │ ○ Recurring:    [Daily ▼] at [06:00] [AM ▼]                                                         │ │
│ └───────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                           │
│ Priority: [Normal ▼]                                                                                      │
│                                                                                                           │
│ Notifications:                                                                                            │
│ ☑ Email on completion    ☑ Email on failure    ☐ Slack notification                                     │
│                                                                                                           │
│                                                              [Cancel]  [Save as Template]  [Submit Job]   │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Scheduled Jobs Calendar
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Scheduled Jobs - February 2024                                                              [< Prev]  [Today]  [Next >]│
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                        │
│       Mon           Tue           Wed           Thu           Fri           Sat           Sun                          │
│  ┌───────────┬───────────┬───────────┬───────────┬───────────┬───────────┬───────────┐                                │
│  │     29    │     30    │     31    │      1    │      2    │      3    │      4    │                                │
│  │           │           │           │ 🔵 Daily  │ 🔵 Daily  │           │           │                                │
│  │           │           │           │    VaR    │    VaR    │           │           │                                │
│  ├───────────┼───────────┼───────────┼───────────┼───────────┼───────────┼───────────┤                                │
│  │      5    │      6    │      7    │      8    │      9    │     10    │     11    │                                │
│  │ 🔵 Daily  │ 🔵 Daily  │ 🔵 Daily  │ 🔵 Daily  │ 🔵 Daily  │           │           │                                │
│  │    VaR    │    VaR    │    VaR    │    VaR    │    VaR    │           │           │                                │
│  │ 🟢 Weekly │           │           │           │ 🟢 Weekly │           │           │                                │
│  │    Risk   │           │           │           │    Attr   │           │           │                                │
│  └───────────┴───────────┴───────────┴───────────┴───────────┴───────────┴───────────┘                                │
│                                                                                                                        │
│  Legend: 🔵 Daily  🟢 Weekly  🟡 Monthly  🔴 Ad-hoc                                                                    │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/JobManagerPage.tsx

<JobManagerPage>
  <JobManagerHeader>
    <StatusTabs 
      tabs={['All Jobs', 'Running', 'Queued', 'Completed', 'Failed', 'Scheduled']}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    />
    <ActionButtons>
      <NewJobButton onClick={openNewJobDialog} />
      <RefreshButton onClick={refreshJobs} />
      <ClearCompletedButton onClick={clearCompleted} />
    </ActionButtons>
    <SearchBar value={search} onChange={setSearch} />
  </JobManagerHeader>
  
  <SplitPane>
    <JobListPanel>
      <JobListTable 
        jobs={filteredJobs}
        selectedJob={selectedJob}
        onSelectJob={setSelectedJob}
      />
      <Pagination page={page} totalPages={totalPages} />
    </JobListPanel>
    
    <JobDetailPanel job={selectedJob} />
  </SplitPane>
  
  <NewJobDialog 
    open={dialogOpen}
    onClose={() => setDialogOpen(false)}
    onSubmit={handleSubmitJob}
  />
</JobManagerPage>
```

### TypeScript Interfaces
```typescript
type JobStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled' | 'scheduled';

type JobType = 
  | 'risk_analytics'
  | 'var_calculation'
  | 'performance_attribution'
  | 'factor_attribution'
  | 'scenario_analysis'
  | 'portfolio_optimization'
  | 'liquidity_analysis';

interface Job {
  id: string;
  name: string;
  type: JobType;
  status: JobStatus;
  
  // Timing
  submittedAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  duration?: number;  // milliseconds
  
  // Progress
  progress: number;   // 0-100
  currentStep?: string;
  totalSteps?: number;
  currentStepNumber?: number;
  
  // Configuration
  portfolioIds: string[];
  benchmarkId?: string;
  asOfDate: Date;
  parameters: JobParameters;
  
  // Metadata
  requestedBy: string;
  priority: 'low' | 'normal' | 'high' | 'critical';
  
  // Results
  resultId?: string;
  error?: string;
  
  // Scheduling
  schedule?: JobSchedule;
}

interface JobParameters {
  // VaR specific
  varMethods?: ('monte_carlo' | 'historical' | 'parametric')[];
  varConfidence?: number;
  varHorizon?: number;
  numSimulations?: number;
  
  // Attribution specific
  attributionMethod?: 'brinson' | 'factor';
  
  // Scenario specific
  scenarioIds?: string[];
  
  // Optimization specific
  optimizationObjective?: string;
  constraints?: Record<string, any>;
  
  // Risk model
  riskModel?: string;
}

interface JobSchedule {
  type: 'once' | 'daily' | 'weekly' | 'monthly';
  scheduledTime: Date;
  timezone: string;
  
  // For recurring
  daysOfWeek?: number[];  // 0-6, Sunday = 0
  dayOfMonth?: number;
}

interface JobTimeline {
  timestamp: Date;
  event: string;
  status: 'info' | 'success' | 'error' | 'warning';
}
```

### Job List Table
```typescript
function JobListTable({
  jobs,
  selectedJob,
  onSelectJob
}: {
  jobs: Job[];
  selectedJob: Job | null;
  onSelectJob: (job: Job) => void;
}) {
  const columns: ColumnDef<Job>[] = [
    {
      header: 'ID',
      accessorKey: 'id',
      cell: ({ row }) => (
        <span className="font-mono text-gray-400">#{row.original.id}</span>
      ),
    },
    {
      header: 'Job Name',
      accessorKey: 'name',
      cell: ({ row }) => (
        <span className="text-white font-medium">{row.original.name}</span>
      ),
    },
    {
      header: 'Type',
      accessorKey: 'type',
      cell: ({ row }) => (
        <span className="px-2 py-1 bg-blue-900/30 text-blue-300 rounded text-xs">
          {formatJobType(row.original.type)}
        </span>
      ),
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: ({ row }) => <JobStatusBadge status={row.original.status} />,
    },
    {
      header: 'Submitted',
      accessorKey: 'submittedAt',
      cell: ({ row }) => formatTime(row.original.submittedAt),
    },
    {
      header: 'Duration',
      accessorKey: 'duration',
      cell: ({ row }) => row.original.duration 
        ? formatDuration(row.original.duration) 
        : '--',
    },
    {
      header: 'Actions',
      cell: ({ row }) => <JobActions job={row.original} />,
    },
  ];
  
  return (
    <DataTable
      columns={columns}
      data={jobs}
      selectedRow={selectedJob?.id}
      onRowClick={(row) => onSelectJob(row)}
    />
  );
}

function JobStatusBadge({ status }: { status: JobStatus }) {
  const statusConfig = {
    running: { icon: '🟢', label: 'Running', color: 'text-green-400' },
    queued: { icon: '🟡', label: 'Queued', color: 'text-yellow-400' },
    completed: { icon: '✅', label: 'Complete', color: 'text-green-400' },
    failed: { icon: '❌', label: 'Failed', color: 'text-red-400' },
    cancelled: { icon: '⛔', label: 'Cancelled', color: 'text-gray-400' },
    scheduled: { icon: '📅', label: 'Scheduled', color: 'text-blue-400' },
  };
  
  const { icon, label, color } = statusConfig[status];
  
  return (
    <span className={`flex items-center gap-1 ${color}`}>
      {icon} {label}
    </span>
  );
}
```

### Job Detail Panel
```typescript
function JobDetailPanel({ job }: { job: Job | null }) {
  if (!job) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        Select a job to view details
      </div>
    );
  }
  
  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-medium text-white">
          Job Details: #{job.id} - {job.name}
        </h2>
        <JobStatusBadge status={job.status} />
      </div>
      
      {/* Progress bar for running jobs */}
      {job.status === 'running' && (
        <div>
          <div className="flex justify-between text-sm text-gray-400 mb-1">
            <span>Progress</span>
            <span>{job.progress}%</span>
          </div>
          <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 transition-all duration-300"
              style={{ width: `${job.progress}%` }}
            />
          </div>
          {job.currentStep && (
            <p className="text-sm text-gray-400 mt-2">
              Current Step: {job.currentStep} 
              (Step {job.currentStepNumber} of {job.totalSteps})
            </p>
          )}
        </div>
      )}
      
      {/* Configuration */}
      <div className="bg-[#252536] p-4 rounded-lg">
        <h3 className="text-white font-medium mb-3">Configuration</h3>
        <dl className="grid grid-cols-2 gap-y-2 text-sm">
          <dt className="text-gray-400">Portfolio</dt>
          <dd className="text-white">{job.portfolioIds.join(', ')}</dd>
          
          <dt className="text-gray-400">As Of Date</dt>
          <dd className="text-white">{formatDate(job.asOfDate)}</dd>
          
          <dt className="text-gray-400">Requested By</dt>
          <dd className="text-white">{job.requestedBy}</dd>
          
          <dt className="text-gray-400">Priority</dt>
          <dd className="text-white capitalize">{job.priority}</dd>
        </dl>
      </div>
      
      {/* Timeline */}
      <JobTimeline jobId={job.id} />
      
      {/* Actions */}
      <div className="flex justify-end gap-2">
        {job.status === 'running' && (
          <>
            <button className="px-4 py-2 bg-yellow-600 text-white rounded">
              Pause Job
            </button>
            <button className="px-4 py-2 bg-red-600 text-white rounded">
              Cancel Job
            </button>
          </>
        )}
        {job.status === 'completed' && (
          <>
            <button className="px-4 py-2 bg-blue-600 text-white rounded">
              View Results
            </button>
            <button className="px-4 py-2 bg-gray-600 text-white rounded">
              Rerun
            </button>
          </>
        )}
      </div>
    </div>
  );
}
```

### New Job Dialog
```typescript
function NewJobDialog({
  open,
  onClose,
  onSubmit
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (job: CreateJobRequest) => void;
}) {
  const [jobType, setJobType] = useState<JobType>('risk_analytics');
  const [selectedPortfolios, setSelectedPortfolios] = useState<string[]>([]);
  const [scheduling, setScheduling] = useState<'immediate' | 'scheduled' | 'recurring'>('immediate');
  const [parameters, setParameters] = useState<JobParameters>({});
  
  const { data: portfolios } = usePortfolios();
  
  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg">
      <DialogTitle>Create New Job</DialogTitle>
      <DialogContent>
        {/* Job Type Selection */}
        <div className="mb-6">
          <h4 className="text-white font-medium mb-2">Job Type</h4>
          <div className="space-y-2">
            {JOB_TYPES.map((type) => (
              <label key={type.value} className="flex items-start gap-3 p-2 rounded hover:bg-[#252536]">
                <input
                  type="radio"
                  name="jobType"
                  value={type.value}
                  checked={jobType === type.value}
                  onChange={() => setJobType(type.value)}
                />
                <div>
                  <span className="text-white">{type.label}</span>
                  <p className="text-sm text-gray-400">{type.description}</p>
                </div>
              </label>
            ))}
          </div>
        </div>
        
        {/* Portfolio Selection */}
        <div className="mb-6">
          <h4 className="text-white font-medium mb-2">Portfolio Selection</h4>
          <div className="grid grid-cols-2 gap-2">
            {portfolios?.map((p) => (
              <label key={p.id} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedPortfolios.includes(p.id)}
                  onChange={(e) => togglePortfolio(p.id, e.target.checked)}
                />
                <span className="text-gray-300">{p.name}</span>
              </label>
            ))}
          </div>
        </div>
        
        {/* Type-specific parameters */}
        <JobTypeParameters 
          type={jobType} 
          parameters={parameters}
          onChange={setParameters}
        />
        
        {/* Scheduling */}
        <SchedulingOptions
          value={scheduling}
          onChange={setScheduling}
        />
      </DialogContent>
      <DialogActions>
        <button onClick={onClose} className="px-4 py-2 bg-gray-600 text-white rounded">
          Cancel
        </button>
        <button className="px-4 py-2 bg-gray-600 text-white rounded">
          Save as Template
        </button>
        <button 
          onClick={() => onSubmit({ jobType, selectedPortfolios, parameters, scheduling })}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          Submit Job
        </button>
      </DialogActions>
    </Dialog>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/jobs")

@router.get("/")
async def list_jobs(
    status: JobStatus | None = None,
    job_type: JobType | None = None,
    page: int = 1,
    page_size: int = 50
) -> PaginatedResponse[Job]:
    """List jobs with optional filtering."""
    pass

@router.get("/{job_id}")
async def get_job(job_id: str) -> Job:
    """Get job details."""
    pass

@router.post("/")
async def create_job(request: CreateJobRequest) -> Job:
    """Create and queue a new job."""
    pass

@router.post("/{job_id}/pause")
async def pause_job(job_id: str) -> Job:
    """Pause a running job."""
    pass

@router.post("/{job_id}/resume")
async def resume_job(job_id: str) -> Job:
    """Resume a paused job."""
    pass

@router.post("/{job_id}/cancel")
async def cancel_job(job_id: str) -> Job:
    """Cancel a running or queued job."""
    pass

@router.post("/{job_id}/rerun")
async def rerun_job(job_id: str) -> Job:
    """Rerun a completed or failed job."""
    pass

@router.get("/{job_id}/timeline")
async def get_job_timeline(job_id: str) -> list[JobTimelineEvent]:
    """Get job execution timeline."""
    pass

@router.get("/{job_id}/result")
async def get_job_result(job_id: str) -> JobResult:
    """Get job result (redirect to appropriate result endpoint)."""
    pass

@router.delete("/completed")
async def clear_completed_jobs(
    before: datetime | None = None
) -> int:
    """Clear completed jobs, optionally before a date."""
    pass

# Scheduled jobs
@router.get("/scheduled")
async def list_scheduled_jobs() -> list[ScheduledJob]:
    """List all scheduled jobs."""
    pass

@router.delete("/scheduled/{schedule_id}")
async def delete_scheduled_job(schedule_id: str) -> None:
    """Delete a scheduled job."""
    pass
```

### Pydantic Models
```python
class CreateJobRequest(BaseModel):
    name: str | None
    job_type: JobType
    portfolio_ids: list[str]
    benchmark_id: str | None
    as_of_date: date | None
    
    parameters: dict[str, Any] = {}
    
    priority: Literal['low', 'normal', 'high', 'critical'] = 'normal'
    
    # Scheduling
    schedule_type: Literal['immediate', 'scheduled', 'recurring'] = 'immediate'
    scheduled_time: datetime | None
    recurrence: RecurrenceConfig | None
    
    # Notifications
    notify_on_completion: bool = True
    notify_on_failure: bool = True
    notification_emails: list[str] = []

class Job(BaseModel):
    id: str
    name: str
    job_type: JobType
    status: JobStatus
    
    submitted_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    
    progress: int
    current_step: str | None
    total_steps: int | None
    current_step_number: int | None
    
    portfolio_ids: list[str]
    benchmark_id: str | None
    as_of_date: date
    parameters: dict[str, Any]
    
    requested_by: str
    priority: str
    
    result_id: str | None
    error: str | None
    
    schedule_id: str | None

class JobTimelineEvent(BaseModel):
    timestamp: datetime
    event: str
    status: Literal['info', 'success', 'error', 'warning']
    details: str | None
```

### Job Queue Service
```python
from celery import Celery
import redis

class JobQueueService:
    def __init__(self, celery: Celery, redis_client: redis.Redis):
        self.celery = celery
        self.redis = redis_client
    
    async def submit_job(self, request: CreateJobRequest, user: User) -> Job:
        """Submit job to queue."""
        
        # Create job record
        job = Job(
            id=str(uuid4()),
            name=request.name or self._generate_job_name(request),
            job_type=request.job_type,
            status='queued',
            submitted_at=datetime.now(UTC),
            progress=0,
            portfolio_ids=request.portfolio_ids,
            benchmark_id=request.benchmark_id,
            as_of_date=request.as_of_date or date.today(),
            parameters=request.parameters,
            requested_by=user.email,
            priority=request.priority,
        )
        
        await self._save_job(job)
        
        # Queue based on schedule
        if request.schedule_type == 'immediate':
            self._queue_job(job)
        elif request.schedule_type == 'scheduled':
            self._schedule_job(job, request.scheduled_time)
        elif request.schedule_type == 'recurring':
            self._setup_recurring_job(job, request.recurrence)
        
        return job
    
    def _queue_job(self, job: Job):
        """Add job to Celery queue."""
        
        task_map = {
            'risk_analytics': 'tasks.calculate_risk_analytics',
            'var_calculation': 'tasks.calculate_var',
            'performance_attribution': 'tasks.calculate_attribution',
            'factor_attribution': 'tasks.calculate_factor_attribution',
            'scenario_analysis': 'tasks.run_scenarios',
            'portfolio_optimization': 'tasks.run_optimization',
            'liquidity_analysis': 'tasks.analyze_liquidity',
        }
        
        task_name = task_map[job.job_type]
        
        self.celery.send_task(
            task_name,
            args=[job.id],
            kwargs=job.parameters,
            priority=self._get_priority_number(job.priority),
            task_id=job.id,
        )
    
    async def update_progress(
        self, 
        job_id: str, 
        progress: int,
        current_step: str | None = None,
        step_number: int | None = None,
        total_steps: int | None = None
    ):
        """Update job progress (called by worker)."""
        
        job = await self._get_job(job_id)
        job.progress = progress
        job.current_step = current_step
        job.current_step_number = step_number
        job.total_steps = total_steps
        
        await self._save_job(job)
        
        # Publish progress update via Redis pub/sub
        self.redis.publish(
            f'job:{job_id}:progress',
            json.dumps({
                'progress': progress,
                'current_step': current_step,
            })
        )
```

### Celery Task Example
```python
from celery import shared_task

@shared_task(bind=True)
def calculate_var(self, job_id: str, **parameters):
    """VaR calculation task."""
    
    job_service = get_job_service()
    var_service = get_var_service()
    
    try:
        # Update status to running
        await job_service.update_status(job_id, 'running')
        await job_service.add_timeline_event(job_id, 'Job started', 'info')
        
        job = await job_service.get_job(job_id)
        
        methods = parameters.get('var_methods', ['monte_carlo', 'historical', 'parametric'])
        confidence = parameters.get('var_confidence', 0.99)
        horizon = parameters.get('var_horizon', 1)
        
        total_calcs = len(job.portfolio_ids) * len(methods)
        completed = 0
        
        results = []
        
        for portfolio_id in job.portfolio_ids:
            for method in methods:
                # Update progress
                await job_service.update_progress(
                    job_id,
                    progress=int(completed / total_calcs * 100),
                    current_step=f'Calculating {method} VaR for portfolio {portfolio_id}',
                    step_number=completed + 1,
                    total_steps=total_calcs
                )
                
                # Calculate VaR
                result = await var_service.calculate_var(
                    portfolio_id,
                    method=method,
                    confidence=confidence,
                    horizon=horizon
                )
                
                results.append(result)
                completed += 1
        
        # Save results
        result_id = await job_service.save_results(job_id, results)
        
        # Mark complete
        await job_service.complete_job(job_id, result_id)
        await job_service.add_timeline_event(job_id, 'Job completed successfully', 'success')
        
    except Exception as e:
        await job_service.fail_job(job_id, str(e))
        await job_service.add_timeline_event(job_id, f'Job failed: {e}', 'error')
        raise
```

---

## SQL Schema

```sql
-- Jobs table
CREATE TABLE jobs (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    job_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    
    submitted_at TIMESTAMP NOT NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms INT,
    
    progress INT DEFAULT 0,
    current_step VARCHAR(200),
    total_steps INT,
    current_step_number INT,
    
    portfolio_ids JSONB NOT NULL,  -- Array of portfolio IDs
    benchmark_id UUID,
    as_of_date DATE NOT NULL,
    parameters JSONB NOT NULL DEFAULT '{}',
    
    requested_by VARCHAR(100) NOT NULL,
    priority VARCHAR(20) DEFAULT 'normal',
    
    result_id VARCHAR(36),
    error TEXT,
    
    schedule_id VARCHAR(36),
    
    INDEX idx_jobs_status (status),
    INDEX idx_jobs_type (job_type),
    INDEX idx_jobs_submitted (submitted_at DESC),
    INDEX idx_jobs_user (requested_by)
);

-- Job timeline events
CREATE TABLE job_timeline (
    id BIGSERIAL PRIMARY KEY,
    job_id VARCHAR(36) NOT NULL REFERENCES jobs(id),
    
    timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
    event VARCHAR(500) NOT NULL,
    status VARCHAR(20) NOT NULL,
    details TEXT,
    
    INDEX idx_timeline_job (job_id, timestamp)
);

-- Scheduled/recurring jobs
CREATE TABLE scheduled_jobs (
    id VARCHAR(36) PRIMARY KEY,
    job_template JSONB NOT NULL,  -- CreateJobRequest
    
    schedule_type VARCHAR(20) NOT NULL,  -- 'once', 'daily', 'weekly', 'monthly'
    scheduled_time TIME,
    timezone VARCHAR(50) DEFAULT 'UTC',
    
    days_of_week INT[],  -- For weekly
    day_of_month INT,    -- For monthly
    
    next_run_at TIMESTAMP,
    last_run_at TIMESTAMP,
    
    is_active BOOLEAN DEFAULT true,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    
    INDEX idx_scheduled_next_run (next_run_at) WHERE is_active = true
);

-- Job results (polymorphic)
CREATE TABLE job_results (
    id VARCHAR(36) PRIMARY KEY,
    job_id VARCHAR(36) NOT NULL REFERENCES jobs(id),
    
    result_type VARCHAR(50) NOT NULL,
    result_data JSONB NOT NULL,
    
    created_at TIMESTAMP DEFAULT NOW()
);

-- Job notifications
CREATE TABLE job_notifications (
    id BIGSERIAL PRIMARY KEY,
    job_id VARCHAR(36) NOT NULL REFERENCES jobs(id),
    
    notification_type VARCHAR(20) NOT NULL,  -- 'completion', 'failure'
    channel VARCHAR(20) NOT NULL,  -- 'email', 'slack'
    recipient VARCHAR(200) NOT NULL,
    
    sent_at TIMESTAMP,
    error TEXT
);
```

---

## WebSocket Real-time Updates

```typescript
// Frontend: Subscribe to job updates
function useJobProgress(jobId: string) {
  const [progress, setProgress] = useState<number>(0);
  const [currentStep, setCurrentStep] = useState<string | null>(null);
  
  useEffect(() => {
    const ws = new WebSocket(`wss://api.example.com/ws/jobs/${jobId}`);
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'progress') {
        setProgress(data.progress);
        setCurrentStep(data.current_step);
      } else if (data.type === 'completed') {
        // Handle completion
      } else if (data.type === 'failed') {
        // Handle failure
      }
    };
    
    return () => ws.close();
  }, [jobId]);
  
  return { progress, currentStep };
}
```

```python
# Backend: WebSocket endpoint
@router.websocket("/ws/jobs/{job_id}")
async def job_websocket(websocket: WebSocket, job_id: str):
    await websocket.accept()
    
    pubsub = redis_client.pubsub()
    await pubsub.subscribe(f'job:{job_id}:progress')
    
    try:
        async for message in pubsub.listen():
            if message['type'] == 'message':
                await websocket.send_text(message['data'])
    finally:
        await pubsub.unsubscribe()
```
