# Liquidity Risk Analysis

## Overview
Analyze portfolio liquidity based on average daily volume and participation rates. Calculate days to liquidate positions and identify concentration in illiquid securities. Based on Bloomberg PORT Liquidity Risk tab.

![Reference: PORT Liquidity Risk Tab]

---

## UI Components

### 1. Liquidity Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │ Characteristics │ VaR │ Tracking Error/Volatility │ Scenarios │ Performance │ Attribution│
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Main View │ Summary │ Cash Flows │[Liquidity Risk]│ Key Rates                                                 │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [None ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18                         │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Analytic: [Total Days To Liquidate ▼]                                                                         │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Liquidity Summary Matrix
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Liquidity Summary                                                                   Unit: Days                │
├──────────┬─────────────────────────────────────────────────────────────────────────────────────────────────────┤
│          │                                Volume History                                                      │
│ % Part   │    5 D      10 D      20 D      30 D       3 M       6 M                                          │
├──────────┼──────────┬──────────┬──────────┬──────────┬──────────┬──────────────────────────────────────────────┤
│    5     │   0.16   │   0.16   │   0.16   │  [0.16]  │   0.17   │   0.18                                      │
│   10     │   0.08   │   0.08   │   0.08   │   0.08   │   0.09   │   0.09                                      │
│   15     │   0.05   │   0.05   │   0.05   │   0.05   │   0.06   │   0.06                                      │
│   20     │   0.04   │   0.04   │   0.04   │   0.04   │   0.04   │   0.04                                      │
│   25     │   0.03   │   0.03   │   0.03   │   0.03   │   0.03   │   0.04                                      │
│   30     │   0.03   │   0.03   │   0.03   │   0.03   │   0.03   │   0.03                                      │
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┴──────────────────────────────────────────────┘

% Part = Participation Rate (% of average daily volume)
Days = Number of trading days to liquidate entire position
```

### 3. Sector Liquidity Breakdown
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Breakdown                           % Part: 5    Volume History: 30 D                                         │
├─────────────────────────────────┬──────────────────────────────────────────────────────┬──────────────────────┤
│ Security                        │ Liquidity                                            │ Cost                 │
├─────────────────────────────────┼──────────────────────────────────────────────────────┼──────────────────────┤
│ Portfolio                       │ █████████████████████████████████████████████  0.16 │   0.00               │
│ ▸ Materials                     │ █████████████████████████████████████████████  0.16 │   0.00               │
│   VALVOLINE INC                 │ █████████████████████████████████████████████  0.16 │   0.00               │
│   RELIANCE STEEL                │ █████████████████████████████████████         0.13 │   0.00               │
│   ROYAL GOLD                    │ ████████████████████████                       0.06 │   0.00               │
│   ALBEMARLE CORP                │ ████                                           0.01 │   0.00               │
│ ▸ Financials                    │ █████████████████████████████████████████████  0.15 │   0.00               │
│ ▸ Real Estate                   │ █████████████████████████████████████████████  0.15 │   0.00               │
│ ▸ Utilities                     │ █████████████████████████████████████          0.11 │   0.00               │
│ ▸ Industrials                   │ █████████████████████████████████              0.09 │   0.00               │
│ ▸ Health Care                   │ █████████████████████████████████              0.09 │   0.00               │
└─────────────────────────────────┴──────────────────────────────────────────────────────┴──────────────────────┘

Bar represents days to liquidate (longer = less liquid)
```

### 4. Liquidity Distribution Pie
```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│ Liquidity Distribution                                                                │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                       │
│     Very Liquid (<0.5 days)  ████████████████████████████████████  72.3%              │
│                                                                                       │
│     Liquid (0.5-1 day)       █████████████████████                  18.5%              │
│                                                                                       │
│     Less Liquid (1-3 days)   ████████                                6.8%              │
│                                                                                       │
│     Illiquid (>3 days)       ███                                     2.4%              │
│                                                                                       │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/LiquidityRiskPage.tsx

<LiquidityRiskPage>
  <LiquidityHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <GroupBySelector />
    <DateSelector />
  </LiquidityHeader>
  
  <AnalyticSelector 
    options={[
      'Total Days To Liquidate',
      'Avg Days To Liquidate',
      'Market Impact Cost',
      'Liquidation Cost'
    ]}
  />
  
  <div className="grid grid-cols-2 gap-4">
    <LiquiditySummaryMatrix 
      data={data.summaryMatrix}
      participationRates={[5, 10, 15, 20, 25, 30]}
      volumeHistories={['5D', '10D', '20D', '30D', '3M', '6M']}
    />
    <LiquidityDistributionChart data={data.distribution} />
  </div>
  
  <SectorLiquidityBreakdown 
    sectors={data.sectorBreakdown}
    participationRate={selectedRate}
    volumeHistory={selectedHistory}
  />
</LiquidityRiskPage>
```

### Liquidity Types
```typescript
interface LiquidityAnalysis {
  portfolioId: string;
  asOfDate: Date;
  
  // Summary matrix
  summaryMatrix: LiquiditySummaryCell[][];
  
  // By security
  securities: SecurityLiquidity[];
  
  // By sector
  sectorBreakdown: SectorLiquidity[];
  
  // Distribution
  distribution: LiquidityBucket[];
  
  // Portfolio totals
  totalDaysToLiquidate: number;  // At default participation rate
  weightedAvgDays: number;
  estimatedMarketImpact: number;
}

interface LiquiditySummaryCell {
  participationRate: number;   // 5, 10, 15, 20, 25, 30
  volumeHistory: string;       // '5D', '10D', '20D', '30D', '3M', '6M'
  daysToLiquidate: number;
  isHighlighted?: boolean;
}

interface SecurityLiquidity {
  symbol: string;
  name: string;
  sector: string;
  
  // Position info
  quantity: number;
  marketValue: number;
  weight: number;
  
  // Volume data
  avgDailyVolume: number;
  avgDailyValue: number;
  volumeHistory: string;  // Which period used
  
  // Liquidity metrics
  positionAsPctOfADV: number;
  daysToLiquidate: number;
  marketImpactCost: number;
  
  // Liquidity category
  liquidityTier: 'very_liquid' | 'liquid' | 'less_liquid' | 'illiquid';
}

interface SectorLiquidity {
  sector: string;
  
  totalWeight: number;
  totalMarketValue: number;
  holdingsCount: number;
  
  avgDaysToLiquidate: number;
  maxDaysToLiquidate: number;
  totalMarketImpact: number;
  
  securities: SecurityLiquidity[];
}

interface LiquidityBucket {
  tier: string;
  minDays: number;
  maxDays: number;
  weight: number;
  marketValue: number;
  holdingsCount: number;
}
```

### Days to Liquidate Calculator
```typescript
/**
 * Calculate days to liquidate a position
 * 
 * Days = Position Value / (ADV × Participation Rate)
 * 
 * Where:
 * - Position Value = shares × price
 * - ADV = Average Daily Volume (in dollars)
 * - Participation Rate = % of ADV we're willing to trade
 */
function calculateDaysToLiquidate(
  positionValue: number,
  avgDailyVolume: number,
  avgPrice: number,
  participationRate: number  // e.g., 0.05 for 5%
): number {
  const dailyTradingCapacity = avgDailyVolume * avgPrice * participationRate;
  
  if (dailyTradingCapacity <= 0) return Infinity;
  
  return positionValue / dailyTradingCapacity;
}

/**
 * Calculate market impact cost using square-root model
 * 
 * Impact = k × σ × √(Q / ADV)
 * 
 * Where:
 * - k = constant (typically 0.1 to 0.5)
 * - σ = daily volatility
 * - Q = quantity to trade
 * - ADV = average daily volume
 */
function calculateMarketImpact(
  quantity: number,
  avgDailyVolume: number,
  volatility: number,
  impactCoeff: number = 0.3
): number {
  if (avgDailyVolume <= 0) return 0;
  
  const participationFraction = quantity / avgDailyVolume;
  return impactCoeff * volatility * Math.sqrt(participationFraction);
}
```

### Liquidity Matrix Component
```typescript
function LiquiditySummaryMatrix({ 
  data,
  participationRates,
  volumeHistories,
  selectedRate,
  selectedHistory,
  onCellSelect
}: Props) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-700">
            <th className="px-2 py-1 text-left text-gray-400">% Part</th>
            {volumeHistories.map(vh => (
              <th key={vh} className="px-2 py-1 text-center text-gray-400">{vh}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {participationRates.map(rate => (
            <tr key={rate} className="border-b border-gray-800">
              <td className="px-2 py-1 text-gray-300">{rate}</td>
              {volumeHistories.map(vh => {
                const cell = data.find(
                  c => c.participationRate === rate && c.volumeHistory === vh
                );
                const isSelected = rate === selectedRate && vh === selectedHistory;
                
                return (
                  <td 
                    key={vh}
                    className={clsx(
                      'px-2 py-1 text-center font-mono cursor-pointer',
                      isSelected && 'bg-[#f59e0b] text-black',
                      !isSelected && 'hover:bg-[#252536]'
                    )}
                    onClick={() => onCellSelect(rate, vh)}
                  >
                    {cell?.daysToLiquidate.toFixed(2)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

### Sector Breakdown Component
```typescript
function SectorLiquidityBreakdown({ 
  sectors, 
  participationRate,
  volumeHistory 
}: Props) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const maxDays = Math.max(...sectors.flatMap(s => 
    s.securities.map(sec => sec.daysToLiquidate)
  ));
  
  return (
    <div className="space-y-1">
      {sectors.map(sector => (
        <div key={sector.sector}>
          {/* Sector Header */}
          <div 
            className="flex items-center gap-2 px-2 py-1 bg-[#252536] cursor-pointer hover:bg-[#2d2d43]"
            onClick={() => toggleExpand(sector.sector)}
          >
            <ChevronRight className={clsx('h-4 w-4', expanded.has(sector.sector) && 'rotate-90')} />
            <span className="text-white font-medium flex-1">{sector.sector}</span>
            <LiquidityBar value={sector.avgDaysToLiquidate} maxValue={maxDays} />
            <span className="font-mono text-sm w-12 text-right">
              {sector.avgDaysToLiquidate.toFixed(2)}
            </span>
          </div>
          
          {/* Securities */}
          {expanded.has(sector.sector) && (
            <div className="bg-[#1a1a2e] pl-6">
              {sector.securities.map(security => (
                <div key={security.symbol} className="flex items-center gap-2 px-2 py-1 border-b border-gray-800">
                  <span className="text-gray-300 flex-1">{security.symbol}</span>
                  <LiquidityBar value={security.daysToLiquidate} maxValue={maxDays} />
                  <span className="font-mono text-sm w-12 text-right">
                    {security.daysToLiquidate.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function LiquidityBar({ value, maxValue }: { value: number; maxValue: number }) {
  const width = Math.min((value / maxValue) * 100, 100);
  
  // Color based on liquidity tier
  const color = value < 0.5 ? 'bg-green-500' : 
                value < 1 ? 'bg-green-600' :
                value < 3 ? 'bg-yellow-500' : 'bg-red-500';
  
  return (
    <div className="w-48 h-3 bg-gray-800 rounded overflow-hidden">
      <div className={`h-full ${color}`} style={{ width: `${width}%` }} />
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/liquidity")

@router.get("/{portfolio_id}")
async def get_liquidity_analysis(
    portfolio_id: str,
    participation_rate: float = 0.05,
    volume_history: Literal['5D', '10D', '20D', '30D', '3M', '6M'] = '30D',
    as_of_date: date | None = None
) -> LiquidityAnalysis:
    """Get comprehensive liquidity analysis."""
    pass

@router.get("/{portfolio_id}/matrix")
async def get_liquidity_matrix(
    portfolio_id: str,
    as_of_date: date | None = None
) -> list[list[LiquiditySummaryCell]]:
    """Get liquidity summary matrix."""
    pass

@router.get("/{portfolio_id}/securities")
async def get_security_liquidity(
    portfolio_id: str,
    participation_rate: float = 0.05,
    volume_history: str = '30D',
    sort_by: str = 'days_to_liquidate',
    sort_desc: bool = True
) -> list[SecurityLiquidity]:
    """Get security-level liquidity metrics."""
    pass

@router.get("/{portfolio_id}/scenario")
async def run_liquidity_scenario(
    portfolio_id: str,
    liquidation_percent: float,  # e.g., 0.25 for 25%
    max_days: int,
    participation_rate: float = 0.05
) -> LiquidityScenarioResult:
    """Simulate partial liquidation scenario."""
    pass
```

### Pydantic Models
```python
class SecurityLiquidity(BaseModel):
    symbol: str
    name: str
    sector: str
    
    quantity: Decimal
    market_value: Decimal
    weight: Decimal
    
    avg_daily_volume: Decimal
    avg_daily_value: Decimal
    volume_history: str
    
    position_as_pct_of_adv: Decimal
    days_to_liquidate: Decimal
    market_impact_cost: Decimal
    
    liquidity_tier: str

class SectorLiquidity(BaseModel):
    sector: str
    
    total_weight: Decimal
    total_market_value: Decimal
    holdings_count: int
    
    avg_days_to_liquidate: Decimal
    max_days_to_liquidate: Decimal
    total_market_impact: Decimal
    
    securities: list[SecurityLiquidity]

class LiquidityAnalysis(BaseModel):
    portfolio_id: str
    as_of_date: date
    participation_rate: Decimal
    volume_history: str
    
    total_days_to_liquidate: Decimal
    weighted_avg_days: Decimal
    estimated_market_impact: Decimal
    
    summary_matrix: list[list[LiquiditySummaryCell]]
    securities: list[SecurityLiquidity]
    sector_breakdown: list[SectorLiquidity]
    distribution: list[LiquidityBucket]
```

### Liquidity Service
```python
class LiquidityService:
    PARTICIPATION_RATES = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]
    VOLUME_HISTORIES = ['5D', '10D', '20D', '30D', '3M', '6M']
    
    LIQUIDITY_TIERS = [
        ('very_liquid', 0, 0.5),
        ('liquid', 0.5, 1.0),
        ('less_liquid', 1.0, 3.0),
        ('illiquid', 3.0, float('inf')),
    ]
    
    async def analyze_liquidity(
        self,
        portfolio_id: str,
        participation_rate: float,
        volume_history: str,
        as_of_date: date
    ) -> LiquidityAnalysis:
        """Comprehensive liquidity analysis."""
        
        # Get holdings with volume data
        holdings = await self._get_holdings_with_volume(
            portfolio_id, volume_history, as_of_date
        )
        
        # Calculate liquidity for each security
        securities = []
        for h in holdings:
            days = self._calculate_days_to_liquidate(
                h['market_value'],
                h['avg_daily_volume'],
                h['price'],
                participation_rate
            )
            
            impact = self._calculate_market_impact(
                h['quantity'],
                h['avg_daily_volume'],
                h['volatility']
            )
            
            tier = self._get_liquidity_tier(days)
            
            securities.append(SecurityLiquidity(
                symbol=h['symbol'],
                name=h['name'],
                sector=h['sector'],
                quantity=h['quantity'],
                market_value=h['market_value'],
                weight=h['weight'],
                avg_daily_volume=h['avg_daily_volume'],
                avg_daily_value=h['avg_daily_volume'] * h['price'],
                volume_history=volume_history,
                position_as_pct_of_adv=h['quantity'] / h['avg_daily_volume'],
                days_to_liquidate=days,
                market_impact_cost=impact,
                liquidity_tier=tier
            ))
        
        # Generate summary matrix
        matrix = await self._generate_liquidity_matrix(holdings)
        
        # Calculate sector breakdown
        sector_breakdown = self._aggregate_by_sector(securities)
        
        # Calculate distribution
        distribution = self._calculate_distribution(securities)
        
        # Portfolio totals
        total_days = max(s.days_to_liquidate for s in securities)
        weighted_avg = sum(s.weight * s.days_to_liquidate for s in securities)
        total_impact = sum(s.market_impact_cost * s.weight for s in securities)
        
        return LiquidityAnalysis(
            portfolio_id=portfolio_id,
            as_of_date=as_of_date,
            participation_rate=participation_rate,
            volume_history=volume_history,
            total_days_to_liquidate=total_days,
            weighted_avg_days=weighted_avg,
            estimated_market_impact=total_impact,
            summary_matrix=matrix,
            securities=securities,
            sector_breakdown=sector_breakdown,
            distribution=distribution
        )
    
    def _calculate_days_to_liquidate(
        self,
        position_value: Decimal,
        avg_daily_volume: Decimal,
        price: Decimal,
        participation_rate: float
    ) -> Decimal:
        """Calculate days to liquidate position."""
        if avg_daily_volume <= 0:
            return Decimal('999')  # Very illiquid
        
        daily_capacity = avg_daily_volume * price * Decimal(str(participation_rate))
        return position_value / daily_capacity
```

---

## SQL Schema

```sql
-- Security volume history
CREATE TABLE security_volume (
    id BIGSERIAL PRIMARY KEY,
    security_id UUID NOT NULL REFERENCES securities(security_id),
    trade_date DATE NOT NULL,
    
    volume DECIMAL(18,0),           -- Shares traded
    dollar_volume DECIMAL(18,2),    -- Dollar value traded
    vwap DECIMAL(12,4),             -- Volume-weighted average price
    
    UNIQUE (security_id, trade_date),
    INDEX idx_volume_date (trade_date),
    INDEX idx_volume_security (security_id, trade_date DESC)
);

-- Average daily volume (pre-calculated)
CREATE TABLE security_adv (
    id BIGSERIAL PRIMARY KEY,
    security_id UUID NOT NULL REFERENCES securities(security_id),
    as_of_date DATE NOT NULL,
    
    adv_5d DECIMAL(18,0),
    adv_10d DECIMAL(18,0),
    adv_20d DECIMAL(18,0),
    adv_30d DECIMAL(18,0),
    adv_60d DECIMAL(18,0),
    adv_90d DECIMAL(18,0),
    
    -- Dollar volume equivalents
    adv_value_5d DECIMAL(18,2),
    adv_value_10d DECIMAL(18,2),
    adv_value_20d DECIMAL(18,2),
    adv_value_30d DECIMAL(18,2),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (security_id, as_of_date),
    INDEX idx_adv (security_id, as_of_date DESC)
);

-- Portfolio liquidity snapshots
CREATE TABLE portfolio_liquidity (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    participation_rate DECIMAL(6,4) NOT NULL,
    volume_history VARCHAR(10) NOT NULL,
    
    total_days_to_liquidate DECIMAL(12,4),
    weighted_avg_days DECIMAL(12,4),
    estimated_market_impact DECIMAL(12,6),
    
    -- Distribution by tier
    pct_very_liquid DECIMAL(8,4),
    pct_liquid DECIMAL(8,4),
    pct_less_liquid DECIMAL(8,4),
    pct_illiquid DECIMAL(8,4),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, as_of_date, participation_rate, volume_history),
    INDEX idx_liquidity (portfolio_id, as_of_date)
);

-- Security-level liquidity
CREATE TABLE security_liquidity (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    security_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    participation_rate DECIMAL(6,4) NOT NULL,
    volume_history VARCHAR(10) NOT NULL,
    
    position_value DECIMAL(18,4),
    avg_daily_volume DECIMAL(18,0),
    
    days_to_liquidate DECIMAL(12,4),
    market_impact_cost DECIMAL(12,6),
    liquidity_tier VARCHAR(20),
    
    INDEX idx_sec_liquidity (portfolio_id, as_of_date)
);
```

---

## Key Calculations

### 1. Days to Liquidate
```
Days = Position Value / (ADV × Price × Participation Rate)

Example:
- Position: $10M
- ADV: 500,000 shares
- Price: $50
- Participation Rate: 5%

Days = $10,000,000 / (500,000 × $50 × 0.05)
     = $10,000,000 / $1,250,000
     = 8 days
```

### 2. Market Impact (Square Root Model)
```
Impact % = k × σ × √(Q / ADV)

Where:
- k = impact coefficient (0.1 to 0.5)
- σ = daily volatility
- Q = quantity to trade
- ADV = average daily volume

Example:
- k = 0.3
- σ = 2% daily volatility
- Q = 100,000 shares
- ADV = 500,000 shares

Impact = 0.3 × 0.02 × √(100,000 / 500,000)
       = 0.3 × 0.02 × 0.447
       = 0.27% (27 bps)
```

### 3. Participation Rate Guidelines
| Rate | Description | Use Case |
|------|-------------|----------|
| 5% | Very conservative | Large caps, minimal impact |
| 10% | Conservative | Normal trading |
| 15% | Moderate | Active trading |
| 20% | Aggressive | Urgent trades |
| 25-30% | Very aggressive | Fire sale scenarios |
