# Low-Touch Order Management System (OMS)

## Overview
Multi-asset order management with smart order routing, execution monitoring, and compliance controls. Based on Horizon Trader / FlexTrade style interfaces.

![Reference: Horizon Trader Low-Touch Orders]

---

## UI Components

### 1. Order Blotter (Main Grid)
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [All Orders] [Rejected] [Buy] [Sell]  Creation Time [IS▼] [today▼]  [+ Add] [Reset]   🔍 [Visual] [Text] │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Ind │ Initial Time │ Ticker │ Side │ Quantity │ Price  │ Client Status      │ Exec Status │ Algo   │ ... │
├─────┼──────────────┼────────┼──────┼──────────┼────────┼────────────────────┼─────────────┼────────┼─────┤
│ 🇫🇷 │ Today 15:47:08│ RI FP │ Sell │ 220,900  │    9   │ PARTIALLY_FILLED   │ InlineVol   │ VOLUM  │     │
│ 🇫🇷 │ Today 15:46:51│ -     │ Buy  │   3,307  │    9   │ PENDING_NEW        │ REJECTED    │        │     │
│ 🇫🇷 │ Today 15:32:17│ -     │ Buy  │      15  │15,492  │ NEW                │ NEW         │        │     │
│ 🇫🇷 │ Today 15:32:16│ -     │ Buy  │      10  │15,265  │ NEW                │ NEW         │        │     │
│ 🇫🇷 │ Today 15:31:02│ -     │ Buy  │   4,623  │ 51.18  │ PENDING_NEW        │ PENDING_NEW │        │     │
│ 🇫🇷 │ Today 15:30:53│ AI FP │ Sell │     485  │143.08  │ PENDING_NEW        │ PENDING_NEW │        │     │
│ 🇫🇷 │ Today 13:33:31│ VK FP │ Buy  │   1,313  │ MARKET │ FILLED             │ FILLED      │        │     │
│ 🇫🇷 │ Today 13:33:31│ ORA FP│ Buy  │   2,478  │    10  │ FILLED             │ FILLED      │ NEW    │     │
└─────┴──────────────┴────────┴──────┴──────────┴────────┴────────────────────┴─────────────┴────────┴─────┘
│ Showing 402 of 1007 entries                                                                              │
└──────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

**Key Columns:**
- Country indicator flag
- Timestamp (sortable)
- Ticker/Symbol
- Side (color-coded: Green=Buy, Red=Sell)
- Quantity
- Price (or MARKET)
- Client Status (workflow state)
- Execution Status
- Target Algo
- Destination
- Validity (DAY, GTC, etc.)
- Mkt Qty / % Exec / Executed Qty / Avg Exec Price
- Client Name

### 2. Time Parameters Panel
```
┌─────────────────────────────────────────────┐
│ Time Parameters                             │
├─────────────────────────────────────────────┤
│ Start Time: [2024-12-12 15:47:06.000    ]   │
│ End Time:   [                           ]   │
└─────────────────────────────────────────────┘
```

### 3. Strategy Parameters Panel
```
┌─────────────────────────────────────────────┐
│ Strategy Parameters                         │
├─────────────────────────────────────────────┤
│ Max % Vol (1-50)*:     [12        ] ○       │
│ Lit Would % (5-99):    [          ] ○       │
│ Lit WouldPx:           [188.00    ] ○       │
│ Dark Would % (5-99):   [          ] ○       │
│ Dark WouldPx:          [          ] ○       │
│ Min Dark Fills Size (>1): [       ] ○       │
│ Inc Open Auction:      [    ▼     ] ○       │
│ Inc Close Auction:     [    ▼     ] ○       │
└─────────────────────────────────────────────┘
```

### 4. Order Benchmarks Panel (Right Side)
```
┌────────────────────────────────────────────────────────────────────────┐
│ Order Benchmarks                     [Follow active view] 🔲 📋 ⚡ ✕   │
├────────────────────────────────────────────────────────────────────────┤
│ FR0000120693@XPAR          SELL      220,900 @ InlineVol              │
│ fidameur / fidameur 123 (Fidelity Asset Mgt Europe / Rounding Account)│
│                                               bps        Amount (EUR)  │
├────────────────────────────────────────────────────────────────────────┤
│ VWAP                       │ Realized    │    -28    │    -21,413     │
│   190,930                  │ Unrealized  │     -2    │    -26,772     │
│                            │ Total       │     -6    │    -26,772     │
├────────────────────────────────────────────────────────────────────────┤
│ Unlimited VWAP             │ Realized    │    -28    │    -21,413     │
│   190,930                  │ Unrealized  │     -2    │     -5,359     │
│   CURRENT                  │ Total       │     -6    │    -26,772     │
├────────────────────────────────────────────────────────────────────────┤
│ Arrival Price              │ Realized    │    -39    │    -30,391     │
│   191,150                  │ Unrealized  │    -13    │    -45,034     │
│   CURRENT                  │ Total       │    -18    │    -75,425     │
├────────────────────────────────────────────────────────────────────────┤
│ Unlimited MVSOT            │ Realized    │     -     │        -       │
│   9,339.0                  │ Unrealized  │     -     │        -       │
│   CURRENT                  │ Total       │     -     │        -       │
└────────────────────────────────────────────────────────────────────────┘
```

**Benchmark Types:**
- VWAP (Volume-Weighted Average Price)
- Unlimited VWAP (full-day)
- Arrival Price (decision price)
- MVSOT (Market Value Start of Trade)
- Implementation Shortfall
- Close Price

### 5. Low-Touch Executions Panel
```
┌──────────────────────────────────────────────────────────────────────────┐
│ Low-Touch Executions                       [Follow active view] 🔲 📋 ⚡ │
├──────────────────────────────────────────────────────────────────────────┤
│ Time        │ Description    │ Side │  Qty  │ Price  │ Market │ Exec ID │
├─────────────┼────────────────┼──────┼───────┼────────┼────────┼─────────┤
│ Today 15:47:09│ PERNOD RICARD│ Sell │ 7,916 │ 190.7  │  XPAR  │2024121..│
│ Today 15:47:09│ PERNOD RICARD│ Sell │    57 │ 190.8  │  XPAR  │2024121..│
│ Today 15:47:09│ PERNOD RICARD│ Sell │ 2,316 │ 190.85 │  XPAR  │2024121..│
│ Today 15:47:09│ PERNOD RICARD│ Sell │ 8,079 │ 190.9  │  XPAR  │2024121..│
│ Today 15:47:09│ PERNOD RICARD│ Sell │   141 │ 190.95 │  XPAR  │2024121..│
│ Today 15:47:09│ PERNOD RICARD│ Sell │ 1,526 │ 191    │  XPAR  │2024121..│
└──────────────┴────────────────┴──────┴───────┴────────┴────────┴─────────┘
│ Showing 6 of 6 entries                                                   │
└──────────────────────────────────────────────────────────────────────────┘
```

### 6. Routing Rule Edition Panel
```
┌───────────────────────────────────────────────────────────────────────┐
│ Routing Rule Edition                    [Follow active view] 🔲 📋 ⚡ │
├───────────────────────────────────────────────────────────────────────┤
│ 🔲 🔲 🔲 🔲  [Priority icons]                                         │
│                                                                       │
│ # │ Prio │ Name │ Action │ Destination                                │
├───┴──────┴──────┴────────┴────────────────────────────────────────────┤
│                                                                       │
│ [empty - no rules configured]                                         │
│                                                                       │
├───────────────────────────────────────────────────────────────────────┤
│ Criteria │ Criteria Param │ Operator │ Value │ Error Details          │
├──────────┴────────────────┴──────────┴───────┴────────────────────────┤
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
│                               [Validate] [Apply] [Reset] [?]          │
└───────────────────────────────────────────────────────────────────────┘
```

### 7. Connections Status Panel
```
┌───────────────────────────────────────────────────────────────────────────────┐
│ Connections                                                                   │
├───────────────────────────────────────────────────────────────────────────────┤
│ Status │ Details │ Destinations                                               │
├────────┴─────────┴────────────────────────────────────────────────────────────┤
│ C │   │ mic  │stream.SU│stream.DEPTH│trx.ORDER│trx.QUOTE│trx.BLOCK_TR│       │
├───┼───┼──────┼─────────┼────────────┼─────────┼─────────┼────────────┼───────┤
│ 🟢│   │ XTSE │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
│ 🟢│   │ XPAR │   UP    │     UP     │   UP    │   NA    │     NA     │  UP   │
│ 🟢│   │ XNAS │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
│ 🟠│   │ XLON │   NA    │     NA     │   UP    │   UP    │     NA     │  NA   │
│ 🔴│   │ XLIS │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
│ 🟢│   │ XEUR │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
│ 🔴│   │ XBRU │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
│ 🟠│   │ XAMS │   UP    │     UP     │   UP    │   UP    │     UP     │  UP   │
└───┴───┴──────┴─────────┴────────────┴─────────┴─────────┴────────────┴───────┘
```

---

## Frontend Implementation

### Component Hierarchy
```typescript
// src/pages/OrderManagementPage.tsx

<OrderManagementPage>
  <OMSHeader>
    <FilterTabs />           {/* All Orders, Rejected, Buy, Sell */}
    <DateFilter />
    <SearchBar />
  </OMSHeader>
  
  <MainContent>
    <LeftPanel>
      <OrderBlotter />        {/* Main order grid */}
      <ExecutionFeed />       {/* Low-touch executions */}
      <StrategyDetail />      {/* Strategy analysis */}
    </LeftPanel>
    
    <RightPanel>
      <OrderBenchmarks />     {/* VWAP, Arrival, etc. */}
      <RoutingRules />        {/* Smart order routing config */}
      <ConnectionStatus />    {/* Exchange connectivity */}
    </RightPanel>
  </MainContent>
</OrderManagementPage>
```

### Order Blotter Grid
```typescript
interface OrderBlotterColumn {
  id: string;
  header: string;
  accessor: keyof Order | ((order: Order) => ReactNode);
  width: number;
  sortable: boolean;
  filterable: boolean;
  cellRenderer?: (value: any, order: Order) => ReactNode;
}

const columns: OrderBlotterColumn[] = [
  {
    id: 'country',
    header: '',
    width: 30,
    cellRenderer: (_, order) => <CountryFlag code={order.countryCode} />
  },
  {
    id: 'time',
    header: 'Initial Time',
    accessor: 'createdAt',
    width: 120,
    sortable: true,
    cellRenderer: (value) => formatTimestamp(value)
  },
  {
    id: 'ticker',
    header: 'Ticker',
    accessor: 'symbol',
    width: 80,
    filterable: true
  },
  {
    id: 'side',
    header: 'Side',
    accessor: 'side',
    width: 50,
    cellRenderer: (side) => (
      <span className={side === 'BUY' ? 'text-green-500 bg-green-500/20' : 'text-red-500 bg-red-500/20'}>
        {side}
      </span>
    )
  },
  {
    id: 'quantity',
    header: 'Quantity',
    accessor: 'quantity',
    width: 100,
    cellRenderer: (qty) => qty.toLocaleString()
  },
  {
    id: 'clientStatus',
    header: 'Client Status',
    accessor: 'clientStatus',
    width: 150,
    cellRenderer: (status) => <StatusBadge status={status} />
  },
  // ... more columns
];
```

### Real-time Updates with Flash
```typescript
function OrderRow({ order, isNew }: { order: Order; isNew: boolean }) {
  const [flash, setFlash] = useState(isNew);
  
  useEffect(() => {
    if (isNew) {
      setFlash(true);
      const timer = setTimeout(() => setFlash(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isNew, order.updatedAt]);
  
  return (
    <tr className={clsx(
      'transition-colors',
      flash && order.side === 'BUY' && 'bg-green-500/30',
      flash && order.side === 'SELL' && 'bg-red-500/30'
    )}>
      {/* cells */}
    </tr>
  );
}
```

---

## Backend Implementation (Python)

### API Endpoints
```python
from fastapi import APIRouter, Query, WebSocket
from typing import Literal

router = APIRouter(prefix="/api/v1/oms")

@router.get("/orders")
async def list_orders(
    status: list[str] | None = Query(None),
    side: Literal['BUY', 'SELL'] | None = None,
    symbol: str | None = None,
    from_date: datetime | None = None,
    to_date: datetime | None = None,
    page: int = 1,
    page_size: int = 50
) -> PaginatedResponse[Order]:
    """List orders with filtering."""
    pass

@router.get("/orders/{order_id}/benchmarks")
async def get_order_benchmarks(order_id: str) -> OrderBenchmarks:
    """Get benchmark comparisons for an order."""
    pass

@router.get("/orders/{order_id}/executions")
async def get_order_executions(order_id: str) -> list[Execution]:
    """Get all executions for an order."""
    pass

@router.post("/orders")
async def create_order(order: CreateOrderRequest) -> Order:
    """Create a new order."""
    pass

@router.patch("/orders/{order_id}")
async def modify_order(order_id: str, update: ModifyOrderRequest) -> Order:
    """Modify an existing order."""
    pass

@router.delete("/orders/{order_id}")
async def cancel_order(order_id: str, reason: str | None = None) -> Order:
    """Cancel an order."""
    pass

@router.get("/routing-rules")
async def list_routing_rules() -> list[RoutingRule]:
    """Get smart order routing rules."""
    pass

@router.post("/routing-rules")
async def create_routing_rule(rule: CreateRoutingRuleRequest) -> RoutingRule:
    """Create a new routing rule."""
    pass

@router.get("/connections")
async def get_connection_status() -> list[ExchangeConnection]:
    """Get exchange/venue connection status."""
    pass

@router.websocket("/ws/orders")
async def order_stream(websocket: WebSocket):
    """Real-time order updates stream."""
    pass
```

### Benchmark Calculation Service
```python
class BenchmarkService:
    async def calculate_benchmarks(self, order_id: str) -> OrderBenchmarks:
        order = await self.get_order(order_id)
        executions = await self.get_executions(order_id)
        market_data = await self.get_market_data(order.symbol, order.created_at)
        
        return OrderBenchmarks(
            order_id=order_id,
            vwap=self._calculate_vwap_benchmark(order, executions, market_data),
            unlimited_vwap=self._calculate_unlimited_vwap(order, executions, market_data),
            arrival_price=self._calculate_arrival_benchmark(order, executions),
            close_price=self._calculate_close_benchmark(order, executions, market_data),
        )
    
    def _calculate_vwap_benchmark(
        self, 
        order: Order, 
        executions: list[Execution],
        market_data: MarketData
    ) -> BenchmarkResult:
        # VWAP = Σ(Price × Volume) / Σ(Volume) during order period
        interval_vwap = market_data.calculate_vwap(
            order.start_time or order.created_at,
            order.end_time or datetime.utcnow()
        )
        
        avg_exec_price = self._weighted_avg_price(executions)
        filled_qty = sum(e.quantity for e in executions)
        
        realized_bps = (avg_exec_price - interval_vwap) / interval_vwap * 10000
        if order.side == 'BUY':
            realized_bps = -realized_bps  # Buying higher is bad
        
        return BenchmarkResult(
            benchmark_name='VWAP',
            benchmark_price=interval_vwap,
            current_price=market_data.last_price,
            realized_bps=realized_bps,
            unrealized_bps=self._calc_unrealized(order, market_data),
            realized_amount=realized_bps * filled_qty * avg_exec_price / 10000,
            unrealized_amount=...,
        )
```

---

## SQL Schema

```sql
-- Orders table (main)
CREATE TABLE orders (
    order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_order_id VARCHAR(50) UNIQUE,
    parent_order_id UUID REFERENCES orders(order_id),
    
    -- Security identification
    symbol VARCHAR(20) NOT NULL,
    isin VARCHAR(12),
    sedol VARCHAR(7),
    mic VARCHAR(10),  -- Market Identifier Code
    country_code CHAR(2),
    
    -- Order details
    side VARCHAR(10) NOT NULL CHECK (side IN ('BUY', 'SELL', 'SHORT', 'COVER')),
    order_type VARCHAR(20) NOT NULL,
    quantity INTEGER NOT NULL,
    limit_price DECIMAL(18,6),
    stop_price DECIMAL(18,6),
    time_in_force VARCHAR(10) DEFAULT 'DAY',
    
    -- Workflow status
    client_status VARCHAR(30) NOT NULL DEFAULT 'NEW',
    exec_status VARCHAR(30) NOT NULL DEFAULT 'NEW',
    
    -- Execution tracking
    filled_quantity INTEGER DEFAULT 0,
    remaining_quantity INTEGER,
    avg_exec_price DECIMAL(18,6),
    
    -- Routing
    target_algo VARCHAR(50),
    destination VARCHAR(20),
    broker VARCHAR(50),
    
    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    submitted_at TIMESTAMP,
    first_fill_at TIMESTAMP,
    last_fill_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Scheduling
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    
    -- Metadata
    client_id VARCHAR(50),
    account_id VARCHAR(50),
    trader_id VARCHAR(50),
    portfolio_id UUID,
    
    -- Reference prices
    arrival_price DECIMAL(18,6),
    decision_price DECIMAL(18,6),
    
    INDEX idx_orders_symbol (symbol),
    INDEX idx_orders_status (client_status, exec_status),
    INDEX idx_orders_created (created_at DESC),
    INDEX idx_orders_portfolio (portfolio_id)
);

-- Order status workflow
CREATE TYPE order_client_status AS ENUM (
    'NEW',
    'PENDING_NEW', 
    'PARTIALLY_FILLED',
    'FILLED',
    'PENDING_CANCEL',
    'CANCELLED',
    'REJECTED',
    'EXPIRED'
);

-- Executions/Fills
CREATE TABLE executions (
    execution_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES orders(order_id),
    
    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,
    quantity INTEGER NOT NULL,
    price DECIMAL(18,6) NOT NULL,
    
    execution_venue VARCHAR(20),  -- MIC code
    liquidity_flag CHAR(1),  -- A=Add, R=Remove
    
    execution_time TIMESTAMP NOT NULL,
    trade_date DATE NOT NULL,
    settlement_date DATE,
    
    commission DECIMAL(12,4),
    fees DECIMAL(12,4),
    
    -- Regulatory reporting
    exec_id_external VARCHAR(50),
    trade_match_id VARCHAR(50),
    
    INDEX idx_executions_order (order_id),
    INDEX idx_executions_time (execution_time DESC)
);

-- Benchmark snapshots (captured at order events)
CREATE TABLE order_benchmarks (
    id BIGSERIAL PRIMARY KEY,
    order_id UUID NOT NULL REFERENCES orders(order_id),
    snapshot_time TIMESTAMP NOT NULL DEFAULT NOW(),
    
    -- Benchmark prices
    vwap_price DECIMAL(18,6),
    unlimited_vwap DECIMAL(18,6),
    arrival_price DECIMAL(18,6),
    close_price DECIMAL(18,6),
    twap_price DECIMAL(18,6),
    
    -- Current execution metrics
    avg_exec_price DECIMAL(18,6),
    filled_qty INTEGER,
    
    -- Slippage calculations
    vwap_slippage_bps DECIMAL(10,4),
    arrival_slippage_bps DECIMAL(10,4),
    
    INDEX idx_benchmarks_order (order_id, snapshot_time DESC)
);

-- Smart Order Routing Rules
CREATE TABLE routing_rules (
    rule_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    priority INTEGER NOT NULL,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Conditions (JSON for flexibility)
    conditions JSONB NOT NULL,
    /*
    Example:
    {
      "symbol_pattern": "*.FP",
      "side": "BUY",
      "quantity_min": 1000,
      "quantity_max": 100000,
      "price_type": "LIMIT"
    }
    */
    
    -- Action
    action VARCHAR(20) NOT NULL,  -- ROUTE, REJECT, HOLD, SPLIT
    destination VARCHAR(50),
    algo VARCHAR(50),
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by VARCHAR(50),
    
    UNIQUE (priority)
);

-- Exchange/Venue Connections
CREATE TABLE exchange_connections (
    mic VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100),
    
    -- Connection status
    is_connected BOOLEAN DEFAULT FALSE,
    last_heartbeat TIMESTAMP,
    
    -- Capability flags
    supports_market_data BOOLEAN DEFAULT TRUE,
    supports_depth BOOLEAN DEFAULT TRUE,
    supports_orders BOOLEAN DEFAULT TRUE,
    supports_quotes BOOLEAN DEFAULT TRUE,
    supports_block_trades BOOLEAN DEFAULT FALSE,
    
    -- Session info
    session_state VARCHAR(20),  -- PRE, OPEN, AUCTION, CLOSE, POST
    session_start TIME,
    session_end TIME,
    timezone VARCHAR(50)
);
```

---

## Key Features to Implement

### 1. Status Color Coding
```typescript
const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  'NEW': { bg: 'bg-blue-500/20', text: 'text-blue-400' },
  'PENDING_NEW': { bg: 'bg-yellow-500/20', text: 'text-yellow-400' },
  'PARTIALLY_FILLED': { bg: 'bg-cyan-500/20', text: 'text-cyan-400' },
  'FILLED': { bg: 'bg-green-500/20', text: 'text-green-400' },
  'CANCELLED': { bg: 'bg-gray-500/20', text: 'text-gray-400' },
  'REJECTED': { bg: 'bg-red-500/20', text: 'text-red-400' },
};
```

### 2. Real-time Blotter Updates
```typescript
// WebSocket message types
type OrderUpdate = 
  | { type: 'NEW_ORDER'; order: Order }
  | { type: 'ORDER_UPDATE'; orderId: string; changes: Partial<Order> }
  | { type: 'EXECUTION'; orderId: string; execution: Execution }
  | { type: 'ORDER_CANCELLED'; orderId: string }
  | { type: 'ORDER_REJECTED'; orderId: string; reason: string };
```

### 3. Benchmark Slippage Display
```typescript
function BenchmarkRow({ benchmark }: { benchmark: BenchmarkResult }) {
  const isNegative = benchmark.realizedBps < 0;
  
  return (
    <tr>
      <td>{benchmark.name}</td>
      <td className="font-mono">{formatPrice(benchmark.benchmarkPrice)}</td>
      <td className={isNegative ? 'text-red-400' : 'text-green-400'}>
        {benchmark.realizedBps.toFixed(0)}
      </td>
      <td className={isNegative ? 'text-red-400' : 'text-green-400'}>
        {formatCurrency(benchmark.realizedAmount)}
      </td>
    </tr>
  );
}
```
