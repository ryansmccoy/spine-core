# PORT Holdings & Intraday Performance

## Overview
Portfolio holdings view showing positions, P&L contribution, market values, and real-time price changes. Based on Bloomberg PORT function and institutional portfolio monitoring systems.

![Reference: PORT Holdings View]

---

## UI Components

### 1. Portfolio Summary Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio Analytics  [MEGA CAP ▼]  as of 14-Aug-25 4:00PM  Holdings        │ [◀ ▶]           │
├────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Source: [BGH Positions]   Benchmark: [R2000G ▼]                                               │
│ Currency: [USD ▼]         Period: [1D ▼]  [5D] [MTD] [QTD] [YTD] [1Y]                        │
└────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Holdings Grid
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Holdings                                                                                                               │
├────────┬─────────┬──────────┬──────────┬──────────┬──────────┬─────────┬─────────┬──────────┬─────────┬───────────────┤
│Security│% Weight │CTR       │ P/L      │ P/L %    │Mkt Val   │ Price   │ Chg     │ Chg %    │ Shares  │ Sector        │
├────────┼─────────┼──────────┼──────────┼──────────┼──────────┼─────────┼─────────┼──────────┼─────────┼───────────────┤
│ NVDA   │ 12.45%  │ +156 bps │ +2.34M   │ +4.21%   │ 57.89M   │ 142.56  │ +5.67   │ +4.15%   │ 406,123 │ Technology    │
│ AAPL   │ 10.23%  │ +42 bps  │ +589K    │ +1.23%   │ 48.45M   │ 189.32  │ +2.31   │ +1.23%   │ 255,980 │ Technology    │
│ MSFT   │  9.87%  │ +38 bps  │ +512K    │ +1.12%   │ 46.23M   │ 412.45  │ +4.56   │ +1.12%   │ 112,100 │ Technology    │
│ AMZN   │  8.12%  │ -12 bps  │ -156K    │ -0.41%   │ 38.12M   │ 185.23  │ -0.78   │ -0.42%   │ 205,800 │ Consumer Disc │
│ GOOGL  │  7.45%  │ +23 bps  │ +298K    │ +0.85%   │ 35.12M   │ 175.89  │ +1.45   │ +0.83%   │ 199,650 │ Technology    │
│ META   │  6.89%  │ +67 bps  │ +789K    │ +2.45%   │ 32.56M   │ 512.34  │ +12.34  │ +2.47%   │  63,540 │ Technology    │
│ TSLA   │  5.34%  │ -45 bps  │ -523K    │ -2.01%   │ 25.12M   │ 245.67  │ -5.12   │ -2.04%   │ 102,280 │ Consumer Disc │
│ JPM    │  4.23%  │ +18 bps  │ +198K    │ +1.01%   │ 19.89M   │ 198.45  │ +1.98   │ +1.01%   │ 100,200 │ Financials    │
│ V      │  3.89%  │ +15 bps  │ +167K    │ +0.92%   │ 18.34M   │ 267.89  │ +2.45   │ +0.92%   │  68,450 │ Financials    │
│ UNH    │  3.45%  │ -8 bps   │ -89K     │ -0.55%   │ 16.23M   │ 512.34  │ -2.89   │ -0.56%   │  31,680 │ Healthcare    │
├────────┼─────────┼──────────┼──────────┼──────────┼──────────┼─────────┼─────────┼──────────┼─────────┼───────────────┤
│ TOTAL  │ 100.0%  │ +294 bps │ +4.07M   │ +2.94%   │ 469.5M   │         │         │          │         │               │
└────────┴─────────┴──────────┴──────────┴──────────┴──────────┴─────────┴─────────┴──────────┴─────────┴───────────────┘
```

**Column Definitions:**
- **% Weight**: Position weight in portfolio
- **CTR**: Contribution to Return (in basis points)
- **P/L**: Dollar profit/loss for period
- **P/L %**: Percentage return for period
- **Mkt Val**: Current market value
- **Price**: Current price
- **Chg**: Price change for period
- **Chg %**: Price percentage change
- **Shares**: Share quantity held

### 3. Intraday Performance Chart
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Intraday Returns                                                             [1D] [5D] [MTD] [Custom]      │
├─────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                             │
│  +3.0% │                                                              ████████████████████                 │
│        │                                              ██████████████████                                    │
│  +2.0% │                              ████████████████                                                      │
│        │                  ████████████                                        Portfolio ─────               │
│  +1.0% │      ████████████                                                    Benchmark ═════               │
│        │  ████                                                                                              │
│   0.0% │──────────────────────────────────────────────────────════════════════════════════════════          │
│        │              ════════════════════════════════════════════════════════                              │
│  -1.0% │                                                                                                    │
│        │                                                                                                    │
│        └────────────────────────────────────────────────────────────────────────────────────────────────    │
│         9:30    10:00    10:30    11:00    11:30    12:00    12:30    1:00     1:30     2:00     3:00      │
└─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Top Contributors Panel
```
┌───────────────────────────────────────────────────────────────────────┐
│ Top Contributors                              Top Detractors          │
├───────────────────────────────────────────────────────────────────────┤
│ ▲ NVDA     +156 bps   █████████████████       │ ▼ TSLA    -45 bps ████│
│ ▲ META     +67 bps    ████████                │ ▼ AMZN    -12 bps █   │
│ ▲ AAPL     +42 bps    █████                   │ ▼ UNH      -8 bps     │
│ ▲ MSFT     +38 bps    ████                    │                       │
│ ▲ GOOGL    +23 bps    ███                     │                       │
└───────────────────────────────────────────────────────────────────────┘
```

### 5. Sector Breakdown
```
┌────────────────────────────────────────────────────────────────────────────────────┐
│ Sector Analysis                                                                    │
├───────────────┬─────────┬─────────┬──────────┬──────────┬──────────────────────────┤
│ Sector        │ % Port  │ % Bench │ Active   │ CTR      │ Distribution             │
├───────────────┼─────────┼─────────┼──────────┼──────────┼──────────────────────────┤
│ Technology    │  47.1%  │  32.5%  │ +14.6%   │ +326 bps │ ████████████████████████ │
│ Consumer Disc │  13.5%  │  15.2%  │  -1.7%   │ -57 bps  │ ██████████               │
│ Financials    │   8.1%  │  12.8%  │  -4.7%   │ +33 bps  │ ████████                 │
│ Healthcare    │   7.2%  │  14.5%  │  -7.3%   │  -8 bps  │ ███████                  │
│ Industrials   │   5.4%  │   8.9%  │  -3.5%   │ +12 bps  │ █████                    │
│ Other         │  18.7%  │  16.1%  │  +2.6%   │ -12 bps  │ ██████████████           │
├───────────────┼─────────┼─────────┼──────────┼──────────┼──────────────────────────┤
│ TOTAL         │ 100.0%  │ 100.0%  │   0.0%   │ +294 bps │                          │
└───────────────┴─────────┴─────────┴──────────┴──────────┴──────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/PortfolioHoldingsPage.tsx

interface PortfolioHoldingsPageProps {
  portfolioId: string;
}

<PortfolioHoldingsPage>
  <PortfolioHeader>
    <PortfolioSelector portfolios={portfolios} selected={portfolioId} />
    <BenchmarkSelector benchmarks={benchmarks} selected={benchmarkId} />
    <PeriodSelector period={period} onChange={setPeriod} />
    <CurrencySelector currency={currency} />
  </PortfolioHeader>
  
  <PortfolioSummaryBar portfolio={portfolio} />
  
  <div className="grid grid-cols-3 gap-4">
    <div className="col-span-2">
      <HoldingsGrid 
        holdings={holdings} 
        sortBy={sortBy}
        onSort={setSortBy}
      />
    </div>
    <div>
      <IntradayChart portfolio={portfolio} benchmark={benchmark} />
      <TopContributors holdings={holdings} />
      <SectorBreakdown sectors={sectorData} />
    </div>
  </div>
</PortfolioHoldingsPage>
```

### Holdings Interface
```typescript
interface PortfolioHolding {
  // Identity
  symbol: string;
  securityId: string;
  name: string;
  
  // Position
  quantity: number;
  marketValue: number;
  weight: number;  // Portfolio weight (0-1)
  
  // Price data
  currentPrice: number;
  priceChange: number;
  priceChangePercent: number;
  previousClose: number;
  
  // P&L
  pnl: number;
  pnlPercent: number;
  
  // Contribution
  contributionToReturn: number;  // In decimal (0.0156 = 156 bps)
  contributionBps: number;       // In basis points (156)
  
  // Classification
  sector: string;
  industry: string;
  country: string;
  
  // Risk
  beta: number;
  volatility: number;
}

interface PortfolioSummary {
  portfolioId: string;
  name: string;
  asOfDate: Date;
  
  // Values
  totalMarketValue: number;
  cashBalance: number;
  totalNav: number;
  
  // Returns
  dailyReturn: number;
  mtdReturn: number;
  ytdReturn: number;
  
  // vs Benchmark
  dailyExcessReturn: number;
  mtdExcessReturn: number;
  ytdExcessReturn: number;
  
  // Risk
  trackingError: number;
  beta: number;
  sharpeRatio: number;
}
```

### Contribution to Return Calculator
```typescript
function calculateContributionToReturn(holdings: PortfolioHolding[]): PortfolioHolding[] {
  // Total portfolio return
  const totalPnL = holdings.reduce((sum, h) => sum + h.pnl, 0);
  const totalMV = holdings.reduce((sum, h) => sum + h.marketValue - h.pnl, 0); // Beginning MV
  const portfolioReturn = totalMV > 0 ? totalPnL / totalMV : 0;
  
  return holdings.map(holding => {
    // Contribution = Weight × Security Return
    const beginningMV = holding.marketValue - holding.pnl;
    const beginningWeight = totalMV > 0 ? beginningMV / totalMV : 0;
    const securityReturn = beginningMV > 0 ? holding.pnl / beginningMV : 0;
    
    const contribution = beginningWeight * securityReturn;
    
    return {
      ...holding,
      contributionToReturn: contribution,
      contributionBps: contribution * 10000,
    };
  });
}
```

### Holdings Grid Component
```typescript
const holdingsColumns: ColumnDef<PortfolioHolding>[] = [
  {
    header: 'Security',
    accessorKey: 'symbol',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <span className="font-medium text-white">{row.original.symbol}</span>
        <span className="text-xs text-gray-500">{row.original.name}</span>
      </div>
    ),
  },
  {
    header: '% Weight',
    accessorKey: 'weight',
    cell: ({ row }) => (
      <span className="text-right">{formatPercent(row.original.weight)}</span>
    ),
  },
  {
    header: 'CTR',
    accessorKey: 'contributionBps',
    cell: ({ row }) => (
      <span className={clsx(
        'text-right font-mono',
        row.original.contributionBps >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {row.original.contributionBps >= 0 ? '+' : ''}
        {row.original.contributionBps.toFixed(0)} bps
      </span>
    ),
  },
  {
    header: 'P/L',
    accessorKey: 'pnl',
    cell: ({ row }) => <PnLCell value={row.original.pnl} />,
  },
  {
    header: 'P/L %',
    accessorKey: 'pnlPercent',
    cell: ({ row }) => (
      <span className={clsx(
        'text-right font-mono',
        row.original.pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {formatPercent(row.original.pnlPercent, { showSign: true })}
      </span>
    ),
  },
  {
    header: 'Mkt Val',
    accessorKey: 'marketValue',
    cell: ({ row }) => formatCurrency(row.original.marketValue),
  },
  {
    header: 'Price',
    accessorKey: 'currentPrice',
    cell: ({ row }) => formatPrice(row.original.currentPrice),
  },
  {
    header: 'Chg',
    accessorKey: 'priceChange',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.priceChange >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {row.original.priceChange >= 0 ? '+' : ''}
        {row.original.priceChange.toFixed(2)}
      </span>
    ),
  },
  {
    header: 'Chg %',
    accessorKey: 'priceChangePercent',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {formatPercent(row.original.priceChangePercent / 100, { showSign: true })}
      </span>
    ),
  },
  {
    header: 'Shares',
    accessorKey: 'quantity',
    cell: ({ row }) => formatNumber(row.original.quantity),
  },
  {
    header: 'Sector',
    accessorKey: 'sector',
  },
];
```

### Intraday Chart Component
```typescript
interface IntradayDataPoint {
  timestamp: Date;
  portfolioReturn: number;
  benchmarkReturn: number;
}

function IntradayPerformanceChart({ data }: { data: IntradayDataPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis 
          dataKey="timestamp" 
          tickFormatter={(t) => format(t, 'h:mm a')}
          stroke="#6b7280"
        />
        <YAxis 
          tickFormatter={(v) => `${(v * 100).toFixed(1)}%`}
          stroke="#6b7280"
        />
        <ReferenceLine y={0} stroke="#4b5563" />
        <Area 
          type="monotone" 
          dataKey="portfolioReturn" 
          stroke="#3b82f6" 
          fill="url(#portfolioGradient)"
          name="Portfolio"
        />
        <Line 
          type="monotone" 
          dataKey="benchmarkReturn" 
          stroke="#9ca3af" 
          strokeDasharray="5 5"
          dot={false}
          name="Benchmark"
        />
        <Tooltip content={<IntradayTooltip />} />
        <Legend />
      </AreaChart>
    </ResponsiveContainer>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/portfolio")

@router.get("/{portfolio_id}/holdings")
async def get_holdings(
    portfolio_id: str,
    as_of: date | None = None,
    period: Literal['1D', '5D', 'MTD', 'QTD', 'YTD', '1Y'] = '1D'
) -> PortfolioHoldingsResponse:
    """Get portfolio holdings with P&L and contribution."""
    pass

@router.get("/{portfolio_id}/summary")
async def get_portfolio_summary(
    portfolio_id: str,
    as_of: date | None = None
) -> PortfolioSummary:
    """Get portfolio summary statistics."""
    pass

@router.get("/{portfolio_id}/intraday")
async def get_intraday_performance(
    portfolio_id: str,
    benchmark_id: str | None = None,
    interval: Literal['1m', '5m', '15m', '30m'] = '5m'
) -> list[IntradayDataPoint]:
    """Get intraday performance data."""
    pass

@router.get("/{portfolio_id}/contributors")
async def get_top_contributors(
    portfolio_id: str,
    period: str = '1D',
    top_n: int = 10
) -> ContributorsResponse:
    """Get top contributors and detractors."""
    pass

@router.get("/{portfolio_id}/sectors")
async def get_sector_breakdown(
    portfolio_id: str,
    benchmark_id: str | None = None,
    period: str = '1D'
) -> list[SectorBreakdown]:
    """Get sector allocation and contribution."""
    pass

@router.websocket("/ws/{portfolio_id}/stream")
async def portfolio_stream(websocket: WebSocket, portfolio_id: str):
    """Real-time portfolio updates."""
    pass
```

### Pydantic Models
```python
class PortfolioHolding(BaseModel):
    symbol: str
    security_id: str
    name: str
    
    quantity: Decimal
    market_value: Decimal
    weight: Decimal
    
    current_price: Decimal
    price_change: Decimal
    price_change_percent: Decimal
    
    pnl: Decimal
    pnl_percent: Decimal
    
    contribution_to_return: Decimal
    contribution_bps: Decimal
    
    sector: str | None
    industry: str | None

class PortfolioHoldingsResponse(BaseModel):
    portfolio_id: str
    as_of_date: datetime
    period: str
    
    holdings: list[PortfolioHolding]
    
    # Totals
    total_market_value: Decimal
    total_pnl: Decimal
    total_pnl_percent: Decimal
    total_contribution_bps: Decimal

class IntradayDataPoint(BaseModel):
    timestamp: datetime
    portfolio_return: Decimal
    benchmark_return: Decimal | None
    excess_return: Decimal | None

class SectorBreakdown(BaseModel):
    sector: str
    
    portfolio_weight: Decimal
    benchmark_weight: Decimal | None
    active_weight: Decimal | None
    
    contribution_bps: Decimal
    
    holdings_count: int
    market_value: Decimal
```

### Holdings Service
```python
class PortfolioHoldingsService:
    async def get_holdings_with_contribution(
        self, 
        portfolio_id: str, 
        period: str
    ) -> list[PortfolioHolding]:
        """Calculate holdings with contribution to return."""
        
        # Get positions
        positions = await self.db.fetch_positions(portfolio_id)
        
        # Get period returns
        start_date = self._get_period_start(period)
        
        holdings = []
        total_beginning_mv = Decimal(0)
        
        for pos in positions:
            # Get prices
            current_price = await self.market_data.get_price(pos.symbol)
            start_price = await self.market_data.get_price(pos.symbol, start_date)
            
            # Calculate values
            current_mv = pos.quantity * current_price
            beginning_mv = pos.quantity * start_price
            
            pnl = current_mv - beginning_mv
            pnl_percent = pnl / beginning_mv if beginning_mv > 0 else Decimal(0)
            
            total_beginning_mv += beginning_mv
            
            holdings.append({
                'symbol': pos.symbol,
                'quantity': pos.quantity,
                'market_value': current_mv,
                'beginning_mv': beginning_mv,
                'pnl': pnl,
                'pnl_percent': pnl_percent,
                'current_price': current_price,
                'price_change': current_price - start_price,
                'price_change_percent': (current_price - start_price) / start_price * 100,
            })
        
        # Calculate weights and contribution
        for h in holdings:
            h['weight'] = h['beginning_mv'] / total_beginning_mv if total_beginning_mv > 0 else Decimal(0)
            h['contribution_to_return'] = h['weight'] * h['pnl_percent']
            h['contribution_bps'] = h['contribution_to_return'] * 10000
        
        return [PortfolioHolding(**h) for h in holdings]
    
    async def get_intraday_performance(
        self, 
        portfolio_id: str,
        benchmark_id: str | None,
        interval: str
    ) -> list[IntradayDataPoint]:
        """Calculate intraday performance series."""
        
        # Get today's starting values
        positions = await self.db.fetch_positions(portfolio_id)
        start_of_day = datetime.combine(date.today(), time(9, 30))
        
        # Get intraday prices at intervals
        timestamps = self._generate_timestamps(start_of_day, interval)
        
        data_points = []
        initial_portfolio_value = None
        initial_benchmark_value = None
        
        for ts in timestamps:
            portfolio_value = Decimal(0)
            
            for pos in positions:
                price = await self.market_data.get_price_at(pos.symbol, ts)
                portfolio_value += pos.quantity * price
            
            if initial_portfolio_value is None:
                initial_portfolio_value = portfolio_value
            
            portfolio_return = (portfolio_value - initial_portfolio_value) / initial_portfolio_value
            
            # Benchmark
            benchmark_return = None
            if benchmark_id:
                benchmark_price = await self.market_data.get_price_at(benchmark_id, ts)
                if initial_benchmark_value is None:
                    initial_benchmark_value = benchmark_price
                benchmark_return = (benchmark_price - initial_benchmark_value) / initial_benchmark_value
            
            data_points.append(IntradayDataPoint(
                timestamp=ts,
                portfolio_return=portfolio_return,
                benchmark_return=benchmark_return,
                excess_return=portfolio_return - benchmark_return if benchmark_return else None
            ))
        
        return data_points
```

---

## SQL Schema

```sql
-- Portfolio positions (current holdings)
CREATE TABLE portfolio_positions (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL REFERENCES portfolios(portfolio_id),
    security_id UUID NOT NULL REFERENCES securities(security_id),
    
    quantity DECIMAL(18,6) NOT NULL,
    cost_basis DECIMAL(18,4),
    acquisition_date DATE,
    
    -- Classification overrides
    sector_override VARCHAR(50),
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, security_id),
    INDEX idx_positions_portfolio (portfolio_id)
);

-- Historical position snapshots (end of day)
CREATE TABLE position_snapshots (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    security_id UUID NOT NULL,
    snapshot_date DATE NOT NULL,
    
    quantity DECIMAL(18,6) NOT NULL,
    price DECIMAL(18,6) NOT NULL,
    market_value DECIMAL(18,4) NOT NULL,
    
    -- Period returns
    daily_return DECIMAL(12,8),
    mtd_return DECIMAL(12,8),
    ytd_return DECIMAL(12,8),
    
    -- Contribution
    weight DECIMAL(10,8),
    contribution_1d DECIMAL(12,8),
    contribution_mtd DECIMAL(12,8),
    contribution_ytd DECIMAL(12,8),
    
    INDEX idx_snapshots_portfolio_date (portfolio_id, snapshot_date DESC),
    INDEX idx_snapshots_date (snapshot_date)
);

-- Intraday portfolio values (for intraday chart)
CREATE TABLE portfolio_intraday (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    
    total_market_value DECIMAL(18,4) NOT NULL,
    cash_balance DECIMAL(18,4),
    nav DECIMAL(18,4),
    
    cumulative_return DECIMAL(12,8),
    
    INDEX idx_intraday_portfolio_ts (portfolio_id, timestamp DESC)
);

-- Top contributors cache (refreshed periodically)
CREATE TABLE portfolio_contributors (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    period VARCHAR(10) NOT NULL,  -- '1D', 'MTD', 'YTD'
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    
    contribution_bps DECIMAL(12,4) NOT NULL,
    pnl DECIMAL(18,4) NOT NULL,
    
    rank_positive INTEGER,  -- Rank among contributors (NULL if detractor)
    rank_negative INTEGER,  -- Rank among detractors (NULL if contributor)
    
    UNIQUE (portfolio_id, as_of_date, period, security_id),
    INDEX idx_contributors_lookup (portfolio_id, as_of_date, period)
);

-- Sector aggregates
CREATE TABLE portfolio_sector_summary (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    as_of_date DATE NOT NULL,
    period VARCHAR(10) NOT NULL,
    sector VARCHAR(50) NOT NULL,
    
    holdings_count INTEGER,
    market_value DECIMAL(18,4),
    weight DECIMAL(10,8),
    
    -- Benchmark comparison
    benchmark_weight DECIMAL(10,8),
    active_weight DECIMAL(10,8),
    
    -- Performance
    contribution_bps DECIMAL(12,4),
    
    UNIQUE (portfolio_id, as_of_date, period, sector),
    INDEX idx_sector_summary (portfolio_id, as_of_date, period)
);
```

---

## Key Features

### 1. Real-time Price Updates
```typescript
function useRealtimeHoldings(portfolioId: string) {
  const [holdings, setHoldings] = useState<PortfolioHolding[]>([]);
  
  useEffect(() => {
    // Initial load
    fetchHoldings(portfolioId).then(setHoldings);
    
    // Subscribe to price updates
    const ws = new WebSocket(`/ws/portfolio/${portfolioId}/stream`);
    
    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      
      setHoldings(prev => prev.map(holding => {
        if (holding.symbol === update.symbol) {
          const newPnL = (update.price - holding.previousClose) * holding.quantity;
          return {
            ...holding,
            currentPrice: update.price,
            priceChange: update.price - holding.previousClose,
            priceChangePercent: (update.price - holding.previousClose) / holding.previousClose * 100,
            pnl: newPnL,
            marketValue: update.price * holding.quantity,
          };
        }
        return holding;
      }));
    };
    
    return () => ws.close();
  }, [portfolioId]);
  
  return holdings;
}
```

### 2. Period Selector
```typescript
type Period = '1D' | '5D' | 'MTD' | 'QTD' | 'YTD' | '1Y' | 'Custom';

function PeriodSelector({ value, onChange }: { value: Period; onChange: (p: Period) => void }) {
  const periods: Period[] = ['1D', '5D', 'MTD', 'QTD', 'YTD', '1Y'];
  
  return (
    <div className="flex items-center gap-1">
      {periods.map(period => (
        <button
          key={period}
          onClick={() => onChange(period)}
          className={clsx(
            'px-3 py-1 text-xs font-medium rounded',
            value === period 
              ? 'bg-blue-600 text-white' 
              : 'bg-[#252536] text-gray-400 hover:bg-[#2d2d43]'
          )}
        >
          {period}
        </button>
      ))}
    </div>
  );
}
```

### 3. Sortable Holdings
```typescript
function HoldingsGrid({ holdings }: { holdings: PortfolioHolding[] }) {
  const [sorting, setSorting] = useState<SortingState>([
    { id: 'contributionBps', desc: true }
  ]);
  
  const table = useReactTable({
    data: holdings,
    columns: holdingsColumns,
    state: { sorting },
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
  });
  
  return (
    <Table>
      <TableHeader>
        {table.getHeaderGroups().map(headerGroup => (
          <TableRow key={headerGroup.id}>
            {headerGroup.headers.map(header => (
              <TableHead 
                key={header.id}
                onClick={header.column.getToggleSortingHandler()}
                className="cursor-pointer hover:bg-[#252536]"
              >
                {flexRender(header.column.columnDef.header, header.getContext())}
                {{
                  asc: ' ↑',
                  desc: ' ↓',
                }[header.column.getIsSorted() as string] ?? null}
              </TableHead>
            ))}
          </TableRow>
        ))}
      </TableHeader>
      <TableBody>
        {table.getRowModel().rows.map(row => (
          <TableRow key={row.id}>
            {row.getVisibleCells().map(cell => (
              <TableCell key={cell.id}>
                {flexRender(cell.column.columnDef.cell, cell.getContext())}
              </TableCell>
            ))}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
```
