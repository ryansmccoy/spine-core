# Trade Simulation & What-If Analysis

## Overview
Simulate hypothetical portfolio changes before execution. Analyze impact on risk, tracking error, sector exposures, and factor tilts. Based on Bloomberg PORT Trade Simulation functionality.

![Reference: PORT Trade Simulation]

---

## UI Components

### 1. Trade Simulation Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │ Characteristics │ VaR │ Tracking Error │ Scenarios │ Performance │ Attribution          │
│                                                               │[Trade Simulation]│                            │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [S&P 500 INDE ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18                │
│ Model: [Bloomberg Ri ▼]                                                                                       │
│                                                                                                               │
│ [ Import Trades ]  [ Clear All ]  [ Save Scenario ]  [ Run Simulation ]                                       │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Trade Entry Panel
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Hypothetical Trades                                                                                             │
├──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                 │
│  Add Trade:  [AAPL US Equity     ▼]  [Buy ▼]  Shares: [1,000  ]  or  Weight: [0.50%]  [+ Add]                 │
│                                                                                                                 │
├─────────────────┬─────────┬─────────┬────────────┬───────────┬────────────┬────────────┬─────────────────────────┤
│ Security        │ Side    │ Shares  │ Notional   │ Curr Wt   │ New Wt     │ Change     │ Actions                 │
├─────────────────┼─────────┼─────────┼────────────┼───────────┼────────────┼────────────┼─────────────────────────┤
│ AAPL US Equity  │ BUY     │ 1,000   │ $175,200   │ 3.50%     │ 3.67%      │ +0.17%     │ [Edit] [×]              │
│ MSFT US Equity  │ BUY     │ 500     │ $205,000   │ 4.20%     │ 4.41%      │ +0.21%     │ [Edit] [×]              │
│ XOM US Equity   │ SELL    │ 2,000   │ -$198,000  │ 2.10%     │ 1.90%      │ -0.20%     │ [Edit] [×]              │
│ JPM US Equity   │ SELL    │ 1,500   │ -$246,000  │ 2.80%     │ 2.55%      │ -0.25%     │ [Edit] [×]              │
├─────────────────┼─────────┼─────────┼────────────┼───────────┼────────────┼────────────┼─────────────────────────┤
│ NET CHANGE      │         │         │ -$63,800   │           │            │ -0.07%     │                         │
└─────────────────┴─────────┴─────────┴────────────┴───────────┴────────────┴────────────┴─────────────────────────┘
```

### 3. Impact Summary
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Simulation Impact Summary                                                                                             │
├────────────────────────────────────────────┬─────────────────────┬─────────────────────┬────────────────────────────────┤
│ Metric                                     │ Current             │ Simulated           │ Change                        │
├────────────────────────────────────────────┼─────────────────────┼─────────────────────┼────────────────────────────────┤
│ Portfolio Value                            │ $100,000,000        │ $99,936,200         │ -$63,800 (-0.06%)             │
│ Total Risk (Volatility)                    │ 11.29%              │ 11.18%              │ ▼ -0.11%                      │
│ Tracking Error                             │ 4.72%               │ 4.65%               │ ▼ -0.07%                      │
│ Beta                                       │ 1.02                │ 1.01                │ -0.01                         │
│ VaR (99%, 1-day)                           │ $2,847,350          │ $2,821,400          │ -$25,950 (-0.91%)             │
│ Active Share                               │ 65.2%               │ 64.8%               │ -0.4%                         │
├────────────────────────────────────────────┼─────────────────────┼─────────────────────┼────────────────────────────────┤
│ Est. Transaction Cost                      │                     │                     │ $12,760 (2bps)                │
│ Est. Market Impact                         │                     │                     │ $8,500 (1.3bps)               │
└────────────────────────────────────────────┴─────────────────────┴─────────────────────┴────────────────────────────────┘
```

### 4. Sector Weight Comparison
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Sector Weight Changes                                                                                                 │
├───────────────────────────────────┬─────────────────┬─────────────────┬─────────────────┬───────────────┬──────────────┤
│ Sector                            │ Benchmark       │ Current         │ Simulated       │ Curr Active   │ Sim Active  │
├───────────────────────────────────┼─────────────────┼─────────────────┼─────────────────┼───────────────┼──────────────┤
│ Information Technology            │ 28.0%           │ 28.5%           │ 28.9%           │ +0.5%         │ +0.9%       │
│ Financials                        │ 13.0%           │ 18.2%           │ 17.9%           │ +5.2%         │ +4.9%       │
│ Health Care                       │ 13.0%           │ 14.1%           │ 14.1%           │ +1.1%         │ +1.1%       │
│ Consumer Discretionary            │ 10.5%           │ 11.8%           │ 11.8%           │ +1.3%         │ +1.3%       │
│ Communication Services            │ 8.5%            │ 9.3%            │ 9.3%            │ +0.8%         │ +0.8%       │
│ Industrials                       │ 8.5%            │ 8.4%            │ 8.4%            │ -0.1%         │ -0.1%       │
│ Energy                            │ 4.5%            │ 2.4%            │ 2.2%            │ -2.1%         │ ▼ -2.3%     │
│ Consumer Staples                  │ 6.5%            │ 4.2%            │ 4.2%            │ -2.3%         │ -2.3%       │
│ Materials                         │ 3.5%            │ 3.1%            │ 3.2%            │ -0.4%         │ -0.3%       │
└───────────────────────────────────┴─────────────────┴─────────────────┴─────────────────┴───────────────┴──────────────┘
```

### 5. Factor Exposure Changes
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Factor Exposure Changes                                                                                               │
├───────────────────────────────────┬─────────────────┬─────────────────┬─────────────────┬───────────────────────────────┤
│ Factor                            │ Benchmark       │ Current         │ Simulated       │ Visualization                 │
├───────────────────────────────────┼─────────────────┼─────────────────┼─────────────────┼───────────────────────────────┤
│ Size                              │ 0.00            │ 0.52            │ 0.58            │ ====|====○======              │
│ Value                             │ 0.05            │ -0.18           │ -0.12           │ ===○=|=====                   │
│ Momentum                          │ 0.12            │ 0.31            │ 0.28            │ =====|===○===                 │
│ Volatility                        │ 0.00            │ -0.08           │ -0.10           │ ===○=|====                    │
│ Quality                           │ 0.15            │ 0.22            │ 0.25            │ =====|==○====                 │
│ Dividend Yield                    │ 0.10            │ 0.05            │ 0.02            │ ====○|====                    │
└───────────────────────────────────┴─────────────────┴─────────────────┴─────────────────┴───────────────────────────────┘
                                                                         ← Underweight    Neutral    Overweight →
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/TradeSimulationPage.tsx

<TradeSimulationPage>
  <SimulationHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <ActionButtons>
      <ImportTradesButton />
      <ClearAllButton />
      <SaveScenarioButton />
      <RunSimulationButton />
    </ActionButtons>
  </SimulationHeader>
  
  <TwoColumnLayout>
    <LeftPanel>
      <TradeEntryPanel onAddTrade={handleAddTrade} />
      <HypotheticalTradesTable trades={trades} />
    </LeftPanel>
    
    <RightPanel>
      <ImpactSummaryCard current={current} simulated={simulated} />
      <SectorWeightComparison />
      <FactorExposureChanges />
    </RightPanel>
  </TwoColumnLayout>
</TradeSimulationPage>
```

### TypeScript Interfaces
```typescript
interface HypotheticalTrade {
  id: string;
  securityId: string;
  symbol: string;
  name: string;
  side: 'BUY' | 'SELL';
  
  // Quantity (one or the other)
  shares?: number;
  targetWeight?: number;
  
  // Calculated fields
  notional: number;
  currentWeight: number;
  newWeight: number;
  weightChange: number;
  
  // Current position info
  currentShares: number;
  price: number;
}

interface SimulationResult {
  portfolioId: string;
  benchmarkId: string;
  asOfDate: Date;
  
  // Overall impact
  currentMetrics: PortfolioMetrics;
  simulatedMetrics: PortfolioMetrics;
  
  // Trades
  trades: HypotheticalTrade[];
  netNotionalChange: number;
  
  // Cost estimates
  estimatedCommission: number;
  estimatedMarketImpact: number;
  totalTransactionCost: number;
  
  // Breakdowns
  sectorComparison: SectorComparison[];
  factorExposureChanges: FactorExposureChange[];
  riskContributionChanges: RiskContributionChange[];
}

interface PortfolioMetrics {
  portfolioValue: number;
  totalRisk: number;
  trackingError: number;
  beta: number;
  var99: number;
  activeShare: number;
}

interface SectorComparison {
  sector: string;
  benchmarkWeight: number;
  currentWeight: number;
  simulatedWeight: number;
  currentActive: number;
  simulatedActive: number;
}

interface FactorExposureChange {
  factorId: string;
  factorName: string;
  benchmarkExposure: number;
  currentExposure: number;
  simulatedExposure: number;
}
```

### Trade Entry Panel
```typescript
function TradeEntryPanel({ onAddTrade }: { onAddTrade: (trade: HypotheticalTrade) => void }) {
  const [symbol, setSymbol] = useState('');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [shares, setShares] = useState<number | undefined>();
  const [weight, setWeight] = useState<number | undefined>();
  
  const handleAdd = () => {
    if (!symbol) return;
    
    onAddTrade({
      id: crypto.randomUUID(),
      symbol,
      side,
      shares,
      targetWeight: weight ? weight / 100 : undefined,
      // ... other fields populated by API lookup
    });
    
    // Reset
    setSymbol('');
    setShares(undefined);
    setWeight(undefined);
  };
  
  return (
    <div className="flex items-center gap-3 p-3 bg-[#252536] rounded">
      <span className="text-gray-400">Add Trade:</span>
      
      <SecurityAutocomplete 
        value={symbol}
        onChange={setSymbol}
        className="w-48"
      />
      
      <select 
        value={side}
        onChange={(e) => setSide(e.target.value as 'BUY' | 'SELL')}
        className="px-3 py-2 bg-[#1a1a2e] text-white rounded"
      >
        <option value="BUY">Buy</option>
        <option value="SELL">Sell</option>
      </select>
      
      <div className="flex items-center gap-2">
        <span className="text-gray-400">Shares:</span>
        <input
          type="number"
          value={shares ?? ''}
          onChange={(e) => {
            setShares(e.target.value ? parseInt(e.target.value) : undefined);
            setWeight(undefined);
          }}
          className="w-24 px-2 py-2 bg-[#1a1a2e] text-white text-right font-mono rounded"
        />
      </div>
      
      <span className="text-gray-500">or</span>
      
      <div className="flex items-center gap-2">
        <span className="text-gray-400">Weight:</span>
        <input
          type="number"
          step="0.01"
          value={weight ?? ''}
          onChange={(e) => {
            setWeight(e.target.value ? parseFloat(e.target.value) : undefined);
            setShares(undefined);
          }}
          className="w-20 px-2 py-2 bg-[#1a1a2e] text-white text-right font-mono rounded"
        />
        <span className="text-gray-500">%</span>
      </div>
      
      <button 
        onClick={handleAdd}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        + Add
      </button>
    </div>
  );
}
```

### Impact Summary Card
```typescript
function ImpactSummaryCard({ 
  current, 
  simulated 
}: { 
  current: PortfolioMetrics; 
  simulated: PortfolioMetrics;
}) {
  const metrics = [
    { label: 'Portfolio Value', current: current.portfolioValue, simulated: simulated.portfolioValue, format: 'currency' },
    { label: 'Total Risk (Volatility)', current: current.totalRisk, simulated: simulated.totalRisk, format: 'percent' },
    { label: 'Tracking Error', current: current.trackingError, simulated: simulated.trackingError, format: 'percent' },
    { label: 'Beta', current: current.beta, simulated: simulated.beta, format: 'decimal' },
    { label: 'VaR (99%, 1-day)', current: current.var99, simulated: simulated.var99, format: 'currency' },
    { label: 'Active Share', current: current.activeShare, simulated: simulated.activeShare, format: 'percent' },
  ];
  
  return (
    <div className="bg-[#252536] p-4 rounded-lg">
      <h3 className="text-white font-medium mb-4">Simulation Impact Summary</h3>
      
      <table className="w-full text-sm">
        <thead>
          <tr className="text-gray-400 border-b border-gray-700">
            <th className="text-left py-2">Metric</th>
            <th className="text-right">Current</th>
            <th className="text-right">Simulated</th>
            <th className="text-right">Change</th>
          </tr>
        </thead>
        <tbody>
          {metrics.map(({ label, current, simulated, format }) => {
            const change = simulated - current;
            const changePercent = current !== 0 ? change / current : 0;
            
            return (
              <tr key={label} className="border-b border-gray-800">
                <td className="py-2 text-white">{label}</td>
                <td className="text-right font-mono text-gray-300">
                  {formatByType(current, format)}
                </td>
                <td className="text-right font-mono text-white">
                  {formatByType(simulated, format)}
                </td>
                <td className={clsx(
                  'text-right font-mono',
                  change > 0 ? 'text-green-400' : change < 0 ? 'text-red-400' : 'text-gray-400'
                )}>
                  {change > 0 && '▲ '}
                  {change < 0 && '▼ '}
                  {formatByType(Math.abs(change), format)}
                  {format === 'currency' && ` (${(changePercent * 100).toFixed(2)}%)`}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
```

### Factor Exposure Visualization
```typescript
function FactorExposureChart({ changes }: { changes: FactorExposureChange[] }) {
  return (
    <div className="space-y-3">
      {changes.map((factor) => (
        <div key={factor.factorId} className="flex items-center gap-4">
          <span className="w-32 text-gray-300">{factor.factorName}</span>
          
          {/* Mini factor exposure bar */}
          <div className="flex-1 relative h-6">
            {/* Center line (benchmark) */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gray-600" />
            
            {/* Current exposure marker */}
            <div 
              className="absolute w-2 h-4 bg-blue-500 rounded top-1"
              style={{ 
                left: `${50 + factor.currentExposure * 25}%`,
                transform: 'translateX(-50%)'
              }}
            />
            
            {/* Simulated exposure marker */}
            <div 
              className="absolute w-3 h-3 border-2 border-orange-500 rounded-full top-1.5"
              style={{ 
                left: `${50 + factor.simulatedExposure * 25}%`,
                transform: 'translateX(-50%)'
              }}
            />
          </div>
          
          {/* Numeric values */}
          <div className="w-20 text-right font-mono">
            <span className="text-blue-400">{factor.currentExposure.toFixed(2)}</span>
            <span className="text-gray-500"> → </span>
            <span className="text-orange-400">{factor.simulatedExposure.toFixed(2)}</span>
          </div>
        </div>
      ))}
      
      <div className="flex justify-between text-xs text-gray-500 mt-2">
        <span>← Underweight</span>
        <span>Neutral</span>
        <span>Overweight →</span>
      </div>
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/simulation")

@router.post("/{portfolio_id}/simulate")
async def run_simulation(
    portfolio_id: str,
    trades: list[HypotheticalTrade],
    benchmark_id: str | None = None
) -> SimulationResult:
    """Run trade simulation and return impact analysis."""
    pass

@router.post("/{portfolio_id}/validate-trade")
async def validate_trade(
    portfolio_id: str,
    trade: HypotheticalTrade
) -> TradeValidation:
    """Validate a single trade and return enriched data."""
    pass

@router.post("/{portfolio_id}/import")
async def import_trades(
    portfolio_id: str,
    file: UploadFile  # CSV/Excel
) -> list[HypotheticalTrade]:
    """Import trades from file."""
    pass

@router.post("/{portfolio_id}/scenarios")
async def save_scenario(
    portfolio_id: str,
    name: str,
    trades: list[HypotheticalTrade]
) -> SimulationScenario:
    """Save trade simulation scenario for later use."""
    pass

@router.get("/{portfolio_id}/scenarios")
async def list_scenarios(
    portfolio_id: str
) -> list[SimulationScenario]:
    """List saved simulation scenarios."""
    pass
```

### Pydantic Models
```python
class HypotheticalTrade(BaseModel):
    security_id: str | None
    symbol: str
    side: Literal['BUY', 'SELL']
    
    shares: int | None
    target_weight: Decimal | None
    
    # Enriched fields (from API)
    name: str | None
    price: Decimal | None
    notional: Decimal | None
    current_weight: Decimal | None
    new_weight: Decimal | None
    weight_change: Decimal | None

class PortfolioMetrics(BaseModel):
    portfolio_value: Decimal
    total_risk: Decimal
    tracking_error: Decimal
    beta: Decimal
    var_99: Decimal
    active_share: Decimal

class SimulationResult(BaseModel):
    portfolio_id: str
    benchmark_id: str | None
    as_of_date: date
    
    current_metrics: PortfolioMetrics
    simulated_metrics: PortfolioMetrics
    
    trades: list[HypotheticalTrade]
    net_notional_change: Decimal
    
    estimated_commission: Decimal
    estimated_market_impact: Decimal
    total_transaction_cost: Decimal
    
    sector_comparison: list[SectorComparison]
    factor_exposure_changes: list[FactorExposureChange]
```

### Simulation Service
```python
class SimulationService:
    async def run_simulation(
        self,
        portfolio_id: str,
        trades: list[HypotheticalTrade],
        benchmark_id: str | None
    ) -> SimulationResult:
        """
        Calculate impact of hypothetical trades on portfolio.
        
        Steps:
        1. Get current portfolio positions and metrics
        2. Apply hypothetical trades to get new positions
        3. Recalculate all metrics with new positions
        4. Compare current vs simulated
        """
        
        # Get current state
        current_positions = await self._get_positions(portfolio_id)
        current_metrics = await self._calculate_metrics(current_positions, benchmark_id)
        
        # Apply trades
        simulated_positions = self._apply_trades(current_positions, trades)
        
        # Calculate new metrics
        simulated_metrics = await self._calculate_metrics(simulated_positions, benchmark_id)
        
        # Calculate transaction costs
        costs = await self._estimate_transaction_costs(trades)
        
        # Get sector comparison
        sectors = await self._compare_sectors(
            current_positions, simulated_positions, benchmark_id
        )
        
        # Get factor exposure changes
        factors = await self._compare_factor_exposures(
            current_positions, simulated_positions, benchmark_id
        )
        
        return SimulationResult(
            portfolio_id=portfolio_id,
            current_metrics=current_metrics,
            simulated_metrics=simulated_metrics,
            trades=trades,
            sector_comparison=sectors,
            factor_exposure_changes=factors,
            **costs
        )
    
    def _apply_trades(
        self,
        positions: list[Position],
        trades: list[HypotheticalTrade]
    ) -> list[Position]:
        """Apply hypothetical trades to position list."""
        
        positions_map = {p.security_id: p.copy() for p in positions}
        
        for trade in trades:
            if trade.security_id in positions_map:
                pos = positions_map[trade.security_id]
                if trade.side == 'BUY':
                    pos.shares += trade.shares
                else:
                    pos.shares -= trade.shares
            else:
                # New position
                positions_map[trade.security_id] = Position(
                    security_id=trade.security_id,
                    shares=trade.shares if trade.side == 'BUY' else -trade.shares
                )
        
        # Remove zero positions
        return [p for p in positions_map.values() if p.shares != 0]
    
    async def _estimate_transaction_costs(
        self,
        trades: list[HypotheticalTrade]
    ) -> dict:
        """Estimate commission and market impact."""
        
        total_notional = sum(abs(t.notional) for t in trades)
        
        # Commission estimate (2 bps)
        commission = total_notional * Decimal('0.0002')
        
        # Market impact (sqrt model)
        impact = Decimal(0)
        for trade in trades:
            security = await self._get_security(trade.security_id)
            adv = await self._get_adv(trade.security_id)
            
            participation = abs(trade.notional) / adv if adv else Decimal(0)
            volatility = security.volatility
            
            # Impact = k * σ * sqrt(Q/ADV)
            trade_impact = Decimal('0.1') * volatility * Decimal(str(math.sqrt(float(participation))))
            impact += trade_impact * abs(trade.notional)
        
        return {
            'estimated_commission': commission,
            'estimated_market_impact': impact,
            'total_transaction_cost': commission + impact
        }
```

---

## SQL Schema

```sql
-- Saved simulation scenarios
CREATE TABLE simulation_scenarios (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    
    created_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    INDEX idx_scenario_portfolio (portfolio_id)
);

-- Trades in saved scenarios
CREATE TABLE scenario_trades (
    id BIGSERIAL PRIMARY KEY,
    scenario_id BIGINT NOT NULL REFERENCES simulation_scenarios(id),
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,
    
    shares INT,
    target_weight DECIMAL(10,8),
    
    INDEX idx_trades_scenario (scenario_id)
);

-- Simulation result history
CREATE TABLE simulation_results (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID,
    scenario_id BIGINT REFERENCES simulation_scenarios(id),
    
    run_at TIMESTAMP DEFAULT NOW(),
    
    -- Current metrics
    current_portfolio_value DECIMAL(18,4),
    current_total_risk DECIMAL(10,6),
    current_tracking_error DECIMAL(10,6),
    current_beta DECIMAL(8,4),
    current_var_99 DECIMAL(18,4),
    current_active_share DECIMAL(10,6),
    
    -- Simulated metrics
    simulated_portfolio_value DECIMAL(18,4),
    simulated_total_risk DECIMAL(10,6),
    simulated_tracking_error DECIMAL(10,6),
    simulated_beta DECIMAL(8,4),
    simulated_var_99 DECIMAL(18,4),
    simulated_active_share DECIMAL(10,6),
    
    -- Costs
    estimated_commission DECIMAL(18,4),
    estimated_market_impact DECIMAL(18,4),
    total_transaction_cost DECIMAL(18,4),
    
    INDEX idx_results_portfolio (portfolio_id, run_at)
);
```
