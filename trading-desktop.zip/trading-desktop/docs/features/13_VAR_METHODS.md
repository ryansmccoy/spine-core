# VaR Methods Comparison

## Overview
Compare Value at Risk (VaR) calculations across different methodologies: Monte Carlo, Historical, and Parametric. Shows aggregate VaR, confidence intervals, and contribution breakdown by sector/security. Based on Bloomberg PORT VaR tab.

![Reference: PORT VaR Tab]

---

## UI Components

### 1. VaR Method Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │ Characteristics │[VaR]│ Tracking Error/Volatility │ Scenarios │ Performance │ Attribution│
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Main View │ VaR Comparison │ Contributors │ Historical Distribution                                           │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [S&P 500 INDE ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18                │
│ Model: [Bloomberg Ri ▼]  Horizon: [1 Day ▼]  Confidence: [99% ▼]                                             │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. VaR Summary Cards
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                        VaR Summary (99% Confidence, 1-Day)                                  │
├─────────────────────────────┬─────────────────────────────┬─────────────────────────────────────────────────┤
│     Monte Carlo VaR         │      Historical VaR         │      Parametric VaR                             │
│                             │                             │                                                 │
│       $2,847,350            │       $2,612,440            │       $2,934,210                                │
│         2.84%               │         2.61%               │         2.93%                                   │
│                             │                             │                                                 │
│  CVaR: $3,412,820 (3.41%)   │  CVaR: $3,156,920 (3.16%)   │  CVaR: $3,520,650 (3.52%)                       │
│                             │                             │                                                 │
│  [10,000 simulations]       │  [252 days lookback]        │  [Variance-Covariance]                          │
└─────────────────────────────┴─────────────────────────────┴─────────────────────────────────────────────────┘
```

### 3. VaR Comparison Table
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Method Comparison                                                                                                   │
├────────────────────────────────┬────────────────┬────────────────┬────────────────┬────────────────┬─────────────────┤
│                                │ Monte Carlo    │ Historical     │ Parametric     │ Benchmark      │ Active VaR     │
├────────────────────────────────┼────────────────┼────────────────┼────────────────┼────────────────┼─────────────────┤
│ VaR (99%, 1-day)               │ $2,847,350     │ $2,612,440     │ $2,934,210     │ $2,156,320     │ $691,030       │
│ VaR %                          │ 2.84%          │ 2.61%          │ 2.93%          │ 2.16%          │ 0.69%          │
│ CVaR (Expected Shortfall)      │ $3,412,820     │ $3,156,920     │ $3,520,650     │ $2,587,580     │ $825,240       │
│ CVaR %                         │ 3.41%          │ 3.16%          │ 3.52%          │ 2.59%          │ 0.83%          │
├────────────────────────────────┼────────────────┼────────────────┼────────────────┼────────────────┼─────────────────┤
│ VaR (95%, 1-day)               │ $1,892,230     │ $1,741,630     │ $1,956,140     │ $1,437,550     │ $454,680       │
│ VaR (99%, 10-day)              │ $9,004,780     │ $8,261,700     │ $9,279,550     │ $6,820,440     │ $2,184,340     │
└────────────────────────────────┴────────────────┴────────────────┴────────────────┴────────────────┴─────────────────┘
```

### 4. VaR by Sector
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ VaR Contribution by Sector (Monte Carlo)                                                                              │
├───────────────────────────────────┬─────────────┬─────────────┬─────────────────────────────────────────────────────────┤
│ Sector                            │ Port Weight │ VaR Contrib │                                                        │
├───────────────────────────────────┼─────────────┼─────────────┼─────────────────────────────────────────────────────────┤
│ Information Technology            │    28.5%    │   $854,205  │ ███████████████████████████████ 30.0%                   │
│ Financials                        │    18.2%    │   $569,470  │ ████████████████████ 20.0%                              │
│ Health Care                       │    14.1%    │   $398,629  │ ██████████████ 14.0%                                    │
│ Consumer Discretionary            │    11.8%    │   $341,682  │ ████████████ 12.0%                                      │
│ Communication Services            │     9.3%    │   $284,735  │ ██████████ 10.0%                                        │
│ Industrials                       │     8.4%    │   $199,315  │ ███████ 7.0%                                            │
│ Consumer Staples                  │     4.2%    │   $114,182  │ ████ 4.0%                                               │
│ Materials                         │     3.1%    │    $56,947  │ ██ 2.0%                                                 │
│ Energy                            │     2.4%    │    $28,185  │ █ 1.0%                                                  │
├───────────────────────────────────┼─────────────┼─────────────┼─────────────────────────────────────────────────────────┤
│ TOTAL                             │   100.0%    │ $2,847,350  │                                                         │
└───────────────────────────────────┴─────────────┴─────────────┴─────────────────────────────────────────────────────────┘
```

### 5. Historical Distribution Chart
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ P&L Distribution (Monte Carlo - 10,000 simulations)                                                               │
│                                                                                                                   │
│    Freq│                                                                                                          │
│    800 │                              ╭───╮                                                                        │
│        │                           ╭──┤   ├──╮                                                                     │
│    600 │                        ╭──┤  │   │  ├──╮                                                                  │
│        │                     ╭──┤  │  │   │  │  ├──╮                                                               │
│    400 │                  ╭──┤  │  │  │   │  │  │  ├──╮                                                            │
│        │               ╭──┤  │  │  │  │   │  │  │  │  ├──╮                                                         │
│    200 │            ╭──┤  │  │  │  │  │   │  │  │  │  │  ├──╮                                                      │
│        │         ╭──┤  │  │  │  │  │  │   │  │  │  │  │  │  ├──╮                                                   │
│      0 │ ────────┴──┴──┴──┴──┴──┴──┴──┴───┴──┴──┴──┴──┴──┴──┴──┴────────                                          │
│        └─────────────────────────────────────────────────────────────────────────                                  │
│         -5%   -4%   -3%   -2%   -1%   0%   +1%   +2%   +3%   +4%   +5%                                            │
│                    ▲                                                                                               │
│                 99% VaR                                                                                            │
│               (-2.84%)                                                                                             │
│                                                                                                                   │
│        ■ Simulated P&L    │ 99% VaR: -2.84%    │ 95% VaR: -1.89%    │ Mean: +0.02%                                 │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/VaRAnalysisPage.tsx

<VaRAnalysisPage>
  <VaRHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <RiskModelSelector />
    <HorizonSelector values={['1 Day', '5 Day', '10 Day', '1 Month']} />
    <ConfidenceSelector values={['95%', '99%', '99.5%']} />
  </VaRHeader>
  
  <VaRSummaryCards methods={['monteCarlo', 'historical', 'parametric']} />
  
  <Tabs>
    <Tab label="Main View">
      <VaRComparisonTable data={varComparison} />
    </Tab>
    <Tab label="Contributors">
      <VaRContributors contributors={sectorContribs} />
      <TopContributorsTable securities={topSecurities} />
    </Tab>
    <Tab label="Historical Distribution">
      <PLDistributionChart simulations={simResults} />
      <HistoricalReturnsChart returns={historicalReturns} />
    </Tab>
  </Tabs>
</VaRAnalysisPage>
```

### TypeScript Interfaces
```typescript
interface VaRResult {
  method: 'monte_carlo' | 'historical' | 'parametric';
  confidence: number;       // 0.95, 0.99, etc.
  horizon: number;          // Days
  
  var: number;              // VaR in dollars
  varPercent: number;       // VaR as % of portfolio
  
  cvar: number;             // Conditional VaR (Expected Shortfall)
  cvarPercent: number;
  
  // Method-specific metadata
  numSimulations?: number;  // For Monte Carlo
  lookbackDays?: number;    // For Historical
}

interface VaRComparison {
  portfolioId: string;
  benchmarkId: string;
  asOfDate: Date;
  
  monteCarlo: VaRResult;
  historical: VaRResult;
  parametric: VaRResult;
  
  benchmarkVaR: VaRResult;
  activeVaR: VaRResult;
}

interface VaRContributor {
  category: string;         // Sector, Country, etc.
  name: string;
  weight: number;
  varContribution: number;
  varContributionPercent: number;
  marginalVaR: number;
  componentVaR: number;
}

interface PLSimulation {
  scenarioId: number;
  pnlDollar: number;
  pnlPercent: number;
}

interface HistoricalReturn {
  date: Date;
  portfolioReturn: number;
  benchmarkReturn: number;
  activeReturn: number;
}
```

### VaR Summary Cards
```typescript
function VaRSummaryCards({ data }: { data: VaRComparison }) {
  const methods = [
    { key: 'monteCarlo', label: 'Monte Carlo VaR', sublabel: `${data.monteCarlo.numSimulations?.toLocaleString()} simulations` },
    { key: 'historical', label: 'Historical VaR', sublabel: `${data.historical.lookbackDays} days lookback` },
    { key: 'parametric', label: 'Parametric VaR', sublabel: 'Variance-Covariance' },
  ];
  
  return (
    <div className="grid grid-cols-3 gap-4">
      {methods.map(({ key, label, sublabel }) => {
        const result = data[key as keyof VaRComparison] as VaRResult;
        
        return (
          <div key={key} className="bg-[#252536] p-4 rounded-lg">
            <h3 className="text-gray-400 text-sm">{label}</h3>
            
            <div className="text-2xl font-mono text-red-400 mt-2">
              {formatCurrency(result.var)}
            </div>
            <div className="text-lg font-mono text-red-400">
              {(result.varPercent * 100).toFixed(2)}%
            </div>
            
            <div className="text-sm text-gray-400 mt-3">
              CVaR: {formatCurrency(result.cvar)} ({(result.cvarPercent * 100).toFixed(2)}%)
            </div>
            
            <div className="text-xs text-gray-500 mt-2">
              [{sublabel}]
            </div>
          </div>
        );
      })}
    </div>
  );
}
```

### VaR Comparison Table
```typescript
const varComparisonColumns: ColumnDef<any>[] = [
  { header: '', accessorKey: 'metric' },
  {
    header: 'Monte Carlo',
    accessorKey: 'monteCarlo',
    cell: ({ row }) => (
      <span className="font-mono text-white">{formatValue(row.original.monteCarlo)}</span>
    ),
  },
  {
    header: 'Historical',
    accessorKey: 'historical',
    cell: ({ row }) => (
      <span className="font-mono text-white">{formatValue(row.original.historical)}</span>
    ),
  },
  {
    header: 'Parametric',
    accessorKey: 'parametric',
    cell: ({ row }) => (
      <span className="font-mono text-white">{formatValue(row.original.parametric)}</span>
    ),
  },
  {
    header: 'Benchmark',
    accessorKey: 'benchmark',
    cell: ({ row }) => (
      <span className="font-mono text-gray-400">{formatValue(row.original.benchmark)}</span>
    ),
  },
  {
    header: 'Active VaR',
    accessorKey: 'active',
    cell: ({ row }) => (
      <span className="font-mono text-orange-400">{formatValue(row.original.active)}</span>
    ),
  },
];

function buildComparisonData(data: VaRComparison): any[] {
  return [
    {
      metric: `VaR (${data.monteCarlo.confidence * 100}%, ${data.monteCarlo.horizon}-day)`,
      monteCarlo: data.monteCarlo.var,
      historical: data.historical.var,
      parametric: data.parametric.var,
      benchmark: data.benchmarkVaR.var,
      active: data.activeVaR.var,
    },
    {
      metric: 'VaR %',
      monteCarlo: data.monteCarlo.varPercent,
      historical: data.historical.varPercent,
      parametric: data.parametric.varPercent,
      benchmark: data.benchmarkVaR.varPercent,
      active: data.activeVaR.varPercent,
    },
    {
      metric: 'CVaR (Expected Shortfall)',
      monteCarlo: data.monteCarlo.cvar,
      historical: data.historical.cvar,
      parametric: data.parametric.cvar,
      benchmark: data.benchmarkVaR.cvar,
      active: data.activeVaR.cvar,
    },
    // ... more metrics
  ];
}
```

### P&L Distribution Chart
```typescript
function PLDistributionChart({ 
  simulations,
  varThresholds
}: { 
  simulations: PLSimulation[];
  varThresholds: { confidence: number; value: number }[];
}) {
  // Create histogram bins
  const bins = useMemo(() => {
    const pnls = simulations.map(s => s.pnlPercent);
    const min = Math.min(...pnls);
    const max = Math.max(...pnls);
    const binCount = 50;
    const binWidth = (max - min) / binCount;
    
    const histogram = Array(binCount).fill(0);
    pnls.forEach(pnl => {
      const binIndex = Math.min(
        Math.floor((pnl - min) / binWidth),
        binCount - 1
      );
      histogram[binIndex]++;
    });
    
    return histogram.map((count, i) => ({
      bin: min + (i + 0.5) * binWidth,
      count,
    }));
  }, [simulations]);
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={bins}>
        <XAxis 
          dataKey="bin" 
          tickFormatter={(v) => `${(v * 100).toFixed(1)}%`}
          stroke="#9ca3af"
        />
        <YAxis stroke="#9ca3af" />
        
        {/* VaR threshold lines */}
        {varThresholds.map(({ confidence, value }) => (
          <ReferenceLine
            key={confidence}
            x={value}
            stroke="#f59e0b"
            strokeDasharray="5 5"
            label={{ 
              value: `${confidence * 100}% VaR`, 
              fill: '#f59e0b',
              position: 'top'
            }}
          />
        ))}
        
        <Bar dataKey="count" fill="#3b82f6" />
      </BarChart>
    </ResponsiveContainer>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/var")

@router.get("/{portfolio_id}")
async def calculate_var(
    portfolio_id: str,
    method: Literal['monte_carlo', 'historical', 'parametric', 'all'] = 'all',
    confidence: float = 0.99,
    horizon: int = 1,
    benchmark_id: str | None = None
) -> VaRResult | VaRComparison:
    """Calculate VaR using specified method(s)."""
    pass

@router.get("/{portfolio_id}/contributors")
async def get_var_contributors(
    portfolio_id: str,
    group_by: Literal['sector', 'country', 'security'] = 'sector',
    method: str = 'monte_carlo',
    confidence: float = 0.99,
    horizon: int = 1
) -> list[VaRContributor]:
    """Get VaR contribution breakdown."""
    pass

@router.get("/{portfolio_id}/simulations")
async def get_simulations(
    portfolio_id: str,
    num_simulations: int = 10000
) -> list[PLSimulation]:
    """Get Monte Carlo simulation results."""
    pass

@router.get("/{portfolio_id}/backtest")
async def backtest_var(
    portfolio_id: str,
    method: str = 'parametric',
    lookback_days: int = 252,
    confidence: float = 0.99
) -> VaRBacktest:
    """Backtest VaR model against actual returns."""
    pass
```

### Pydantic Models
```python
class VaRResult(BaseModel):
    method: Literal['monte_carlo', 'historical', 'parametric']
    confidence: Decimal
    horizon: int
    
    var: Decimal
    var_percent: Decimal
    
    cvar: Decimal
    cvar_percent: Decimal
    
    num_simulations: int | None
    lookback_days: int | None

class VaRComparison(BaseModel):
    portfolio_id: str
    benchmark_id: str | None
    as_of_date: date
    
    monte_carlo: VaRResult
    historical: VaRResult
    parametric: VaRResult
    
    benchmark_var: VaRResult | None
    active_var: VaRResult | None

class VaRContributor(BaseModel):
    category: str
    name: str
    weight: Decimal
    
    var_contribution: Decimal
    var_contribution_percent: Decimal
    marginal_var: Decimal
    component_var: Decimal
```

### VaR Service
```python
class VaRService:
    async def calculate_monte_carlo_var(
        self,
        portfolio_id: str,
        confidence: float,
        horizon: int,
        num_simulations: int = 10000
    ) -> VaRResult:
        """
        Monte Carlo VaR using correlated random draws from factor model.
        
        Steps:
        1. Get factor exposures and covariance matrix
        2. Generate correlated random factor returns
        3. Calculate portfolio P&L for each simulation
        4. Find percentile corresponding to confidence level
        """
        
        # Get portfolio positions and exposures
        positions = await self._get_positions(portfolio_id)
        exposures = await self._get_factor_exposures(portfolio_id)
        cov_matrix = await self._get_covariance_matrix()
        
        # Generate correlated random returns (Cholesky decomposition)
        L = np.linalg.cholesky(cov_matrix)
        random_draws = np.random.standard_normal((num_simulations, len(cov_matrix)))
        factor_returns = random_draws @ L.T
        
        # Scale for horizon
        factor_returns *= np.sqrt(horizon / 252)
        
        # Calculate portfolio P&L for each simulation
        portfolio_returns = factor_returns @ np.array(exposures)
        
        # Add specific risk
        specific_risk = await self._get_specific_risk(positions)
        specific_returns = np.random.normal(0, specific_risk, num_simulations)
        portfolio_returns += specific_returns
        
        # Calculate VaR at confidence level
        var_percentile = 1 - confidence
        var = np.percentile(portfolio_returns, var_percentile * 100)
        
        # Calculate CVaR (Expected Shortfall)
        tail_returns = portfolio_returns[portfolio_returns <= var]
        cvar = np.mean(tail_returns)
        
        portfolio_value = await self._get_portfolio_value(portfolio_id)
        
        return VaRResult(
            method='monte_carlo',
            confidence=Decimal(str(confidence)),
            horizon=horizon,
            var=Decimal(str(-var * portfolio_value)),
            var_percent=Decimal(str(-var)),
            cvar=Decimal(str(-cvar * portfolio_value)),
            cvar_percent=Decimal(str(-cvar)),
            num_simulations=num_simulations
        )
    
    async def calculate_historical_var(
        self,
        portfolio_id: str,
        confidence: float,
        horizon: int,
        lookback_days: int = 252
    ) -> VaRResult:
        """
        Historical VaR using actual portfolio returns.
        
        Steps:
        1. Get historical returns for lookback period
        2. Sort returns from worst to best
        3. Find percentile corresponding to confidence level
        """
        
        returns = await self._get_historical_returns(portfolio_id, lookback_days)
        
        if horizon > 1:
            # Rolling sum for multi-day horizon
            returns = pd.Series(returns).rolling(horizon).sum().dropna().values
        
        var_percentile = 1 - confidence
        var = np.percentile(returns, var_percentile * 100)
        
        tail_returns = returns[returns <= var]
        cvar = np.mean(tail_returns)
        
        portfolio_value = await self._get_portfolio_value(portfolio_id)
        
        return VaRResult(
            method='historical',
            confidence=Decimal(str(confidence)),
            horizon=horizon,
            var=Decimal(str(-var * portfolio_value)),
            var_percent=Decimal(str(-var)),
            cvar=Decimal(str(-cvar * portfolio_value)),
            cvar_percent=Decimal(str(-cvar)),
            lookback_days=lookback_days
        )
    
    async def calculate_parametric_var(
        self,
        portfolio_id: str,
        confidence: float,
        horizon: int
    ) -> VaRResult:
        """
        Parametric (Variance-Covariance) VaR assuming normal distribution.
        
        VaR = z_α × σ_p × √T × Portfolio_Value
        
        Where:
        - z_α = z-score for confidence level
        - σ_p = portfolio volatility
        - T = time horizon in years
        """
        from scipy.stats import norm
        
        portfolio_vol = await self._get_portfolio_volatility(portfolio_id)
        portfolio_value = await self._get_portfolio_value(portfolio_id)
        
        z_score = norm.ppf(confidence)
        
        # Scale for horizon (assuming sqrt(T) scaling)
        horizon_factor = np.sqrt(horizon / 252)
        
        var = z_score * portfolio_vol * horizon_factor
        
        # CVaR for normal distribution
        cvar_factor = norm.pdf(z_score) / (1 - confidence)
        cvar = cvar_factor * portfolio_vol * horizon_factor
        
        return VaRResult(
            method='parametric',
            confidence=Decimal(str(confidence)),
            horizon=horizon,
            var=Decimal(str(var * portfolio_value)),
            var_percent=Decimal(str(var)),
            cvar=Decimal(str(cvar * portfolio_value)),
            cvar_percent=Decimal(str(cvar))
        )
```

---

## SQL Schema

```sql
-- VaR calculation results
CREATE TABLE var_results (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID,
    as_of_date DATE NOT NULL,
    
    method VARCHAR(20) NOT NULL,  -- 'monte_carlo', 'historical', 'parametric'
    confidence DECIMAL(5,4) NOT NULL,
    horizon INT NOT NULL,  -- Days
    
    var_dollar DECIMAL(18,4) NOT NULL,
    var_percent DECIMAL(12,8) NOT NULL,
    cvar_dollar DECIMAL(18,4),
    cvar_percent DECIMAL(12,8),
    
    num_simulations INT,  -- For Monte Carlo
    lookback_days INT,    -- For Historical
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, method, confidence, horizon, as_of_date),
    INDEX idx_var_portfolio (portfolio_id, as_of_date)
);

-- VaR contributors (sector/security level)
CREATE TABLE var_contributors (
    id BIGSERIAL PRIMARY KEY,
    var_result_id BIGINT NOT NULL REFERENCES var_results(id),
    
    group_type VARCHAR(20) NOT NULL,  -- 'sector', 'country', 'security'
    group_id VARCHAR(50) NOT NULL,
    group_name VARCHAR(100) NOT NULL,
    
    weight DECIMAL(10,8),
    var_contribution DECIMAL(18,4),
    var_contribution_percent DECIMAL(12,8),
    marginal_var DECIMAL(18,4),
    component_var DECIMAL(18,4),
    
    INDEX idx_contrib_result (var_result_id)
);

-- Monte Carlo simulation storage (optional - for analysis)
CREATE TABLE mc_simulations (
    id BIGSERIAL PRIMARY KEY,
    var_result_id BIGINT NOT NULL REFERENCES var_results(id),
    
    scenario_number INT NOT NULL,
    pnl_dollar DECIMAL(18,4),
    pnl_percent DECIMAL(12,8),
    
    INDEX idx_mc_result (var_result_id)
);

-- Historical returns for VaR calculation
CREATE TABLE portfolio_daily_returns (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    return_date DATE NOT NULL,
    
    total_return DECIMAL(12,8) NOT NULL,
    price_return DECIMAL(12,8),
    income_return DECIMAL(12,8),
    
    UNIQUE (portfolio_id, return_date),
    INDEX idx_returns_portfolio (portfolio_id, return_date)
);

-- VaR backtesting results
CREATE TABLE var_backtest (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    method VARCHAR(20) NOT NULL,
    confidence DECIMAL(5,4) NOT NULL,
    horizon INT NOT NULL,
    
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_observations INT NOT NULL,
    
    expected_breaches INT NOT NULL,
    actual_breaches INT NOT NULL,
    breach_rate DECIMAL(8,6) NOT NULL,
    
    kupiec_test_stat DECIMAL(12,6),
    kupiec_p_value DECIMAL(8,6),
    
    calculated_at TIMESTAMP DEFAULT NOW()
);
```

---

## Key Formulas

### Parametric VaR
$$VaR_\alpha = z_\alpha \cdot \sigma_p \cdot \sqrt{T} \cdot V$$

Where:
- $z_\alpha$ = z-score for confidence level $\alpha$
- $\sigma_p$ = annualized portfolio volatility
- $T$ = horizon in years
- $V$ = portfolio value

### Conditional VaR (Expected Shortfall)
$$CVaR_\alpha = E[L | L > VaR_\alpha]$$

For normal distribution:
$$CVaR_\alpha = \frac{\phi(z_\alpha)}{1-\alpha} \cdot \sigma_p$$

### Component VaR
$$CVaR_i = w_i \cdot \frac{\partial VaR}{\partial w_i}$$

### Marginal VaR
$$MVaR_i = \frac{\partial VaR}{\partial w_i} = z_\alpha \cdot \frac{Cov(r_i, r_p)}{\sigma_p}$$
