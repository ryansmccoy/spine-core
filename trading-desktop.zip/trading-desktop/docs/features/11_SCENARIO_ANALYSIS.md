# Scenario Analysis & Stress Testing

## Overview
Stress test portfolios against historical events (2008 crisis, Brexit, COVID) and hypothetical shocks (VIX spike, rate changes, equity moves). Based on Bloomberg PORT Scenarios tab.

![Reference: PORT Scenarios Tab]

---

## UI Components

### 1. Scenario Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │ Characteristics │ VaR │ Tracking Error/Volatility │[Scenarios]│ Performance │ Attribution│
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Main View │[Scenario Summary]│ Best & Worst │ Scenario Navigator                                              │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [S&P 500 INDE ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18                │
│ Model: [Bloomberg Ri ▼]                                                                                       │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Scenario Results Grid
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Scenario Summary                                                                                                      │
├──────────────────────────────────────────────────────────────┬─────────────┬─────────────┬─────────────────────────────┤
│ Scenario                                                     │  P&L (+/-)  │ P&L % (+/-) │ Stress MV (+/-)             │
├──────────────────────────────────────────────────────────────┼─────────────┼─────────────┼─────────────────────────────┤
│ ⚠ Debt Ceiling Crisis & Downgrade in 2011                    │   -256,645  │   -2.28     │     -256,645                │
│ ⚠ Vix up 300                                                 │   -211,709  │   -1.88     │     -211,709                │
│ ⚠ Lehman Default - 2008                                      │   -132,028  │   -1.17     │     -132,028                │
│ ⚠ Equities down 10%                                          │   -105,601  │   -0.94     │     -105,601                │
│ ⚠ Brexit 2016                                                │    -28,166  │   -0.25     │      -28,166                │
│ ⚠ EUR up 10% vs. USD                                         │    -17,256  │   -0.15     │      -17,256                │
│ ✓ EUR down 10% vs. USD                                       │    +17,254  │   +0.15     │      +17,254                │
│ ✓ US 10yr treasury +100bps with propagat...                  │    +21,593  │   +0.19     │      +21,593                │
│ ✓ Japan Earthquake in Mar 2011                               │    +83,554  │   +0.74     │      +83,554                │
│ ✓ Equities up 10%                                            │   +105,575  │   +0.94     │     +105,575                │
└──────────────────────────────────────────────────────────────┴─────────────┴─────────────┴─────────────────────────────┘
```

### 3. Scenario Impact Chart
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                              ∠ Annotate                   │
├───────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                          │
│  +1.00% │  ███                                                                             ███           │
│         │  ███                                                                             ███           │
│  +0.50% │  ███                                          ███                                ███           │
│         │  ███                                          ███                                ███           │
│   0.00% │──███──────────────────────────────────────────███───────────────────────────────███──────────  │
│         │        ███       ███                                    ███   ███                              │
│  -0.50% │        ███       ███                                    ███   ███                              │
│         │        ███       ███       ███                          ███   ███                              │
│  -1.00% │        ███       ███       ███                          ███   ███                              │
│         │        ███       ███       ███       ███                ███   ███                              │
│  -1.50% │        ███       ███       ███       ███                ███   ███                              │
│         │        ███       ███       ███       ███                ███   ███                              │
│  -2.00% │        ███       ███       ███       ███                                                       │
│         │        ███                 ███       ███                                                       │
│  -2.50% │        ███                           ███                                                       │
│         └────────────────────────────────────────────────────────────────────────────────────────────────│
│           Equities  US 10yr  EUR up   Brexit  Equities  Japan    EUR down  VIX     Debt                 │
│           up 10%    +100bps  10%      2016    down 10%  2011     10%       up 300  Ceiling              │
│                                                                                                          │
│                               ■ Positive    ■ Negative                                                   │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Custom Scenario Builder
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Create Custom Scenario                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                           │
│ Scenario Name: [My Custom Stress Test                                    ]                                │
│                                                                                                           │
│ Factor Shocks:                                                                                            │
│ ┌─────────────────────────────────────┬─────────────┬─────────────────────────────────────────────────┐  │
│ │ Factor                              │ Shock (%)   │ Slider                                          │  │
│ ├─────────────────────────────────────┼─────────────┼─────────────────────────────────────────────────┤  │
│ │ Equity Market                       │   [-15.0 ]  │ ◀════════●════▶                                 │  │
│ │ US 10Y Treasury Yield               │   [+1.50 ]  │ ◀══════════════●▶                               │  │
│ │ Credit Spread (IG)                  │   [+0.75 ]  │ ◀═════════●════▶                                │  │
│ │ VIX                                 │   [+20.0 ]  │ ◀══════════════════●▶                           │  │
│ │ USD/EUR                             │   [-5.00 ]  │ ◀═══●══════════▶                                │  │
│ └─────────────────────────────────────┴─────────────┴─────────────────────────────────────────────────┘  │
│                                                                                                           │
│                                                          [Cancel]  [Save & Run]                           │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/ScenarioAnalysisPage.tsx

<ScenarioAnalysisPage>
  <ScenarioHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <RiskModelSelector />
    <DateSelector />
  </ScenarioHeader>
  
  <Tabs>
    <Tab label="Scenario Summary">
      <ScenarioResultsGrid scenarios={scenarios} />
      <ScenarioImpactChart scenarios={scenarios} />
    </Tab>
    <Tab label="Best & Worst">
      <BestWorstAnalysis scenarios={scenarios} />
    </Tab>
    <Tab label="Scenario Navigator">
      <ScenarioNavigator 
        historicalScenarios={historical}
        hypotheticalScenarios={hypothetical}
      />
    </Tab>
  </Tabs>
  
  <CustomScenarioBuilder onSave={handleSaveScenario} />
</ScenarioAnalysisPage>
```

### Scenario Types
```typescript
interface StressScenario {
  scenarioId: string;
  name: string;
  description: string;
  category: 'historical' | 'hypothetical' | 'custom';
  
  // Dates for historical scenarios
  eventDate?: Date;
  startDate?: Date;
  endDate?: Date;
  
  // Factor shocks
  shocks: FactorShock[];
  
  // Pre-calculated results (if available)
  preCalculated?: boolean;
}

interface FactorShock {
  factorId: string;
  factorName: string;
  shockValue: number;      // Percentage change
  shockType: 'absolute' | 'relative';
}

interface ScenarioResult {
  scenarioId: string;
  name: string;
  
  // P&L impact
  pnlDollar: number;
  pnlPercent: number;
  stressedMarketValue: number;
  
  // vs Benchmark
  benchmarkPnl?: number;
  activePnl?: number;
  
  // Breakdown by factor
  factorContributions: FactorContribution[];
  
  // Breakdown by sector
  sectorContributions: SectorContribution[];
  
  // Top impacted securities
  topLosers: SecurityImpact[];
  topGainers: SecurityImpact[];
}

interface SecurityImpact {
  symbol: string;
  name: string;
  weight: number;
  pnlDollar: number;
  pnlPercent: number;
}

// Historical scenario library
const HISTORICAL_SCENARIOS: StressScenario[] = [
  {
    scenarioId: 'lehman_2008',
    name: 'Lehman Default - 2008',
    description: 'September 2008 financial crisis following Lehman Brothers bankruptcy',
    category: 'historical',
    eventDate: new Date('2008-09-15'),
    shocks: [
      { factorId: 'equity_market', factorName: 'Equity Market', shockValue: -0.35, shockType: 'relative' },
      { factorId: 'credit_spread_hy', factorName: 'HY Credit Spread', shockValue: 0.08, shockType: 'absolute' },
      { factorId: 'vix', factorName: 'VIX', shockValue: 0.50, shockType: 'absolute' },
    ],
  },
  {
    scenarioId: 'debt_ceiling_2011',
    name: 'Debt Ceiling Crisis & Downgrade in 2011',
    description: 'US debt ceiling crisis and S&P downgrade of US credit rating',
    category: 'historical',
    eventDate: new Date('2011-08-05'),
    shocks: [
      { factorId: 'equity_market', factorName: 'Equity Market', shockValue: -0.17, shockType: 'relative' },
      { factorId: 'us_10y_yield', factorName: 'US 10Y Yield', shockValue: -0.005, shockType: 'absolute' },
    ],
  },
  {
    scenarioId: 'brexit_2016',
    name: 'Brexit 2016',
    description: 'UK vote to leave European Union',
    category: 'historical',
    eventDate: new Date('2016-06-24'),
    shocks: [
      { factorId: 'equity_market', factorName: 'Equity Market', shockValue: -0.05, shockType: 'relative' },
      { factorId: 'gbp_usd', factorName: 'GBP/USD', shockValue: -0.10, shockType: 'relative' },
    ],
  },
  // ... more scenarios
];

const HYPOTHETICAL_SCENARIOS: StressScenario[] = [
  {
    scenarioId: 'equities_down_10',
    name: 'Equities down 10%',
    description: 'Broad equity market decline of 10%',
    category: 'hypothetical',
    shocks: [
      { factorId: 'equity_market', factorName: 'Equity Market', shockValue: -0.10, shockType: 'relative' },
    ],
  },
  {
    scenarioId: 'vix_up_300',
    name: 'VIX up 300%',
    description: 'Volatility spike to 3x current levels',
    category: 'hypothetical',
    shocks: [
      { factorId: 'vix', factorName: 'VIX', shockValue: 2.00, shockType: 'relative' },  // 200% increase = 3x
    ],
  },
  {
    scenarioId: 'rates_up_100bps',
    name: 'US 10yr treasury +100bps',
    description: '100 basis point parallel shift in US rates',
    category: 'hypothetical',
    shocks: [
      { factorId: 'us_10y_yield', factorName: 'US 10Y Yield', shockValue: 0.01, shockType: 'absolute' },
    ],
  },
];
```

### Scenario Results Grid
```typescript
const scenarioColumns: ColumnDef<ScenarioResult>[] = [
  {
    header: 'Scenario',
    accessorKey: 'name',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <span className={row.original.pnlDollar < 0 ? 'text-amber-500' : 'text-green-500'}>
          {row.original.pnlDollar < 0 ? '⚠' : '✓'}
        </span>
        <span className="text-white">{row.original.name}</span>
      </div>
    ),
  },
  {
    header: 'P&L (+/-)',
    accessorKey: 'pnlDollar',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.pnlDollar >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {row.original.pnlDollar >= 0 ? '+' : ''}
        {formatCurrency(row.original.pnlDollar)}
      </span>
    ),
  },
  {
    header: 'P&L % (+/-)',
    accessorKey: 'pnlPercent',
    cell: ({ row }) => (
      <span className={clsx(
        'font-mono',
        row.original.pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {row.original.pnlPercent >= 0 ? '+' : ''}
        {(row.original.pnlPercent * 100).toFixed(2)}%
      </span>
    ),
  },
  {
    header: 'Stress MV (+/-)',
    accessorKey: 'stressedMarketValue',
    cell: ({ row }) => formatCurrency(row.original.stressedMarketValue),
  },
];
```

### Scenario Impact Chart
```typescript
function ScenarioImpactChart({ scenarios }: { scenarios: ScenarioResult[] }) {
  // Sort by impact for better visualization
  const sortedScenarios = useMemo(() => 
    [...scenarios].sort((a, b) => b.pnlPercent - a.pnlPercent),
    [scenarios]
  );
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={sortedScenarios} layout="vertical">
        <XAxis 
          type="number" 
          domain={['dataMin', 'dataMax']}
          tickFormatter={(v) => `${(v * 100).toFixed(1)}%`}
          stroke="#9ca3af"
        />
        <YAxis 
          type="category" 
          dataKey="name" 
          width={200}
          stroke="#9ca3af"
        />
        <ReferenceLine x={0} stroke="#4b5563" />
        <Tooltip 
          formatter={(value: number) => `${(value * 100).toFixed(2)}%`}
          contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}
        />
        <Bar dataKey="pnlPercent">
          {sortedScenarios.map((entry, index) => (
            <Cell 
              key={index} 
              fill={entry.pnlPercent >= 0 ? '#22c55e' : '#ef4444'} 
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
```

### Custom Scenario Builder
```typescript
function CustomScenarioBuilder({ onSave }: { onSave: (scenario: StressScenario) => void }) {
  const [name, setName] = useState('');
  const [shocks, setShocks] = useState<FactorShock[]>([]);
  
  const availableFactors = [
    { id: 'equity_market', name: 'Equity Market', range: [-50, 50] },
    { id: 'us_10y_yield', name: 'US 10Y Treasury Yield', range: [-2, 2] },
    { id: 'credit_spread_ig', name: 'Credit Spread (IG)', range: [-1, 3] },
    { id: 'credit_spread_hy', name: 'Credit Spread (HY)', range: [-2, 8] },
    { id: 'vix', name: 'VIX', range: [-20, 50] },
    { id: 'usd_eur', name: 'USD/EUR', range: [-20, 20] },
    { id: 'oil_price', name: 'Oil Price', range: [-50, 100] },
  ];
  
  const addFactor = (factorId: string) => {
    const factor = availableFactors.find(f => f.id === factorId);
    if (factor) {
      setShocks([...shocks, {
        factorId: factor.id,
        factorName: factor.name,
        shockValue: 0,
        shockType: 'relative',
      }]);
    }
  };
  
  return (
    <div className="bg-[#252536] p-4 rounded-lg">
      <h3 className="text-white font-medium mb-4">Create Custom Scenario</h3>
      
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Scenario Name"
        className="w-full px-3 py-2 bg-[#1a1a2e] text-white rounded mb-4"
      />
      
      <div className="space-y-3">
        {shocks.map((shock, index) => (
          <div key={shock.factorId} className="flex items-center gap-4">
            <span className="text-gray-300 w-48">{shock.factorName}</span>
            <input
              type="number"
              value={shock.shockValue * 100}
              onChange={(e) => updateShock(index, parseFloat(e.target.value) / 100)}
              className="w-24 px-2 py-1 bg-[#1a1a2e] text-white text-right font-mono rounded"
            />
            <span className="text-gray-500">%</span>
            <input
              type="range"
              min={-50}
              max={50}
              value={shock.shockValue * 100}
              onChange={(e) => updateShock(index, parseFloat(e.target.value) / 100)}
              className="flex-1"
            />
          </div>
        ))}
      </div>
      
      <select 
        onChange={(e) => addFactor(e.target.value)}
        className="mt-4 px-3 py-2 bg-[#1a1a2e] text-white rounded"
      >
        <option value="">+ Add Factor</option>
        {availableFactors
          .filter(f => !shocks.some(s => s.factorId === f.id))
          .map(f => (
            <option key={f.id} value={f.id}>{f.name}</option>
          ))
        }
      </select>
      
      <div className="flex justify-end gap-2 mt-4">
        <button className="px-4 py-2 bg-gray-600 text-white rounded">Cancel</button>
        <button 
          onClick={() => onSave({ scenarioId: `custom_${Date.now()}`, name, shocks, category: 'custom' })}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          Save & Run
        </button>
      </div>
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/scenarios")

@router.get("/")
async def list_scenarios(
    category: Literal['historical', 'hypothetical', 'custom', 'all'] = 'all'
) -> list[StressScenario]:
    """List available stress scenarios."""
    pass

@router.post("/{portfolio_id}/run")
async def run_scenario(
    portfolio_id: str,
    scenario_id: str,
    benchmark_id: str | None = None
) -> ScenarioResult:
    """Run a stress scenario on portfolio."""
    pass

@router.post("/{portfolio_id}/run-multiple")
async def run_multiple_scenarios(
    portfolio_id: str,
    scenario_ids: list[str],
    benchmark_id: str | None = None
) -> list[ScenarioResult]:
    """Run multiple scenarios."""
    pass

@router.post("/{portfolio_id}/custom")
async def run_custom_scenario(
    portfolio_id: str,
    scenario: CustomScenarioRequest,
    benchmark_id: str | None = None
) -> ScenarioResult:
    """Run a custom scenario with user-defined shocks."""
    pass

@router.post("/custom")
async def save_custom_scenario(
    scenario: CreateScenarioRequest
) -> StressScenario:
    """Save a custom scenario for reuse."""
    pass
```

### Pydantic Models
```python
class FactorShock(BaseModel):
    factor_id: str
    factor_name: str
    shock_value: Decimal  # As decimal (0.10 = 10%)
    shock_type: Literal['absolute', 'relative']

class StressScenario(BaseModel):
    scenario_id: str
    name: str
    description: str | None
    category: Literal['historical', 'hypothetical', 'custom']
    
    event_date: date | None
    shocks: list[FactorShock]

class ScenarioResult(BaseModel):
    scenario_id: str
    name: str
    
    pnl_dollar: Decimal
    pnl_percent: Decimal
    stressed_market_value: Decimal
    
    benchmark_pnl: Decimal | None
    active_pnl: Decimal | None
    
    factor_contributions: list[FactorContribution]
    sector_contributions: list[SectorContribution]
    
    top_losers: list[SecurityImpact]
    top_gainers: list[SecurityImpact]

class CustomScenarioRequest(BaseModel):
    name: str
    description: str | None
    shocks: list[FactorShock]
```

### Scenario Service
```python
class ScenarioService:
    async def run_scenario(
        self,
        portfolio_id: str,
        scenario: StressScenario,
        benchmark_id: str | None
    ) -> ScenarioResult:
        """
        Apply factor shocks to portfolio and calculate P&L impact.
        
        Impact = Σ (Factor Exposure × Factor Shock × Factor Sensitivity)
        """
        
        # Get portfolio exposures
        exposures = await self.risk_model.get_portfolio_exposures(portfolio_id)
        
        # Get portfolio NAV
        nav = await self._get_portfolio_nav(portfolio_id)
        
        # Calculate impact for each shock
        total_impact = Decimal(0)
        factor_contributions = []
        
        for shock in scenario.shocks:
            exposure = exposures.get(shock.factor_id, Decimal(0))
            
            if shock.shock_type == 'relative':
                # Relative shock: multiply exposure by shock
                contribution = exposure * shock.shock_value
            else:
                # Absolute shock: use factor sensitivity
                sensitivity = await self._get_factor_sensitivity(shock.factor_id)
                contribution = sensitivity * shock.shock_value * exposure
            
            total_impact += contribution
            factor_contributions.append(FactorContribution(
                factor_id=shock.factor_id,
                factor_name=shock.factor_name,
                exposure=exposure,
                shock=shock.shock_value,
                contribution=contribution
            ))
        
        # Calculate security-level impacts
        security_impacts = await self._calculate_security_impacts(
            portfolio_id, scenario.shocks
        )
        
        pnl_dollar = total_impact * nav
        
        # Benchmark impact if provided
        benchmark_pnl = None
        if benchmark_id:
            benchmark_pnl = await self._calculate_benchmark_impact(
                benchmark_id, scenario.shocks
            )
        
        return ScenarioResult(
            scenario_id=scenario.scenario_id,
            name=scenario.name,
            pnl_dollar=pnl_dollar,
            pnl_percent=total_impact,
            stressed_market_value=nav + pnl_dollar,
            benchmark_pnl=benchmark_pnl,
            active_pnl=total_impact - benchmark_pnl if benchmark_pnl else None,
            factor_contributions=factor_contributions,
            top_losers=sorted(security_impacts, key=lambda x: x.pnl_dollar)[:10],
            top_gainers=sorted(security_impacts, key=lambda x: x.pnl_dollar, reverse=True)[:10]
        )
```

---

## SQL Schema

```sql
-- Predefined stress scenarios
CREATE TABLE stress_scenarios (
    scenario_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(20) NOT NULL,  -- 'historical', 'hypothetical', 'custom'
    
    event_date DATE,  -- For historical scenarios
    
    is_active BOOLEAN DEFAULT true,
    is_system BOOLEAN DEFAULT true,  -- false for user-created
    created_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW(),
    
    INDEX idx_scenarios_category (category)
);

-- Factor shocks for each scenario
CREATE TABLE scenario_factor_shocks (
    id BIGSERIAL PRIMARY KEY,
    scenario_id VARCHAR(50) NOT NULL REFERENCES stress_scenarios(scenario_id),
    
    factor_id VARCHAR(50) NOT NULL,
    factor_name VARCHAR(100),
    
    shock_value DECIMAL(12,6) NOT NULL,  -- As decimal
    shock_type VARCHAR(20) NOT NULL,  -- 'absolute', 'relative'
    
    INDEX idx_shocks_scenario (scenario_id)
);

-- Scenario results (cached)
CREATE TABLE scenario_results (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    scenario_id VARCHAR(50) NOT NULL,
    benchmark_id UUID,
    as_of_date DATE NOT NULL,
    
    pnl_dollar DECIMAL(18,4),
    pnl_percent DECIMAL(12,8),
    stressed_market_value DECIMAL(18,4),
    
    benchmark_pnl DECIMAL(12,8),
    active_pnl DECIMAL(12,8),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, scenario_id, as_of_date, benchmark_id),
    INDEX idx_results_portfolio (portfolio_id, as_of_date)
);

-- Factor contributions to scenario results
CREATE TABLE scenario_factor_contributions (
    id BIGSERIAL PRIMARY KEY,
    result_id BIGINT NOT NULL REFERENCES scenario_results(id),
    
    factor_id VARCHAR(50) NOT NULL,
    factor_name VARCHAR(100),
    
    exposure DECIMAL(12,6),
    shock_value DECIMAL(12,6),
    contribution DECIMAL(12,8),
    
    INDEX idx_factor_contrib (result_id)
);

-- Security-level impacts
CREATE TABLE scenario_security_impacts (
    id BIGSERIAL PRIMARY KEY,
    result_id BIGINT NOT NULL REFERENCES scenario_results(id),
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    
    weight DECIMAL(10,8),
    pnl_dollar DECIMAL(18,4),
    pnl_percent DECIMAL(12,8),
    
    INDEX idx_security_impact (result_id)
);
```

---

## Predefined Scenarios

### Historical Scenarios
| Scenario | Date | Key Shocks |
|----------|------|------------|
| Lehman Default 2008 | Sep 2008 | Equities -35%, HY Spread +800bps, VIX +50 |
| Debt Ceiling 2011 | Aug 2011 | Equities -17%, Gold +15% |
| Brexit 2016 | Jun 2016 | Equities -5%, GBP -10% |
| COVID Crash 2020 | Mar 2020 | Equities -34%, VIX +80, Oil -65% |
| Japan Earthquake 2011 | Mar 2011 | Nikkei -20%, JPY +5% |

### Hypothetical Scenarios
| Scenario | Shocks |
|----------|--------|
| Equities down 10% | SPX -10% |
| Equities up 10% | SPX +10% |
| VIX up 300% | VIX +200% (3x) |
| Rates +100bps | 10Y Yield +1% |
| Rates -100bps | 10Y Yield -1% |
| EUR +10% vs USD | EUR/USD +10% |
| EUR -10% vs USD | EUR/USD -10% |
