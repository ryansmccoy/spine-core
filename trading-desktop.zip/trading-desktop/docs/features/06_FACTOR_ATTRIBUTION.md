# Factor-Based Performance Attribution

## Overview
Multi-factor performance attribution decomposing returns by factor exposures (value, growth, momentum, size, volatility, etc.). Based on Bloomberg PORT factor attribution, Barra risk models, and multi-factor portfolio analytics.

![Reference: Factor Attribution View]

---

## UI Components

### 1. Factor Attribution Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Factor Attribution  [MEGA CAP ▼]   Model: [Barra US Equity Model ▼]                                  │
├────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Period: [MTD ▼]  From: 2025-07-01  To: 2025-08-14   Benchmark: [R2000G ▼]                            │
└────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Return Decomposition Summary
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Return Decomposition                                                                                   │
├──────────────────────┬──────────────────────┬──────────────────────┬──────────────────────────────────┤
│   Market Return      │   Factor Return      │   Specific Return    │      Total Portfolio Return     │
│       +3.18%         │       +1.45%         │       +0.79%         │           +5.42%                │
│   ████████████       │    ██████████        │       ████           │      ██████████████████████     │
└──────────────────────┴──────────────────────┴──────────────────────┴──────────────────────────────────┘
```

### 3. Factor Contribution Grid
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Factor Contributions                                                                                                    │
├──────────────────┬──────────┬──────────┬──────────┬───────────┬───────────┬──────────────────────────────────────────────┤
│ Factor           │Port Exp  │Bench Exp │Active Exp│Factor Ret │Contrib    │ Visual                                       │
├──────────────────┼──────────┼──────────┼──────────┼───────────┼───────────┼──────────────────────────────────────────────┤
│ ▸ Style Factors  │          │          │          │           │ +0.89%    │                                              │
│   Momentum       │   0.45   │   0.12   │  +0.33   │   +2.34%  │ +0.77%    │ ██████████████████████████████████████       │
│   Growth         │   0.38   │   0.25   │  +0.13   │   +1.56%  │ +0.20%    │ ██████████                                   │
│   Value          │  -0.22   │   0.15   │  -0.37   │   -0.89%  │ +0.33%    │ █████████████████                            │
│   Quality        │   0.28   │   0.18   │  +0.10   │   +0.45%  │ +0.05%    │ ██                                           │
│   Low Volatility │  -0.35   │   0.05   │  -0.40   │   +1.12%  │ -0.45%    │ ██████████████████████                       │
├──────────────────┼──────────┼──────────┼──────────┼───────────┼───────────┼──────────────────────────────────────────────┤
│ ▸ Industry Factors│         │          │          │           │ +0.34%    │                                              │
│   Technology     │   0.85   │   0.45   │  +0.40   │   +3.45%  │ +1.38%    │ ██████████████████████████████████████████   │
│   Healthcare     │  -0.25   │   0.15   │  -0.40   │   +1.23%  │ -0.49%    │ █████████████████████████                    │
│   Financials     │  -0.15   │   0.12   │  -0.27   │   +2.12%  │ -0.57%    │ ████████████████████████████                 │
│   Consumer Disc  │   0.12   │   0.08   │  +0.04   │   +0.78%  │ +0.03%    │ █                                            │
├──────────────────┼──────────┼──────────┼──────────┼───────────┼───────────┼──────────────────────────────────────────────┤
│ ▸ Country Factors│          │          │          │           │ +0.22%    │                                              │
│   US             │   0.95   │   0.92   │  +0.03   │   +3.18%  │ +0.10%    │ █████                                        │
│   Emerging Mkts  │   0.05   │   0.08   │  -0.03   │   -4.12%  │ +0.12%    │ ██████                                       │
├──────────────────┼──────────┼──────────┼──────────┼───────────┼───────────┼──────────────────────────────────────────────┤
│ Specific Return  │          │          │          │           │ +0.79%    │ ████████████████████████████████████████     │
├──────────────────┼──────────┼──────────┼──────────┼───────────┼───────────┼──────────────────────────────────────────────┤
│ TOTAL            │          │          │          │           │ +2.24%    │                                              │
└──────────────────┴──────────┴──────────┴──────────┴───────────┴───────────┴──────────────────────────────────────────────┘
```

### 4. Factor Exposure Comparison Chart
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Factor Exposure Comparison                                  [Portfolio] [Benchmark] [Active]              │
├───────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                          │
│ Momentum      ████████████████████████  0.45                                                             │
│               ████                      0.12                                                             │
│                                                                                                          │
│ Growth        ███████████████████       0.38                                                             │
│               █████████████             0.25                                                             │
│                                                                                                          │
│ Value         ▓▓▓▓▓▓▓▓▓▓                -0.22                                                            │
│               ████████                  0.15                                                             │
│                                                                                                          │
│ Size          ████████████████          0.32                                                             │
│               ████████████              0.24                                                             │
│                                                                                                          │
│ Volatility    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓         -0.35                                                            │
│               ██                        0.05                                                             │
│                                                                                                          │
│              -0.5     0.0     0.5     1.0     Exposure (Standardized)                                   │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Cumulative Factor Attribution Chart
```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Cumulative Factor Attribution (MTD)                                                                      │
├───────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                          │
│  +2.5% │                                               ████████████████████████████████ Total            │
│        │                                    ████████████                                                 │
│  +2.0% │                         ███████████                                                             │
│        │                                                                                                 │
│  +1.5% │              ████████████                    ═══════════════════════════════ Specific           │
│        │                                                                                                 │
│  +1.0% │    ██████████                        ─────────────────────────────────────── Factor             │
│        │                                                                                                 │
│  +0.5% │ ███                                  ......................................... Market           │
│        │                                                                                                 │
│   0.0% │─────────────────────────────────────────────────────────────────────────────────────            │
│        │                                                                                                 │
│  -0.5% │                                                                                                 │
│        └─────────────────────────────────────────────────────────────────────────────────────            │
│         7/1    7/8    7/15    7/22    7/29    8/5     8/12                                               │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 6. Top Factor Contributors
```
┌───────────────────────────────────────────────────────────────────────────────────────────┐
│ Top Contributors                          │ Top Detractors                               │
├───────────────────────────────────────────┼──────────────────────────────────────────────┤
│ ▲ Technology Exp   +1.38%  ███████████████│ ▼ Financials Exp   -0.57%  ██████████████   │
│ ▲ Momentum         +0.77%  ███████████    │ ▼ Healthcare Exp   -0.49%  ████████████     │
│ ▲ Value Underweight+0.33%  ████████       │ ▼ Low Vol Underw   -0.45%  ███████████      │
│ ▲ Growth           +0.20%  █████          │                                              │
│ ▲ EM Underweight   +0.12%  ███            │                                              │
└───────────────────────────────────────────┴──────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/FactorAttributionPage.tsx

<FactorAttributionPage>
  <FactorHeader>
    <PortfolioSelector />
    <RiskModelSelector models={['Barra USE4', 'Axioma', 'Custom']} />
    <BenchmarkSelector />
    <PeriodSelector />
  </FactorHeader>
  
  <ReturnDecompositionBar 
    marketReturn={data.marketReturn}
    factorReturn={data.factorReturn}
    specificReturn={data.specificReturn}
    totalReturn={data.totalReturn}
  />
  
  <div className="grid grid-cols-2 gap-4">
    <FactorContributionGrid factors={data.factors} />
    <FactorExposureChart exposures={data.exposures} />
  </div>
  
  <Tabs>
    <Tab label="Cumulative">
      <CumulativeFactorChart data={data.timeSeries} />
    </Tab>
    <Tab label="Risk Decomposition">
      <RiskDecompositionView risk={data.riskDecomposition} />
    </Tab>
    <Tab label="Factor Correlation">
      <FactorCorrelationMatrix factors={data.factorCorrelations} />
    </Tab>
  </Tabs>
</FactorAttributionPage>
```

### Factor Attribution Types
```typescript
interface FactorAttribution {
  portfolioId: string;
  benchmarkId: string;
  riskModelId: string;
  periodStart: Date;
  periodEnd: Date;
  
  // Return decomposition
  totalReturn: number;
  marketReturn: number;
  factorReturn: number;
  specificReturn: number;
  
  // Excess return decomposition
  excessReturn: number;
  factorContribution: number;
  specificContribution: number;
  
  // Factor details
  factors: FactorContribution[];
  
  // Factor groups
  factorGroups: FactorGroup[];
}

interface FactorContribution {
  factorId: string;
  factorName: string;
  factorCategory: 'style' | 'industry' | 'country' | 'currency';
  
  // Exposures
  portfolioExposure: number;
  benchmarkExposure: number;
  activeExposure: number;
  
  // Returns
  factorReturn: number;
  contribution: number;
  
  // T-stat for significance
  tStat: number;
}

interface FactorGroup {
  category: string;
  factors: FactorContribution[];
  totalContribution: number;
}

interface FactorExposure {
  factorId: string;
  factorName: string;
  portfolioExposure: number;
  benchmarkExposure: number;
  activeExposure: number;
  
  // For time series
  exposureHistory?: {
    date: Date;
    exposure: number;
  }[];
}
```

### Factor Contribution Calculation
```typescript
/**
 * Factor contribution = Active Exposure × Factor Return
 * 
 * Where:
 * - Active Exposure = Portfolio Exposure - Benchmark Exposure
 * - Factor Return = Return of factor during period
 */
function calculateFactorContribution(
  portfolioExposure: number,
  benchmarkExposure: number,
  factorReturn: number
): number {
  const activeExposure = portfolioExposure - benchmarkExposure;
  return activeExposure * factorReturn;
}

// Example: If portfolio has momentum exposure of 0.45 and benchmark 0.12,
// and momentum factor returned 2.34% for the period:
// Contribution = (0.45 - 0.12) × 0.0234 = 0.33 × 0.0234 = 0.77%
```

### Factor Contribution Grid Component
```typescript
function FactorContributionGrid({ factorGroups }: { factorGroups: FactorGroup[] }) {
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(factorGroups.map(g => g.category))
  );
  
  const toggleGroup = (category: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(category)) {
        next.delete(category);
      } else {
        next.add(category);
      }
      return next;
    });
  };
  
  return (
    <div className="space-y-1">
      {factorGroups.map(group => (
        <div key={group.category}>
          {/* Group Header */}
          <div 
            className="flex items-center gap-2 px-2 py-1 bg-[#252536] cursor-pointer hover:bg-[#2d2d43]"
            onClick={() => toggleGroup(group.category)}
          >
            <ChevronRight 
              className={clsx('h-4 w-4 transition-transform', 
                expandedGroups.has(group.category) && 'rotate-90'
              )} 
            />
            <span className="text-white font-medium">{group.category}</span>
            <div className="ml-auto">
              <ContributionCell value={group.totalContribution} />
            </div>
          </div>
          
          {/* Factor Rows */}
          {expandedGroups.has(group.category) && (
            <div className="bg-[#1a1a2e]">
              {group.factors.map(factor => (
                <FactorRow key={factor.factorId} factor={factor} />
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function FactorRow({ factor }: { factor: FactorContribution }) {
  return (
    <div className="grid grid-cols-7 gap-2 px-4 py-1 text-sm border-b border-gray-800 hover:bg-[#252536]">
      <div className="text-gray-300 pl-4">{factor.factorName}</div>
      <div className="text-right font-mono">{factor.portfolioExposure.toFixed(2)}</div>
      <div className="text-right font-mono">{factor.benchmarkExposure.toFixed(2)}</div>
      <div className={clsx(
        'text-right font-mono',
        factor.activeExposure >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {factor.activeExposure >= 0 ? '+' : ''}{factor.activeExposure.toFixed(2)}
      </div>
      <div className={clsx(
        'text-right font-mono',
        factor.factorReturn >= 0 ? 'text-green-400' : 'text-red-400'
      )}>
        {formatPercent(factor.factorReturn, { showSign: true })}
      </div>
      <div>
        <ContributionCell value={factor.contribution} />
      </div>
      <div className="w-24">
        <ContributionBar value={factor.contribution} maxValue={0.015} />
      </div>
    </div>
  );
}
```

### Factor Exposure Chart
```typescript
function FactorExposureChart({ exposures }: { exposures: FactorExposure[] }) {
  const sortedExposures = useMemo(() => 
    [...exposures].sort((a, b) => Math.abs(b.activeExposure) - Math.abs(a.activeExposure)),
    [exposures]
  );
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart 
        data={sortedExposures} 
        layout="vertical"
        margin={{ left: 100 }}
      >
        <XAxis type="number" domain={[-1, 1]} stroke="#9ca3af" />
        <YAxis type="category" dataKey="factorName" stroke="#9ca3af" />
        <ReferenceLine x={0} stroke="#4b5563" />
        <Tooltip 
          formatter={(value: number) => value.toFixed(2)}
          labelStyle={{ color: '#fff' }}
          contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}
        />
        <Legend />
        <Bar 
          dataKey="portfolioExposure" 
          fill="#3b82f6" 
          name="Portfolio"
          barSize={12}
        />
        <Bar 
          dataKey="benchmarkExposure" 
          fill="#6b7280" 
          name="Benchmark"
          barSize={12}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/factor-attribution")

@router.get("/{portfolio_id}")
async def get_factor_attribution(
    portfolio_id: str,
    benchmark_id: str,
    risk_model: str = 'USE4',
    period: str = 'MTD',
    start_date: date | None = None,
    end_date: date | None = None
) -> FactorAttributionResponse:
    """Calculate factor-based attribution."""
    pass

@router.get("/{portfolio_id}/exposures")
async def get_factor_exposures(
    portfolio_id: str,
    benchmark_id: str | None = None,
    risk_model: str = 'USE4',
    as_of_date: date | None = None
) -> list[FactorExposure]:
    """Get current factor exposures."""
    pass

@router.get("/{portfolio_id}/time-series")
async def get_factor_time_series(
    portfolio_id: str,
    benchmark_id: str,
    risk_model: str = 'USE4',
    period: str = 'MTD'
) -> FactorTimeSeriesResponse:
    """Get cumulative factor attribution over time."""
    pass

@router.get("/models")
async def list_risk_models() -> list[RiskModel]:
    """List available risk models."""
    pass

@router.get("/models/{model_id}/factors")
async def get_model_factors(model_id: str) -> list[FactorDefinition]:
    """Get factors in a risk model."""
    pass
```

### Pydantic Models
```python
class FactorContribution(BaseModel):
    factor_id: str
    factor_name: str
    factor_category: Literal['style', 'industry', 'country', 'currency']
    
    portfolio_exposure: Decimal
    benchmark_exposure: Decimal
    active_exposure: Decimal
    
    factor_return: Decimal
    contribution: Decimal
    
    t_stat: Decimal | None

class FactorGroup(BaseModel):
    category: str
    factors: list[FactorContribution]
    total_contribution: Decimal

class FactorAttributionResponse(BaseModel):
    portfolio_id: str
    benchmark_id: str
    risk_model: str
    period_start: date
    period_end: date
    
    # Return decomposition
    total_return: Decimal
    market_return: Decimal
    factor_return: Decimal
    specific_return: Decimal
    
    # Excess decomposition
    excess_return: Decimal
    factor_contribution: Decimal
    specific_contribution: Decimal
    
    # Factor groups
    factor_groups: list[FactorGroup]

class FactorExposure(BaseModel):
    factor_id: str
    factor_name: str
    factor_category: str
    
    portfolio_exposure: Decimal
    benchmark_exposure: Decimal | None
    active_exposure: Decimal | None
```

### Factor Attribution Service
```python
class FactorAttributionService:
    def __init__(self, risk_model_service: RiskModelService):
        self.risk_model = risk_model_service
    
    async def calculate_factor_attribution(
        self,
        portfolio_id: str,
        benchmark_id: str,
        risk_model_id: str,
        start_date: date,
        end_date: date
    ) -> FactorAttributionResponse:
        """
        Calculate factor-based performance attribution.
        
        Total Return = Market Return + Factor Return + Specific Return
        
        Factor Return = Σ (Active Exposure × Factor Return)
        Specific Return = Total - Market - Factor
        """
        
        # Get portfolio and benchmark holdings
        portfolio = await self._get_portfolio_weights(portfolio_id, start_date)
        benchmark = await self._get_benchmark_weights(benchmark_id, start_date)
        
        # Get factor exposures
        portfolio_exposures = await self.risk_model.get_portfolio_exposures(
            portfolio, risk_model_id
        )
        benchmark_exposures = await self.risk_model.get_portfolio_exposures(
            benchmark, risk_model_id
        )
        
        # Get factor returns for period
        factor_returns = await self.risk_model.get_factor_returns(
            risk_model_id, start_date, end_date
        )
        
        # Get market return (beta exposure × market return)
        market_return = await self._calculate_market_return(
            portfolio_exposures, benchmark_exposures, factor_returns
        )
        
        # Calculate factor contributions
        factors = []
        total_factor_contribution = Decimal(0)
        
        for factor_id, factor_def in self.risk_model.get_factors(risk_model_id).items():
            port_exp = portfolio_exposures.get(factor_id, Decimal(0))
            bench_exp = benchmark_exposures.get(factor_id, Decimal(0))
            active_exp = port_exp - bench_exp
            factor_ret = factor_returns.get(factor_id, Decimal(0))
            
            contribution = active_exp * factor_ret
            total_factor_contribution += contribution
            
            factors.append(FactorContribution(
                factor_id=factor_id,
                factor_name=factor_def.name,
                factor_category=factor_def.category,
                portfolio_exposure=port_exp,
                benchmark_exposure=bench_exp,
                active_exposure=active_exp,
                factor_return=factor_ret,
                contribution=contribution
            ))
        
        # Calculate total and specific returns
        total_return = await self._get_portfolio_return(portfolio_id, start_date, end_date)
        benchmark_return = await self._get_portfolio_return(benchmark_id, start_date, end_date)
        specific_return = total_return - market_return - total_factor_contribution
        
        # Group factors by category
        factor_groups = self._group_factors(factors)
        
        return FactorAttributionResponse(
            portfolio_id=portfolio_id,
            benchmark_id=benchmark_id,
            risk_model=risk_model_id,
            period_start=start_date,
            period_end=end_date,
            total_return=total_return,
            market_return=market_return,
            factor_return=total_factor_contribution,
            specific_return=specific_return,
            excess_return=total_return - benchmark_return,
            factor_contribution=total_factor_contribution,
            specific_contribution=specific_return,
            factor_groups=factor_groups
        )
    
    def _group_factors(self, factors: list[FactorContribution]) -> list[FactorGroup]:
        """Group factors by category."""
        groups = defaultdict(list)
        for f in factors:
            groups[f.factor_category].append(f)
        
        return [
            FactorGroup(
                category=cat.title() + ' Factors',
                factors=sorted(fs, key=lambda x: abs(x.contribution), reverse=True),
                total_contribution=sum(f.contribution for f in fs)
            )
            for cat, fs in groups.items()
        ]
```

---

## SQL Schema

```sql
-- Risk model definitions
CREATE TABLE risk_models (
    model_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    provider VARCHAR(50),  -- 'Barra', 'Axioma', 'Custom'
    
    -- Model parameters
    factor_count INTEGER,
    estimation_universe VARCHAR(50),
    
    is_active BOOLEAN DEFAULT true,
    
    INDEX idx_risk_models_active (is_active)
);

-- Factor definitions within risk models
CREATE TABLE risk_factors (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(20) NOT NULL REFERENCES risk_models(model_id),
    factor_id VARCHAR(50) NOT NULL,
    factor_name VARCHAR(100) NOT NULL,
    
    category VARCHAR(20) NOT NULL,  -- 'style', 'industry', 'country', 'currency'
    sub_category VARCHAR(50),
    
    description TEXT,
    
    UNIQUE (model_id, factor_id),
    INDEX idx_factors_model (model_id)
);

-- Security factor exposures (point-in-time)
CREATE TABLE security_factor_exposures (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(20) NOT NULL,
    security_id UUID NOT NULL,
    factor_id VARCHAR(50) NOT NULL,
    as_of_date DATE NOT NULL,
    
    exposure DECIMAL(10,6) NOT NULL,
    
    UNIQUE (model_id, security_id, factor_id, as_of_date),
    INDEX idx_exposures_date (model_id, as_of_date),
    INDEX idx_exposures_security (security_id, as_of_date)
);

-- Factor returns
CREATE TABLE factor_returns (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(20) NOT NULL,
    factor_id VARCHAR(50) NOT NULL,
    return_date DATE NOT NULL,
    
    daily_return DECIMAL(12,8) NOT NULL,
    cumulative_mtd DECIMAL(12,8),
    cumulative_qtd DECIMAL(12,8),
    cumulative_ytd DECIMAL(12,8),
    
    UNIQUE (model_id, factor_id, return_date),
    INDEX idx_factor_returns (model_id, return_date)
);

-- Pre-calculated portfolio factor exposures
CREATE TABLE portfolio_factor_exposures (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    model_id VARCHAR(20) NOT NULL,
    as_of_date DATE NOT NULL,
    
    factor_id VARCHAR(50) NOT NULL,
    exposure DECIMAL(10,6) NOT NULL,
    
    UNIQUE (portfolio_id, model_id, as_of_date, factor_id),
    INDEX idx_portfolio_exposures (portfolio_id, model_id, as_of_date)
);

-- Factor attribution results
CREATE TABLE factor_attribution (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID NOT NULL,
    model_id VARCHAR(20) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    
    -- Return decomposition
    total_return DECIMAL(12,8),
    market_return DECIMAL(12,8),
    factor_return DECIMAL(12,8),
    specific_return DECIMAL(12,8),
    
    -- Excess decomposition
    excess_return DECIMAL(12,8),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, benchmark_id, model_id, period_start, period_end),
    INDEX idx_factor_attribution (portfolio_id, period_end DESC)
);

-- Factor-level attribution details
CREATE TABLE factor_attribution_detail (
    id BIGSERIAL PRIMARY KEY,
    attribution_id BIGINT NOT NULL REFERENCES factor_attribution(id),
    
    factor_id VARCHAR(50) NOT NULL,
    factor_name VARCHAR(100),
    factor_category VARCHAR(20),
    
    portfolio_exposure DECIMAL(10,6),
    benchmark_exposure DECIMAL(10,6),
    active_exposure DECIMAL(10,6),
    
    factor_return DECIMAL(12,8),
    contribution DECIMAL(12,8),
    
    INDEX idx_factor_detail (attribution_id)
);
```

---

## Key Calculations

### 1. Return Decomposition
```
Total Return = Market Return + Factor Return + Specific Return

Market Return = β_portfolio × R_market
Factor Return = Σ (Active_Exposure_i × Factor_Return_i)
Specific Return = Total - Market - Factor (residual)
```

### 2. Factor Contribution
```
Factor Contribution = Active Exposure × Factor Return

Active Exposure = Portfolio Exposure - Benchmark Exposure

Example:
- Portfolio Momentum Exposure: 0.45
- Benchmark Momentum Exposure: 0.12
- Momentum Factor Return (MTD): +2.34%

Contribution = (0.45 - 0.12) × 2.34% = 0.77%
```

### 3. Specific Return
```
Specific Return captures idiosyncratic security selection beyond factor tilts

Specific = Σ (w_i × r_specific_i)

Where:
- w_i = security weight
- r_specific_i = security return unexplained by factors
```

### 4. Risk Model Factor Categories
```
Style Factors:
- Momentum: Price momentum over trailing period
- Value: Book-to-market, earnings yield
- Growth: Earnings growth, sales growth
- Size: Market capitalization
- Volatility: Historical price volatility
- Quality: ROE, debt ratios

Industry Factors:
- Technology, Healthcare, Financials, etc.

Country Factors:
- US, Europe, Emerging Markets, etc.

Currency Factors:
- USD, EUR, JPY exposures
```
