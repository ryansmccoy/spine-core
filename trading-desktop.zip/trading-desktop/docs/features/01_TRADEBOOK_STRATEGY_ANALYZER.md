# Tradebook Strategy Analyzer (EMSX-Style)

## Overview
Real-time algorithmic order execution monitoring with market microstructure analytics. Based on Bloomberg's EMSX Tradebook interface.

![Reference: Bloomberg Tradebook Strategy Analyzer]

---

## UI Components

### 1. Order Header Bar
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ B BSMART 50000 @ 85 (13:01-16:00)  Order Qty │ Fill Qty │ Rem. Qty │ Limit     │
│ [Strategy Dropdown]                 50,000   │  22,992  │  27,008  │ 85.000    │
│                                    Avg Px vs Arr Px │ Part Rate                 │
│                                    84.998 -0.351bp  │ 30.779%                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Fields:**
- Symbol + Side indicator (B=Buy, S=Sell)
- Strategy name (BSMART, VWAP, TWAP, etc.)
- Target quantity and limit price
- Execution schedule (start-end time)
- Fill/Remaining quantities
- Slippage vs Arrival Price (in basis points)
- Participation rate vs market volume

### 2. Order Book Depth (Level 2)
```
┌──────────────────────────────────────────────────────────────────┐
│ Total │ Ord │ Size │  Bid   │  Ask   │ Size │ Ord │ Total        │
├───────┼─────┼──────┼────────┼────────┼──────┼─────┼──────────────┤
│   1   │  1  │   1  │ 84.99  │ 85.00  │ 2.02 │  1  │ 2.02         │
│   6   │  1  │   5  │ 84.98  │ 85.01  │ 3.50 │  1  │ 5.52         │
│   8   │  1  │   2  │ 84.97  │ 85.03  │  2   │  1  │ 7.52         │
│  12   │  1  │   4  │ 84.96  │ 85.04  │  1   │     │ 8.52         │
├───────┴─────┴──────┴────────┴────────┴──────┴─────┴──────────────┤
│ LD 81.30 - Security Price Limits - LU 89.86                      │
└──────────────────────────────────────────────────────────────────┘
```

**Columns:**
- Cumulative depth (Total)
- Number of orders at level (Ord)
- Size at price level
- Bid/Ask prices
- Lower/Upper circuit limits

### 3. Predictive Analytics Panel
```
┌─────────────────────────────────────────────────┐
│ Predictive Analytics                            │
├─────────────────────────────────────────────────┤
│ Est Rem Volume      1M      Est Close Auction   │
│ Price Predictor     -0.006  142.2k              │
│ Horizon Minutes     1.0                         │
└─────────────────────────────────────────────────┘
```

**Metrics:**
- Estimated remaining market volume
- Short-term price direction predictor
- Estimated closing auction volume
- Time horizon for predictions

### 4. Intraday Tracker (Execution Quality)
```
┌────────────────────────────────────────────────────────────────────┐
│ Intraday Tracker                               [% of Order ▼]      │
├──────────────┬─────────────────┬────────────────────────────────────┤
│              │ Volume vs Market│ Avg Px vs Interval VWAP           │
├──────────────┼────────┬────────┼────────┬──────────────────────────┤
│ Total        │ 100.0% │ 100.0% │ 84.998 │ 0.011      1.3bp        │
│ Open Auct    │   --   │   --   │   --   │  --         --          │
│ Continuous   │ 100.0% │ 100.0% │ 84.998 │ 0.011      1.3bp        │
│   Bid        │ 61.2%  │ 55.8%  │ 84.999 │ 0.007      0.8bp        │
│   Mid        │ 38.0%  │ 29.4%  │ 84.996 │ 0.013      1.5bp        │
│   Ask        │  0.9%  │ 14.8%  │ 85.000 │ 0.020      2.3bp        │
│ Close Auct   │   --   │   --   │   --   │  --         --          │
│ Blocks       │   --   │   --   │   --   │  --         --          │
│ Dark         │ 13.0%  │ 16.2%  │ 84.998 │ 0.010      1.2bp        │
└──────────────┴────────┴────────┴────────┴──────────────────────────┘
```

**Breakdown by execution type:**
- Auction participation (open/close)
- Continuous market (by price aggressiveness)
- Dark pool executions
- Block trades

### 5. Analysis Charts
```
┌─────────────────────────────────────────────────────────────────┐
│ Analysis Charts  Overlay With [SPX Index ▼]                     │
│ ○ Participation  ○ Cost                                         │
├─────────────────────────────────────────────────────────────────┤
│ [Price Chart with Index Overlay]                                │
│  - White line: Stock price                                      │
│  - Orange line: Index price                                     │
│  - Annotations: Track, Annotate, Zoom controls                  │
├─────────────────────────────────────────────────────────────────┤
│ [Volume/Participation Bar Chart]                                │
│  - Cyan bars: Our participation                                 │
│  - Shows % of market volume captured                            │
├─────────────────────────────────────────────────────────────────┤
│ [Buy/Sell Pressure Chart]                                       │
│  - Green: Buy pressure (1297)                                   │
│  - Red: Sell pressure (36)                                      │
│  - Cumulative imbalance indicator                               │
└─────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### React Components Structure
```typescript
// src/components/trading/TradebookAnalyzer.tsx

interface TradebookAnalyzerProps {
  orderId: string;
  symbol: string;
}

// Sub-components:
// - OrderHeaderBar
// - OrderBookDepth (Level 2)
// - PredictiveAnalyticsPanel
// - IntradayTracker
// - AnalysisCharts (with Recharts/D3)
```

### Key State Management
```typescript
interface TradebookState {
  order: AlgoOrder;
  orderBook: {
    bids: PriceLevel[];
    asks: PriceLevel[];
  };
  predictions: {
    remainingVolume: number;
    pricePredictor: number;
    closeAuctionVolume: number;
    horizonMinutes: number;
  };
  executionBreakdown: {
    category: 'open_auction' | 'continuous' | 'close_auction' | 'dark' | 'block';
    subcategory?: 'bid' | 'mid' | 'ask';
    volumePct: number;
    marketVolumePct: number;
    avgPrice: number;
    vwapDiff: number;
    vwapDiffBps: number;
  }[];
  chartData: {
    timestamp: number;
    price: number;
    indexPrice: number;
    participation: number;
    buyPressure: number;
    sellPressure: number;
  }[];
}
```

### WebSocket Subscription
```typescript
// Real-time updates for order execution
const ws = new WebSocket('/ws/tradebook');
ws.onmessage = (event) => {
  const update = JSON.parse(event.data);
  switch (update.type) {
    case 'FILL':
      updateExecutionBreakdown(update);
      break;
    case 'BOOK_UPDATE':
      setOrderBook(update.book);
      break;
    case 'PREDICTION_UPDATE':
      setPredictions(update.predictions);
      break;
  }
};
```

---

## Backend Implementation (Python FastAPI)

### API Endpoints
```python
from fastapi import APIRouter, WebSocket
from pydantic import BaseModel
from datetime import datetime
from decimal import Decimal

router = APIRouter(prefix="/api/v1/tradebook")

@router.get("/orders/{order_id}/strategy-analysis")
async def get_strategy_analysis(order_id: str) -> StrategyAnalysis:
    """Get full tradebook analysis for an algo order."""
    pass

@router.get("/orders/{order_id}/execution-breakdown")
async def get_execution_breakdown(order_id: str) -> ExecutionBreakdown:
    """Get execution quality breakdown by venue/type."""
    pass

@router.get("/orders/{order_id}/orderbook")
async def get_order_book(order_id: str, levels: int = 5) -> OrderBook:
    """Get current order book snapshot."""
    pass

@router.websocket("/ws/orders/{order_id}/stream")
async def stream_order_updates(websocket: WebSocket, order_id: str):
    """Stream real-time updates for order execution."""
    await websocket.accept()
    # Subscribe to order updates, book updates, predictions
    pass
```

### Pydantic Models
```python
class PriceLevel(BaseModel):
    price: Decimal
    size: int
    order_count: int
    cumulative_size: int

class OrderBook(BaseModel):
    symbol: str
    timestamp: datetime
    bids: list[PriceLevel]
    asks: list[PriceLevel]
    lower_limit: Decimal | None
    upper_limit: Decimal | None

class ExecutionCategory(BaseModel):
    category: str  # 'open_auction', 'continuous', 'close_auction', 'dark', 'block'
    subcategory: str | None  # 'bid', 'mid', 'ask' for continuous
    our_volume_pct: Decimal
    market_volume_pct: Decimal
    avg_price: Decimal
    vwap_diff: Decimal
    vwap_diff_bps: Decimal

class PredictiveAnalytics(BaseModel):
    estimated_remaining_volume: int
    price_predictor: Decimal  # Short-term direction (-1 to 1)
    estimated_close_auction: int
    horizon_minutes: Decimal
    confidence: Decimal

class StrategyAnalysis(BaseModel):
    order_id: str
    symbol: str
    side: str
    strategy: str
    start_time: datetime
    end_time: datetime
    target_qty: int
    filled_qty: int
    remaining_qty: int
    limit_price: Decimal | None
    avg_fill_price: Decimal | None
    arrival_price: Decimal
    slippage_bps: Decimal
    participation_rate: Decimal
    order_book: OrderBook
    predictions: PredictiveAnalytics
    execution_breakdown: list[ExecutionCategory]
```

### Service Layer
```python
class TradebookService:
    def __init__(self, db: Session, market_data: MarketDataService):
        self.db = db
        self.market_data = market_data
    
    async def calculate_execution_breakdown(
        self, order_id: str
    ) -> list[ExecutionCategory]:
        """
        Categorize executions by:
        - Venue type (lit, dark, auction)
        - Price aggressiveness (bid/mid/ask)
        - Time period (open auction, continuous, close auction)
        """
        executions = await self.get_executions(order_id)
        interval_vwaps = await self.calculate_interval_vwaps(order_id)
        
        breakdown = defaultdict(lambda: {
            'fills': [],
            'total_qty': 0,
            'total_notional': Decimal(0)
        })
        
        for exec in executions:
            category = self._categorize_execution(exec)
            breakdown[category]['fills'].append(exec)
            breakdown[category]['total_qty'] += exec.quantity
            breakdown[category]['total_notional'] += exec.notional
        
        return self._compute_metrics(breakdown, interval_vwaps)
    
    async def predict_remaining_volume(self, symbol: str) -> int:
        """Predict remaining volume until close using historical patterns."""
        # Use ML model or historical averages
        pass
```

---

## SQL Schema

```sql
-- Algo order tracking
CREATE TABLE algo_orders (
    order_id UUID PRIMARY KEY,
    parent_order_id UUID REFERENCES orders(order_id),
    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,
    strategy VARCHAR(50) NOT NULL,  -- VWAP, TWAP, IS, POV, etc.
    target_qty INTEGER NOT NULL,
    limit_price DECIMAL(18,6),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    arrival_price DECIMAL(18,6),
    created_at TIMESTAMP DEFAULT NOW(),
    
    -- Algo-specific parameters
    participation_rate DECIMAL(5,4),  -- For POV
    urgency VARCHAR(20),              -- LOW, MEDIUM, HIGH
    dark_pool_only BOOLEAN DEFAULT FALSE,
    
    INDEX idx_algo_orders_symbol (symbol),
    INDEX idx_algo_orders_start (start_time)
);

-- Execution categorization
CREATE TABLE execution_categories (
    execution_id UUID PRIMARY KEY REFERENCES executions(execution_id),
    order_id UUID NOT NULL REFERENCES algo_orders(order_id),
    
    -- Categorization
    venue_type VARCHAR(20) NOT NULL,  -- LIT, DARK, AUCTION, BLOCK
    session_type VARCHAR(20) NOT NULL,  -- OPEN_AUCTION, CONTINUOUS, CLOSE_AUCTION
    aggressiveness VARCHAR(10),  -- BID, MID, ASK (for continuous)
    
    -- Reference prices at execution time
    interval_vwap DECIMAL(18,6),
    market_midpoint DECIMAL(18,6),
    nbbo_bid DECIMAL(18,6),
    nbbo_ask DECIMAL(18,6),
    
    -- Calculated metrics
    vwap_diff_bps DECIMAL(10,4),
    market_volume_at_execution INTEGER,
    
    INDEX idx_exec_cat_order (order_id),
    INDEX idx_exec_cat_venue (venue_type)
);

-- Intraday market statistics (for analysis)
CREATE TABLE intraday_market_stats (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    interval_start TIMESTAMP NOT NULL,
    interval_end TIMESTAMP NOT NULL,
    interval_seconds INTEGER NOT NULL,  -- 60, 300, etc.
    
    vwap DECIMAL(18,6),
    open_price DECIMAL(18,6),
    high_price DECIMAL(18,6),
    low_price DECIMAL(18,6),
    close_price DECIMAL(18,6),
    volume INTEGER,
    trade_count INTEGER,
    
    buy_volume INTEGER,
    sell_volume INTEGER,
    
    UNIQUE (symbol, interval_start, interval_seconds),
    INDEX idx_market_stats_symbol_time (symbol, interval_start)
);

-- Predictive model outputs
CREATE TABLE volume_predictions (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    prediction_time TIMESTAMP NOT NULL,
    horizon_minutes INTEGER NOT NULL,
    
    predicted_volume INTEGER,
    predicted_close_auction INTEGER,
    price_direction DECIMAL(5,4),  -- -1 to 1
    confidence DECIMAL(5,4),
    
    -- Actuals (filled later)
    actual_volume INTEGER,
    actual_close_auction INTEGER,
    
    INDEX idx_predictions_symbol (symbol, prediction_time)
);
```

---

## Key Calculations

### Slippage vs Arrival Price
```python
def calculate_arrival_slippage(
    avg_fill_price: Decimal,
    arrival_price: Decimal,
    side: str
) -> Decimal:
    """Calculate slippage in basis points."""
    if side in ('BUY', 'COVER'):
        slippage = (avg_fill_price - arrival_price) / arrival_price
    else:  # SELL, SHORT
        slippage = (arrival_price - avg_fill_price) / arrival_price
    return slippage * 10000  # Convert to bps
```

### Participation Rate
```python
def calculate_participation_rate(
    our_volume: int,
    market_volume: int,
    start_time: datetime,
    end_time: datetime
) -> Decimal:
    """Calculate % of market volume we captured."""
    if market_volume == 0:
        return Decimal(0)
    return Decimal(our_volume) / Decimal(market_volume)
```

### Price Aggressiveness Classification
```python
def classify_aggressiveness(
    exec_price: Decimal,
    nbbo_bid: Decimal,
    nbbo_ask: Decimal,
    side: str
) -> str:
    """Classify if execution was at bid, mid, or ask."""
    mid = (nbbo_bid + nbbo_ask) / 2
    spread = nbbo_ask - nbbo_bid
    threshold = spread * Decimal('0.25')
    
    if side in ('BUY', 'COVER'):
        if exec_price <= nbbo_bid + threshold:
            return 'BID'
        elif exec_price >= nbbo_ask - threshold:
            return 'ASK'
        else:
            return 'MID'
    else:
        if exec_price >= nbbo_ask - threshold:
            return 'ASK'
        elif exec_price <= nbbo_bid + threshold:
            return 'BID'
        else:
            return 'MID'
```
