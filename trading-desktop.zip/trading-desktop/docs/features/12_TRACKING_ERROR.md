# Tracking Error & Volatility Analysis

## Overview
Decompose portfolio risk (tracking error, total volatility) by factor categories: Country, Industry, Style, Currency, Non-Factor (idiosyncratic). Based on Bloomberg PORT Tracking Error/Volatility tab.

![Reference: PORT Tracking Error Tab]

---

## UI Components

### 1. Tracking Error Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio & Risk Analytics                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Intraday │ Holdings │ Characteristics │ VaR │[Tracking Error/Volatility]│ Scenarios │ Performance │ Attribution│
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│[Risk Summary]│ Risk Comparisons │ Covariance & Correlation                                                   │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [S&P 500 INDE ▼]  by [GICS Sectors ▼]  in [USD ▼]     As of: 02/01/18                │
│ Model: [Bloomberg Ri ▼]                                                                                       │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Risk Decomposition Table
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Risk Summary                                                                                                  │
├────────────────────┬─────────────────────────────────────────────────────────────────────────────────────────────┤
│                    │  Contrib. to Tracking Error │ Contrib. to Benchmark Risk │ Contrib. to Portfolio Risk   │
├────────────────────┼─────────────────────────────┼────────────────────────────┼──────────────────────────────┤
│ Country            │            0.55             │            5.79            │            5.58              │
│ Industry           │            0.19             │            2.04            │            2.25              │
│ Style              │            0.75             │            4.30            │            3.62              │
│ Currency           │           -0.02             │            0.02            │            0.00              │
│ Non-Factor         │            3.26             │            2.07            │            5.32              │
├────────────────────┼─────────────────────────────┼────────────────────────────┼──────────────────────────────┤
│ Total (ex-Beta)    │            4.72             │           10.03            │           11.27              │
│ Systematic Beta    │            0.00             │            0.00            │            0.54              │
├────────────────────┼─────────────────────────────┼────────────────────────────┼──────────────────────────────┤
│ TOTAL              │            4.72             │           10.03            │           11.29              │
└────────────────────┴─────────────────────────────┴────────────────────────────┴──────────────────────────────┘
```

### 3. Tracking Error Decomposition Chart
```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                     Tracking Error Decomposition                                                │
│                                                                                                                 │
│        Non-Factor  ████████████████████████████████████████████████████████████████████  69%  (3.26%)          │
│                                                                                                                 │
│            Style   ████████████████████  16%  (0.75%)                                                           │
│                                                                                                                 │
│          Country   ████████████  12%  (0.55%)                                                                   │
│                                                                                                                 │
│         Industry   █████  4%  (0.19%)                                                                           │
│                                                                                                                 │
│         Currency   █  -0.4%  (-0.02%)                                                                           │
│                                                                                                                 │
└──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Factor-Level Detail
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Style Factor Detail                                                                           [Expand All]            │
├───────────────────────────────────────┬─────────────────┬─────────────────┬─────────────────┬──────────────────────────┤
│ Factor                                │ Port Exposure   │ Bench Exposure  │ Active Exposure │ Contrib to TE           │
├───────────────────────────────────────┼─────────────────┼─────────────────┼─────────────────┼──────────────────────────┤
│ ▸ Size                                │       0.52      │       0.00      │       0.52      │        0.32              │
│ ▸ Value                               │      -0.18      │       0.05      │      -0.23      │        0.15              │
│ ▸ Momentum                            │       0.31      │       0.12      │       0.19      │        0.14              │
│ ▸ Volatility                          │      -0.08      │       0.00      │      -0.08      │        0.07              │
│ ▸ Quality                             │       0.22      │       0.15      │       0.07      │        0.05              │
│ ▸ Dividend Yield                      │       0.05      │       0.10      │      -0.05      │        0.02              │
├───────────────────────────────────────┼─────────────────┼─────────────────┼─────────────────┼──────────────────────────┤
│ TOTAL - Style                         │                 │                 │                 │        0.75              │
└───────────────────────────────────────┴─────────────────┴─────────────────┴─────────────────┴──────────────────────────┘
```

### 5. Historical Tracking Error Chart
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 1Y Rolling Tracking Error                                                                                     │
│                                                                                                               │
│   6.0% │                                                                                                      │
│        │                              ╭──╮                                                                    │
│   5.5% │                          ╭──╯    ╰──╮         ╭──╮                                                   │
│        │                      ╭──╯            ╰──╮ ╭──╯    ╰──╮                                               │
│   5.0% │              ╭──╮ ╭─╯                   ╰╯            ╰──╮                                            │
│        │          ╭──╯    ╰                                       ╰──╮                                        │
│   4.5% │      ╭──╯                                                    ╰─────────────●                         │
│        │  ╭──╯                                                                                                │
│   4.0% │ ╯                                                                                                    │
│        │                                                                                                      │
│   3.5% │                                                                                                      │
│        └────────────────────────────────────────────────────────────────────────────────────────────────────  │
│         Feb   Mar   Apr   May   Jun   Jul   Aug   Sep   Oct   Nov   Dec   Jan   Feb                          │
│         '17   '17   '17   '17   '17   '17   '17   '17   '17   '17   '17   '18   '18                          │
│                                                                                                               │
│        — Tracking Error  ---- Target TE (5.0%)                                                                │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/TrackingErrorPage.tsx

<TrackingErrorPage>
  <RiskHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <RiskModelSelector />
    <DateSelector />
  </RiskHeader>
  
  <Tabs>
    <Tab label="Risk Summary">
      <RiskDecompositionTable data={riskSummary} />
      <TrackingErrorChart categories={categories} />
    </Tab>
    <Tab label="Risk Comparisons">
      <RiskComparisonMatrix portfolios={portfolios} />
    </Tab>
    <Tab label="Covariance & Correlation">
      <CovarianceMatrix factors={factors} />
    </Tab>
  </Tabs>
  
  <FactorDetailAccordion factors={factorDetails} />
  <HistoricalTEChart timeSeries={historicalTE} />
</TrackingErrorPage>
```

### TypeScript Interfaces
```typescript
interface RiskDecomposition {
  portfolioId: string;
  benchmarkId: string;
  asOfDate: Date;
  riskModel: string;
  
  // Summary metrics
  totalTrackingError: number;
  totalPortfolioRisk: number;
  totalBenchmarkRisk: number;
  
  // Category breakdown
  categoryContributions: CategoryContribution[];
  
  // Detail factors
  factorDetails: FactorDetail[];
}

interface CategoryContribution {
  category: 'Country' | 'Industry' | 'Style' | 'Currency' | 'Non-Factor' | 'Systematic Beta';
  
  contribToTE: number;       // Contribution to tracking error
  contribToBenchRisk: number; // Contribution to benchmark risk
  contribToPortRisk: number;  // Contribution to portfolio risk
  
  percentOfTE: number;       // % of total tracking error
}

interface FactorDetail {
  category: string;
  factorId: string;
  factorName: string;
  
  portfolioExposure: number;
  benchmarkExposure: number;
  activeExposure: number;
  
  contribToTE: number;
  factorVolatility: number;
}

interface HistoricalTE {
  date: Date;
  trackingError: number;
  portfolioVol: number;
  benchmarkVol: number;
  correlation: number;
}
```

### Risk Decomposition Table
```typescript
function RiskDecompositionTable({ data }: { data: RiskDecomposition }) {
  const categories = [
    { name: 'Country', key: 'country' },
    { name: 'Industry', key: 'industry' },
    { name: 'Style', key: 'style' },
    { name: 'Currency', key: 'currency' },
    { name: 'Non-Factor', key: 'non_factor' },
  ];
  
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="text-gray-400 border-b border-gray-700">
          <th className="text-left py-2 px-4"></th>
          <th className="text-right px-4">Contrib. to Tracking Error</th>
          <th className="text-right px-4">Contrib. to Benchmark Risk</th>
          <th className="text-right px-4">Contrib. to Portfolio Risk</th>
        </tr>
      </thead>
      <tbody>
        {data.categoryContributions.map((cat) => (
          <tr key={cat.category} className="border-b border-gray-800 hover:bg-[#252536]">
            <td className="py-2 px-4 text-white">{cat.category}</td>
            <td className={clsx(
              'text-right px-4 font-mono',
              cat.contribToTE >= 0 ? 'text-white' : 'text-red-400'
            )}>
              {cat.contribToTE.toFixed(2)}
            </td>
            <td className="text-right px-4 font-mono text-white">
              {cat.contribToBenchRisk.toFixed(2)}
            </td>
            <td className="text-right px-4 font-mono text-white">
              {cat.contribToPortRisk.toFixed(2)}
            </td>
          </tr>
        ))}
        
        {/* Totals */}
        <tr className="border-b border-gray-700 bg-[#1a1a2e] font-medium">
          <td className="py-2 px-4 text-white">Total (ex-Beta)</td>
          <td className="text-right px-4 font-mono text-orange-400">
            {data.totalTrackingError.toFixed(2)}
          </td>
          <td className="text-right px-4 font-mono text-white">
            {data.totalBenchmarkRisk.toFixed(2)}
          </td>
          <td className="text-right px-4 font-mono text-white">
            {data.totalPortfolioRisk.toFixed(2)}
          </td>
        </tr>
      </tbody>
    </table>
  );
}
```

### Tracking Error Chart
```typescript
function TrackingErrorDecompositionChart({ 
  categories 
}: { 
  categories: CategoryContribution[] 
}) {
  const chartData = useMemo(() => 
    categories
      .filter(c => c.category !== 'Systematic Beta')
      .map(c => ({
        name: c.category,
        value: c.contribToTE,
        percent: c.percentOfTE,
        fill: getCategoryColor(c.category),
      }))
      .sort((a, b) => Math.abs(b.value) - Math.abs(a.value)),
    [categories]
  );
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Country': '#3b82f6',    // Blue
      'Industry': '#22c55e',   // Green  
      'Style': '#f59e0b',      // Orange
      'Currency': '#8b5cf6',   // Purple
      'Non-Factor': '#ef4444', // Red
    };
    return colors[category] || '#6b7280';
  };
  
  return (
    <div className="flex gap-8">
      {/* Horizontal bar chart */}
      <div className="flex-1">
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={chartData} layout="vertical">
            <XAxis 
              type="number" 
              tickFormatter={(v) => `${v.toFixed(2)}%`}
              stroke="#9ca3af"
            />
            <YAxis 
              type="category" 
              dataKey="name" 
              width={100}
              stroke="#9ca3af"
            />
            <Tooltip
              formatter={(value: number) => `${value.toFixed(2)}%`}
              contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}
            />
            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
              {chartData.map((entry, index) => (
                <Cell key={index} fill={entry.fill} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      {/* Pie chart */}
      <div className="w-48">
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={chartData}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={80}
              label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
            >
              {chartData.map((entry, index) => (
                <Cell key={index} fill={entry.fill} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
```

### Factor Detail Accordion
```typescript
function FactorDetailAccordion({ factors }: { factors: FactorDetail[] }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  
  const groupedFactors = useMemo(() => 
    factors.reduce((acc, f) => {
      if (!acc[f.category]) acc[f.category] = [];
      acc[f.category].push(f);
      return acc;
    }, {} as Record<string, FactorDetail[]>),
    [factors]
  );
  
  return (
    <div className="space-y-2">
      {Object.entries(groupedFactors).map(([category, categoryFactors]) => (
        <div key={category} className="border border-gray-700 rounded">
          <button
            onClick={() => toggleCategory(category)}
            className="w-full flex items-center justify-between p-3 hover:bg-[#252536]"
          >
            <span className="text-white font-medium">{category} Factor Detail</span>
            <ChevronDown className={clsx(
              'transition-transform',
              expanded.has(category) && 'rotate-180'
            )} />
          </button>
          
          {expanded.has(category) && (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-400 border-t border-gray-700">
                  <th className="text-left py-2 px-4">Factor</th>
                  <th className="text-right px-4">Port Exp</th>
                  <th className="text-right px-4">Bench Exp</th>
                  <th className="text-right px-4">Active Exp</th>
                  <th className="text-right px-4">Contrib to TE</th>
                </tr>
              </thead>
              <tbody>
                {categoryFactors.map((factor) => (
                  <tr key={factor.factorId} className="border-t border-gray-800">
                    <td className="py-2 px-4 text-white">
                      <span className="mr-2">▸</span>
                      {factor.factorName}
                    </td>
                    <td className="text-right px-4 font-mono text-white">
                      {factor.portfolioExposure.toFixed(2)}
                    </td>
                    <td className="text-right px-4 font-mono text-gray-400">
                      {factor.benchmarkExposure.toFixed(2)}
                    </td>
                    <td className={clsx(
                      'text-right px-4 font-mono',
                      factor.activeExposure > 0 ? 'text-green-400' : 'text-red-400'
                    )}>
                      {factor.activeExposure.toFixed(2)}
                    </td>
                    <td className="text-right px-4 font-mono text-orange-400">
                      {factor.contribToTE.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ))}
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/tracking-error")

@router.get("/{portfolio_id}")
async def get_risk_decomposition(
    portfolio_id: str,
    benchmark_id: str,
    risk_model: str = "bloomberg",
    as_of_date: date | None = None
) -> RiskDecomposition:
    """Get tracking error decomposition by factor category."""
    pass

@router.get("/{portfolio_id}/factors")
async def get_factor_details(
    portfolio_id: str,
    benchmark_id: str,
    category: str | None = None,
    risk_model: str = "bloomberg"
) -> list[FactorDetail]:
    """Get detailed factor exposures and contributions."""
    pass

@router.get("/{portfolio_id}/history")
async def get_historical_tracking_error(
    portfolio_id: str,
    benchmark_id: str,
    period: str = "1y"  # 1m, 3m, 6m, 1y, 3y, 5y
) -> list[HistoricalTE]:
    """Get historical rolling tracking error."""
    pass

@router.get("/{portfolio_id}/comparison")
async def compare_risk(
    portfolio_ids: list[str],
    benchmark_id: str
) -> list[RiskComparison]:
    """Compare tracking error across multiple portfolios."""
    pass
```

### Pydantic Models
```python
class CategoryContribution(BaseModel):
    category: str
    
    contrib_to_te: Decimal
    contrib_to_bench_risk: Decimal
    contrib_to_port_risk: Decimal
    
    percent_of_te: Decimal

class FactorDetail(BaseModel):
    category: str
    factor_id: str
    factor_name: str
    
    portfolio_exposure: Decimal
    benchmark_exposure: Decimal
    active_exposure: Decimal
    
    contrib_to_te: Decimal
    factor_volatility: Decimal

class RiskDecomposition(BaseModel):
    portfolio_id: str
    benchmark_id: str
    as_of_date: date
    risk_model: str
    
    total_tracking_error: Decimal
    total_portfolio_risk: Decimal
    total_benchmark_risk: Decimal
    
    category_contributions: list[CategoryContribution]
    factor_details: list[FactorDetail]
```

### Risk Service
```python
class TrackingErrorService:
    async def calculate_tracking_error(
        self,
        portfolio_id: str,
        benchmark_id: str,
        risk_model: str
    ) -> RiskDecomposition:
        """
        Calculate tracking error using factor model.
        
        Tracking Error = sqrt(w_a' * Σ * w_a)
        
        Where:
        - w_a = active weights (portfolio - benchmark)
        - Σ = factor covariance matrix + specific risk
        
        Contribution by category:
        TE_category = Σ (factor_exposure_i * factor_vol_i * corr_i)
        """
        
        # Get weights
        port_weights = await self._get_portfolio_weights(portfolio_id)
        bench_weights = await self._get_benchmark_weights(benchmark_id)
        active_weights = self._calculate_active_weights(port_weights, bench_weights)
        
        # Get factor exposures
        port_exposures = await self._get_factor_exposures(portfolio_id, risk_model)
        bench_exposures = await self._get_factor_exposures(benchmark_id, risk_model)
        
        # Get covariance matrix
        cov_matrix = await self._get_factor_covariance(risk_model)
        
        # Calculate tracking error
        active_exposures = self._calculate_active_exposures(port_exposures, bench_exposures)
        total_te = self._calculate_total_te(active_exposures, cov_matrix)
        
        # Decompose by category
        categories = await self._decompose_by_category(
            active_exposures, cov_matrix, total_te
        )
        
        return RiskDecomposition(
            portfolio_id=portfolio_id,
            benchmark_id=benchmark_id,
            total_tracking_error=total_te,
            category_contributions=categories,
            # ... other fields
        )
    
    def _calculate_total_te(
        self, 
        active_exposures: dict,
        cov_matrix: np.ndarray
    ) -> Decimal:
        """TE² = w'Σw"""
        w = np.array(list(active_exposures.values()))
        variance = w @ cov_matrix @ w.T
        return Decimal(str(np.sqrt(variance)))
```

---

## SQL Schema

```sql
-- Factor risk model definitions
CREATE TABLE risk_models (
    model_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    provider VARCHAR(50) NOT NULL,  -- 'bloomberg', 'barra', 'axioma'
    description TEXT,
    is_active BOOLEAN DEFAULT true
);

-- Factor categories
CREATE TABLE factor_categories (
    category_id VARCHAR(50) PRIMARY KEY,
    model_id VARCHAR(50) NOT NULL REFERENCES risk_models(model_id),
    name VARCHAR(100) NOT NULL,
    display_order INT
);

-- Individual factors
CREATE TABLE risk_factors (
    factor_id VARCHAR(50) PRIMARY KEY,
    category_id VARCHAR(50) NOT NULL REFERENCES factor_categories(category_id),
    name VARCHAR(100) NOT NULL,
    description TEXT
);

-- Security factor exposures
CREATE TABLE security_factor_exposures (
    id BIGSERIAL PRIMARY KEY,
    security_id UUID NOT NULL,
    factor_id VARCHAR(50) NOT NULL REFERENCES risk_factors(factor_id),
    as_of_date DATE NOT NULL,
    
    exposure DECIMAL(10,6) NOT NULL,
    
    UNIQUE (security_id, factor_id, as_of_date),
    INDEX idx_exposure_security (security_id, as_of_date),
    INDEX idx_exposure_factor (factor_id, as_of_date)
);

-- Factor covariance matrix
CREATE TABLE factor_covariance (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(50) NOT NULL REFERENCES risk_models(model_id),
    factor_id_1 VARCHAR(50) NOT NULL,
    factor_id_2 VARCHAR(50) NOT NULL,
    as_of_date DATE NOT NULL,
    
    covariance DECIMAL(16,12) NOT NULL,
    
    UNIQUE (model_id, factor_id_1, factor_id_2, as_of_date),
    INDEX idx_cov_model_date (model_id, as_of_date)
);

-- Security specific risk (idiosyncratic)
CREATE TABLE security_specific_risk (
    id BIGSERIAL PRIMARY KEY,
    security_id UUID NOT NULL,
    model_id VARCHAR(50) NOT NULL,
    as_of_date DATE NOT NULL,
    
    specific_risk DECIMAL(10,6) NOT NULL,  -- Annualized std dev
    
    UNIQUE (security_id, model_id, as_of_date)
);

-- Portfolio tracking error (cached)
CREATE TABLE portfolio_tracking_error (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID NOT NULL,
    model_id VARCHAR(50) NOT NULL,
    as_of_date DATE NOT NULL,
    
    total_tracking_error DECIMAL(10,6),
    total_portfolio_risk DECIMAL(10,6),
    total_benchmark_risk DECIMAL(10,6),
    
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (portfolio_id, benchmark_id, model_id, as_of_date)
);

-- Category contributions
CREATE TABLE te_category_contributions (
    id BIGSERIAL PRIMARY KEY,
    tracking_error_id BIGINT NOT NULL REFERENCES portfolio_tracking_error(id),
    
    category_id VARCHAR(50) NOT NULL,
    
    contrib_to_te DECIMAL(10,6),
    contrib_to_bench_risk DECIMAL(10,6),
    contrib_to_port_risk DECIMAL(10,6),
    percent_of_te DECIMAL(10,6)
);

-- Factor-level contributions
CREATE TABLE te_factor_contributions (
    id BIGSERIAL PRIMARY KEY,
    tracking_error_id BIGINT NOT NULL REFERENCES portfolio_tracking_error(id),
    
    factor_id VARCHAR(50) NOT NULL,
    
    portfolio_exposure DECIMAL(10,6),
    benchmark_exposure DECIMAL(10,6),
    active_exposure DECIMAL(10,6),
    
    contrib_to_te DECIMAL(10,6),
    
    INDEX idx_te_factor (tracking_error_id)
);
```

---

## Key Formulas

### Tracking Error
$$TE = \sqrt{w_a^T \Sigma w_a}$$

Where:
- $w_a$ = Active weights (portfolio weight - benchmark weight)
- $\Sigma$ = Factor covariance matrix

### Factor Contribution to TE
$$TE_{factor_i} = w_{a,i} \cdot \sigma_i \cdot \rho_{i,P}$$

Where:
- $w_{a,i}$ = Active exposure to factor i
- $\sigma_i$ = Factor volatility
- $\rho_{i,P}$ = Correlation of factor i with portfolio

### Category Contribution
$$TE_{category} = \sum_{i \in category} TE_{factor_i}$$
