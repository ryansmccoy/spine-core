# Portfolio Optimization & Efficient Frontier

## Overview
Optimize portfolio allocations using mean-variance optimization, risk parity, or custom objectives. Visualize efficient frontier and generate trade lists to achieve target portfolios. Based on Bloomberg PORT Optimization functionality.

![Reference: PORT Optimization]

---

## UI Components

### 1. Optimization Header
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Portfolio Optimization                                                                                        │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ [MID CAP EQUITY ▼]  vs [S&P 500 INDE ▼]  Model: [Bloomberg Ri ▼]  As of: 02/01/18                           │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ Optimization Type: [Mean-Variance ▼]                                                                          │
│                                                                                                               │
│ [Efficient Frontier]│[Optimizer Settings]│[Constraints]│[Results]                                            │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Efficient Frontier Chart
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Efficient Frontier                                                                                    [Export]        │
│                                                                                                                       │
│  Expected                                                                     ●─●  Efficient Frontier                 │
│  Return (%)                                                                 ●                                         │
│                                                                           ●                                           │
│    14% │                                                                ●                                             │
│        │                                                              ●                                               │
│    12% │                                                            ●     ◐ Maximum Sharpe                            │
│        │                                                          ●                                                   │
│    10% │                                                        ●                                                     │
│        │                                                      ●                                                       │
│     8% │                                                    ●               ▲ Current Portfolio                       │
│        │                                                  ●                                                           │
│     6% │                                        ○  ○  ●                                                               │
│        │                                    ○          ◉ Minimum Variance                                             │
│     4% │                          ○    ○                                                                              │
│        │              ○       ○                          ★ Benchmark                                                  │
│     2% │     ○   ○                                                                                                    │
│        │                                                                                                              │
│     0% └──────────────────────────────────────────────────────────────────────────────────────────────────────────────│
│         0%     5%    10%    15%    20%    25%    30%    35%                                                          │
│                                  Risk (Volatility %)                                                                  │
│                                                                                                                       │
│  ○ Individual Assets    ● Efficient Frontier    ▲ Current    ★ Benchmark    ◐ Max Sharpe    ◉ Min Var                │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3. Optimizer Settings Panel
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Optimizer Settings                                                                                                    │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                       │
│ Objective Function:                                                                                                   │
│ ┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ○ Maximize Return (given risk target)                                                                            │ │
│ │ ● Minimize Risk (given return target)                                                                            │ │
│ │ ○ Maximize Sharpe Ratio                                                                                          │ │
│ │ ○ Minimize Tracking Error                                                                                        │ │
│ │ ○ Risk Parity                                                                                                    │ │
│ └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                                       │
│ Target Parameters:                                                                                                    │
│ ┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Target Return:         [ 10.0 ] %   (Current: 8.5%)                                                              │ │
│ │ Target Risk:           [ 15.0 ] %   (Current: 16.2%)                                                             │ │
│ │ Target Tracking Error: [ 3.00 ] %   (Current: 4.72%)                                                             │ │
│ │ Risk-Free Rate:        [ 2.50 ] %                                                                                │ │
│ └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                                       │
│ Transaction Costs:                                                                                                    │
│ ┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ☑ Include Transaction Costs in Optimization                                                                      │ │
│ │ Commission Rate: [ 0.02 ] %                                                                                      │ │
│ │ Market Impact:   [ Linear ▼]                                                                                     │ │
│ └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                                       │
│                                                                        [Reset to Defaults]  [Run Optimization]        │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Constraints Panel
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Constraints                                                                                        [+ Add Constraint] │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                       │
│ Position Constraints:                                                                                                 │
│ ┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Min Weight per Security:  [ 0.00 ] %      Max Weight per Security:  [ 5.00 ] %                                   │ │
│ │ Max # of Securities:      [ 100  ]        Min # of Securities:      [ 40   ]                                     │ │
│ │ ☑ Long Only (no short selling)                                                                                   │ │
│ │ ☑ Fully Invested (weights sum to 100%)                                                                           │ │
│ └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                                       │
│ Sector Constraints:                                                                                                   │
│ ┌────────────────────────────────────────┬──────────────────┬──────────────────┬──────────────────────────────────────┤
│ │ Sector                                 │ Min Weight       │ Max Weight       │ Max Active (vs Bench)               │
│ ├────────────────────────────────────────┼──────────────────┼──────────────────┼──────────────────────────────────────┤
│ │ Information Technology                 │ [ 20.0 ] %       │ [ 35.0 ] %       │ [ 5.0 ] %                           │
│ │ Financials                             │ [ 10.0 ] %       │ [ 25.0 ] %       │ [ 5.0 ] %                           │
│ │ Health Care                            │ [  5.0 ] %       │ [ 20.0 ] %       │ [ 5.0 ] %                           │
│ │ Energy                                 │ [  0.0 ] %       │ [ 10.0 ] %       │ [ 3.0 ] %                           │
│ └────────────────────────────────────────┴──────────────────┴──────────────────┴──────────────────────────────────────┘ │
│                                                                                                                       │
│ Factor Constraints:                                                                                                   │
│ ┌────────────────────────────────────────┬──────────────────┬──────────────────────────────────────────────────────────┤
│ │ Factor                                 │ Min Exposure     │ Max Exposure                                            │
│ ├────────────────────────────────────────┼──────────────────┼──────────────────────────────────────────────────────────┤
│ │ Beta                                   │ [ 0.90 ]         │ [ 1.10 ]                                                │
│ │ Size                                   │ [-0.50 ]         │ [ 1.00 ]                                                │
│ │ Value                                  │ [-0.30 ]         │ [ 0.30 ]                                                │
│ └────────────────────────────────────────┴──────────────────┴──────────────────────────────────────────────────────────┘ │
│                                                                                                                       │
│ Turnover Constraints:                                                                                                 │
│ ┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Max One-Way Turnover: [ 20.0 ] %                                                                                 │ │
│ │ Max Single Trade:     [ 2.00 ] % of portfolio                                                                    │ │
│ └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Optimization Results
```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Optimization Results                                                             [Export Trades]  [Send to OMS]       │
├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                       │
│ Summary:                                                                                                              │
│ ┌────────────────────────────────────────┬─────────────────────┬─────────────────────┬────────────────────────────────┤
│ │ Metric                                 │ Current             │ Optimal             │ Change                        │
│ ├────────────────────────────────────────┼─────────────────────┼─────────────────────┼────────────────────────────────┤
│ │ Expected Return                        │ 8.50%               │ 10.00%              │ +1.50%                        │
│ │ Volatility (Risk)                      │ 16.20%              │ 14.80%              │ -1.40%                        │
│ │ Sharpe Ratio                           │ 0.37                │ 0.51                │ +0.14                         │
│ │ Tracking Error                         │ 4.72%               │ 3.85%               │ -0.87%                        │
│ │ Information Ratio                      │ 0.42                │ 0.52                │ +0.10                         │
│ │ Turnover (one-way)                     │ --                  │ 18.5%               │                               │
│ │ Est. Transaction Cost                  │ --                  │ $185,000            │                               │
│ └────────────────────────────────────────┴─────────────────────┴─────────────────────┴────────────────────────────────┘ │
│                                                                                                                       │
│ Suggested Trades:                                                                                                     │
│ ┌─────────────────┬─────────┬────────────────┬───────────────┬───────────────┬───────────────┬────────────────────────┤
│ │ Security        │ Side    │ Curr Weight    │ Opt Weight    │ Δ Weight      │ Shares        │ Notional              │
│ ├─────────────────┼─────────┼────────────────┼───────────────┼───────────────┼───────────────┼────────────────────────┤
│ │ AAPL US         │ BUY     │ 3.50%          │ 4.50%         │ +1.00%        │ +5,700        │ +$999,000             │
│ │ MSFT US         │ BUY     │ 4.20%          │ 5.00%         │ +0.80%        │ +1,950        │ +$799,500             │
│ │ NVDA US         │ BUY     │ 2.10%          │ 3.20%         │ +1.10%        │ +2,240        │ +$1,098,560           │
│ │ XOM US          │ SELL    │ 2.10%          │ 1.00%         │ -1.10%        │ -11,100       │ -$1,098,900           │
│ │ CVX US          │ SELL    │ 1.80%          │ 0.80%         │ -1.00%        │ -6,750        │ -$999,000             │
│ │ JPM US          │ SELL    │ 2.80%          │ 2.20%         │ -0.60%        │ -3,650        │ -$599,125             │
│ │ ... (42 more trades)                                                                                               │
│ └─────────────────┴─────────┴────────────────┴───────────────┴───────────────┴───────────────┴────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Frontend Implementation

### Component Structure
```typescript
// src/pages/PortfolioOptimizationPage.tsx

<PortfolioOptimizationPage>
  <OptimizationHeader>
    <PortfolioSelector />
    <BenchmarkSelector />
    <RiskModelSelector />
  </OptimizationHeader>
  
  <Tabs>
    <Tab label="Efficient Frontier">
      <EfficientFrontierChart 
        frontier={frontierData}
        currentPortfolio={current}
        benchmark={benchmark}
        optimalPoints={optimalPoints}
      />
    </Tab>
    <Tab label="Optimizer Settings">
      <ObjectiveSelector value={objective} onChange={setObjective} />
      <TargetParameters params={params} onChange={setParams} />
      <TransactionCostSettings costs={costs} onChange={setCosts} />
    </Tab>
    <Tab label="Constraints">
      <PositionConstraints />
      <SectorConstraints />
      <FactorConstraints />
      <TurnoverConstraints />
    </Tab>
    <Tab label="Results">
      <OptimizationSummary current={current} optimal={optimal} />
      <SuggestedTradesTable trades={suggestedTrades} />
    </Tab>
  </Tabs>
  
  <ActionBar>
    <ExportButton />
    <SendToOMSButton />
  </ActionBar>
</PortfolioOptimizationPage>
```

### TypeScript Interfaces
```typescript
interface OptimizationSettings {
  objective: OptimizationObjective;
  targetReturn?: number;
  targetRisk?: number;
  targetTrackingError?: number;
  riskFreeRate: number;
  includeTransactionCosts: boolean;
  commissionRate: number;
  marketImpactModel: 'linear' | 'sqrt' | 'none';
}

type OptimizationObjective = 
  | 'maximize_return'
  | 'minimize_risk'
  | 'maximize_sharpe'
  | 'minimize_tracking_error'
  | 'risk_parity';

interface OptimizationConstraints {
  // Position constraints
  minWeightPerSecurity: number;
  maxWeightPerSecurity: number;
  maxSecurities: number;
  minSecurities: number;
  longOnly: boolean;
  fullyInvested: boolean;
  
  // Sector constraints
  sectorConstraints: SectorConstraint[];
  
  // Factor constraints
  factorConstraints: FactorConstraint[];
  
  // Turnover constraints
  maxOneWayTurnover: number;
  maxSingleTrade: number;
}

interface SectorConstraint {
  sector: string;
  minWeight: number;
  maxWeight: number;
  maxActiveWeight: number;
}

interface FactorConstraint {
  factorId: string;
  factorName: string;
  minExposure: number;
  maxExposure: number;
}

interface FrontierPoint {
  risk: number;
  return: number;
  sharpe: number;
  weights: Record<string, number>;
}

interface OptimizationResult {
  status: 'optimal' | 'infeasible' | 'unbounded' | 'max_iterations';
  
  currentMetrics: PortfolioMetrics;
  optimalMetrics: PortfolioMetrics;
  
  optimalWeights: Record<string, number>;
  suggestedTrades: SuggestedTrade[];
  
  turnover: number;
  estimatedTransactionCost: number;
  
  // Active constraints
  bindingConstraints: string[];
}

interface SuggestedTrade {
  securityId: string;
  symbol: string;
  name: string;
  side: 'BUY' | 'SELL';
  currentWeight: number;
  optimalWeight: number;
  weightChange: number;
  shares: number;
  notional: number;
}
```

### Efficient Frontier Chart
```typescript
function EfficientFrontierChart({
  frontier,
  currentPortfolio,
  benchmark,
  optimalPoints
}: {
  frontier: FrontierPoint[];
  currentPortfolio: { risk: number; return: number };
  benchmark: { risk: number; return: number };
  optimalPoints: {
    maxSharpe: FrontierPoint;
    minVariance: FrontierPoint;
  };
}) {
  return (
    <ResponsiveContainer width="100%" height={500}>
      <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
        <XAxis 
          type="number" 
          dataKey="risk" 
          name="Risk" 
          tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
          domain={['dataMin', 'dataMax']}
          stroke="#9ca3af"
        />
        <YAxis 
          type="number" 
          dataKey="return" 
          name="Return" 
          tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
          domain={['dataMin', 'dataMax']}
          stroke="#9ca3af"
        />
        
        {/* Efficient frontier line */}
        <Scatter 
          name="Efficient Frontier" 
          data={frontier} 
          fill="#f59e0b"
          line={{ stroke: '#f59e0b', strokeWidth: 2 }}
        />
        
        {/* Current portfolio */}
        <Scatter
          name="Current Portfolio"
          data={[currentPortfolio]}
          fill="#3b82f6"
          shape="triangle"
        />
        
        {/* Benchmark */}
        <Scatter
          name="Benchmark"
          data={[benchmark]}
          fill="#ffffff"
          shape="star"
        />
        
        {/* Maximum Sharpe */}
        <Scatter
          name="Maximum Sharpe"
          data={[optimalPoints.maxSharpe]}
          fill="#22c55e"
        />
        
        {/* Minimum Variance */}
        <Scatter
          name="Minimum Variance"
          data={[optimalPoints.minVariance]}
          fill="#8b5cf6"
        />
        
        <Tooltip
          formatter={(value: number, name: string) => [
            `${(value * 100).toFixed(2)}%`,
            name
          ]}
          contentStyle={{ backgroundColor: '#1f2937', border: 'none' }}
        />
        <Legend />
      </ScatterChart>
    </ResponsiveContainer>
  );
}
```

### Optimization Settings Form
```typescript
function OptimizationSettingsForm({
  settings,
  onSettingsChange,
  onRunOptimization
}: {
  settings: OptimizationSettings;
  onSettingsChange: (settings: OptimizationSettings) => void;
  onRunOptimization: () => void;
}) {
  return (
    <div className="space-y-6">
      {/* Objective Selection */}
      <div className="bg-[#252536] p-4 rounded-lg">
        <h4 className="text-white font-medium mb-3">Objective Function</h4>
        <div className="space-y-2">
          {[
            { value: 'maximize_return', label: 'Maximize Return (given risk target)' },
            { value: 'minimize_risk', label: 'Minimize Risk (given return target)' },
            { value: 'maximize_sharpe', label: 'Maximize Sharpe Ratio' },
            { value: 'minimize_tracking_error', label: 'Minimize Tracking Error' },
            { value: 'risk_parity', label: 'Risk Parity' },
          ].map(({ value, label }) => (
            <label key={value} className="flex items-center gap-3 text-gray-300">
              <input
                type="radio"
                name="objective"
                value={value}
                checked={settings.objective === value}
                onChange={(e) => onSettingsChange({ ...settings, objective: e.target.value })}
                className="text-orange-500"
              />
              {label}
            </label>
          ))}
        </div>
      </div>
      
      {/* Target Parameters */}
      <div className="bg-[#252536] p-4 rounded-lg">
        <h4 className="text-white font-medium mb-3">Target Parameters</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 text-sm mb-1">Target Return</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                step="0.1"
                value={settings.targetReturn ?? ''}
                onChange={(e) => onSettingsChange({ 
                  ...settings, 
                  targetReturn: parseFloat(e.target.value) 
                })}
                className="w-24 px-3 py-2 bg-[#1a1a2e] text-white text-right font-mono rounded"
              />
              <span className="text-gray-500">%</span>
            </div>
          </div>
          {/* Similar inputs for targetRisk, targetTrackingError, riskFreeRate */}
        </div>
      </div>
      
      <button
        onClick={onRunOptimization}
        className="w-full py-3 bg-blue-600 text-white font-medium rounded hover:bg-blue-700"
      >
        Run Optimization
      </button>
    </div>
  );
}
```

---

## Backend Implementation

### API Endpoints
```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/optimization")

@router.post("/{portfolio_id}/optimize")
async def run_optimization(
    portfolio_id: str,
    settings: OptimizationSettings,
    constraints: OptimizationConstraints,
    benchmark_id: str | None = None
) -> OptimizationResult:
    """Run portfolio optimization."""
    pass

@router.post("/{portfolio_id}/frontier")
async def calculate_frontier(
    portfolio_id: str,
    constraints: OptimizationConstraints,
    num_points: int = 50
) -> list[FrontierPoint]:
    """Calculate efficient frontier."""
    pass

@router.post("/{portfolio_id}/validate-constraints")
async def validate_constraints(
    portfolio_id: str,
    constraints: OptimizationConstraints
) -> ConstraintValidation:
    """Validate constraints are feasible."""
    pass

@router.post("/{portfolio_id}/results/{result_id}/send-to-oms")
async def send_to_oms(
    portfolio_id: str,
    result_id: str,
    trades: list[str] | None = None  # Filter specific trades
) -> OMSResponse:
    """Send optimization trades to OMS."""
    pass
```

### Pydantic Models
```python
class OptimizationSettings(BaseModel):
    objective: Literal[
        'maximize_return', 
        'minimize_risk', 
        'maximize_sharpe',
        'minimize_tracking_error',
        'risk_parity'
    ]
    
    target_return: Decimal | None
    target_risk: Decimal | None
    target_tracking_error: Decimal | None
    risk_free_rate: Decimal = Decimal('0.025')
    
    include_transaction_costs: bool = False
    commission_rate: Decimal = Decimal('0.0002')
    market_impact_model: Literal['linear', 'sqrt', 'none'] = 'sqrt'

class OptimizationConstraints(BaseModel):
    min_weight_per_security: Decimal = Decimal('0')
    max_weight_per_security: Decimal = Decimal('0.05')
    max_securities: int | None
    min_securities: int | None
    long_only: bool = True
    fully_invested: bool = True
    
    sector_constraints: list[SectorConstraint] = []
    factor_constraints: list[FactorConstraint] = []
    
    max_one_way_turnover: Decimal | None
    max_single_trade: Decimal | None

class FrontierPoint(BaseModel):
    risk: Decimal
    expected_return: Decimal
    sharpe: Decimal
    weights: dict[str, Decimal]

class OptimizationResult(BaseModel):
    status: Literal['optimal', 'infeasible', 'unbounded', 'max_iterations']
    
    current_metrics: PortfolioMetrics
    optimal_metrics: PortfolioMetrics
    
    optimal_weights: dict[str, Decimal]
    suggested_trades: list[SuggestedTrade]
    
    turnover: Decimal
    estimated_transaction_cost: Decimal
    
    binding_constraints: list[str]
```

### Optimization Service
```python
import cvxpy as cp
import numpy as np

class OptimizationService:
    async def optimize(
        self,
        portfolio_id: str,
        settings: OptimizationSettings,
        constraints: OptimizationConstraints,
        benchmark_id: str | None
    ) -> OptimizationResult:
        """
        Mean-Variance Optimization using CVXPY.
        
        Objective:
        - Maximize: μᵀw - λ/2 * wᵀΣw  (risk-adjusted return)
        - Or minimize: wᵀΣw  (variance)
        
        Subject to:
        - Σwᵢ = 1 (fully invested)
        - wᵢ ≥ 0 (long only)
        - wᵢ ≤ max_weight
        - Sector constraints
        - Factor constraints
        - Turnover constraints
        """
        
        # Get universe and data
        universe = await self._get_universe(portfolio_id)
        n = len(universe)
        
        # Get expected returns and covariance
        mu = await self._get_expected_returns(universe)  # n x 1
        Sigma = await self._get_covariance_matrix(universe)  # n x n
        
        # Current weights
        current_weights = await self._get_current_weights(portfolio_id, universe)
        
        # Decision variable: portfolio weights
        w = cp.Variable(n)
        
        # Build objective
        if settings.objective == 'minimize_risk':
            # Minimize variance subject to return target
            objective = cp.Minimize(cp.quad_form(w, Sigma))
            constraints_list = [mu @ w >= settings.target_return]
            
        elif settings.objective == 'maximize_return':
            # Maximize return subject to risk target
            objective = cp.Maximize(mu @ w)
            constraints_list = [cp.quad_form(w, Sigma) <= settings.target_risk ** 2]
            
        elif settings.objective == 'maximize_sharpe':
            # Maximize Sharpe using reformulation
            # y = w/κ where κ = 1ᵀw, then maximize (μᵀy - rf) / ||Σ^½y||
            # Reformulate as SOCP
            y = cp.Variable(n)
            kappa = cp.Variable()
            
            objective = cp.Maximize(mu @ y - settings.risk_free_rate * kappa)
            constraints_list = [
                cp.SOC(kappa, Sigma_sqrt @ y),
                cp.sum(y) == kappa,
                kappa >= 0
            ]
            # Then w = y/kappa
            
        # Add standard constraints
        constraints_list.extend([
            cp.sum(w) == 1 if constraints.fully_invested else cp.sum(w) <= 1,
            w >= constraints.min_weight_per_security,
            w <= constraints.max_weight_per_security,
        ])
        
        if constraints.long_only:
            constraints_list.append(w >= 0)
        
        # Sector constraints
        for sc in constraints.sector_constraints:
            sector_mask = await self._get_sector_mask(universe, sc.sector)
            constraints_list.append(cp.sum(w[sector_mask]) >= sc.min_weight)
            constraints_list.append(cp.sum(w[sector_mask]) <= sc.max_weight)
        
        # Factor constraints
        factor_exposures = await self._get_factor_exposures(universe)
        for fc in constraints.factor_constraints:
            exposure = factor_exposures[fc.factor_id]  # n x 1
            constraints_list.append(exposure @ w >= fc.min_exposure)
            constraints_list.append(exposure @ w <= fc.max_exposure)
        
        # Turnover constraint
        if constraints.max_one_way_turnover:
            constraints_list.append(
                cp.norm(w - current_weights, 1) <= 2 * constraints.max_one_way_turnover
            )
        
        # Solve
        problem = cp.Problem(objective, constraints_list)
        problem.solve(solver=cp.ECOS)
        
        if problem.status != 'optimal':
            return OptimizationResult(status=problem.status, ...)
        
        # Extract results
        optimal_weights = dict(zip(universe, w.value))
        
        # Calculate metrics
        optimal_metrics = self._calculate_metrics(optimal_weights, mu, Sigma)
        
        # Generate trades
        trades = self._generate_trades(current_weights, optimal_weights, universe)
        
        return OptimizationResult(
            status='optimal',
            optimal_weights=optimal_weights,
            suggested_trades=trades,
            optimal_metrics=optimal_metrics,
            turnover=self._calculate_turnover(current_weights, optimal_weights),
            ...
        )
    
    async def calculate_frontier(
        self,
        portfolio_id: str,
        constraints: OptimizationConstraints,
        num_points: int = 50
    ) -> list[FrontierPoint]:
        """Calculate efficient frontier by varying target return."""
        
        universe = await self._get_universe(portfolio_id)
        mu = await self._get_expected_returns(universe)
        Sigma = await self._get_covariance_matrix(universe)
        
        # Find min/max feasible returns
        min_return = self._solve_for_return(universe, mu, Sigma, constraints, 'min')
        max_return = self._solve_for_return(universe, mu, Sigma, constraints, 'max')
        
        frontier = []
        for target in np.linspace(min_return, max_return, num_points):
            result = await self.optimize(
                portfolio_id,
                OptimizationSettings(
                    objective='minimize_risk',
                    target_return=Decimal(str(target))
                ),
                constraints
            )
            
            if result.status == 'optimal':
                frontier.append(FrontierPoint(
                    expected_return=Decimal(str(mu @ list(result.optimal_weights.values()))),
                    risk=result.optimal_metrics.total_risk,
                    sharpe=(result.optimal_metrics.expected_return - Decimal('0.025')) / result.optimal_metrics.total_risk,
                    weights=result.optimal_weights
                ))
        
        return frontier
```

---

## SQL Schema

```sql
-- Optimization runs
CREATE TABLE optimization_runs (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    benchmark_id UUID,
    
    run_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(20) NOT NULL,
    
    -- Settings
    objective VARCHAR(50) NOT NULL,
    target_return DECIMAL(10,6),
    target_risk DECIMAL(10,6),
    target_tracking_error DECIMAL(10,6),
    risk_free_rate DECIMAL(10,6),
    include_transaction_costs BOOLEAN,
    
    -- Results
    optimal_return DECIMAL(10,6),
    optimal_risk DECIMAL(10,6),
    optimal_sharpe DECIMAL(10,6),
    turnover DECIMAL(10,6),
    estimated_transaction_cost DECIMAL(18,4),
    
    INDEX idx_opt_portfolio (portfolio_id, run_at)
);

-- Optimization constraints
CREATE TABLE optimization_constraints (
    id BIGSERIAL PRIMARY KEY,
    run_id BIGINT NOT NULL REFERENCES optimization_runs(id),
    
    constraint_type VARCHAR(50) NOT NULL,
    constraint_name VARCHAR(100),
    
    min_value DECIMAL(10,6),
    max_value DECIMAL(10,6),
    is_binding BOOLEAN
);

-- Optimal weights
CREATE TABLE optimal_weights (
    id BIGSERIAL PRIMARY KEY,
    run_id BIGINT NOT NULL REFERENCES optimization_runs(id),
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20),
    
    current_weight DECIMAL(10,8),
    optimal_weight DECIMAL(10,8),
    
    INDEX idx_weights_run (run_id)
);

-- Suggested trades
CREATE TABLE suggested_trades (
    id BIGSERIAL PRIMARY KEY,
    run_id BIGINT NOT NULL REFERENCES optimization_runs(id),
    
    security_id UUID NOT NULL,
    symbol VARCHAR(20),
    
    side VARCHAR(10) NOT NULL,
    weight_change DECIMAL(10,8),
    shares INT,
    notional DECIMAL(18,4),
    
    sent_to_oms BOOLEAN DEFAULT false,
    oms_order_id VARCHAR(50),
    
    INDEX idx_trades_run (run_id)
);

-- Efficient frontier cache
CREATE TABLE efficient_frontier (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id UUID NOT NULL,
    calculated_at TIMESTAMP DEFAULT NOW(),
    
    point_index INT NOT NULL,
    expected_return DECIMAL(10,6),
    risk DECIMAL(10,6),
    sharpe DECIMAL(10,6),
    
    weights JSONB,  -- {security_id: weight}
    
    INDEX idx_frontier_portfolio (portfolio_id, calculated_at)
);
```

---

## Key Formulas

### Mean-Variance Optimization
$$\max_{w} \mu^T w - \frac{\lambda}{2} w^T \Sigma w$$

Subject to:
- $\mathbf{1}^T w = 1$ (fully invested)
- $w \geq 0$ (long only)

### Sharpe Ratio
$$SR = \frac{\mu_p - r_f}{\sigma_p}$$

### Maximum Sharpe Portfolio
$$w^* = \frac{\Sigma^{-1}(\mu - r_f \mathbf{1})}{\mathbf{1}^T \Sigma^{-1}(\mu - r_f \mathbf{1})}$$

### Risk Parity
Find $w$ such that:
$$w_i \cdot (\Sigma w)_i = \frac{1}{n} \cdot w^T \Sigma w \quad \forall i$$
