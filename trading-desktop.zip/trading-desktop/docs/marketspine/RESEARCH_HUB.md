# MarketSpine Research Hub

## Overview

The Research Hub is the central repository for investment research, company analysis, and knowledge management. It combines structured data (SEC filings, financials) with unstructured research (notes, transcripts, reports) through a powerful knowledge graph.

---

## Module Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           RESEARCH HUB                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Research Notes      │  │  Company Dashboard │  │  Knowledge Graph  │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Rich Editor       │  │  • Profile Card    │  │  • Entity Viewer  │  │
│  │   • Entity Linking    │  │  • SEC Filings     │  │  • Relationships  │  │
│  │   • Version History   │  │  • News Feed       │  │  • Path Finding   │  │
│  │   • Collaboration     │  │  • Research Notes  │  │  • Clustering     │  │
│  │   • Templates         │  │  • Positions       │  │  • Search         │  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Earnings Center     │  │  Filing Viewer     │  │  Research Search  │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Calendar          │  │  • 10-K/10-Q       │  │  • Full-Text      │  │
│  │   • Transcripts       │  │  • 8-K Events      │  │  • Filters        │  │
│  │   • Estimates         │  │  • Insider (Form4) │  │  • Saved Searches │  │
│  │   • Alerts            │  │  • Institutions    │  │  • History        │  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Research Notes Editor

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Research Notes                                        [+ New Note] [Search]│
├────────────────┬────────────────────────────────────────────────────────────┤
│ NOTES LIST     │  EDITOR                                                    │
│ ────────────── │  ────────────────────────────────────────────────────────  │
│                │                                                            │
│ 📝 AAPL Q3     │  Title: Apple Q3 2024 Earnings Analysis                   │
│    Earnings    │  ─────────────────────────────────────────────────────    │
│    Aug 1, 2024 │  Status: [Draft ▼]    Author: John Smith                  │
│    ⭐ Buy      │  Tags:  [AAPL] [Earnings] [Services] [+]                  │
│                │                                                            │
│ 📝 NVDA AI     │  ┌─────────────────────────────────────────────────────┐  │
│    Thesis      │  │ Toolbar: B I U | H1 H2 | • | [] | @ | 🔗 | 📊      │  │
│    Jul 28      │  ├─────────────────────────────────────────────────────┤  │
│    ⭐ Strong   │  │                                                     │  │
│       Buy      │  │ ## Key Takeaways                                    │  │
│                │  │                                                     │  │
│ 📝 MSFT Cloud  │  │ Services revenue grew **14% YoY** to $24.2B,       │  │
│    Analysis    │  │ beating estimates by $500M. [[AAPL]] management    │  │
│    Jul 22      │  │ highlighted strong growth in:                       │  │
│    ⭐ Hold     │  │                                                     │  │
│                │  │ - Apple Music (+12%)                                │  │
│ 📝 GOOGL       │  │ - iCloud (+18%)                                     │  │
│    Antitrust   │  │ - App Store (+8%)                                   │  │
│    Jul 15      │  │                                                     │  │
│    ⚠️ Concern  │  │ ## Valuation                                        │  │
│                │  │                                                     │  │
│ [+ New Note]   │  │ At current price of $227, [[AAPL]] trades at       │  │
│                │  │ 28x forward P/E vs 5-year avg of 25x.              │  │
│ FILTERS        │  │                                                     │  │
│ ───────────    │  │ @John Smith - can you verify the DCF model?        │  │
│ Company:  All  │  │                                                     │  │
│ Status:   All  │  │ [Insert Table] [Insert Chart] [Insert Filing]      │  │
│ Rating:   All  │  │                                                     │  │
│ Author:   All  │  └─────────────────────────────────────────────────────┘  │
│ Date:  Last 30d│                                                            │
│                │  LINKED ENTITIES                     VERSION HISTORY       │
└────────────────┴────────────────────────────────────────────────────────────┘
```

### Features

1. **Rich Markdown Editor**
   - Full Markdown support with live preview
   - Code blocks with syntax highlighting
   - Tables and charts embedding
   - Image upload and inline display

2. **Entity Linking**
   - `[[AAPL]]` syntax for company links
   - `@username` for user mentions
   - Auto-complete suggestions while typing
   - Bi-directional linking (notes that mention this company)

3. **Templates**
   - Earnings Analysis Template
   - Investment Thesis Template
   - Due Diligence Checklist
   - Industry Overview Template

4. **Collaboration**
   - Real-time collaborative editing
   - Comments and inline annotations
   - Draft/Review/Published workflow
   - @mention notifications

5. **Rating System**
   - Investment rating: Strong Buy, Buy, Hold, Sell, Strong Sell
   - Price target with timeframe
   - Conviction level (1-5)
   - Key risks and catalysts

---

## Company Dashboard

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Company Dashboard                                      [Watchlist ⭐] [×]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────┐  ┌───────────────────────────┐ │
│  │ APPLE INC (AAPL)                       │  │ YOUR POSITION             │ │
│  │ ────────────────────────────────────── │  │ ─────────────────────     │ │
│  │ Technology | Consumer Electronics      │  │ 50,000 shares             │ │
│  │ Market Cap: $3.4T   P/E: 28.5x        │  │ Avg Cost: $175.00         │ │
│  │                                        │  │ Market Value: $11.35M     │ │
│  │ Price: $227.00  ▲ +2.35 (+1.05%)      │  │ Unrealized P&L: +$2.6M    │ │
│  │ [Daily ▼] [1Y ▼]                       │  │ Weight: 2.3% of AUM       │ │
│  │ ┌──────────────────────────────────┐  │  │                           │ │
│  │ │         📈 Price Chart           │  │  │ [Trade] [Analyze]         │ │
│  │ │         [Interactive]            │  │  └───────────────────────────┘ │
│  │ └──────────────────────────────────┘  │                                │
│  └────────────────────────────────────────┘                                │
│                                                                              │
│  TABS: [Overview] [Filings] [News] [Research] [Financials] [Graph]         │
│  ═══════════════════════════════════════════════════════════════════       │
│                                                                              │
│  ┌─────────────────────────────┐  ┌────────────────────────────────────┐   │
│  │ RECENT FILINGS              │  │ RECENT NEWS                        │   │
│  │ ─────────────────────────── │  │ ────────────────────────────────── │   │
│  │ 📄 10-Q  Aug 2, 2024        │  │ 📰 Apple Beats Q3 Estimates        │   │
│  │    Q3 Quarterly Report      │  │    Reuters • 2 hours ago           │   │
│  │                             │  │    Sentiment: 😊 Positive           │   │
│  │ 📄 8-K   Aug 1, 2024        │  │                                    │   │
│  │    Earnings Release         │  │ 📰 iPhone 16 Production Ramps Up   │   │
│  │                             │  │    Bloomberg • 5 hours ago         │   │
│  │ 📄 4     Jul 28, 2024       │  │    Sentiment: 😊 Positive           │   │
│  │    Tim Cook - Sale          │  │                                    │   │
│  │    100,000 shares @ $225    │  │ 📰 EU Investigation Update         │   │
│  │                             │  │    FT • 1 day ago                  │   │
│  │ [View All Filings →]        │  │    Sentiment: 😐 Neutral            │   │
│  └─────────────────────────────┘  └────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────┐  ┌────────────────────────────────────┐   │
│  │ YOUR RESEARCH NOTES         │  │ RELATED ENTITIES                   │   │
│  │ ─────────────────────────── │  │ ────────────────────────────────── │   │
│  │ 📝 AAPL Q3 Earnings         │  │ Competitors: MSFT, GOOGL, AMZN     │   │
│  │    John Smith • Aug 1       │  │ Suppliers:   TSM, QCOM, AVGO       │   │
│  │    Rating: ⭐ Buy           │  │ Customers:   (B2C)                 │   │
│  │                             │  │ Board:       Tim Cook (CEO)        │   │
│  │ 📝 iPhone Market Analysis   │  │              Luca Maestri (CFO)    │   │
│  │    Jane Doe • Jun 15        │  │                                    │   │
│  │    Rating: ⭐ Buy           │  │ [View Knowledge Graph →]           │   │
│  └─────────────────────────────┘  └────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Tabs

1. **Overview** - Key metrics, price chart, position summary
2. **Filings** - SEC filings (10-K, 10-Q, 8-K, Form 4, 13F)
3. **News** - Company news with sentiment analysis
4. **Research** - Internal research notes
5. **Financials** - Income statement, balance sheet, cash flow
6. **Graph** - Knowledge graph centered on this company

---

## Knowledge Graph Visualization

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Knowledge Graph                               [Search] [Filter] [Export]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  NODE TYPES        RELATIONSHIP TYPES           LAYOUT                      │
│  ──────────────    ───────────────────          ──────────────              │
│  [✓] Companies     [✓] competes_with            [Force] [Tree] [Radial]    │
│  [✓] Securities    [✓] supplies_to                                          │
│  [✓] People        [✓] board_member             DEPTH: [1] [2] [3]          │
│  [ ] Trades        [✓] owns_position                                        │
│  [ ] Events        [ ] filed_with                                           │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                         ┌─────────┐                                 │   │
│  │                         │  MSFT   │                                 │   │
│  │                         │ $420.50 │                                 │   │
│  │                         └────┬────┘                                 │   │
│  │                              │ competes_with                        │   │
│  │        ┌─────────┐      ┌────┴────┐      ┌─────────┐               │   │
│  │        │  NVDA   │──────│  AAPL   │──────│  GOOGL  │               │   │
│  │        │ $125.00 │      │ $227.00 │      │ $175.00 │               │   │
│  │        └────┬────┘      └────┬────┘      └────┬────┘               │   │
│  │             │                │                │                     │   │
│  │             │ supplies_to    │ owns_position  │ competes_with       │   │
│  │             │                │                │                     │   │
│  │        ┌────┴────┐      ┌────┴────┐      ┌────┴────┐               │   │
│  │        │  TSM    │      │ Fund A  │      │  AMZN   │               │   │
│  │        │ $180.00 │      │ 50,000  │      │ $185.00 │               │   │
│  │        └─────────┘      │ shares  │      └─────────┘               │   │
│  │                         └─────────┘                                 │   │
│  │                                                                     │   │
│  │  [Zoom +] [Zoom -] [Fit] [Center]                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  NODE DETAILS                                                               │
│  ─────────────────────────────────────────────────────────────────────     │
│  Selected: AAPL (Apple Inc)                                                 │
│  Type: Company | Sector: Technology | Market Cap: $3.4T                    │
│  Connections: 12 companies, 3 funds, 5 people                               │
│  [View Dashboard] [Add to Watchlist] [Create Note]                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Interaction Patterns

1. **Click Node** - Select and show details panel
2. **Double-Click Node** - Expand/collapse connected nodes
3. **Drag Node** - Reposition in layout
4. **Right-Click Node** - Context menu (view, add note, trade)
5. **Hover Edge** - Show relationship details
6. **Mouse Wheel** - Zoom in/out
7. **Click + Drag Canvas** - Pan view

### Graph Queries

```sql
-- Find all companies connected to AAPL within 2 hops
WITH RECURSIVE connections AS (
    SELECT 
        r.source_entity_id,
        r.target_entity_id,
        r.relationship_type,
        1 as depth
    FROM entity_relationships r
    WHERE r.source_entity_id = :company_id
    
    UNION ALL
    
    SELECT 
        r.source_entity_id,
        r.target_entity_id,
        r.relationship_type,
        c.depth + 1
    FROM entity_relationships r
    JOIN connections c ON r.source_entity_id = c.target_entity_id
    WHERE c.depth < 2
)
SELECT DISTINCT * FROM connections;
```

---

## Earnings Center

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Earnings Center                                      [This Week ▼] [🔔]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  UPCOMING EARNINGS (Your Holdings)                                          │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ MON       TUE       WED       THU       FRI                         │   │
│  │ Aug 5    Aug 6    Aug 7    Aug 8    Aug 9                          │   │
│  ├─────────┬─────────┬─────────┬─────────┬─────────┐                   │   │
│  │         │ 🏢 NVDA │         │ 🏢 DIS  │         │                   │   │
│  │         │ AMC     │         │ AMC     │         │                   │   │
│  │         │         │         │         │         │                   │   │
│  │         │ 🏢 UBER │ 🏢 SHOP │         │         │                   │   │
│  │         │ BMO     │ BMO     │         │         │                   │   │
│  └─────────┴─────────┴─────────┴─────────┴─────────┘                   │   │
│                                                                              │
│  EARNINGS DETAILS: NVDA - Aug 6 (After Market Close)                        │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌────────────────────────────────┐  ┌──────────────────────────────────┐  │
│  │ CONSENSUS ESTIMATES            │  │ YOUR EXPECTATIONS                │  │
│  │ ────────────────────────────── │  │ ──────────────────────────────── │  │
│  │ EPS:      $2.70 (vs $2.04 YoY) │  │ EPS Estimate: $2.85             │  │
│  │ Revenue:  $28.7B               │  │ Conviction: High                 │  │
│  │ Whisper:  $2.82                │  │ Notes: Expect beat on data       │  │
│  │                                │  │        center demand             │  │
│  │ [Beat/Miss History]            │  │ [Edit Estimates]                 │  │
│  └────────────────────────────────┘  └──────────────────────────────────┘  │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ PREP MATERIALS                                                       │   │
│  │ ─────────────────────────────────────────────────────────────────── │   │
│  │ 📄 Latest 10-K    📄 Q2 Transcript    📝 Your Notes    📊 Model     │   │
│  │                                                                      │   │
│  │ KEY QUESTIONS FOR CALL:                                             │   │
│  │ • Data center demand trajectory?                                    │   │
│  │ • Gross margin outlook with Blackwell?                              │   │
│  │ • China exposure updates?                                           │   │
│  │ [Add Question]                                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  [Set Alert] [Generate Prep Pack] [Schedule Meeting]                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Filing Viewer

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  SEC Filing Viewer                                          [Download] [×]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Apple Inc (AAPL) - 10-K Annual Report                                      │
│  Filed: November 3, 2023 | Period: September 30, 2023                       │
│                                                                              │
│  SECTIONS                    DOCUMENT                                       │
│  ────────────────            ─────────────────────────────────────────────  │
│                                                                              │
│  📁 Part I                   Risk Factors                                   │
│    └ Item 1. Business        ════════════════════════════════════════════   │
│    └ Item 1A. Risk Factors   The Company's business, reputation, results   │
│    └ Item 1B. Staff Comments of operations, financial condition and stock  │
│    └ Item 2. Properties      price can be affected by a number of factors, │
│    └ Item 3. Legal           whether currently known or unknown, including │
│                              but not limited to those described below...    │
│  📁 Part II                                                                 │
│    └ Item 5. Market          Global and regional economic conditions       │
│    └ Item 6. [Reserved]      could materially adversely affect the        │
│    └ Item 7. MD&A ◄──────    Company. [Highlight this ✏️]                  │
│    └ Item 7A. Quantitative                                                  │
│    └ Item 8. Financials      The Company has international operations      │
│    └ Item 9. Changes         with sales outside the U.S. representing a   │
│                              majority of the Company's total net sales...  │
│  📁 Part III                                                                │
│                              ┌────────────────────────────────────────┐    │
│  📁 Part IV                  │ 📝 Your Annotation                     │    │
│                              │ ────────────────────────────────────── │    │
│  ANNOTATIONS (3)             │ Key risk: China supply chain exposure  │    │
│  ────────────────            │ affects 20%+ of revenue. Monitor       │    │
│  🔖 Page 15 - Risk           │ Taiwan situation closely.              │    │
│  🔖 Page 42 - Revenue        │                                        │    │
│  🔖 Page 67 - Guidance       │ [Save] [Delete] [Share]                │    │
│                              └────────────────────────────────────────┘    │
│  [Add Annotation]                                                           │
│                              [◄ Prev Section] [Next Section ►]             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## API Endpoints

### Research Notes

```yaml
GET /api/v1/research/notes
  Query: firm_id, company_id, author_id, status, tags, search, page, limit
  Response: List of research notes with metadata

POST /api/v1/research/notes
  Body: title, content, company_ids, tags, rating, price_target
  Response: Created note with ID

GET /api/v1/research/notes/{id}
  Response: Full note with version history and linked entities

PUT /api/v1/research/notes/{id}
  Body: Partial update fields
  Response: Updated note

DELETE /api/v1/research/notes/{id}
  Response: 204 No Content (soft delete)

GET /api/v1/research/notes/{id}/versions
  Response: List of all versions with diffs

POST /api/v1/research/notes/{id}/publish
  Response: Move note to published status
```

### Company Dashboard

```yaml
GET /api/v1/companies/{id}/dashboard
  Response: {
    company: Company profile,
    price: Current price and change,
    position: User's position if any,
    filings: Recent SEC filings,
    news: Recent news articles,
    notes: Related research notes,
    relationships: Connected entities
  }

GET /api/v1/companies/{id}/filings
  Query: form_type, date_from, date_to, page, limit
  Response: List of SEC filings

GET /api/v1/companies/{id}/news
  Query: date_from, date_to, sentiment, source, page, limit
  Response: List of news articles with sentiment

GET /api/v1/companies/{id}/graph
  Query: depth, relationship_types
  Response: Nodes and edges for graph visualization
```

### Knowledge Graph

```yaml
GET /api/v1/graph/entities
  Query: type, search, page, limit
  Response: List of entities (companies, securities, people)

GET /api/v1/graph/relationships
  Query: source_id, target_id, type, page, limit
  Response: List of relationships

GET /api/v1/graph/explore/{entity_id}
  Query: depth, relationship_types
  Response: Subgraph centered on entity

POST /api/v1/graph/query
  Body: { cypher: "MATCH path query..." }
  Response: Query results
```

### Earnings Calendar

```yaml
GET /api/v1/earnings/calendar
  Query: date_from, date_to, watchlist_only
  Response: List of earnings events

GET /api/v1/earnings/{company_id}
  Response: Earnings details with estimates, history, transcripts

POST /api/v1/earnings/{company_id}/estimates
  Body: { eps_estimate, revenue_estimate, notes }
  Response: Saved user estimates
```

---

## Data Models

### Research Note

```typescript
interface ResearchNote {
  id: string;
  firmId: string;
  authorId: string;
  author: User;
  
  title: string;
  content: string;  // Markdown
  contentHtml: string;  // Rendered HTML
  
  status: 'draft' | 'in_review' | 'published' | 'archived';
  
  // Investment thesis
  rating: 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell' | null;
  priceTarget: number | null;
  priceTargetDate: Date | null;
  conviction: 1 | 2 | 3 | 4 | 5 | null;
  
  // Linked entities
  companies: Company[];
  securities: Security[];
  tags: string[];
  
  // Collaboration
  collaborators: User[];
  comments: Comment[];
  
  // Metadata
  createdAt: Date;
  updatedAt: Date;
  publishedAt: Date | null;
  version: number;
}
```

### Company Dashboard

```typescript
interface CompanyDashboard {
  company: {
    id: string;
    name: string;
    ticker: string;
    sector: string;
    industry: string;
    description: string;
    employees: number;
    headquarters: string;
    website: string;
    cik: string;
  };
  
  price: {
    current: number;
    change: number;
    changePercent: number;
    high52Week: number;
    low52Week: number;
    marketCap: number;
    peRatio: number;
    dividendYield: number;
  };
  
  position: {
    quantity: number;
    avgCost: number;
    marketValue: number;
    unrealizedPnl: number;
    weight: number;
  } | null;
  
  recentFilings: Filing[];
  recentNews: NewsArticle[];
  researchNotes: ResearchNote[];
  relatedEntities: Entity[];
}
```

---

## Component Structure

```
src/components/research/
├── notes/
│   ├── NotesList.tsx
│   ├── NoteEditor.tsx
│   ├── NoteViewer.tsx
│   ├── NoteCard.tsx
│   ├── RatingBadge.tsx
│   ├── EntityLinker.tsx
│   └── VersionHistory.tsx
├── company/
│   ├── CompanyDashboard.tsx
│   ├── CompanyHeader.tsx
│   ├── CompanyFilings.tsx
│   ├── CompanyNews.tsx
│   ├── CompanyNotes.tsx
│   └── CompanyPosition.tsx
├── graph/
│   ├── KnowledgeGraph.tsx
│   ├── GraphNode.tsx
│   ├── GraphEdge.tsx
│   ├── GraphControls.tsx
│   └── NodeDetails.tsx
├── earnings/
│   ├── EarningsCalendar.tsx
│   ├── EarningsDetail.tsx
│   └── EstimatesForm.tsx
└── filings/
    ├── FilingViewer.tsx
    ├── FilingNav.tsx
    └── FilingAnnotations.tsx
```
