# MarketSpine Portfolio Manager

## Overview

The Portfolio Manager provides comprehensive position tracking, risk analytics, and performance attribution across all funds and accounts. It enables portfolio managers to monitor exposures, analyze performance drivers, and make informed allocation decisions.

---

## Module Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PORTFOLIO MANAGER                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Position Grid       │  │  Risk Dashboard    │  │  Performance      │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Fund Hierarchy    │  │  • VaR/CVaR        │  │  • Returns        │  │
│  │   • Real-time P&L     │  │  • Factor Exposure │  │  • Attribution    │  │
│  │   • Sector Grouping   │  │  • Stress Tests    │  │  • Benchmarks     │  │
│  │   • Weight Analysis   │  │  • Concentration   │  │  • Fee Analysis   │  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Holdings History    │  │  Cash Management   │  │  Rebalancing      │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Time Series       │  │  • Cash Positions  │  │  • Drift Analysis │  │
│  │   • Weight Changes    │  │  • Flow Tracking   │  │  • Target Weights │  │
│  │   • Trade Impact      │  │  • Projections     │  │  • Optimization   │  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Position Grid

### Wireframe - Hierarchical View

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Positions                                    [Fund View ▼] [Export] [⚙️]  │
├─────────────────────────────────────────────────────────────────────────────┤
│  Date: Aug 2, 2024  |  AUM: $500,234,567  |  Daily P&L: +$1,234,567 (+0.25%)│
├─────────────────────────────────────────────────────────────────────────────┤
│  GROUP BY: [None] [Sector] [Industry] [Fund] [Account]  | SEARCH: [      ] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                           POSITION GRID                              │   │
│  ├───────┬────────┬────────┬───────────┬───────────┬─────────┬────────┤   │
│  │       │ Symbol │ Shares │   Value   │ Day P&L   │ Weight  │ Avg    │   │
│  │       │        │        │           │           │         │ Cost   │   │
│  ├───────┼────────┼────────┼───────────┼───────────┼─────────┼────────┤   │
│  │ ▼ Global Equity Fund             $250,234,567   +$567,890   50.0%      │   │
│  │   ├▼ Alpha Account               $150,000,000   +$300,000   30.0%      │   │
│  │   │  ├─ AAPL  │ 50,000 │$11,350,000│  +$125,000│   2.3%  │$175.00│   │
│  │   │  ├─ MSFT  │ 30,000 │$12,600,000│   +$89,000│   2.5%  │$380.00│   │
│  │   │  ├─ NVDA  │ 80,000 │$10,000,000│  +$450,000│   2.0%  │$100.00│   │
│  │   │  ├─ GOOGL │ 25,000 │ $4,375,000│   +$25,000│   0.9%  │$165.00│   │
│  │   │  └─ ...   │        │           │           │         │        │   │
│  │   └▼ Beta Account                $100,000,000   +$267,890   20.0%      │   │
│  │      ├─ META  │ 40,000 │$19,200,000│  +$180,000│   3.8%  │$420.00│   │
│  │      ├─ AMZN  │ 50,000 │ $9,250,000│   +$50,000│   1.9%  │$175.00│   │
│  │      └─ ...   │        │           │           │         │        │   │
│  │ ▶ Fixed Income Fund              $150,000,000   +$100,000   30.0%      │   │
│  │ ▶ Emerging Markets Fund          $100,000,000   +$566,677   20.0%      │   │
│  └───────┴────────┴────────┴───────────┴───────────┴─────────┴────────┘   │
│                                                                              │
│  TOTALS                             $500,234,567 │+$1,234,567│  100%       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Wireframe - Sector Grouping

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Positions by Sector                                      [Sector View ▼]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ SECTOR          │  VALUE        │ WEIGHT │ TARGET │  DRIFT │ P&L   │   │
│  ├─────────────────┼───────────────┼────────┼────────┼────────┼───────┤   │
│  │ ▼ Technology    │ $175,000,000  │ 35.0%  │ 30.0%  │ +5.0%  │+$800K │   │
│  │   AAPL          │  $50,000,000  │ 10.0%  │        │        │+$200K │   │
│  │   MSFT          │  $45,000,000  │  9.0%  │        │        │+$150K │   │
│  │   NVDA          │  $40,000,000  │  8.0%  │        │        │+$350K │   │
│  │   GOOGL         │  $25,000,000  │  5.0%  │        │        │ +$50K │   │
│  │   META          │  $15,000,000  │  3.0%  │        │        │ +$50K │   │
│  │ ▼ Healthcare    │ $100,000,000  │ 20.0%  │ 20.0%  │  0.0%  │+$200K │   │
│  │   JNJ           │  $35,000,000  │  7.0%  │        │        │ +$80K │   │
│  │   UNH           │  $30,000,000  │  6.0%  │        │        │ +$60K │   │
│  │   PFE           │  $20,000,000  │  4.0%  │        │        │ +$30K │   │
│  │   ABBV          │  $15,000,000  │  3.0%  │        │        │ +$30K │   │
│  │ ▶ Financials    │  $75,000,000  │ 15.0%  │ 15.0%  │  0.0%  │+$100K │   │
│  │ ▶ Consumer      │  $50,000,000  │ 10.0%  │ 12.0%  │ -2.0%  │ +$50K │   │
│  │ ▶ Industrials   │  $50,000,000  │ 10.0%  │ 10.0%  │  0.0%  │ +$40K │   │
│  │ ▶ Energy        │  $25,000,000  │  5.0%  │  8.0%  │ -3.0%  │ +$20K │   │
│  │ ▶ Other         │  $25,000,000  │  5.0%  │  5.0%  │  0.0%  │ +$24K │   │
│  └─────────────────┴───────────────┴────────┴────────┴────────┴───────┘   │
│                                                                              │
│  ⚠️ DRIFT ALERTS: Technology +5.0% over target | Energy -3.0% under target  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Risk Dashboard

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Risk Dashboard                               [Global Equity Fund ▼] [📊]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  RISK SUMMARY (as of Aug 2, 2024)                                           │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ VALUE AT RISK    │ │ EXPECTED         │ │ BETA             │            │
│  │ (95%, 1-day)     │ │ SHORTFALL        │ │                  │            │
│  │ ────────────────│ │ ────────────────│ │ ────────────────│            │
│  │  $2,500,000      │ │  $3,800,000      │ │  1.15            │            │
│  │  (1.0% of NAV)   │ │  (1.5% of NAV)   │ │  vs S&P 500      │            │
│  │  ▼ -$100K        │ │  ▲ +$200K        │ │  ▲ +0.05         │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│                                                                              │
│  FACTOR EXPOSURES                                                           │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  Market   ████████████████████████████████████████  1.15            │   │
│  │  Size     ████████████████████░░░░░░░░░░░░░░░░░░░░  0.45 (Large)    │   │
│  │  Value    ░░░░░░░░░░░░░░░░░░░░████████████░░░░░░░░ -0.25 (Growth)   │   │
│  │  Momentum ████████████████████████░░░░░░░░░░░░░░░░  0.55            │   │
│  │  Quality  ████████████████████████████░░░░░░░░░░░░  0.65            │   │
│  │  Vol      ████████████████░░░░░░░░░░░░░░░░░░░░░░░░  0.35            │   │
│  │                                                                     │   │
│  │           -1.0        -0.5         0         0.5         1.0       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  CONCENTRATION ANALYSIS                  STRESS SCENARIOS                   │
│  ════════════════════════                ═══════════════════════════════    │
│  ┌────────────────────────┐             ┌───────────────────────────────┐  │
│  │ Top 10 Holdings: 45%   │             │ SCENARIO          │ IMPACT    │  │
│  │ ──────────────────────│             ├───────────────────┼───────────┤  │
│  │ 1. AAPL      10.0%    │             │ Market -10%       │ -$28.8M   │  │
│  │ 2. MSFT       9.0%    │             │ Tech Crash -20%   │ -$35.0M   │  │
│  │ 3. NVDA       8.0%    │             │ Rate Hike +100bp  │ -$12.5M   │  │
│  │ 4. JNJ        7.0%    │             │ USD +10%          │  -$8.0M   │  │
│  │ 5. UNH        6.0%    │             │ Oil +50%          │  -$5.0M   │  │
│  │ 6. META       5.0%    │             │ 2008 Replay       │ -$87.5M   │  │
│  │                       │             │ COVID Crash       │ -$62.5M   │  │
│  │ [View All →]          │             │ [Run Custom →]    │           │  │
│  └────────────────────────┘             └───────────────────────────────┘  │
│                                                                              │
│  ⚠️ RISK ALERTS                                                             │
│  • Single stock concentration: AAPL at 10% (limit: 8%)                      │
│  • Sector overweight: Technology at 35% (limit: 30%)                        │
│  • Factor tilt: Momentum exposure elevated (0.55 vs target 0.30)           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Performance Attribution

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Performance Attribution                     [YTD ▼] [vs S&P 500 ▼] [📊]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  RETURN SUMMARY (YTD through Aug 2, 2024)                                   │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ PORTFOLIO        │ │ BENCHMARK        │ │ EXCESS RETURN    │            │
│  │ ────────────────│ │ ────────────────│ │ ────────────────│            │
│  │  +18.5%          │ │  +15.2%          │ │  +3.3%           │            │
│  │  +$85.2M         │ │  (S&P 500)       │ │  (Alpha)         │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│                                                                              │
│  BRINSON ATTRIBUTION                                                        │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  Total Excess Return: +3.3%                                        │   │
│  │  ════════════════════════════                                       │   │
│  │                                                                     │   │
│  │  ┌─────────────────┐    ┌─────────────────┐    ┌────────────────┐  │   │
│  │  │ ALLOCATION      │ +  │ SELECTION       │ +  │ INTERACTION    │  │   │
│  │  │ ───────────────│    │ ───────────────│    │ ──────────────│  │   │
│  │  │ +0.8%           │    │ +2.2%           │    │ +0.3%          │  │   │
│  │  │                 │    │                 │    │                │  │   │
│  │  │ Sector weight   │    │ Stock picking   │    │ Combined       │  │   │
│  │  │ decisions       │    │ within sectors  │    │ effect         │  │   │
│  │  └─────────────────┘    └─────────────────┘    └────────────────┘  │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ATTRIBUTION BY SECTOR                                                      │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌────────────────┬────────┬──────────┬───────────┬───────────┬─────────┐  │
│  │ SECTOR         │ PORT   │ BENCH    │ ALLOCATION│ SELECTION │ TOTAL   │  │
│  │                │ WEIGHT │ WEIGHT   │ EFFECT    │ EFFECT    │ CONTRIB │  │
│  ├────────────────┼────────┼──────────┼───────────┼───────────┼─────────┤  │
│  │ Technology     │ 35.0%  │ 28.0%    │ +0.5%     │ +1.5%     │ +2.0%   │  │
│  │ Healthcare     │ 20.0%  │ 13.0%    │ +0.2%     │ +0.4%     │ +0.6%   │  │
│  │ Financials     │ 15.0%  │ 13.0%    │ +0.1%     │ +0.2%     │ +0.3%   │  │
│  │ Consumer       │ 10.0%  │ 11.0%    │ -0.0%     │ +0.1%     │ +0.1%   │  │
│  │ Industrials    │ 10.0%  │ 8.0%     │ +0.0%     │ +0.1%     │ +0.1%   │  │
│  │ Energy         │  5.0%  │ 5.0%     │  0.0%     │ -0.1%     │ -0.1%   │  │
│  │ Other          │  5.0%  │ 22.0%    │  0.0%     │ +0.0%     │ +0.0%   │  │
│  ├────────────────┼────────┼──────────┼───────────┼───────────┼─────────┤  │
│  │ TOTAL          │ 100%   │ 100%     │ +0.8%     │ +2.2%     │ +3.3%   │  │
│  └────────────────┴────────┴──────────┴───────────┴───────────┴─────────┘  │
│                                                                              │
│  TOP CONTRIBUTORS                        TOP DETRACTORS                     │
│  ══════════════════                      ════════════════════               │
│  1. NVDA   +1.2%  (Stock selection)     1. XOM   -0.2%  (Stock selection)  │
│  2. AAPL   +0.5%  (Stock selection)     2. BAC   -0.1%  (Stock selection)  │
│  3. MSFT   +0.4%  (Stock selection)     3. T     -0.1%  (Allocation)       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Holdings History

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Holdings History                             [AAPL ▼] [6 Months ▼] [📊]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  POSITION TIMELINE: AAPL                                                    │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Shares                                                              │   │
│  │  60K ┤                                    ┌───────────────────      │   │
│  │  50K ┤              ┌─────────────────────┘          Current: 50K   │   │
│  │  40K ┤    ┌─────────┘                                               │   │
│  │  30K ┤────┘                                                          │   │
│  │  20K ┤                                                               │   │
│  │      └────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────   │   │
│  │         Feb  Mar  Apr  May  Jun  Jul  Aug                           │   │
│  │                                                                      │   │
│  │  ▲ Buy 10K @ $170    ▲ Buy 20K @ $180    ▼ Sell 10K @ $220         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  TRANSACTION HISTORY                                                        │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌──────────┬────────┬──────────┬──────────┬───────────┬───────────────┐   │
│  │ DATE     │ ACTION │ QUANTITY │ PRICE    │ VALUE     │ RUNNING TOTAL │   │
│  ├──────────┼────────┼──────────┼──────────┼───────────┼───────────────┤   │
│  │ Feb 15   │ BUY    │ +30,000  │ $165.00  │$4,950,000 │ 30,000        │   │
│  │ Mar 10   │ BUY    │ +10,000  │ $170.00  │$1,700,000 │ 40,000        │   │
│  │ May 20   │ BUY    │ +20,000  │ $180.00  │$3,600,000 │ 60,000        │   │
│  │ Jul 15   │ SELL   │ -10,000  │ $220.00  │$2,200,000 │ 50,000        │   │
│  ├──────────┼────────┼──────────┼──────────┼───────────┼───────────────┤   │
│  │ CURRENT  │        │ 50,000   │          │           │ Avg: $175.00  │   │
│  └──────────┴────────┴──────────┴──────────┴───────────┴───────────────┘   │
│                                                                              │
│  WEIGHT OVER TIME                                                           │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Weight                                                              │   │
│  │  12% ┤                                              ┌────           │   │
│  │  10% ┤                            ┌─────────────────┘               │   │
│  │   8% ┤              ┌─────────────┘                                  │   │
│  │   6% ┤    ┌─────────┘                                                │   │
│  │   4% ┤────┘                                                          │   │
│  │      └────┬────┬────┬────┬────┬────┬────┬────                       │   │
│  │         Feb  Mar  Apr  May  Jun  Jul  Aug                           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## API Endpoints

### Positions

```yaml
GET /api/v1/portfolio/positions
  Query: fund_id, account_id, as_of_date, group_by
  Response: {
    positions: [Position],
    totals: { value, pnl, weight },
    grouping: optional grouping info
  }

GET /api/v1/portfolio/positions/{symbol}
  Query: account_id, include_history
  Response: Position with history

GET /api/v1/portfolio/positions/hierarchy
  Query: as_of_date
  Response: Fund → Account → Position tree

GET /api/v1/portfolio/positions/sector-breakdown
  Query: fund_id, as_of_date
  Response: Positions grouped by sector with totals
```

### Risk Analytics

```yaml
GET /api/v1/portfolio/risk/summary
  Query: fund_id, as_of_date
  Response: {
    var_95: VaR calculation,
    expected_shortfall: CVaR,
    beta: Market beta,
    factor_exposures: Factor loadings
  }

GET /api/v1/portfolio/risk/var
  Query: fund_id, confidence_level, horizon_days
  Response: VaR with breakdown by position

GET /api/v1/portfolio/risk/factors
  Query: fund_id, factor_model
  Response: Factor exposures and contributions

POST /api/v1/portfolio/risk/stress-test
  Body: { scenarios: [ScenarioDefinition] }
  Response: Impact by scenario and position

GET /api/v1/portfolio/risk/concentration
  Query: fund_id, limit_type
  Response: Concentration metrics and limit breaches
```

### Performance

```yaml
GET /api/v1/portfolio/performance/returns
  Query: fund_id, period, frequency
  Response: Time-weighted returns

GET /api/v1/portfolio/performance/attribution
  Query: fund_id, benchmark_id, period, method
  Response: Brinson attribution breakdown

GET /api/v1/portfolio/performance/contributors
  Query: fund_id, period, top_n
  Response: Top/bottom contributors

GET /api/v1/portfolio/performance/comparison
  Query: fund_ids, benchmark_ids, period
  Response: Comparative performance data
```

### Holdings History

```yaml
GET /api/v1/portfolio/holdings/history
  Query: fund_id, symbol, date_from, date_to
  Response: Position history time series

GET /api/v1/portfolio/holdings/transactions
  Query: fund_id, symbol, date_from, date_to
  Response: Trade history for position

GET /api/v1/portfolio/holdings/weight-history
  Query: fund_id, symbol, date_from, date_to
  Response: Weight over time
```

---

## Data Models

### Position

```typescript
interface Position {
  id: string;
  firmId: string;
  fundId: string;
  accountId: string;
  securityId: string;
  
  // Security info
  symbol: string;
  name: string;
  sector: string;
  industry: string;
  
  // Position data
  quantity: number;
  avgCost: number;
  costBasis: number;
  
  // Current values
  price: number;
  marketValue: number;
  
  // P&L
  unrealizedPnl: number;
  unrealizedPnlPercent: number;
  dayPnl: number;
  dayPnlPercent: number;
  
  // Weights
  weight: number;
  targetWeight: number | null;
  drift: number | null;
  
  // Metadata
  asOfDate: Date;
  updatedAt: Date;
}
```

### Risk Summary

```typescript
interface RiskSummary {
  fundId: string;
  asOfDate: Date;
  
  // VaR metrics
  var95_1day: number;
  var99_1day: number;
  var95_10day: number;
  expectedShortfall95: number;
  
  // Market risk
  beta: number;
  correlation: number;
  trackingError: number;
  informationRatio: number;
  
  // Factor exposures
  factorExposures: {
    market: number;
    size: number;
    value: number;
    momentum: number;
    quality: number;
    volatility: number;
  };
  
  // Concentration
  top10Weight: number;
  herfindahlIndex: number;
  maxSinglePosition: number;
  
  // Alerts
  alerts: RiskAlert[];
}
```

### Attribution Result

```typescript
interface AttributionResult {
  fundId: string;
  benchmarkId: string;
  period: string;
  
  // Returns
  portfolioReturn: number;
  benchmarkReturn: number;
  excessReturn: number;
  
  // Attribution effects
  allocationEffect: number;
  selectionEffect: number;
  interactionEffect: number;
  
  // By sector
  sectorAttribution: {
    sector: string;
    portfolioWeight: number;
    benchmarkWeight: number;
    portfolioReturn: number;
    benchmarkReturn: number;
    allocationEffect: number;
    selectionEffect: number;
    totalContribution: number;
  }[];
  
  // Top contributors
  topContributors: {
    symbol: string;
    contribution: number;
    source: 'allocation' | 'selection';
  }[];
  
  topDetractors: {
    symbol: string;
    contribution: number;
    source: 'allocation' | 'selection';
  }[];
}
```

---

## Calculation Logic

### VaR Calculation (Historical Simulation)

```python
def calculate_var_historical(
    positions: List[Position],
    returns_history: pd.DataFrame,
    confidence_level: float = 0.95,
    horizon_days: int = 1
) -> float:
    """
    Calculate Value at Risk using historical simulation.
    
    1. Get historical returns for each position
    2. Calculate portfolio returns using current weights
    3. Find percentile corresponding to confidence level
    """
    # Get position weights
    total_value = sum(p.market_value for p in positions)
    weights = {p.symbol: p.market_value / total_value for p in positions}
    
    # Calculate portfolio returns
    portfolio_returns = sum(
        returns_history[symbol] * weight 
        for symbol, weight in weights.items()
    )
    
    # Scale for horizon
    if horizon_days > 1:
        portfolio_returns = portfolio_returns * np.sqrt(horizon_days)
    
    # Calculate VaR
    var = -np.percentile(portfolio_returns, (1 - confidence_level) * 100)
    
    return var * total_value
```

### Brinson Attribution

```python
def calculate_brinson_attribution(
    portfolio_weights: Dict[str, float],
    benchmark_weights: Dict[str, float],
    portfolio_returns: Dict[str, float],
    benchmark_returns: Dict[str, float],
    sectors: Dict[str, str]
) -> Dict:
    """
    Calculate Brinson-Fachler attribution.
    """
    results = {}
    
    for sector in set(sectors.values()):
        # Get sector-level data
        port_weight = sum(w for s, w in portfolio_weights.items() 
                        if sectors.get(s) == sector)
        bench_weight = sum(w for s, w in benchmark_weights.items() 
                         if sectors.get(s) == sector)
        
        port_return = sum(r * portfolio_weights.get(s, 0) 
                        for s, r in portfolio_returns.items() 
                        if sectors.get(s) == sector) / port_weight if port_weight > 0 else 0
        
        bench_return = sum(r * benchmark_weights.get(s, 0) 
                         for s, r in benchmark_returns.items() 
                         if sectors.get(s) == sector) / bench_weight if bench_weight > 0 else 0
        
        # Calculate effects
        total_bench_return = sum(w * benchmark_returns.get(s, 0) 
                                for s, w in benchmark_weights.items())
        
        allocation_effect = (port_weight - bench_weight) * (bench_return - total_bench_return)
        selection_effect = bench_weight * (port_return - bench_return)
        interaction_effect = (port_weight - bench_weight) * (port_return - bench_return)
        
        results[sector] = {
            'allocation_effect': allocation_effect,
            'selection_effect': selection_effect,
            'interaction_effect': interaction_effect,
            'total_contribution': allocation_effect + selection_effect + interaction_effect
        }
    
    return results
```

---

## Component Structure

```
src/components/portfolio/
├── positions/
│   ├── PositionGrid.tsx
│   ├── PositionRow.tsx
│   ├── PositionDetail.tsx
│   ├── SectorGrouping.tsx
│   ├── FundHierarchy.tsx
│   └── DriftAlert.tsx
├── risk/
│   ├── RiskDashboard.tsx
│   ├── VaRCard.tsx
│   ├── FactorExposure.tsx
│   ├── StressTest.tsx
│   ├── ConcentrationChart.tsx
│   └── RiskAlerts.tsx
├── performance/
│   ├── PerformanceChart.tsx
│   ├── AttributionTable.tsx
│   ├── BrinsonChart.tsx
│   ├── ContributorsList.tsx
│   └── BenchmarkComparison.tsx
├── history/
│   ├── HoldingsHistory.tsx
│   ├── PositionTimeline.tsx
│   ├── TransactionList.tsx
│   └── WeightChart.tsx
└── rebalancing/
    ├── DriftAnalysis.tsx
    ├── TargetWeights.tsx
    ├── RebalancePreview.tsx
    └── TradeGenerator.tsx
```
