# Database Schema: MarketSpine

## Overview

PostgreSQL database schema supporting all MarketSpine modules. Designed for:
- Multi-tenant architecture (firm isolation)
- Audit logging and compliance
- High-performance queries with proper indexing
- Soft deletes for regulatory retention

## Schema Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              CORE ENTITIES                                          │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐       │
│  │    firms    │────▶│    users    │────▶│   sessions  │     │ audit_logs  │       │
│  └─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘       │
│         │                   │                                                       │
│         │            ┌──────┴──────┐                                               │
│         │            │             │                                               │
│         ▼            ▼             ▼                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                                 │
│  │    funds    │  │   roles     │  │ permissions │                                 │
│  └─────────────┘  └─────────────┘  └─────────────┘                                 │
│         │                                                                           │
│         ▼                                                                           │
│  ┌─────────────┐                                                                   │
│  │  accounts   │                                                                   │
│  └─────────────┘                                                                   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              TRADING MODULE                                         │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                           │
│  │   brokers   │◀────│   orders    │────▶│ securities  │                           │
│  └─────────────┘     └─────────────┘     └─────────────┘                           │
│         │                   │                   │                                   │
│         │                   ▼                   │                                   │
│         │            ┌─────────────┐            │                                   │
│         └───────────▶│ executions  │◀───────────┘                                   │
│                      └─────────────┘                                               │
│                             │                                                       │
│                      ┌──────┴──────┐                                               │
│                      ▼             ▼                                               │
│               ┌─────────────┐  ┌─────────────┐                                     │
│               │ commissions │  │   venues    │                                     │
│               └─────────────┘  └─────────────┘                                     │
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐                                               │
│  │broker_perf  │     │ tca_reports │                                               │
│  └─────────────┘     └─────────────┘                                               │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              PORTFOLIO MODULE                                       │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                           │
│  │  positions  │────▶│   holdings  │◀────│ benchmarks  │                           │
│  └─────────────┘     └─────────────┘     └─────────────┘                           │
│         │                                                                           │
│         ▼                                                                           │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                           │
│  │ performance │     │ attribution │     │risk_metrics │                           │
│  └─────────────┘     └─────────────┘     └─────────────┘                           │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              RESEARCH MODULE                                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                           │
│  │  companies  │◀────│research_notes│────▶│    tags    │                           │
│  └─────────────┘     └─────────────┘     └─────────────┘                           │
│         │                   │                                                       │
│         │                   ▼                                                       │
│         │            ┌─────────────┐                                               │
│         └───────────▶│note_mentions│                                               │
│                      └─────────────┘                                               │
│                                                                                     │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                           │
│  │news_articles│     │  earnings   │     │analyst_ratings│                         │
│  └─────────────┘     └─────────────┘     └─────────────┘                           │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Table Definitions

### Core: Firms & Users

```sql
-- ============================================================================
-- FIRM & MULTI-TENANCY
-- ============================================================================

CREATE TABLE firms (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    legal_name      VARCHAR(500),
    crd_number      VARCHAR(20),           -- FINRA CRD
    lei             VARCHAR(20),           -- Legal Entity Identifier
    settings        JSONB DEFAULT '{}',    -- Firm-wide settings
    subscription    VARCHAR(50) DEFAULT 'basic', -- basic, professional, enterprise
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ            -- Soft delete
);

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    email           VARCHAR(255) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    first_name      VARCHAR(100),
    last_name       VARCHAR(100),
    title           VARCHAR(100),          -- e.g., "Portfolio Manager"
    department      VARCHAR(100),          -- e.g., "Equities"
    phone           VARCHAR(50),
    avatar_url      VARCHAR(500),
    mfa_enabled     BOOLEAN DEFAULT false,
    mfa_secret      VARCHAR(255),
    status          VARCHAR(20) DEFAULT 'active', -- active, suspended, pending
    last_login_at   TIMESTAMPTZ,
    preferences     JSONB DEFAULT '{}',    -- User preferences
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_users_firm ON users(firm_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;

-- ============================================================================
-- ROLES & PERMISSIONS (RBAC)
-- ============================================================================

CREATE TABLE roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID REFERENCES firms(id), -- NULL = system role
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    permissions     JSONB NOT NULL DEFAULT '[]', -- Array of permission codes
    is_system       BOOLEAN DEFAULT false,  -- Built-in role
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_roles (
    user_id         UUID NOT NULL REFERENCES users(id),
    role_id         UUID NOT NULL REFERENCES roles(id),
    granted_by      UUID REFERENCES users(id),
    granted_at      TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id)
);

-- System roles (inserted on install)
-- INSERT INTO roles (name, permissions, is_system) VALUES
--   ('admin', '["*"]', true),
--   ('portfolio_manager', '["portfolio:*", "research:read", "trading:read"]', true),
--   ('trader', '["trading:*", "portfolio:read"]', true),
--   ('analyst', '["research:*", "portfolio:read"]', true),
--   ('compliance', '["compliance:*", "trading:read", "portfolio:read"]', true),
--   ('viewer', '["*:read"]', true);

-- ============================================================================
-- SESSIONS & AUDIT
-- ============================================================================

CREATE TABLE sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id),
    token_hash      VARCHAR(255) NOT NULL,
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    firm_id         UUID NOT NULL REFERENCES firms(id),
    user_id         UUID REFERENCES users(id),
    action          VARCHAR(100) NOT NULL,  -- e.g., 'order.create', 'user.login'
    resource_type   VARCHAR(100),           -- e.g., 'order', 'research_note'
    resource_id     UUID,
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    user_agent      TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_firm ON audit_logs(firm_id, created_at DESC);
CREATE INDEX idx_audit_user ON audit_logs(user_id, created_at DESC);
CREATE INDEX idx_audit_resource ON audit_logs(resource_type, resource_id);
```

### Trading Module

```sql
-- ============================================================================
-- SECURITIES & COMPANIES
-- ============================================================================

CREATE TABLE companies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    legal_name      VARCHAR(500),
    cik             VARCHAR(10),           -- SEC CIK
    lei             VARCHAR(20),
    industry        VARCHAR(100),
    sector          VARCHAR(100),
    sic_code        VARCHAR(10),
    country         VARCHAR(2),            -- ISO country code
    description     TEXT,
    website         VARCHAR(500),
    headquarters    JSONB,                 -- {city, state, country}
    founded_date    DATE,
    ipo_date        DATE,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_companies_cik ON companies(cik);
CREATE INDEX idx_companies_sector ON companies(sector);

CREATE TABLE securities (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID REFERENCES companies(id),
    symbol          VARCHAR(20) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    security_type   VARCHAR(50) NOT NULL,  -- equity, bond, option, etc.
    exchange        VARCHAR(20),           -- NYSE, NASDAQ, etc.
    cusip           VARCHAR(9),
    isin            VARCHAR(12),
    sedol           VARCHAR(7),
    figi            VARCHAR(12),           -- Bloomberg FIGI
    currency        VARCHAR(3) DEFAULT 'USD',
    lot_size        INTEGER DEFAULT 1,
    is_active       BOOLEAN DEFAULT true,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_securities_symbol_exchange ON securities(symbol, exchange);
CREATE INDEX idx_securities_company ON securities(company_id);
CREATE INDEX idx_securities_cusip ON securities(cusip);

-- ============================================================================
-- BROKERS & VENUES
-- ============================================================================

CREATE TABLE brokers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    short_name      VARCHAR(50),           -- e.g., "JPM", "GS"
    mpid            VARCHAR(4),            -- Market Participant ID
    lei             VARCHAR(20),
    broker_type     VARCHAR(50),           -- executing, prime, clearing
    is_active       BOOLEAN DEFAULT true,
    contact_info    JSONB,                 -- {phone, email, coverage}
    commission_schedule JSONB,             -- Default commission rates
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE venues (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    mic             VARCHAR(4) NOT NULL,   -- Market Identifier Code
    venue_type      VARCHAR(50),           -- exchange, ats, dark_pool
    country         VARCHAR(2),
    is_active       BOOLEAN DEFAULT true,
    fee_schedule    JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- FUNDS & ACCOUNTS
-- ============================================================================

CREATE TABLE funds (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    name            VARCHAR(255) NOT NULL,
    short_name      VARCHAR(50),
    fund_type       VARCHAR(50),           -- mutual_fund, hedge_fund, etf, etc.
    strategy        VARCHAR(100),          -- growth, value, income, etc.
    benchmark_id    UUID,                  -- Reference to benchmark
    inception_date  DATE,
    aum             DECIMAL(20, 2),        -- Assets under management
    currency        VARCHAR(3) DEFAULT 'USD',
    is_active       BOOLEAN DEFAULT true,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_funds_firm ON funds(firm_id);

CREATE TABLE accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    fund_id         UUID REFERENCES funds(id),
    account_number  VARCHAR(50) NOT NULL,
    name            VARCHAR(255),
    account_type    VARCHAR(50),           -- trading, custody, etc.
    custodian       VARCHAR(100),
    is_active       BOOLEAN DEFAULT true,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_accounts_number ON accounts(firm_id, account_number);
CREATE INDEX idx_accounts_fund ON accounts(fund_id);

-- ============================================================================
-- ORDERS & EXECUTIONS
-- ============================================================================

CREATE TABLE orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    account_id      UUID NOT NULL REFERENCES accounts(id),
    fund_id         UUID REFERENCES funds(id),
    security_id     UUID NOT NULL REFERENCES securities(id),
    broker_id       UUID REFERENCES brokers(id),
    trader_id       UUID REFERENCES users(id),
    
    -- Order details
    order_ref       VARCHAR(50) NOT NULL,  -- External reference
    side            VARCHAR(10) NOT NULL,  -- buy, sell, short
    order_type      VARCHAR(20) NOT NULL,  -- market, limit, stop, etc.
    quantity        DECIMAL(20, 4) NOT NULL,
    limit_price     DECIMAL(20, 8),
    stop_price      DECIMAL(20, 8),
    time_in_force   VARCHAR(10),           -- day, gtc, ioc, fok
    
    -- Status
    status          VARCHAR(20) NOT NULL DEFAULT 'pending',
    filled_quantity DECIMAL(20, 4) DEFAULT 0,
    avg_price       DECIMAL(20, 8),
    
    -- Timestamps
    order_date      DATE NOT NULL,
    submitted_at    TIMESTAMPTZ,
    filled_at       TIMESTAMPTZ,
    cancelled_at    TIMESTAMPTZ,
    
    -- Algo/routing
    algo_name       VARCHAR(50),           -- VWAP, TWAP, etc.
    algo_params     JSONB,
    routing_instr   VARCHAR(100),
    
    -- Compliance
    compliance_status VARCHAR(20),
    compliance_notes TEXT,
    
    -- Analysis
    arrival_price   DECIMAL(20, 8),        -- Price at order submission
    vwap_price      DECIMAL(20, 8),        -- VWAP during execution
    close_price     DECIMAL(20, 8),        -- Closing price that day
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_orders_firm ON orders(firm_id, order_date DESC);
CREATE INDEX idx_orders_account ON orders(account_id, order_date DESC);
CREATE INDEX idx_orders_security ON orders(security_id, order_date DESC);
CREATE INDEX idx_orders_broker ON orders(broker_id, order_date DESC);
CREATE INDEX idx_orders_status ON orders(status) WHERE status NOT IN ('filled', 'cancelled');

CREATE TABLE executions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id        UUID NOT NULL REFERENCES orders(id),
    broker_id       UUID REFERENCES brokers(id),
    venue_id        UUID REFERENCES venues(id),
    
    -- Fill details
    exec_ref        VARCHAR(50),           -- Broker execution ID
    quantity        DECIMAL(20, 4) NOT NULL,
    price           DECIMAL(20, 8) NOT NULL,
    gross_amount    DECIMAL(20, 2),        -- qty * price
    
    -- Fees
    commission      DECIMAL(20, 4),
    sec_fee         DECIMAL(20, 4),
    taf_fee         DECIMAL(20, 4),
    exchange_fee    DECIMAL(20, 4),
    clearing_fee    DECIMAL(20, 4),
    net_amount      DECIMAL(20, 2),        -- gross + fees
    
    -- Execution quality
    liquidity_flag  VARCHAR(10),           -- add, remove, other
    capacity        VARCHAR(10),           -- agency, principal, riskless
    
    -- Timestamps
    exec_time       TIMESTAMPTZ NOT NULL,
    settle_date     DATE,
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_executions_order ON executions(order_id);
CREATE INDEX idx_executions_time ON executions(exec_time DESC);

-- ============================================================================
-- COMMISSION & TCA
-- ============================================================================

CREATE TABLE commissions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    execution_id    UUID NOT NULL REFERENCES executions(id),
    broker_id       UUID NOT NULL REFERENCES brokers(id),
    
    commission_type VARCHAR(50),           -- execution, soft_dollar, etc.
    amount          DECIMAL(20, 4) NOT NULL,
    currency        VARCHAR(3) DEFAULT 'USD',
    rate            DECIMAL(10, 6),        -- Per share or %
    rate_type       VARCHAR(20),           -- per_share, percentage, flat
    
    period_date     DATE NOT NULL,
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_commissions_firm ON commissions(firm_id, period_date DESC);
CREATE INDEX idx_commissions_broker ON commissions(broker_id, period_date DESC);

CREATE TABLE broker_performance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    broker_id       UUID NOT NULL REFERENCES brokers(id),
    
    period_type     VARCHAR(10) NOT NULL,  -- daily, weekly, monthly
    period_date     DATE NOT NULL,
    
    -- Metrics
    order_count     INTEGER,
    fill_rate       DECIMAL(5, 2),         -- Percentage filled
    avg_slippage    DECIMAL(20, 8),        -- Avg price vs VWAP
    total_commission DECIMAL(20, 2),
    commission_rate DECIMAL(10, 6),
    avg_fill_time   INTERVAL,
    
    -- Score
    score           DECIMAL(5, 2),         -- 0-100
    score_delta     DECIMAL(5, 2),         -- Change from prior period
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(firm_id, broker_id, period_type, period_date)
);

CREATE INDEX idx_broker_perf_firm ON broker_performance(firm_id, period_date DESC);

CREATE TABLE tca_reports (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    order_id        UUID REFERENCES orders(id),  -- Single order or NULL for aggregate
    
    report_type     VARCHAR(50) NOT NULL,  -- order, daily, monthly, broker
    period_start    DATE,
    period_end      DATE,
    
    -- Metrics
    total_orders    INTEGER,
    total_shares    DECIMAL(20, 4),
    total_value     DECIMAL(20, 2),
    
    -- Slippage
    implementation_shortfall DECIMAL(20, 2),
    vs_arrival      DECIMAL(20, 8),
    vs_vwap         DECIMAL(20, 8),
    vs_twap         DECIMAL(20, 8),
    vs_close        DECIMAL(20, 8),
    
    -- Breakdown
    market_impact   DECIMAL(20, 2),
    timing_cost     DECIMAL(20, 2),
    opportunity_cost DECIMAL(20, 2),
    
    report_data     JSONB,                 -- Full report details
    generated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tca_firm ON tca_reports(firm_id, period_end DESC);
```

### Portfolio Module

```sql
-- ============================================================================
-- POSITIONS & HOLDINGS
-- ============================================================================

CREATE TABLE positions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    account_id      UUID NOT NULL REFERENCES accounts(id),
    security_id     UUID NOT NULL REFERENCES securities(id),
    
    as_of_date      DATE NOT NULL,
    
    quantity        DECIMAL(20, 4) NOT NULL,
    market_value    DECIMAL(20, 2),
    cost_basis      DECIMAL(20, 2),
    avg_cost        DECIMAL(20, 8),
    unrealized_pnl  DECIMAL(20, 2),
    realized_pnl    DECIMAL(20, 2),
    
    -- Weights
    portfolio_weight DECIMAL(10, 6),
    sector_weight   DECIMAL(10, 6),
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(account_id, security_id, as_of_date)
);

CREATE INDEX idx_positions_account ON positions(account_id, as_of_date DESC);
CREATE INDEX idx_positions_security ON positions(security_id, as_of_date DESC);

CREATE TABLE holdings_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    position_id     UUID NOT NULL REFERENCES positions(id),
    as_of_date      DATE NOT NULL,
    
    quantity        DECIMAL(20, 4),
    market_value    DECIMAL(20, 2),
    
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_holdings_history ON holdings_history(position_id, as_of_date DESC);

-- ============================================================================
-- PERFORMANCE & ATTRIBUTION
-- ============================================================================

CREATE TABLE fund_performance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fund_id         UUID NOT NULL REFERENCES funds(id),
    
    period_type     VARCHAR(10) NOT NULL,  -- daily, monthly, quarterly, yearly
    period_date     DATE NOT NULL,
    
    -- Returns
    gross_return    DECIMAL(20, 8),
    net_return      DECIMAL(20, 8),
    benchmark_return DECIMAL(20, 8),
    alpha           DECIMAL(20, 8),
    
    -- Cumulative
    ytd_return      DECIMAL(20, 8),
    inception_return DECIMAL(20, 8),
    
    -- Risk
    volatility      DECIMAL(20, 8),
    sharpe_ratio    DECIMAL(10, 4),
    sortino_ratio   DECIMAL(10, 4),
    max_drawdown    DECIMAL(20, 8),
    beta            DECIMAL(10, 4),
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(fund_id, period_type, period_date)
);

CREATE INDEX idx_fund_perf ON fund_performance(fund_id, period_date DESC);

CREATE TABLE attribution (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fund_id         UUID NOT NULL REFERENCES funds(id),
    
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    attribution_type VARCHAR(50),          -- brinson, factor, etc.
    
    -- Brinson
    allocation_effect DECIMAL(20, 8),
    selection_effect DECIMAL(20, 8),
    interaction_effect DECIMAL(20, 8),
    
    -- By dimension (stored in JSONB)
    by_sector       JSONB,
    by_country      JSONB,
    by_market_cap   JSONB,
    by_factor       JSONB,
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_attribution_fund ON attribution(fund_id, period_end DESC);

-- ============================================================================
-- RISK METRICS
-- ============================================================================

CREATE TABLE risk_metrics (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    entity_type     VARCHAR(50) NOT NULL,  -- fund, account, position
    entity_id       UUID NOT NULL,
    
    as_of_date      DATE NOT NULL,
    
    -- Market risk
    var_95          DECIMAL(20, 2),        -- 95% VaR
    var_99          DECIMAL(20, 2),        -- 99% VaR
    cvar            DECIMAL(20, 2),        -- Conditional VaR
    
    -- Factor exposures
    beta            DECIMAL(10, 4),
    factor_exposures JSONB,                -- {momentum, value, size, etc.}
    
    -- Concentration
    top_10_weight   DECIMAL(10, 4),
    sector_concentration DECIMAL(10, 4),
    country_concentration DECIMAL(10, 4),
    
    -- Liquidity
    liquidity_score DECIMAL(10, 4),
    days_to_liquidate DECIMAL(10, 2),
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(entity_type, entity_id, as_of_date)
);

CREATE INDEX idx_risk_entity ON risk_metrics(entity_type, entity_id, as_of_date DESC);
```

### Research & Collaboration Module

```sql
-- ============================================================================
-- RESEARCH NOTES
-- ============================================================================

CREATE TABLE research_notes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    author_id       UUID NOT NULL REFERENCES users(id),
    
    title           VARCHAR(500) NOT NULL,
    content         TEXT NOT NULL,
    summary         TEXT,
    
    note_type       VARCHAR(50),           -- company, sector, thematic, meeting
    status          VARCHAR(20) DEFAULT 'draft', -- draft, published, archived
    visibility      VARCHAR(20) DEFAULT 'firm', -- private, team, firm
    
    -- Ratings/recommendations
    rating          VARCHAR(20),           -- buy, hold, sell
    price_target    DECIMAL(20, 4),
    conviction      VARCHAR(20),           -- high, medium, low
    
    published_at    TIMESTAMPTZ,
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_research_firm ON research_notes(firm_id, created_at DESC);
CREATE INDEX idx_research_author ON research_notes(author_id, created_at DESC);
CREATE INDEX idx_research_status ON research_notes(status, visibility);

-- Full-text search
CREATE INDEX idx_research_fts ON research_notes 
    USING gin(to_tsvector('english', title || ' ' || content));

-- Link notes to entities
CREATE TABLE note_entities (
    note_id         UUID NOT NULL REFERENCES research_notes(id),
    entity_type     VARCHAR(50) NOT NULL,  -- company, security, sector
    entity_id       UUID NOT NULL,
    PRIMARY KEY (note_id, entity_type, entity_id)
);

CREATE INDEX idx_note_entities ON note_entities(entity_type, entity_id);

CREATE TABLE note_tags (
    note_id         UUID NOT NULL REFERENCES research_notes(id),
    tag             VARCHAR(100) NOT NULL,
    PRIMARY KEY (note_id, tag)
);

CREATE INDEX idx_note_tags ON note_tags(tag);

-- ============================================================================
-- NEWS & ALERTS
-- ============================================================================

CREATE TABLE news_articles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source          VARCHAR(100) NOT NULL,
    source_id       VARCHAR(255),          -- External article ID
    
    title           VARCHAR(1000) NOT NULL,
    summary         TEXT,
    content         TEXT,
    url             VARCHAR(2000),
    author          VARCHAR(255),
    
    published_at    TIMESTAMPTZ NOT NULL,
    
    sentiment       DECIMAL(5, 4),         -- -1 to 1
    relevance       DECIMAL(5, 4),
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_news_published ON news_articles(published_at DESC);
CREATE INDEX idx_news_fts ON news_articles 
    USING gin(to_tsvector('english', title || ' ' || COALESCE(summary, '')));

-- Link news to entities
CREATE TABLE news_entities (
    article_id      UUID NOT NULL REFERENCES news_articles(id),
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID NOT NULL,
    relevance       DECIMAL(5, 4),
    PRIMARY KEY (article_id, entity_type, entity_id)
);

CREATE INDEX idx_news_entities ON news_entities(entity_type, entity_id);

CREATE TABLE alerts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    user_id         UUID REFERENCES users(id), -- NULL = firm-wide
    
    alert_type      VARCHAR(50) NOT NULL,  -- news, price, trade, compliance
    entity_type     VARCHAR(50),
    entity_id       UUID,
    
    title           VARCHAR(500) NOT NULL,
    message         TEXT,
    severity        VARCHAR(20) DEFAULT 'info', -- info, warning, critical
    
    is_read         BOOLEAN DEFAULT false,
    read_at         TIMESTAMPTZ,
    
    expires_at      TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_alerts_user ON alerts(user_id, created_at DESC) WHERE is_read = false;
CREATE INDEX idx_alerts_firm ON alerts(firm_id, created_at DESC);

-- ============================================================================
-- MESSAGING
-- ============================================================================

CREATE TABLE conversations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    
    conversation_type VARCHAR(20) NOT NULL, -- direct, group, channel
    name            VARCHAR(255),           -- For groups/channels
    
    created_by      UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE conversation_members (
    conversation_id UUID NOT NULL REFERENCES conversations(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    role            VARCHAR(20) DEFAULT 'member', -- admin, member
    joined_at       TIMESTAMPTZ DEFAULT NOW(),
    last_read_at    TIMESTAMPTZ,
    PRIMARY KEY (conversation_id, user_id)
);

CREATE TABLE messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(id),
    sender_id       UUID NOT NULL REFERENCES users(id),
    
    content         TEXT NOT NULL,
    message_type    VARCHAR(20) DEFAULT 'text', -- text, file, link, entity
    
    -- For entity shares
    entity_type     VARCHAR(50),
    entity_id       UUID,
    
    is_edited       BOOLEAN DEFAULT false,
    edited_at       TIMESTAMPTZ,
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at DESC);

-- ============================================================================
-- CALENDAR & MEETINGS
-- ============================================================================

CREATE TABLE meetings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id         UUID NOT NULL REFERENCES firms(id),
    organizer_id    UUID NOT NULL REFERENCES users(id),
    
    title           VARCHAR(500) NOT NULL,
    description     TEXT,
    meeting_type    VARCHAR(50),           -- earnings_call, client, internal
    
    start_time      TIMESTAMPTZ NOT NULL,
    end_time        TIMESTAMPTZ NOT NULL,
    timezone        VARCHAR(50),
    
    location        VARCHAR(500),
    video_link      VARCHAR(1000),
    
    status          VARCHAR(20) DEFAULT 'scheduled', -- scheduled, completed, cancelled
    
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_meetings_firm ON meetings(firm_id, start_time);
CREATE INDEX idx_meetings_organizer ON meetings(organizer_id, start_time);

CREATE TABLE meeting_attendees (
    meeting_id      UUID NOT NULL REFERENCES meetings(id),
    user_id         UUID REFERENCES users(id),
    external_email  VARCHAR(255),          -- For external attendees
    status          VARCHAR(20) DEFAULT 'pending', -- pending, accepted, declined
    PRIMARY KEY (meeting_id, COALESCE(user_id::text, external_email))
);

-- Link meetings to entities (companies being discussed)
CREATE TABLE meeting_entities (
    meeting_id      UUID NOT NULL REFERENCES meetings(id),
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID NOT NULL,
    PRIMARY KEY (meeting_id, entity_type, entity_id)
);

CREATE TABLE meeting_notes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    meeting_id      UUID NOT NULL REFERENCES meetings(id),
    author_id       UUID NOT NULL REFERENCES users(id),
    
    content         TEXT NOT NULL,
    is_private      BOOLEAN DEFAULT false,
    
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
```

---

## Indexes Summary

All critical query patterns are indexed:
- Firm-level data isolation (composite indexes with firm_id)
- Time-series queries (date DESC indexes)
- Foreign key relationships
- Full-text search (GIN indexes)
- Status-based filtering (partial indexes)

## Migrations

Use a migration tool like Alembic (Python) or golang-migrate:

```bash
# Create migration
alembic revision --autogenerate -m "add_risk_metrics"

# Run migrations
alembic upgrade head

# Rollback
alembic downgrade -1
```
