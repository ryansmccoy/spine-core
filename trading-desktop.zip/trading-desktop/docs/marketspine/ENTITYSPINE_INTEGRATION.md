# EntitySpine Integration Guide

## Overview

This document describes how EntitySpine's Social Feed and Knowledge Graph features integrate with MarketSpine's institutional investment platform.

---

## Integration Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ENTITYSPINE + MARKETSPINE INTEGRATION                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         ENTITYSPINE                                  │   │
│  │  ═══════════════════════════════════════════════════════════════    │   │
│  │                                                                      │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │ Social Feed  │  │  Knowledge   │  │  Universal   │              │   │
│  │  │   Engine     │  │    Graph     │  │    Query     │              │   │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘              │   │
│  │         │                 │                 │                       │   │
│  │         └─────────────────┼─────────────────┘                       │   │
│  │                           │                                         │   │
│  │                    ┌──────▼──────┐                                  │   │
│  │                    │  Entity API  │                                  │   │
│  │                    │  /api/v1/    │                                  │   │
│  │                    └──────┬──────┘                                  │   │
│  └───────────────────────────┼─────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         MARKETSPINE                                  │   │
│  │  ═══════════════════════════════════════════════════════════════    │   │
│  │                                                                      │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Trading    │  │   Research   │  │  Compliance  │              │   │
│  │  │   Center     │  │     Hub      │  │   Console    │              │   │
│  │  │              │  │              │  │              │              │   │
│  │  │ • Entity     │  │ • Knowledge  │  │ • Relation-  │              │   │
│  │  │   alerts     │  │   graph viz  │  │   ship       │              │   │
│  │  │ • Relation-  │  │ • Social     │  │   monitoring │              │   │
│  │  │   ship risk  │  │   feed       │  │ • Insider    │              │   │
│  │  │              │  │   cards      │  │   detection  │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature Integration Points

### 1. Trading Center Integration

| EntitySpine Feature | MarketSpine Usage | Implementation |
|---------------------|-------------------|----------------|
| **Company Profile** | Quick-view in order entry | Embed `<CompanyMiniProfile ticker={symbol} />` |
| **Relationship Alerts** | Supplier disruption → trading signal | Subscribe to `/feed?types=relationship&tickers={holdings}` |
| **Social Feed Cards** | News sidebar in trading view | Filter feed by portfolio holdings |

#### Trading Alert Example

```typescript
// When EntitySpine detects a relationship change affecting held securities
{
  "alert_type": "relationship_change",
  "source_entity": "Panasonic",
  "target_entity": "TSLA",
  "relationship": "supplies_to",
  "change": "terminated",
  "impact": "Battery supplier relationship ended",
  "action_suggestion": "Review TSLA position - supply chain risk",
  "portfolio_exposure": "$2.5M (3.2% of NAV)"
}
```

### 2. Research Hub Integration

| EntitySpine Feature | MarketSpine Usage | Implementation |
|---------------------|-------------------|----------------|
| **Knowledge Graph** | Visual research exploration | Embed `<RelationshipGraph3D companyId={cik} />` |
| **Social Feed** | Research news stream | `/feed?sectors={watchedSectors}` |
| **Universal Query** | Company screening | NLP query → results table |
| **Company Financials** | Fundamental analysis | Financial statements API |

#### Research Workflow

```
1. Analyst opens Research Hub
2. Views Social Feed filtered by coverage universe
3. Sees "New Relationship: $TSLA → New Battery Supplier"
4. Clicks through to Knowledge Graph
5. Explores supplier network visually
6. Queries "companies supplying Tesla with revenue > $1B"
7. Exports results for further analysis
8. Creates research note with linked entities
```

### 3. Compliance Console Integration

| EntitySpine Feature | MarketSpine Usage | Implementation |
|---------------------|-------------------|----------------|
| **Entity Graph** | Conflict of interest detection | Query relationships for portfolio companies |
| **Person Entities** | Insider tracking | Monitor officer changes |
| **Relationship Changes** | Material event detection | Alert on relationship modifications |

#### Compliance Alert Example

```typescript
// Detect potential conflict when relationship discovered
{
  "alert_type": "potential_conflict",
  "description": "New relationship detected between portfolio company and restricted entity",
  "details": {
    "portfolio_company": "AAPL",
    "relationship": "acquired_by",
    "related_entity": "Restricted Corp",
    "portfolio_exposure": "$5.2M",
    "recommendation": "Review compliance restrictions"
  }
}
```

### 4. Portfolio Manager Integration

| EntitySpine Feature | MarketSpine Usage | Implementation |
|---------------------|-------------------|----------------|
| **Sector Data** | Allocation analysis | `/sectors/{sector}/metrics` |
| **Industry Benchmarks** | Relative valuation | Compare holdings to industry |
| **Relationship Network** | Concentration risk | Supplier overlap analysis |

#### Concentration Risk Example

```
Portfolio holds: $AAPL, $TSLA, $NVDA

Knowledge Graph reveals:
- All three source chips from TSMC
- TSMC supplies 85% of AAPL chip needs
- TSMC supplies 70% of NVDA AI chips
- TSMC supplies 45% of TSLA FSD chips

Risk Alert:
"Taiwan Semiconductor concentration: 67% of portfolio
has significant TSMC dependency. Consider hedging
Taiwan geopolitical risk."
```

---

## Social Feed in MarketSpine

### Feed Card Types for MarketSpine

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  MARKETSPINE NEWS FEED                                [Filter: Portfolio ▼] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ 🔔 PORTFOLIO ALERT • 10 minutes ago                                   │  │
│  │ ─────────────────────────────────────────────────────────────────────│  │
│  │                                                                       │  │
│  │ SUPPLY CHAIN DISRUPTION DETECTED                                      │  │
│  │                                                                       │  │
│  │ $TSLA supplier Panasonic (supplies_to) reported production issues    │  │
│  │ in their 8-K filing. This may impact Tesla's Q4 deliveries.          │  │
│  │                                                                       │  │
│  │ Portfolio Impact: $2.5M exposure (3.2% NAV)                          │  │
│  │                                                                       │  │
│  │ [View Filing] [View Relationship] [Create Order] [Dismiss]            │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ 📄 10-K FILED • 2 hours ago                                           │  │
│  │ ─────────────────────────────────────────────────────────────────────│  │
│  │                                                                       │  │
│  │ $NVDA - NVIDIA Corporation (HELD: $4.2M)                             │  │
│  │                                                                       │  │
│  │ ┌─────────────────────────────────────────────────────────────────┐  │  │
│  │ │ Revenue: $60.9B (+126% YoY)  │ Gross Margin: 72.7%             │  │  │
│  │ │ Data Center: +217% YoY       │ Gaming: +56% YoY                │  │  │
│  │ └─────────────────────────────────────────────────────────────────┘  │  │
│  │                                                                       │  │
│  │ AI Summary: Strong beat driven by AI infrastructure demand...        │  │
│  │                                                                       │  │
│  │ [View Full Filing] [Company Profile] [Add to Research]               │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ 👤 OFFICER CHANGE • 4 hours ago                                       │  │
│  │ ─────────────────────────────────────────────────────────────────────│  │
│  │                                                                       │  │
│  │ $AAPL CFO Luca Maestri stepping down                                 │  │
│  │ New CFO: Kevan Parekh (effective Jan 2025)                           │  │
│  │                                                                       │  │
│  │ Portfolio Impact: $8.1M exposure (10.4% NAV)                         │  │
│  │                                                                       │  │
│  │ [View 8-K] [Officer History] [Company Profile]                       │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Portfolio-Aware Feed Filtering

```python
# API endpoint for portfolio-filtered feed
@router.get("/feed/portfolio")
async def get_portfolio_feed(
    portfolio_id: UUID,
    types: List[str] = Query(default=["filing", "relationship", "officer"]),
    limit: int = 20,
    db: AsyncSession = Depends(get_session)
):
    """
    Get feed items relevant to portfolio holdings.
    
    Automatically filters by:
    - Tickers in portfolio
    - Suppliers/customers of portfolio companies
    - Competitors in same industries
    - Officer changes at held companies
    """
    # Get portfolio tickers
    holdings = await get_portfolio_holdings(portfolio_id, db)
    tickers = [h.ticker for h in holdings]
    
    # Get related entities (suppliers, customers, competitors)
    related = await get_related_entities(tickers, db)
    all_tickers = tickers + related
    
    # Query feed with portfolio context
    query = select(FeedItem).where(
        FeedItem.tickers.overlap(all_tickers),
        FeedItem.item_type.in_(types)
    ).order_by(FeedItem.published_at.desc()).limit(limit)
    
    items = await db.execute(query)
    
    # Annotate with portfolio exposure
    return [
        {
            **item.dict(),
            "portfolio_exposure": calculate_exposure(item.tickers, holdings),
            "is_direct_holding": any(t in tickers for t in item.tickers)
        }
        for item in items.scalars()
    ]
```

---

## Company Profile in MarketSpine Context

When viewing a company from MarketSpine (e.g., from a trading order or research note), the EntitySpine company profile is enhanced with trading context:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ← Back to Order    $TSLA - Tesla, Inc.        [Trade] [Research] [Alert]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  POSITION SUMMARY (MarketSpine)                                      │   │
│  │  ═══════════════════════════════════════════════════════════════    │   │
│  │                                                                      │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │   │
│  │  │ Shares   │ │ Avg Cost │ │ Mkt Value│ │ Unrealized│ │ % of NAV │  │   │
│  │  │ 10,000   │ │ $220.50  │ │ $2.485M  │ │ +$280K   │ │ 3.2%     │  │   │
│  │  │          │ │          │ │          │ │ +12.7%   │ │          │  │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │   │
│  │                                                                      │   │
│  │  Recent Trades:                                                      │   │
│  │  • 2024-10-15: BUY 2,000 @ $225.00 (JPM)                            │   │
│  │  • 2024-09-20: BUY 3,000 @ $218.50 (MS)                             │   │
│  │  • 2024-08-05: BUY 5,000 @ $219.25 (CANT)                           │   │
│  │                                                                      │   │
│  │  [View All Trades] [New Order]                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  COMPANY OVERVIEW (EntitySpine)                                      │   │
│  │  ═══════════════════════════════════════════════════════════════    │   │
│  │                                                                      │   │
│  │  [Standard EntitySpine company profile content here...]              │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## API Endpoints for Integration

### EntitySpine APIs Used by MarketSpine

```yaml
# Company Data
GET /api/v1/companies/{ticker}
GET /api/v1/companies/{ticker}/financials
GET /api/v1/companies/{ticker}/relationships
GET /api/v1/companies/{ticker}/competitors

# Feed Data
GET /api/v1/feed?tickers={portfolio_tickers}
GET /api/v1/feed/portfolio/{portfolio_id}
GET /api/v1/feed/trending

# Knowledge Graph
GET /api/v1/graph?center={ticker}&depth=2
GET /api/v1/relationships?source={ticker}
GET /api/v1/entities/{entity_id}

# Query
POST /api/v1/query/natural
POST /api/v1/query/structured

# Sectors
GET /api/v1/sectors
GET /api/v1/sectors/{sector}/industries/{industry}
```

### MarketSpine-Specific Endpoints

```yaml
# Portfolio-aware feed
GET /api/v1/marketspine/feed/portfolio/{portfolio_id}

# Trading context for company
GET /api/v1/marketspine/companies/{ticker}/trading-context
  Response:
    - position: current holdings
    - recent_trades: last 10 trades
    - alerts: active alerts
    - orders: pending orders

# Compliance relationship check
POST /api/v1/marketspine/compliance/relationship-check
  Body:
    - portfolio_id: UUID
    - check_type: conflict | restriction | concentration
  Response:
    - alerts: potential issues
    - relationships: flagged connections
```

---

## Implementation Checklist

### Phase 1: Basic Integration
- [ ] Embed company mini-profile in Trading Center
- [ ] Add Social Feed sidebar to Research Hub
- [ ] Create portfolio-filtered feed endpoint
- [ ] Add ticker links that navigate to EntitySpine company profile

### Phase 2: Knowledge Graph Integration
- [ ] Embed relationship graph in Research Hub
- [ ] Add supplier/customer network visualization
- [ ] Create concentration risk alerts based on relationships
- [ ] Build relationship-based compliance checks

### Phase 3: Advanced Features
- [ ] Real-time relationship change alerts
- [ ] AI-generated portfolio impact summaries
- [ ] Predictive signals integration
- [ ] Cross-platform search

---

## Component Sharing

### Shared React Components

```typescript
// Used by both EntitySpine frontend and MarketSpine

// Company components
import { CompanyHeader } from '@entityspine/components/company';
import { CompanyMiniProfile } from '@entityspine/components/company';
import { FinancialStatements } from '@entityspine/components/company';

// Feed components
import { FeedCard } from '@entityspine/components/feed';
import { FilingCard } from '@entityspine/components/feed';
import { RelationshipCard } from '@entityspine/components/feed';

// Graph components
import { RelationshipGraph3D } from '@entityspine/components/graph';
import { EntityNode } from '@entityspine/components/graph';

// Query components
import { QueryBuilder } from '@entityspine/components/query';
import { NaturalLanguageInput } from '@entityspine/components/query';
```

### Shared Hooks

```typescript
// Data fetching hooks
import { useCompany } from '@entityspine/hooks';
import { useFeed } from '@entityspine/hooks';
import { useGraph } from '@entityspine/hooks';
import { useQuery } from '@entityspine/hooks';
```

---

## References

- [EntitySpine Social Feed Vision](../../../entityspine/docs/SOCIAL_FEED_VISION.md)
- [EntitySpine Feature Roadmap](../../../entityspine/docs/FEATURE_ROADMAP.md)
- [EntitySpine API Overview](../../../entityspine/backend/docs/API_OVERVIEW.md)
- [MarketSpine Overview](./MARKETSPINE_OVERVIEW.md)
- [MarketSpine Trading Center](./TRADING_CENTER.md)
- [MarketSpine Research Hub](./RESEARCH_HUB.md)
