# Trading Center Module

## Overview

The Trading Center is the command center for institutional traders, providing real-time visibility into order flow, execution quality, broker performance, and commission analysis. The module answers the critical question: **"Are we getting best execution for our clients?"**

## Core Features

### 1. Order Blotter
Real-time view of all orders with status, fills, and performance metrics.

```
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│ ORDER BLOTTER                                                    🔍 Filter  📊 Export    │
├──────────────────────────────────────────────────────────────────────────────────────────┤
│ Order ID │ Symbol │ Side │  Qty  │ Filled │ Broker    │ Avg Price │ VWAP  │ Slippage   │
├──────────────────────────────────────────────────────────────────────────────────────────┤
│ ORD-4521 │ TSLA   │ BUY  │ 5,000 │ 5,000  │ JP Morgan │ $257.00   │$257.15│ -$0.15 ✅  │
│ ORD-4522 │ TSLA   │ BUY  │ 5,000 │ 5,000  │ MS        │ $259.39   │$257.15│ +$2.24 ❌  │
│ ORD-4523 │ TSLA   │ BUY  │ 5,000 │ 3,200  │ Cantor    │ $257.82   │$257.15│ +$0.67 ⚠️  │
│ ORD-4524 │ NVDA   │ SELL │10,000 │10,000  │ Goldman   │ $892.45   │$891.20│ +$1.25 ✅  │
└──────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2. Execution Comparison Widget

Compare identical orders sent to multiple brokers:

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ EXECUTION COMPARISON: TSLA Buy 5,000 shares (Jan 27, 2026)                          │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                     │
│  │   JP MORGAN     │  │ MORGAN STANLEY  │  │ CANTOR FITZ     │                     │
│  │   ⭐ BEST       │  │                 │  │                 │                     │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤                     │
│  │ Avg: $257.00    │  │ Avg: $259.39    │  │ Avg: $257.82    │                     │
│  │ Fills: 12 lots  │  │ Fills: 8 lots   │  │ Fills: 6 lots   │                     │
│  │ Time: 2.3 min   │  │ Time: 4.1 min   │  │ Time: 3.8 min   │                     │
│  │ Commission: $50 │  │ Commission: $45 │  │ Commission: $55 │                     │
│  │                 │  │                 │  │                 │                     │
│  │ Total: $1,285,050│ │ Total: $1,296,995│ │ Total: $1,289,155│                    │
│  │ vs VWAP: -$750  │  │ vs VWAP: +$11,195│ │ vs VWAP: +$3,355│                     │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                     │
│                                                                                     │
│  [📊 View Lot Breakdown]  [📈 Timeline View]  [📋 Export TCA Report]               │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3. Lot Breakdown Drill-Down

Click on any execution to see individual fills:

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LOT BREAKDOWN: JP Morgan TSLA Buy (ORD-4521)                                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ Fill # │ Time       │ Qty   │ Price   │ Venue │ Liquidity │ Commission │           │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ 1      │ 09:31:02.3 │   500 │ $256.80 │ NYSE  │ Add       │ $4.17      │           │
│ 2      │ 09:31:04.1 │   800 │ $256.85 │ ARCA  │ Remove    │ $6.67      │           │
│ 3      │ 09:31:08.7 │   200 │ $256.90 │ BATS  │ Add       │ $1.67      │           │
│ 4      │ 09:31:15.2 │ 1,200 │ $257.00 │ NYSE  │ Remove    │ $10.00     │           │
│ 5      │ 09:31:22.9 │   600 │ $257.05 │ IEX   │ Midpoint  │ $5.00      │           │
│ 6      │ 09:31:31.4 │   400 │ $257.10 │ NASDAQ│ Add       │ $3.33      │           │
│ ...    │ ...        │ ...   │ ...     │ ...   │ ...       │ ...        │           │
│ 12     │ 09:33:18.1 │   300 │ $257.20 │ NYSE  │ Remove    │ $2.50      │           │
├─────────────────────────────────────────────────────────────────────────────────────┤
│ TOTAL  │ 2m 16s     │ 5,000 │ $257.00 │       │           │ $50.00     │           │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 4. Broker Scorecard

Aggregate broker performance over time:

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ BROKER SCORECARD: January 2026                                   Period: [Month ▼]  │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Broker          │ Orders │ Commission │ Avg Slip │ Fill Rate │ Score │ Trend     │
│  ────────────────┼────────┼────────────┼──────────┼───────────┼───────┼─────────  │
│  JP Morgan       │    847 │   $42,350  │  -$0.08  │    98.2%  │  92   │ ↑ +3      │
│  Goldman Sachs   │    623 │   $31,150  │  +$0.12  │    97.8%  │  88   │ → 0       │
│  Morgan Stanley  │    512 │   $25,600  │  +$0.31  │    96.5%  │  79   │ ↓ -5      │
│  Cantor Fitz     │    298 │   $14,900  │  +$0.05  │    94.2%  │  85   │ ↑ +2      │
│  Jefferies       │    187 │    $9,350  │  -$0.02  │    99.1%  │  94   │ ↑ +7      │
│                                                                                     │
│  [📊 Details]  [📈 Trend Chart]  [🔄 Compare Period]  [📋 Export]                   │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 5. Commission Analysis

Track commission spend by broker, fund, strategy:

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ COMMISSION ANALYSIS                                                                 │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  By Broker (YTD)                      By Fund (January)                            │
│  ┌────────────────────────────┐       ┌────────────────────────────┐               │
│  │ ████████████████ JP Morgan │       │ ██████████████ Growth Fund │               │
│  │ $847,200 (28%)             │       │ $52,400 (35%)              │               │
│  │ ████████████ Goldman       │       │ ██████████ Value Fund      │               │
│  │ $623,400 (21%)             │       │ $38,200 (25%)              │               │
│  │ ████████ Morgan Stanley    │       │ ████████ Income Fund       │               │
│  │ $451,200 (15%)             │       │ $28,100 (19%)              │               │
│  │ ██████ Others              │       │ ██████ Others              │               │
│  │ $1,078,200 (36%)           │       │ $31,300 (21%)              │               │
│  └────────────────────────────┘       └────────────────────────────┘               │
│                                                                                     │
│  Commission Rate Trend                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐           │
│  │     $0.015 ─┼──────────────────────────────────────────────────     │           │
│  │             │    ╭─╮                                                │           │
│  │     $0.012 ─┼────╯ ╰─────╮                                          │           │
│  │             │            ╰──────────────╮                           │           │
│  │     $0.009 ─┼───────────────────────────╰──────────────             │           │
│  │             │                                                       │           │
│  │             └───────────────────────────────────────────────        │           │
│  │               Q1    Q2    Q3    Q4    Q1    Q2                      │           │
│  └─────────────────────────────────────────────────────────────────────┘           │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

## Knowledge Graph Integration

### Trade → Entity Relationships

```
                          ┌────────────────┐
                          │     TRADE      │
                          │   ORD-4521     │
                          └───────┬────────┘
                                  │
      ┌───────────────┬───────────┼───────────┬───────────────┐
      │               │           │           │               │
      ▼               ▼           ▼           ▼               ▼
┌───────────┐   ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐
│  ACCOUNT  │   │  BROKER   │ │ SECURITY  │ │  TRADER   │ │   FUND    │
│ ACC-1234  │   │ JP Morgan │ │   TSLA    │ │ J. Smith  │ │  Growth   │
└───────────┘   └───────────┘ └─────┬─────┘ └───────────┘ └───────────┘
                                    │
                              ┌─────▼─────┐
                              │  COMPANY  │
                              │   Tesla   │
                              └─────┬─────┘
                                    │
            ┌───────────────┬───────┴───────┬───────────────┐
            ▼               ▼               ▼               ▼
      ┌───────────┐   ┌───────────┐   ┌───────────┐   ┌───────────┐
      │ INDUSTRY  │   │  RESEARCH │   │    NEWS   │   │ HOLDINGS  │
      │  EV/Auto  │   │   Notes   │   │  Articles │   │  Position │
      └───────────┘   └───────────┘   └───────────┘   └───────────┘
```

### Interactive Graph View

Click on any trade in the blotter to see its relationship graph:
- Connected accounts and funds
- Broker executing the trade
- Security → Company → Industry chain
- Related research notes
- Recent news about the company
- Current portfolio position

## Widget Panels

### Trade Analysis Panel
When a trade is selected, shows:
- Execution timeline
- Price chart with fill markers
- Broker algo parameters
- Market conditions at time of trade

### Company Context Panel
For the traded security:
- Company profile
- Recent earnings
- Analyst ratings
- Internal research notes
- Portfolio exposure

### Portfolio Impact Panel
- Pre/post trade position
- Sector weight change
- Risk metrics impact
- Benchmark tracking impact

## API Endpoints

```
GET  /api/trading/orders                    # List orders with filters
GET  /api/trading/orders/{id}               # Order details
GET  /api/trading/orders/{id}/fills         # Lot breakdown
GET  /api/trading/executions/compare        # Compare same-symbol executions
GET  /api/trading/brokers/scorecard         # Broker performance metrics
GET  /api/trading/commissions               # Commission analysis
GET  /api/trading/tca/report                # Transaction cost analysis
POST /api/trading/orders                    # Create order (if OMS integration)
```

## Data Model

See [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md) for complete table definitions.

Key tables:
- `orders` - Parent order records
- `executions` - Individual fills/lots
- `brokers` - Broker master data
- `broker_performance` - Aggregated metrics
- `commissions` - Commission records
- `tca_reports` - TCA analysis results
