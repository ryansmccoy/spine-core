# MarketSpine Data Pipeline Integration

## Overview

This document describes how to integrate the Market Spine data pipeline backend with the capture-spine-basic frontend, creating a unified platform for both trading analytics and data workflow management.

---

## Market Spine Pipeline Architecture

### Bronze → Silver → Gold Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DATA PIPELINE ARCHITECTURE                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  DATA SOURCES                                                                │
│  ════════════════════════════════════════════════════════════════════       │
│                                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │  FINRA   │ │  SEC     │ │  FIX     │ │  Market  │ │  Broker  │          │
│  │  OTC     │ │  EDGAR   │ │  Drops   │ │  Data    │ │  Reports │          │
│  │  Files   │ │  Filings │ │  (Trades)│ │  Feeds   │ │          │          │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘          │
│       │            │            │            │            │                 │
│       └────────────┴────────────┼────────────┴────────────┘                 │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                          INGEST LAYER                                │   │
│  │                                                                      │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐     │   │
│  │  │  File Connector │  │  API Connector  │  │  FIX Connector  │     │   │
│  │  │  (PSV, CSV, XML)│  │  (REST, SFTP)   │  │  (Drop Parser)  │     │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────┘     │   │
│  │                                                                      │   │
│  │  • Schema validation     • Rate limiting      • Deduplication       │   │
│  │  • Capture ID assignment • Error handling     • Manifest tracking   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         🥉 BRONZE LAYER                              │   │
│  │                        (Raw, Immutable)                              │   │
│  │                                                                      │   │
│  │  ┌────────────────────────────────────────────────────────────┐    │   │
│  │  │  finra_otc_raw          │  Raw FINRA OTC transparency data │    │   │
│  │  │  sec_filings_raw        │  Raw SEC EDGAR filings           │    │   │
│  │  │  executions_raw         │  Raw FIX execution drops         │    │   │
│  │  │  broker_reports_raw     │  Raw broker commission reports   │    │   │
│  │  │  market_data_raw        │  Raw market data (quotes, trades)│    │   │
│  │  └────────────────────────────────────────────────────────────┘    │   │
│  │                                                                      │   │
│  │  • Append-only             • Full source fidelity                   │   │
│  │  • execution_id lineage    • capture_id for point-in-time          │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       NORMALIZE LAYER                                │   │
│  │                                                                      │   │
│  │  • Data type casting       • Null handling                          │   │
│  │  • Enum normalization      • Deduplication                          │   │
│  │  • Schema alignment        • Reject tracking                        │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         🥈 SILVER LAYER                              │   │
│  │                       (Cleaned, Validated)                           │   │
│  │                                                                      │   │
│  │  ┌────────────────────────────────────────────────────────────┐    │   │
│  │  │  finra_otc_normalized   │  Validated OTC data              │    │   │
│  │  │  executions_normalized  │  Cleaned execution records       │    │   │
│  │  │  orders_normalized      │  Order lifecycle events          │    │   │
│  │  │  broker_normalized      │  Standardized broker data        │    │   │
│  │  │  securities_master      │  Security reference data         │    │   │
│  │  └────────────────────────────────────────────────────────────┘    │   │
│  │                                                                      │   │
│  │  • Queryable format        • Consistent types                       │   │
│  │  • Referential integrity   • Quality scores                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       AGGREGATE LAYER                                │   │
│  │                                                                      │   │
│  │  • Pre-computed metrics    • Time-series aggregation                │   │
│  │  • Statistical measures    • Dimensional rollups                    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         🥇 GOLD LAYER                                │   │
│  │                      (Analytics-Ready)                               │   │
│  │                                                                      │   │
│  │  ┌────────────────────────────────────────────────────────────┐    │   │
│  │  │  tca_daily_metrics      │  Daily TCA summaries            │    │   │
│  │  │  broker_scorecard       │  Broker performance rankings    │    │   │
│  │  │  algo_performance       │  Algorithm effectiveness        │    │   │
│  │  │  execution_quality      │  Fill rates, slippage stats     │    │   │
│  │  │  symbol_analytics       │  Per-symbol trading metrics     │    │   │
│  │  └────────────────────────────────────────────────────────────┘    │   │
│  │                                                                      │   │
│  │  • Dashboard-ready         • Low-latency queries                    │   │
│  │  • Time-series optimized   • Materialized views                     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Pipeline Definitions

### Trading Data Pipelines

```yaml
# Pipeline: execution.ingest
name: execution.ingest
description: Ingest FIX execution drops into bronze layer
domain: trading
schedule: "*/5 * * * *"  # Every 5 minutes
params:
  - name: file_path
    type: string
    description: Path to FIX drop file
  - name: source
    type: enum
    values: [jpmorgan, morgan_stanley, goldman, cantor]
stages:
  - name: parse
    action: parse_fix_file
  - name: validate
    action: validate_schema
  - name: insert
    action: insert_bronze
    table: executions_raw

# Pipeline: execution.normalize
name: execution.normalize
description: Normalize executions to silver layer
domain: trading
depends_on: [execution.ingest]
schedule: "*/10 * * * *"  # Every 10 minutes
stages:
  - name: extract
    action: read_bronze
    table: executions_raw
    filter: "normalized_at IS NULL"
  - name: transform
    action: normalize_execution
    mapping:
      symbol: security_id (via securities_master)
      broker: broker_id (via brokers)
      side: enum(buy, sell)
  - name: load
    action: insert_silver
    table: executions_normalized

# Pipeline: tca.daily_aggregate
name: tca.daily_aggregate
description: Compute daily TCA metrics
domain: analytics
depends_on: [execution.normalize]
schedule: "0 18 * * *"  # 6 PM daily (after market close)
params:
  - name: trade_date
    type: date
    default: yesterday
stages:
  - name: extract
    action: read_silver
    table: executions_normalized
    filter: "trade_date = :trade_date"
  - name: compute
    action: calculate_tca
    metrics:
      - vwap_slippage
      - arrival_slippage
      - fill_rate
      - market_impact
  - name: load
    action: upsert_gold
    table: tca_daily_metrics

# Pipeline: broker.scorecard
name: broker.scorecard
description: Compute broker performance scorecard
domain: analytics
depends_on: [tca.daily_aggregate]
schedule: "0 19 * * *"  # 7 PM daily
stages:
  - name: aggregate
    action: aggregate_by_broker
    metrics:
      - avg_slippage
      - fill_rate
      - avg_commission
      - order_count
  - name: rank
    action: compute_rankings
    method: weighted_score
  - name: load
    action: upsert_gold
    table: broker_scorecard
```

---

## Pipeline Monitor UI

### Data Explorer Dashboard

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Data Explorer                                 [Layer: Gold ▼] [Search 🔍] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  DATA CATALOG                                                               │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ 🥇 GOLD TABLES                                                       │   │
│  │ ─────────────────────────────────────────────────────────────────── │   │
│  │                                                                      │   │
│  │ ▼ tca_daily_metrics                                    Last: 2h ago │   │
│  │   Columns: trade_date, symbol, broker_id, vwap_slip, fill_rate ...  │   │
│  │   Rows: 125,432 | Size: 45 MB | Freshness: ✅                       │   │
│  │   [Preview] [Query] [Download]                                       │   │
│  │                                                                      │   │
│  │ ▼ broker_scorecard                                    Last: 1h ago  │   │
│  │   Columns: broker_id, period, rank, score, avg_slip, fill_rate ...  │   │
│  │   Rows: 2,456 | Size: 2.1 MB | Freshness: ✅                        │   │
│  │   [Preview] [Query] [Download]                                       │   │
│  │                                                                      │   │
│  │ ▶ algo_performance                                    Last: 3h ago  │   │
│  │ ▶ execution_quality                                   Last: 2h ago  │   │
│  │ ▶ symbol_analytics                                    Last: 1h ago  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  DATA PREVIEW: tca_daily_metrics                                            │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ trade_date │ symbol │ broker │ vwap_slip │ fill_rate │ orders │    │   │
│  ├────────────┼────────┼────────┼───────────┼───────────┼────────┤    │   │
│  │ 2024-08-02 │ AAPL   │ JPM    │ +1.2bp    │ 98.5%     │ 15     │    │   │
│  │ 2024-08-02 │ AAPL   │ MS     │ +1.8bp    │ 97.2%     │ 12     │    │   │
│  │ 2024-08-02 │ NVDA   │ JPM    │ +0.9bp    │ 99.1%     │ 22     │    │   │
│  │ 2024-08-02 │ NVDA   │ GS     │ +1.5bp    │ 98.0%     │ 18     │    │   │
│  │ 2024-08-02 │ MSFT   │ CANT   │ +2.1bp    │ 96.5%     │ 8      │    │   │
│  │ ... showing 5 of 125,432 rows ...                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  DATA LINEAGE                                                               │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                      │   │
│  │   executions_raw ──▶ executions_normalized ──▶ tca_daily_metrics   │   │
│  │       (Bronze)            (Silver)                  (Gold)          │   │
│  │                                                                      │   │
│  │   capture_id: cap_20240802_001                                      │   │
│  │   execution_id: exec_abc123                                          │   │
│  │   source_file: fix_drops/20240802/jpmorgan.csv                      │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Pipeline Builder UI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Pipeline Builder                              [Save] [Run] [Schedule]      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PIPELINE: Custom TCA Analysis                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         VISUAL PIPELINE EDITOR                       │   │
│  │                                                                      │   │
│  │   ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐  │   │
│  │   │  SOURCE  │────▶│  FILTER  │────▶│ TRANSFORM│────▶│  OUTPUT  │  │   │
│  │   │ ──────── │     │ ──────── │     │ ──────── │     │ ──────── │  │   │
│  │   │executions│     │trade_date│     │ calc_tca │     │ gold.tca │  │   │
│  │   │_normalized     │>= today-7│     │          │     │ _custom  │  │   │
│  │   └──────────┘     └──────────┘     └──────────┘     └──────────┘  │   │
│  │        │                                                 │         │   │
│  │        │           ┌──────────┐                          │         │   │
│  │        └──────────▶│   JOIN   │──────────────────────────┘         │   │
│  │                    │ ──────── │                                    │   │
│  │                    │ brokers  │                                    │   │
│  │                    └──────────┘                                    │   │
│  │                                                                      │   │
│  │   [+ Add Source] [+ Add Transform] [+ Add Output]                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  STAGE CONFIGURATION: TRANSFORM (calc_tca)                                  │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Calculations:                                                        │   │
│  │ ┌───────────────────────────────────────────────────────────────┐  │   │
│  │ │ [✓] VWAP Slippage = (avg_fill_price - vwap) / vwap * 10000    │  │   │
│  │ │ [✓] Arrival Slippage = (avg_fill_price - arrival) / arrival   │  │   │
│  │ │ [✓] Fill Rate = filled_qty / order_qty * 100                  │  │   │
│  │ │ [✓] Implementation Shortfall = (filled - benchmark) * qty     │  │   │
│  │ │ [ ] Market Impact = (realized_price - mid_price) / mid_price  │  │   │
│  │ │                                                                │  │   │
│  │ │ [+ Add Custom Calculation]                                     │  │   │
│  │ └───────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  │ Aggregations:                                                        │   │
│  │ Group By: [symbol, broker_id, trade_date]                           │   │
│  │ Metrics:  [avg, std, min, max, count]                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  SCHEDULE                                                                   │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Frequency: [Daily ▼]  Time: [18:30 ▼]  Timezone: [America/New_York]│   │
│  │ Dependencies: [✓ execution.normalize must complete first]           │   │
│  │ Retry on Failure: [✓] Max Retries: [3]                              │   │
│  │ Notify on: [✓ Failure] [ ] Success] [✓ SLA Miss]                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Database Schema Extensions

### Trading Tables (PostgreSQL + TimescaleDB)

```sql
-- ═══════════════════════════════════════════════════════════════════════════
-- BRONZE LAYER (Raw, Immutable)
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE executions_raw (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id    TEXT NOT NULL,
    capture_id      UUID NOT NULL,
    source          TEXT NOT NULL,  -- 'jpmorgan', 'morgan_stanley', etc.
    
    -- Raw fields (as received)
    raw_symbol      TEXT,
    raw_side        TEXT,
    raw_quantity    TEXT,
    raw_price       TEXT,
    raw_timestamp   TEXT,
    raw_venue       TEXT,
    raw_order_id    TEXT,
    raw_broker      TEXT,
    raw_algo        TEXT,
    
    -- Lineage
    source_file     TEXT,
    source_row      INTEGER,
    captured_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Processing
    normalized_at   TIMESTAMPTZ,
    rejected_at     TIMESTAMPTZ,
    reject_reason   TEXT
);

CREATE INDEX idx_executions_raw_capture ON executions_raw(capture_id);
CREATE INDEX idx_executions_raw_normalized ON executions_raw(normalized_at) 
    WHERE normalized_at IS NULL;


-- ═══════════════════════════════════════════════════════════════════════════
-- SILVER LAYER (Cleaned, Validated)
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE executions_normalized (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    raw_id          UUID REFERENCES executions_raw(id),
    execution_id    TEXT NOT NULL,
    
    -- Normalized fields
    security_id     UUID REFERENCES securities(id),
    order_id        UUID REFERENCES orders(id),
    broker_id       UUID REFERENCES brokers(id),
    
    side            execution_side NOT NULL,  -- 'buy', 'sell'
    quantity        INTEGER NOT NULL,
    price           DECIMAL(18, 8) NOT NULL,
    executed_at     TIMESTAMPTZ NOT NULL,
    
    venue           TEXT,
    algorithm       TEXT,
    
    -- Derived
    trade_date      DATE NOT NULL,
    notional        DECIMAL(18, 2) NOT NULL,
    
    -- Quality
    data_quality_score  DECIMAL(3, 2),
    
    -- Lineage
    capture_id      UUID NOT NULL,
    normalized_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- TimescaleDB hypertable for time-series queries
SELECT create_hypertable('executions_normalized', 'executed_at');

CREATE INDEX idx_exec_norm_order ON executions_normalized(order_id);
CREATE INDEX idx_exec_norm_broker ON executions_normalized(broker_id);
CREATE INDEX idx_exec_norm_security ON executions_normalized(security_id);
CREATE INDEX idx_exec_norm_trade_date ON executions_normalized(trade_date);


-- ═══════════════════════════════════════════════════════════════════════════
-- GOLD LAYER (Analytics-Ready)
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE tca_daily_metrics (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Dimensions
    trade_date      DATE NOT NULL,
    security_id     UUID REFERENCES securities(id),
    broker_id       UUID REFERENCES brokers(id),
    algorithm       TEXT,
    
    -- Metrics
    order_count     INTEGER NOT NULL,
    total_quantity  BIGINT NOT NULL,
    total_notional  DECIMAL(18, 2) NOT NULL,
    
    filled_quantity BIGINT NOT NULL,
    fill_rate       DECIMAL(5, 2) NOT NULL,
    
    avg_fill_price  DECIMAL(18, 8) NOT NULL,
    vwap            DECIMAL(18, 8),
    vwap_slippage_bp DECIMAL(10, 4),
    
    arrival_price   DECIMAL(18, 8),
    arrival_slip_bp DECIMAL(10, 4),
    
    market_impact_bp DECIMAL(10, 4),
    
    avg_time_to_fill_sec INTEGER,
    
    commission_total DECIMAL(18, 2),
    commission_per_share DECIMAL(10, 6),
    
    -- Metadata
    computed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    capture_id      UUID,
    
    UNIQUE (trade_date, security_id, broker_id, algorithm)
);

-- TimescaleDB hypertable
SELECT create_hypertable('tca_daily_metrics', 'trade_date');


CREATE TABLE broker_scorecard (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Dimensions
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    broker_id       UUID REFERENCES brokers(id) NOT NULL,
    
    -- Volume metrics
    order_count     INTEGER NOT NULL,
    total_notional  DECIMAL(18, 2) NOT NULL,
    total_shares    BIGINT NOT NULL,
    
    -- Quality metrics
    avg_vwap_slip_bp DECIMAL(10, 4) NOT NULL,
    avg_fill_rate   DECIMAL(5, 2) NOT NULL,
    avg_time_to_fill_sec INTEGER NOT NULL,
    
    -- Cost metrics
    total_commission DECIMAL(18, 2) NOT NULL,
    avg_commission_per_share DECIMAL(10, 6) NOT NULL,
    
    -- Scores (0-100)
    execution_score INTEGER NOT NULL,
    cost_score      INTEGER NOT NULL,
    reliability_score INTEGER NOT NULL,
    overall_score   INTEGER NOT NULL,
    
    -- Ranking
    rank            INTEGER NOT NULL,
    rank_change     INTEGER,  -- vs previous period
    
    -- Metadata
    computed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    UNIQUE (period_start, period_end, broker_id)
);


CREATE TABLE algo_performance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Dimensions
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    algorithm       TEXT NOT NULL,
    broker_id       UUID REFERENCES brokers(id),
    market_cap_tier TEXT,  -- 'large', 'mid', 'small'
    
    -- Volume
    order_count     INTEGER NOT NULL,
    total_notional  DECIMAL(18, 2) NOT NULL,
    
    -- Performance
    avg_slippage_bp DECIMAL(10, 4) NOT NULL,
    std_slippage_bp DECIMAL(10, 4) NOT NULL,
    max_slippage_bp DECIMAL(10, 4) NOT NULL,
    
    fill_rate       DECIMAL(5, 2) NOT NULL,
    
    -- Time metrics
    avg_duration_min INTEGER NOT NULL,
    
    -- Win rate (beat benchmark)
    win_rate        DECIMAL(5, 2) NOT NULL,
    
    -- Metadata
    computed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    UNIQUE (period_start, period_end, algorithm, broker_id, market_cap_tier)
);
```

---

## API Integration

### FastAPI Routes for Pipeline Management

```python
# api/routes/v1/pipelines.py

from fastapi import APIRouter, Depends, HTTPException
from typing import List, Optional

router = APIRouter(prefix="/pipelines", tags=["pipelines"])


@router.get("/")
async def list_pipelines() -> List[PipelineInfo]:
    """List all registered pipelines with status."""
    return await pipeline_service.list_all()


@router.get("/{name}")
async def get_pipeline(name: str) -> PipelineDetail:
    """Get pipeline definition and recent executions."""
    pipeline = await pipeline_service.get(name)
    if not pipeline:
        raise HTTPException(404, f"Pipeline {name} not found")
    return pipeline


@router.post("/{name}/run")
async def run_pipeline(
    name: str,
    params: dict = {},
    dry_run: bool = False
) -> ExecutionResponse:
    """Submit pipeline for execution."""
    if dry_run:
        return await pipeline_service.validate(name, params)
    
    execution = await dispatcher.submit(
        pipeline=name,
        params=params,
        trigger_source="api"
    )
    return ExecutionResponse(
        execution_id=execution.id,
        status=execution.status,
        message=f"Pipeline {name} submitted"
    )


@router.get("/{name}/executions")
async def list_executions(
    name: str,
    status: Optional[str] = None,
    limit: int = 50
) -> List[ExecutionSummary]:
    """List executions for a pipeline."""
    return await execution_service.list_by_pipeline(
        pipeline=name,
        status=status,
        limit=limit
    )


@router.get("/executions/{execution_id}")
async def get_execution(execution_id: str) -> ExecutionDetail:
    """Get execution details with events and logs."""
    return await execution_service.get(execution_id)


@router.post("/executions/{execution_id}/retry")
async def retry_execution(execution_id: str) -> ExecutionResponse:
    """Retry a failed execution."""
    return await execution_service.retry(execution_id)


@router.get("/status")
async def pipeline_status() -> PipelineStatusSummary:
    """Get overall pipeline health status."""
    return {
        "running": await execution_service.count_by_status("running"),
        "pending": await execution_service.count_by_status("pending"),
        "completed_today": await execution_service.count_completed_today(),
        "failed_today": await execution_service.count_failed_today(),
        "data_freshness": await data_service.get_freshness_report()
    }


# WebSocket for real-time execution updates
@router.websocket("/ws/executions")
async def execution_stream(websocket: WebSocket):
    """Stream execution events in real-time."""
    await websocket.accept()
    async for event in execution_service.stream_events():
        await websocket.send_json(event)
```

---

## Frontend Integration

### React Components for Pipeline UI

```typescript
// src/pages/PipelineMonitorPage.tsx

import { useQuery, useSubscription } from '@tanstack/react-query';
import { pipelineApi } from '@/api/pipelines';

export function PipelineMonitorPage() {
  // Fetch pipeline status
  const { data: status } = useQuery({
    queryKey: ['pipeline-status'],
    queryFn: pipelineApi.getStatus,
    refetchInterval: 10000, // Refresh every 10s
  });

  // Real-time execution stream
  const executions = useSubscription({
    queryKey: ['executions-stream'],
    subscribe: pipelineApi.subscribeToExecutions,
  });

  return (
    <div className="p-6">
      <h1>Data Pipeline Monitor</h1>
      
      {/* Status Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <StatusCard 
          title="Running" 
          value={status?.running} 
          icon="🟢" 
        />
        <StatusCard 
          title="Completed Today" 
          value={status?.completed_today} 
          icon="✅" 
        />
        <StatusCard 
          title="Failed" 
          value={status?.failed_today} 
          icon="❌" 
        />
        <StatusCard 
          title="Pending" 
          value={status?.pending} 
          icon="⏳" 
        />
      </div>

      {/* Data Lake Status */}
      <DataLakeStatus freshness={status?.data_freshness} />

      {/* Active Executions */}
      <ExecutionList executions={executions} />

      {/* Scheduled Pipelines */}
      <ScheduleCalendar />
    </div>
  );
}
```

---

## Implementation Roadmap

### Phase 1: Backend Integration (Week 1-2)
1. Deploy Market Spine backend alongside capture-spine
2. Set up PostgreSQL + TimescaleDB
3. Configure Celery workers
4. Create initial pipeline definitions

### Phase 2: API Layer (Week 3)
1. Implement FastAPI routes for pipelines
2. Add WebSocket support for real-time updates
3. Connect to existing trading data sources
4. Add authentication/authorization

### Phase 3: Frontend Components (Week 4-5)
1. Create Pipeline Monitor page
2. Create Data Explorer page
3. Create Pipeline Builder UI
4. Integrate with existing navigation

### Phase 4: Trading Analytics (Week 6-8)
1. Implement TCA pipelines
2. Implement broker scorecard pipelines
3. Create trading dashboards
4. Connect real-time execution feed
