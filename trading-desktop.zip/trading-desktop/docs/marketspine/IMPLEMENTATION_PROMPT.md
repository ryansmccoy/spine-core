# MarketSpine Implementation Prompt

## Claude Opus Long-Thinking Implementation Prompt

Use this prompt with Claude Opus (with extended thinking enabled) to implement MarketSpine step by step with best practices.

---

## The Prompt

```
You are an expert full-stack software architect implementing MarketSpine, a Bloomberg/FactSet-style institutional investment management platform. Use extended thinking to plan each component thoroughly before implementation.

## Project Context

MarketSpine is a multi-tenant SaaS platform for institutional investment managers (hedge funds, asset managers, family offices) providing:
- Trading analytics with best execution analysis
- Portfolio management with risk analytics
- Research hub with knowledge graph
- Compliance monitoring
- Real-time collaboration

## Technology Stack

### Frontend
- React 19 with TypeScript 5.4+
- Vite for build tooling
- TanStack Query for server state
- Zustand for client state
- AG Grid for high-performance data tables
- Recharts/Visx for data visualization
- React Flow for knowledge graph visualization
- Tailwind CSS with shadcn/ui components
- Socket.io-client for real-time updates

### Backend
- Python 3.12+ with FastAPI
- SQLAlchemy 2.0 with async PostgreSQL
- Redis for caching and pub/sub
- Celery for background tasks
- Elasticsearch for full-text search
- WebSocket for real-time streaming

### Infrastructure
- Docker Compose for local development
- PostgreSQL 16 for primary database
- Redis 7 for caching/messaging
- Elasticsearch 8 for search
- MinIO for object storage (S3-compatible)

## Core Principles

1. **Multi-Tenancy**: All data isolated by firm_id, enforced at database level
2. **Security First**: RBAC, audit logging, encryption at rest/in transit
3. **Real-Time**: WebSocket for live updates, optimistic UI updates
4. **Performance**: Pagination, virtual scrolling, efficient queries
5. **Testability**: Unit tests, integration tests, E2E tests
6. **Documentation**: OpenAPI specs, JSDoc, inline comments

## Implementation Phases

### Phase 1: Foundation (Week 1-2)
Implement the core infrastructure:

1. **Database Schema**
   - Create all tables from DATABASE_SCHEMA.md
   - Set up migrations with Alembic
   - Implement Row-Level Security policies
   - Create database connection pooling

2. **Authentication & Authorization**
   - JWT-based authentication with refresh tokens
   - RBAC with roles: admin, portfolio_manager, trader, analyst, compliance, viewer
   - Session management with Redis
   - Audit logging for all actions

3. **API Foundation**
   - FastAPI app with middleware (CORS, auth, logging)
   - Pydantic models for all entities
   - Generic CRUD base classes
   - Error handling and response formatting

4. **Frontend Foundation**
   - Vite + React + TypeScript setup
   - Authentication context and protected routes
   - Layout components (Sidebar, Header, Main)
   - Theme system with dark/light modes

### Phase 2: Trading Center (Week 3-4)
Build the trading analytics module:

1. **Order Blotter**
   ```typescript
   // Component: OrderBlotter.tsx
   // - AG Grid with server-side pagination
   // - Column definitions for order fields
   // - Row selection for drill-down
   // - Real-time status updates via WebSocket
   // - Filters: date range, symbol, broker, status
   ```

2. **Execution Comparison Widget**
   ```typescript
   // Component: ExecutionComparison.tsx
   // - Select orders for same symbol, same side
   // - Calculate metrics: avg_price, total_qty, slippage, fill_rate
   // - Bar chart comparing brokers
   // - Table with detailed breakdown
   ```

3. **Lot Breakdown Drawer**
   ```typescript
   // Component: LotBreakdown.tsx
   // - Drawer/panel that opens on order click
   // - Timeline visualization of fills
   // - Price vs VWAP chart
   // - Individual lot details table
   ```

4. **Broker Scorecard**
   ```typescript
   // Component: BrokerScorecard.tsx
   // - Aggregate stats per broker
   // - Metrics: fill_rate, avg_slippage, time_to_fill
   // - Trend charts over time
   // - Ranking by performance
   ```

### Phase 3: Portfolio Manager (Week 5-6)
Build portfolio management features:

1. **Position Grid**
   - Hierarchical grid: Fund → Account → Position
   - Real-time P&L updates
   - Sector/industry grouping
   - Export to Excel/CSV

2. **Risk Dashboard**
   - Portfolio VaR calculation
   - Sector exposure charts
   - Concentration alerts
   - Factor exposure analysis

3. **Performance Attribution**
   - Brinson attribution model
   - Benchmark comparison
   - Time-weighted returns
   - Fee-adjusted returns

### Phase 4: Research Hub (Week 7-8)
Build research and knowledge features:

1. **Research Notes Editor**
   - Rich Markdown editor
   - Entity linking (companies, securities)
   - Collaborative editing
   - Version history

2. **Company Dashboard**
   - Aggregate all data for one company
   - SEC filings integration
   - News feed
   - Research notes
   - Position exposure

3. **Knowledge Graph**
   - React Flow visualization
   - Node types: Company, Security, Trade, Person, Event
   - Relationship types: owns, trades, competes_with, supplies
   - Interactive exploration

### Phase 5: News & Alerts (Week 9-10)
Build news aggregation and alerting:

1. **News Feed**
   - Real-time news stream
   - Company/watchlist filtering
   - Sentiment indicators
   - Source attribution

2. **Alert System**
   - Rule builder UI
   - Multiple delivery channels
   - Alert history
   - Snooze/acknowledge

### Phase 6: Collaboration (Week 11-12)
Build collaboration features:

1. **Messaging**
   - Real-time chat with WebSocket
   - Channels (public, private)
   - Direct messages
   - Entity sharing in messages

2. **Meeting Prep**
   - Calendar integration
   - Auto-generated prep packs
   - Meeting notes with entity linking
   - Action item tracking

## Code Quality Standards

### TypeScript
```typescript
// Use strict TypeScript
// tsconfig.json
{
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true
  }
}

// Use proper typing, no 'any'
interface Order {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  quantity: number;
  status: OrderStatus;
  createdAt: Date;
}

// Use discriminated unions for state
type OrderState = 
  | { status: 'pending' }
  | { status: 'filled'; fillPrice: number }
  | { status: 'cancelled'; reason: string };
```

### Python
```python
# Use type hints everywhere
from typing import Optional, List
from pydantic import BaseModel

class OrderCreate(BaseModel):
    symbol: str
    side: Literal["buy", "sell"]
    quantity: int
    order_type: OrderType
    limit_price: Optional[Decimal] = None

# Use async/await for I/O
async def get_orders(
    db: AsyncSession,
    firm_id: UUID,
    filters: OrderFilters
) -> List[Order]:
    stmt = select(Order).where(
        Order.firm_id == firm_id,
        Order.deleted_at.is_(None)
    )
    if filters.symbol:
        stmt = stmt.where(Order.symbol == filters.symbol)
    result = await db.execute(stmt)
    return result.scalars().all()

# Use dependency injection
async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    ...
```

### SQL
```sql
-- Always use parameterized queries
-- Never interpolate user input

-- Use CTEs for complex queries
WITH daily_executions AS (
    SELECT 
        DATE(executed_at) as trade_date,
        broker_id,
        SUM(quantity * price) as notional
    FROM executions
    WHERE firm_id = :firm_id
    GROUP BY 1, 2
)
SELECT 
    b.name,
    de.trade_date,
    de.notional
FROM daily_executions de
JOIN brokers b ON b.id = de.broker_id;

-- Use indexes for frequent queries
CREATE INDEX idx_executions_firm_date 
ON executions(firm_id, executed_at);
```

## Testing Strategy

### Unit Tests
```python
# Test business logic in isolation
def test_calculate_vwap():
    fills = [
        Fill(price=100.0, quantity=100),
        Fill(price=101.0, quantity=200),
    ]
    vwap = calculate_vwap(fills)
    assert vwap == pytest.approx(100.67, rel=0.01)
```

### Integration Tests
```python
# Test API endpoints with real database
@pytest.mark.asyncio
async def test_create_order(client, auth_headers, test_firm):
    response = await client.post(
        "/api/v1/orders",
        headers=auth_headers,
        json={"symbol": "AAPL", "side": "buy", "quantity": 100}
    )
    assert response.status_code == 201
    assert response.json()["symbol"] == "AAPL"
```

### E2E Tests
```typescript
// Test user flows with Playwright
test('user can view order blotter', async ({ page }) => {
  await page.goto('/trading');
  await expect(page.getByRole('grid')).toBeVisible();
  await page.getByRole('row').first().click();
  await expect(page.getByText('Lot Breakdown')).toBeVisible();
});
```

## Security Checklist

- [ ] JWT tokens with short expiry (15 min access, 7 day refresh)
- [ ] HTTPS everywhere, HSTS headers
- [ ] CSRF protection on state-changing requests
- [ ] Rate limiting on API endpoints
- [ ] Input validation with Pydantic
- [ ] SQL injection prevention (parameterized queries)
- [ ] XSS prevention (React escapes by default)
- [ ] Secrets in environment variables
- [ ] Audit logging for compliance
- [ ] Row-level security in PostgreSQL

## File Structure

```
marketspine/
├── frontend/
│   ├── src/
│   │   ├── api/           # API client functions
│   │   ├── components/    # Reusable components
│   │   │   ├── ui/        # shadcn/ui components
│   │   │   ├── trading/   # Trading-specific components
│   │   │   ├── portfolio/ # Portfolio components
│   │   │   └── research/  # Research components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── pages/         # Page components
│   │   ├── store/         # Zustand stores
│   │   ├── types/         # TypeScript types
│   │   └── utils/         # Utility functions
│   ├── public/
│   └── package.json
├── backend/
│   ├── app/
│   │   ├── api/           # API routes
│   │   │   ├── v1/        # Version 1 endpoints
│   │   │   │   ├── trading.py
│   │   │   │   ├── portfolio.py
│   │   │   │   └── research.py
│   │   ├── core/          # Core functionality
│   │   │   ├── config.py
│   │   │   ├── security.py
│   │   │   └── deps.py
│   │   ├── models/        # SQLAlchemy models
│   │   ├── schemas/       # Pydantic schemas
│   │   ├── services/      # Business logic
│   │   └── main.py
│   ├── migrations/        # Alembic migrations
│   ├── tests/
│   └── pyproject.toml
├── docker-compose.yml
└── README.md
```

## Your Task

Implement MarketSpine following these phases. For each component:

1. **Think**: Use extended thinking to plan the component architecture
2. **Design**: Define interfaces, types, and data flow
3. **Implement**: Write clean, tested, production-ready code
4. **Document**: Add JSDoc/docstrings and inline comments

Start with Phase 1 (Foundation) and proceed systematically. Ask clarifying questions if requirements are ambiguous.

When writing code:
- Prefer composition over inheritance
- Use dependency injection for testability
- Handle errors gracefully with proper error types
- Log important operations for debugging
- Add meaningful comments for complex logic
- Write tests alongside implementation

Begin by implementing the database schema and authentication system.
```

---

## Alternative Focused Prompts

### Trading Center Only

```
Implement the MarketSpine Trading Center module with these components:

1. Order Blotter - AG Grid with server-side pagination, filtering, real-time updates
2. Execution Comparison - Compare same-symbol orders across brokers with metrics
3. Lot Breakdown - Drawer showing fill details and timeline
4. Broker Scorecard - Performance metrics and rankings
5. Commission Dashboard - Spend analysis by broker/period

Use React 19 + TypeScript + FastAPI + PostgreSQL.
Include proper TypeScript types, API endpoints, SQL queries, and unit tests.
```

### Portfolio Manager Only

```
Implement the MarketSpine Portfolio Manager module with:

1. Position Grid - Hierarchical (Fund/Account/Position) with real-time P&L
2. Risk Dashboard - VaR, sector exposure, concentration alerts
3. Performance Attribution - Brinson attribution vs benchmarks
4. Holdings History - Track positions over time

Use React 19 + TypeScript + FastAPI + PostgreSQL.
Implement proper aggregation logic, risk calculations, and time-series storage.
```

### Knowledge Graph Only

```
Implement a financial knowledge graph visualization with:

1. Node types: Company, Security, Trade, Person, Event, Filing
2. Relationship types: owns, trades, competes_with, supplies, board_member
3. React Flow visualization with custom node/edge components
4. Interactive exploration with zoom, pan, focus
5. Search and filter capabilities
6. Real-time updates from trade/news events

Store in PostgreSQL with proper graph queries.
```

---

## Incremental Implementation Prompts

### Step 1: Database Setup

```
Create the PostgreSQL schema for MarketSpine with:
- Multi-tenant isolation (firm_id on all tables)
- Users and RBAC (roles, permissions)
- Trading entities (orders, executions, brokers)
- Portfolio entities (funds, accounts, positions)

Include Alembic migrations and SQLAlchemy models.
```

### Step 2: Authentication

```
Implement authentication for MarketSpine:
- JWT tokens (access + refresh)
- Login/logout/register endpoints
- Password hashing with bcrypt
- Session management with Redis
- RBAC middleware checking permissions

Use FastAPI with proper security best practices.
```

### Step 3: Trading API

```
Implement trading API endpoints:
- GET /orders - List with pagination and filters
- GET /orders/{id} - Order details with executions
- GET /orders/{id}/executions - Lot breakdown
- GET /brokers/scorecard - Broker performance metrics
- GET /analytics/comparison - Compare broker executions

Include proper error handling, validation, and tests.
```

### Step 4: Trading UI

```
Implement the Trading Center UI with:
- OrderBlotter component using AG Grid
- ExecutionComparison component with charts
- LotBreakdown drawer component
- BrokerScorecard dashboard
- Real-time updates via WebSocket

Use React 19, TypeScript, TanStack Query, and shadcn/ui.
```

---

## Quality Checklist for Implementation

### Code Quality
- [ ] TypeScript strict mode, no `any`
- [ ] Python type hints on all functions
- [ ] Consistent naming conventions
- [ ] Small, focused functions
- [ ] DRY (Don't Repeat Yourself)
- [ ] SOLID principles followed

### Testing
- [ ] Unit tests for business logic
- [ ] Integration tests for API endpoints
- [ ] E2E tests for critical user flows
- [ ] Test coverage > 80%

### Security
- [ ] Authentication on all protected routes
- [ ] Authorization checks in handlers
- [ ] Input validation
- [ ] SQL injection prevention
- [ ] XSS prevention
- [ ] CSRF protection
- [ ] Rate limiting
- [ ] Audit logging

### Performance
- [ ] Database indexes on query columns
- [ ] Pagination for list endpoints
- [ ] Virtual scrolling for large tables
- [ ] Caching for expensive queries
- [ ] Optimistic UI updates

### Documentation
- [ ] API documented with OpenAPI
- [ ] Components documented with JSDoc
- [ ] README with setup instructions
- [ ] Architecture decision records
