# MarketSpine Compliance Console

## Overview

The Compliance Console provides comprehensive monitoring, enforcement, and reporting tools for investment compliance. It enables compliance officers to set up rules, monitor trading activity, manage restricted lists, and generate regulatory reports.

---

## Module Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         COMPLIANCE CONSOLE                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Surveillance        │  │  Restricted List   │  │  Pre-Trade        │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Alert Dashboard   │  │  • Securities      │  │  • Rule Engine    │  │
│  │   • Pattern Detection │  │  • Persons         │  │  • Limit Checks   │  │
│  │   • Case Management   │  │  • Expiration      │  │  • Real-Time      │  │
│  │   • Investigations    │  │  • Audit Trail     │  │  • Override Log   │  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │   Regulatory Reports  │  │  Personal Trading  │  │  Policy Manager   │  │
│  │   ─────────────────   │  │  ────────────────  │  │  ───────────────  │  │
│  │   • Form 13F          │  │  • Pre-Clearance   │  │  • Policy Library │  │
│  │   • Form PF           │  │  • Attestations    │  │  • Acknowledgments│  │
│  │   • Schedule 13D/G    │  │  • Trade Review    │  │  • Training       │  │
│  │   • ADV               │  │  • Holdings Report │  │  • Version Control│  │
│  └───────────────────────┘  └────────────────────┘  └───────────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Surveillance Dashboard

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Compliance Surveillance                      [Today ▼] [All Funds ▼] [🔔] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ALERT SUMMARY                                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ 🔴 CRITICAL      │ │ 🟠 HIGH          │ │ 🟡 MEDIUM        │            │
│  │ ────────────────│ │ ────────────────│ │ ────────────────│            │
│  │       3          │ │       8          │ │      15          │            │
│  │ Requires Action  │ │ Review Today     │ │ Review This Week │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│                                                                              │
│  ACTIVE ALERTS                                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ SEVERITY │ TIME    │ TYPE            │ DESCRIPTION         │ STATUS │   │
│  ├──────────┼─────────┼─────────────────┼─────────────────────┼────────┤   │
│  │ 🔴 CRIT  │ 9:35 AM │ Restricted List │ Trade in BLOCKED    │ NEW    │   │
│  │          │         │                 │ security: XYZ       │        │   │
│  │ 🔴 CRIT  │ 9:22 AM │ Position Limit  │ AAPL position 12%   │ NEW    │   │
│  │          │         │                 │ exceeds 10% limit   │        │   │
│  │ 🔴 CRIT  │ 9:15 AM │ Information     │ Potential info wall │ NEW    │   │
│  │          │         │ Barrier         │ breach: Analyst →   │        │   │
│  │          │         │                 │ Trader communication│        │   │
│  │ 🟠 HIGH  │ 9:45 AM │ Front Running   │ Pattern detected:   │ REVIEW │   │
│  │          │         │                 │ Personal trade 2min │        │   │
│  │          │         │                 │ before client order │        │   │
│  │ 🟠 HIGH  │ 9:30 AM │ Wash Trade      │ Same-day buy/sell   │ REVIEW │   │
│  │          │         │                 │ of MSFT detected    │        │   │
│  │ 🟡 MED   │ 9:20 AM │ Sector Limit    │ Tech exposure 33%   │ REVIEW │   │
│  │          │         │                 │ approaching 35%     │        │   │
│  │ 🟡 MED   │ 9:10 AM │ Unusual Volume  │ NVDA volume 5x      │DISMISSED│  │
│  │          │         │                 │ normal average      │        │   │
│  └──────────┴─────────┴─────────────────┴─────────────────────┴────────┘   │
│                                                                              │
│  ALERT ACTIONS: [Acknowledge] [Investigate] [Dismiss] [Escalate]            │
│                                                                              │
│  INVESTIGATION QUEUE                                                        │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ CASE #  │ OPENED   │ TYPE            │ SUBJECT        │ ASSIGNED   │   │
│  ├─────────┼──────────┼─────────────────┼────────────────┼────────────┤   │
│  │ INV-042 │ Aug 1    │ Front Running   │ John Smith     │ CCO        │   │
│  │ INV-041 │ Jul 28   │ Info Barrier    │ Trading Desk   │ Deputy CCO │   │
│  │ INV-040 │ Jul 25   │ Best Execution  │ Broker Review  │ Analyst    │   │
│  └─────────┴──────────┴─────────────────┴────────────────┴────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Pre-Trade Compliance

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Pre-Trade Compliance Engine                              [Rules ▼] [⚙️]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  REAL-TIME ORDER CHECK                                                      │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Order: BUY 50,000 AAPL @ Market                                     │   │
│  │ Account: Global Equity Fund - Alpha                                  │   │
│  │ Trader: Jane Doe                                                     │   │
│  │                                                                      │   │
│  │ COMPLIANCE CHECKS                                   STATUS           │   │
│  │ ────────────────────────────────────────────────────────────────    │   │
│  │ ✅ Restricted List Check                            PASS            │   │
│  │ ✅ Personal Trading Conflict                        PASS            │   │
│  │ ⚠️  Position Concentration                          WARN (9.8%→12%) │   │
│  │ ✅ Sector Limit                                     PASS            │   │
│  │ ✅ Liquidity Check (ADV)                            PASS            │   │
│  │ ✅ Short Sale Restriction                           PASS (N/A)      │   │
│  │ ✅ Prospectus Compliance                            PASS            │   │
│  │                                                                      │   │
│  │ ⚠️ WARNING: This order will push AAPL position to 12%              │   │
│  │    exceeding the 10% single-stock limit.                            │   │
│  │                                                                      │   │
│  │ [Override with Reason ▼] [Modify Order] [Cancel]                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ACTIVE COMPLIANCE RULES                                                    │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ RULE             │ TYPE     │ THRESHOLD │ ACTION    │ SCOPE        │   │
│  ├──────────────────┼──────────┼───────────┼───────────┼──────────────┤   │
│  │ Single Stock Lmt │ Position │ 10%       │ Hard Stop │ All Funds    │   │
│  │ Sector Limit     │ Exposure │ 35%       │ Warn      │ All Funds    │   │
│  │ Restricted List  │ Security │ N/A       │ Hard Stop │ Firm-wide    │   │
│  │ Daily Volume     │ ADV %    │ 25%       │ Warn      │ All Funds    │   │
│  │ Market Cap Min   │ Security │ $1B       │ Hard Stop │ Large Cap    │   │
│  │ Short Restricted │ Reg SHO  │ N/A       │ Hard Stop │ All Accounts │   │
│  │ Cash Buffer      │ Account  │ 5%        │ Warn      │ All Accounts │   │
│  │ [+ Add Rule]     │          │           │           │              │   │
│  └──────────────────┴──────────┴───────────┴───────────┴──────────────┘   │
│                                                                              │
│  OVERRIDE LOG (Last 7 Days)                                                 │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ DATE     │ RULE             │ ORDER     │ APPROVER  │ REASON        │   │
│  ├──────────┼──────────────────┼───────────┼───────────┼───────────────┤   │
│  │ Aug 1    │ Position Limit   │ BUY NVDA  │ CCO       │ Temporary     │   │
│  │          │                  │ 10K       │           │ rebalance     │   │
│  │ Jul 30   │ Sector Limit     │ BUY AMD   │ Deputy CCO│ PM discretion │   │
│  │          │                  │ 5K        │           │               │   │
│  │ Jul 28   │ Daily Volume     │ SELL TSLA │ CCO       │ Urgent liq.   │   │
│  │          │                  │ 100K      │           │ need          │   │
│  └──────────┴──────────────────┴───────────┴───────────┴───────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Restricted List Management

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Restricted List                               [+ Add] [Import] [Export]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  SEARCH: [                    ] [Active Only ✓] [Type: All ▼]              │
│                                                                              │
│  RESTRICTED SECURITIES                                                      │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ SYMBOL │ COMPANY           │ TYPE       │ REASON        │ EXPIRES  │   │
│  ├────────┼───────────────────┼────────────┼───────────────┼──────────┤   │
│  │ XYZ    │ XYZ Corporation   │ BLOCKED    │ MNPI - M&A    │ TBD      │   │
│  │        │                   │            │ Advisory      │          │   │
│  │ ABC    │ ABC Industries    │ WATCH      │ Research      │ Sep 15   │   │
│  │        │                   │            │ Coverage      │          │   │
│  │ DEF    │ DEF Holdings      │ BLOCKED    │ Insider       │ Aug 30   │   │
│  │        │                   │            │ Information   │          │   │
│  │ GHI    │ GHI Corp          │ WATCH      │ Board         │ Permanent│   │
│  │        │                   │            │ Connection    │          │   │
│  │ JKL    │ JKL Inc           │ BLOCKED    │ IPO Quiet     │ Aug 15   │   │
│  │        │                   │            │ Period        │          │   │
│  └────────┴───────────────────┴────────────┴───────────────┴──────────┘   │
│                                                                              │
│  RESTRICTION TYPES:                                                         │
│  • BLOCKED: No trading allowed under any circumstances                      │
│  • WATCH:   Trading allowed with enhanced monitoring/approval               │
│  • FROZEN:  No new positions; existing positions may be liquidated         │
│                                                                              │
│  ADD TO RESTRICTED LIST                                                     │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Security: [SYMBOL    ] [🔍]    Company: ABC Corp                    │   │
│  │ Type:     [BLOCKED ▼]          Reason:  [MNPI - Advisory ▼]        │   │
│  │ Effective: [Aug 2, 2024]       Expires: [TBD ▼]                     │   │
│  │ Notes:    [                                                    ]    │   │
│  │ Notify:   [✓] Trading Desk  [✓] Portfolio Managers  [ ] All Users  │   │
│  │                                                                      │   │
│  │ [Add to List]                                                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  RESTRICTED PERSONS                                                         │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ NAME            │ TITLE      │ RESTRICTION      │ RELATED ISSUERS  │   │
│  ├─────────────────┼────────────┼──────────────────┼──────────────────┤   │
│  │ John Executive  │ Board Mbr  │ No personal trde │ XYZ, ABC, DEF    │   │
│  │ Jane Analyst    │ Research   │ Pre-clear all    │ Coverage List    │   │
│  │ Bob Partner     │ Partner    │ No short sales   │ All Securities   │   │
│  └─────────────────┴────────────┴──────────────────┴──────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Regulatory Reporting

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Regulatory Reports                                      [Calendar ▼] [⚙️] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  UPCOMING DEADLINES                                                         │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ 🔴 OVERDUE       │ │ 🟠 DUE THIS WEEK │ │ 🟡 UPCOMING      │            │
│  │ ────────────────│ │ ────────────────│ │ ────────────────│            │
│  │ 0 Reports        │ │ 1 Report         │ │ 3 Reports        │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│                                                                              │
│  REPORT STATUS                                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ REPORT      │ PERIOD   │ DEADLINE  │ STATUS     │ ACTIONS          │   │
│  ├─────────────┼──────────┼───────────┼────────────┼──────────────────┤   │
│  │ Form 13F    │ Q2 2024  │ Aug 14    │ 🟠 DRAFT   │ [Edit] [Submit]  │   │
│  │             │          │           │            │                  │   │
│  │ Form PF     │ Q2 2024  │ Aug 29    │ 🟡 PENDING │ [Generate]       │   │
│  │             │          │           │            │                  │   │
│  │ ADV Update  │ Annual   │ Mar 31    │ ✅ FILED   │ [View]           │   │
│  │             │          │           │            │                  │   │
│  │ Schedule    │ Aug 2024 │ Aug 10    │ 🟡 PENDING │ [Generate]       │   │
│  │ 13D/G       │          │           │ (5%+ AAPL) │                  │   │
│  └─────────────┴──────────┴───────────┴────────────┴──────────────────┘   │
│                                                                              │
│  FORM 13F GENERATOR                                                         │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Period: [Q2 2024 ▼]    As Of: [June 30, 2024]                       │   │
│  │                                                                      │   │
│  │ HOLDINGS (13F Securities Only)                                       │   │
│  │ ┌─────────┬────────────────────┬───────────┬───────────┬─────────┐  │   │
│  │ │ CUSIP   │ ISSUER             │ CLASS     │ VALUE     │ SHARES  │  │   │
│  │ ├─────────┼────────────────────┼───────────┼───────────┼─────────┤  │   │
│  │ │ 037833100│ Apple Inc         │ COM       │$11,350,000│ 50,000  │  │   │
│  │ │ 594918104│ Microsoft Corp    │ COM       │$12,600,000│ 30,000  │  │   │
│  │ │ 67066G104│ NVIDIA Corp       │ COM       │$10,000,000│ 80,000  │  │   │
│  │ │ 02079K305│ Alphabet Inc      │ COM CL A  │ $4,375,000│ 25,000  │  │   │
│  │ │ 30303M102│ Meta Platforms    │ COM CL A  │$19,200,000│ 40,000  │  │   │
│  │ │ ... (45 more securities)                                        │  │   │
│  │ └─────────┴────────────────────┴───────────┴───────────┴─────────┘  │   │
│  │                                                                      │   │
│  │ SUMMARY                                                              │   │
│  │ Total Holdings: 50 securities                                        │   │
│  │ Total Value: $250,234,567                                           │   │
│  │ Total Shares: 2,345,678                                             │   │
│  │                                                                      │   │
│  │ [Preview XML] [Validate] [Export for EDGAR] [Mark as Filed]         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Personal Trading Pre-Clearance

### Wireframe

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Personal Trading                              [My Requests] [Admin View]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  NEW PRE-CLEARANCE REQUEST                                                  │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Security: [AAPL    ] [🔍] Apple Inc                                 │   │
│  │ Action:   [BUY ▼]        Quantity: [100    ] shares                 │   │
│  │ Account:  [Personal Brokerage - Fidelity ▼]                         │   │
│  │ Reason:   [Long-term investment                              ]      │   │
│  │                                                                      │   │
│  │ COMPLIANCE CHECKS                                                    │   │
│  │ ────────────────────────────────────────────────────────────────    │   │
│  │ ✅ Not on Restricted List                                            │   │
│  │ ✅ No firm trading in last 7 days                                    │   │
│  │ ✅ No research coverage conflict                                     │   │
│  │ ✅ Within personal trading limits                                    │   │
│  │ ⚠️  Firm has open position (50,000 shares)                          │   │
│  │                                                                      │   │
│  │ [Submit Request]                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  MY PENDING REQUESTS                                                        │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ DATE     │ SECURITY │ ACTION │ QTY   │ STATUS    │ EXPIRES          │   │
│  ├──────────┼──────────┼────────┼───────┼───────────┼──────────────────┤   │
│  │ Aug 2    │ MSFT     │ BUY    │ 50    │ ⏳ PENDING │ Aug 5 (3 days)   │   │
│  │ Aug 1    │ NVDA     │ BUY    │ 25    │ ✅ APPROVED│ Aug 4 (2 days)   │   │
│  │ Jul 30   │ GOOGL    │ SELL   │ 100   │ ❌ DENIED  │ N/A             │   │
│  │          │          │        │       │ (Restricted)│                │   │
│  └──────────┴──────────┴────────┴───────┴───────────┴──────────────────┘   │
│                                                                              │
│  ADMIN VIEW - PENDING APPROVALS                                             │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ DATE  │ EMPLOYEE    │ SECURITY│ ACTION│ QTY │ REASON    │ ACTIONS  │   │
│  ├───────┼─────────────┼─────────┼───────┼─────┼───────────┼──────────┤   │
│  │ Aug 2 │ John Smith  │ MSFT    │ BUY   │ 50  │ Long-term │ [✓] [✗]  │   │
│  │ Aug 2 │ Jane Doe    │ AMZN    │ BUY   │ 100 │ Retirement│ [✓] [✗]  │   │
│  │ Aug 1 │ Bob Johnson │ TSLA    │ SELL  │ 200 │ Rebalance │ [✓] [✗]  │   │
│  └───────┴─────────────┴─────────┴───────┴─────┴───────────┴──────────┘   │
│                                                                              │
│  QUARTERLY HOLDINGS REPORT                                                  │
│  ═══════════════════════════════════════════════════════════════════════    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Period: [Q2 2024 ▼]                                                  │   │
│  │                                                                      │   │
│  │ ⚠️ 3 employees have not submitted quarterly holdings reports         │   │
│  │                                                                      │   │
│  │ [Send Reminder] [View Submitted] [Download All]                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## API Endpoints

### Surveillance

```yaml
GET /api/v1/compliance/alerts
  Query: severity, type, status, date_from, date_to, page, limit
  Response: List of compliance alerts

POST /api/v1/compliance/alerts/{id}/acknowledge
  Body: { notes: string }
  Response: Updated alert

POST /api/v1/compliance/alerts/{id}/investigate
  Body: { assigned_to: user_id, notes: string }
  Response: Created investigation case

GET /api/v1/compliance/investigations
  Query: status, assigned_to, type, page, limit
  Response: List of investigation cases

PUT /api/v1/compliance/investigations/{id}
  Body: { status, findings, resolution, notes }
  Response: Updated investigation
```

### Pre-Trade Compliance

```yaml
POST /api/v1/compliance/check-order
  Body: { 
    symbol, side, quantity, account_id,
    order_type, limit_price 
  }
  Response: {
    allowed: boolean,
    checks: [
      { rule: string, status: 'pass'|'warn'|'fail', message: string }
    ],
    warnings: string[],
    errors: string[]
  }

POST /api/v1/compliance/override
  Body: { 
    order_id, rule_id, reason,
    approved_by: user_id 
  }
  Response: Override record

GET /api/v1/compliance/rules
  Query: type, scope, active_only
  Response: List of compliance rules

POST /api/v1/compliance/rules
  Body: Rule definition
  Response: Created rule

PUT /api/v1/compliance/rules/{id}
  Body: Updated rule definition
  Response: Updated rule
```

### Restricted List

```yaml
GET /api/v1/compliance/restricted-list
  Query: type, active_only, search
  Response: List of restricted securities/persons

POST /api/v1/compliance/restricted-list
  Body: { 
    symbol, type, reason, 
    effective_date, expiration_date, notes 
  }
  Response: Created restriction

PUT /api/v1/compliance/restricted-list/{id}
  Body: Updated restriction
  Response: Updated restriction

DELETE /api/v1/compliance/restricted-list/{id}
  Response: 204 (soft delete/expire)

GET /api/v1/compliance/restricted-list/check/{symbol}
  Response: { 
    restricted: boolean, 
    type: string | null,
    reason: string | null 
  }
```

### Regulatory Reports

```yaml
GET /api/v1/compliance/reports
  Query: type, period, status
  Response: List of regulatory reports

GET /api/v1/compliance/reports/13f
  Query: period
  Response: Generated 13F data

POST /api/v1/compliance/reports/13f/generate
  Body: { period, as_of_date }
  Response: Generated 13F report

POST /api/v1/compliance/reports/13f/validate
  Body: { report_data }
  Response: Validation results

POST /api/v1/compliance/reports/13f/submit
  Body: { report_id }
  Response: Submission confirmation
```

### Personal Trading

```yaml
GET /api/v1/compliance/personal-trading/requests
  Query: status, user_id, date_from, date_to
  Response: List of pre-clearance requests

POST /api/v1/compliance/personal-trading/requests
  Body: { 
    symbol, action, quantity, 
    account_name, reason 
  }
  Response: Created request with compliance check results

PUT /api/v1/compliance/personal-trading/requests/{id}
  Body: { status: 'approved'|'denied', notes }
  Response: Updated request

GET /api/v1/compliance/personal-trading/holdings
  Query: user_id, period
  Response: Personal holdings report

POST /api/v1/compliance/personal-trading/holdings
  Body: { holdings: [...] }
  Response: Submitted holdings report
```

---

## Data Models

### Compliance Alert

```typescript
interface ComplianceAlert {
  id: string;
  firmId: string;
  
  type: AlertType;
  severity: 'critical' | 'high' | 'medium' | 'low';
  
  subject: {
    type: 'order' | 'trade' | 'position' | 'user' | 'communication';
    id: string;
    description: string;
  };
  
  rule: {
    id: string;
    name: string;
    description: string;
  };
  
  message: string;
  details: Record<string, any>;
  
  status: 'new' | 'acknowledged' | 'investigating' | 'resolved' | 'dismissed';
  
  acknowledgedBy: string | null;
  acknowledgedAt: Date | null;
  
  resolution: string | null;
  resolvedBy: string | null;
  resolvedAt: Date | null;
  
  createdAt: Date;
}

type AlertType = 
  | 'restricted_list'
  | 'position_limit'
  | 'sector_limit'
  | 'front_running'
  | 'wash_trade'
  | 'info_barrier'
  | 'unusual_volume'
  | 'best_execution'
  | 'personal_trading';
```

### Compliance Rule

```typescript
interface ComplianceRule {
  id: string;
  firmId: string;
  
  name: string;
  description: string;
  type: RuleType;
  
  conditions: RuleCondition[];
  
  action: 'hard_stop' | 'soft_stop' | 'warn' | 'log';
  
  scope: {
    funds: string[] | 'all';
    accounts: string[] | 'all';
    securities: string[] | 'all';
    users: string[] | 'all';
  };
  
  active: boolean;
  
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

interface RuleCondition {
  field: string;
  operator: 'gt' | 'lt' | 'eq' | 'gte' | 'lte' | 'in' | 'not_in';
  value: any;
  unit?: string;
}
```

### Restricted Security

```typescript
interface RestrictedSecurity {
  id: string;
  firmId: string;
  
  symbol: string;
  cusip: string | null;
  companyName: string;
  
  restrictionType: 'blocked' | 'watch' | 'frozen';
  reason: RestrictionReason;
  
  effectiveDate: Date;
  expirationDate: Date | null;
  
  notes: string | null;
  
  addedBy: string;
  addedAt: Date;
  
  removedBy: string | null;
  removedAt: Date | null;
}

type RestrictionReason =
  | 'mnpi_ma'
  | 'mnpi_other'
  | 'research_coverage'
  | 'insider_information'
  | 'board_connection'
  | 'ipo_quiet_period'
  | 'other';
```

---

## Compliance Rule Examples

### Position Concentration Limit

```json
{
  "name": "Single Stock Concentration Limit",
  "type": "position_limit",
  "conditions": [
    {
      "field": "position_weight",
      "operator": "gt",
      "value": 10,
      "unit": "percent"
    }
  ],
  "action": "hard_stop",
  "scope": {
    "funds": "all",
    "securities": "all"
  }
}
```

### Sector Exposure Warning

```json
{
  "name": "Technology Sector Limit",
  "type": "sector_limit",
  "conditions": [
    {
      "field": "sector_weight",
      "operator": "gt",
      "value": 35,
      "unit": "percent"
    },
    {
      "field": "sector",
      "operator": "eq",
      "value": "Technology"
    }
  ],
  "action": "warn",
  "scope": {
    "funds": "all"
  }
}
```

### Daily Volume Limit

```json
{
  "name": "ADV Participation Limit",
  "type": "volume_limit",
  "conditions": [
    {
      "field": "order_quantity_vs_adv",
      "operator": "gt",
      "value": 25,
      "unit": "percent"
    }
  ],
  "action": "warn",
  "scope": {
    "funds": "all",
    "securities": "all"
  }
}
```

---

## Component Structure

```
src/components/compliance/
├── surveillance/
│   ├── SurveillanceDashboard.tsx
│   ├── AlertList.tsx
│   ├── AlertDetail.tsx
│   ├── AlertSeverityBadge.tsx
│   ├── InvestigationQueue.tsx
│   └── InvestigationDetail.tsx
├── pre-trade/
│   ├── PreTradeChecker.tsx
│   ├── ComplianceCheckResult.tsx
│   ├── RuleList.tsx
│   ├── RuleEditor.tsx
│   └── OverrideLog.tsx
├── restricted-list/
│   ├── RestrictedList.tsx
│   ├── AddRestriction.tsx
│   ├── RestrictionDetail.tsx
│   └── RestrictedPersons.tsx
├── regulatory/
│   ├── ReportsDashboard.tsx
│   ├── Form13FGenerator.tsx
│   ├── FormPFGenerator.tsx
│   ├── ReportPreview.tsx
│   └── DeadlineCalendar.tsx
├── personal-trading/
│   ├── PreClearanceForm.tsx
│   ├── MyRequests.tsx
│   ├── ApprovalQueue.tsx
│   ├── HoldingsReport.tsx
│   └── TradingPolicy.tsx
└── policies/
    ├── PolicyLibrary.tsx
    ├── PolicyViewer.tsx
    ├── Acknowledgments.tsx
    └── TrainingTracker.tsx
```
