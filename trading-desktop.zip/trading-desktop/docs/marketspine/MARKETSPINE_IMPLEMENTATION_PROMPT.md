# MarketSpine Full Implementation Prompt

## For Claude Opus / Sonnet - Complete Institutional Investment Management Platform

---

## 🎯 Project Overview

Build **MarketSpine**, a Bloomberg PORT-style institutional investment management platform with:
- **capture-spine-basic look and feel** (dark theme, dense data grids, Bloomberg-style colors)
- **Multi-user support** with role-based access control
- **124 integrated features** across Trading, Portfolio, Risk, Research, and Compliance modules

---

## 📋 Core Requirements

### Target Users
| Role | Responsibilities |
|------|-----------------|
| **Portfolio Manager** | Manage portfolios, analyze performance, approve trades |
| **Trader** | Execute orders, analyze execution quality, manage baskets |
| **Research Analyst** | Write research notes, maintain company models |
| **Risk Analyst** | Monitor risk metrics, run scenarios, generate reports |
| **Compliance Officer** | Surveillance, pre-trade compliance, regulatory reporting |
| **Operations** | Settlement, reconciliation, data management |
| **Admin** | User management, permissions, system configuration |

### Design Philosophy
- **Bloomberg-style dense data visualization** - Show maximum information per pixel
- **Dark theme primary** with light theme option
- **Keyboard-first navigation** - Power users expect keyboard shortcuts
- **Real-time updates** - WebSocket for live data
- **Progressive disclosure** - Simple views expand to detailed analysis

---

## 🎨 Design System: Capture-Spine-Basic Style

### Color Palette (Bloomberg-Inspired)
```css
/* Primary Background */
--bg-primary: #0D1117;      /* Deep dark background */
--bg-secondary: #161B22;    /* Card/panel background */
--bg-tertiary: #21262D;     /* Hover states */
--bg-surface: #1C2128;      /* Elevated surfaces */

/* Borders & Dividers */
--border-primary: #30363D;
--border-secondary: #21262D;

/* Text Colors */
--text-primary: #E6EDF3;    /* Primary text */
--text-secondary: #8B949E;  /* Secondary text */
--text-muted: #6E7681;      /* Muted/disabled */

/* Bloomberg Financial Colors */
--price-positive: #3FB950;  /* Green - gains */
--price-negative: #F85149;  /* Red - losses */
--price-neutral: #8B949E;   /* Gray - unchanged */

/* Bloomberg Accent Colors */
--bloomberg-orange: #FF6B35;  /* Headers, accents */
--bloomberg-yellow: #FFD700;  /* Highlights, warnings */
--bloomberg-blue: #58A6FF;    /* Links, interactive */
--bloomberg-cyan: #39D2D7;    /* Charts, data viz */

/* Status Colors */
--status-pending: #FFD700;    /* Yellow */
--status-active: #3FB950;     /* Green */
--status-complete: #58A6FF;   /* Blue */
--status-cancelled: #F85149;  /* Red */
```

### Typography
```css
/* Font Stack - Monospace for Data */
--font-mono: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
--font-sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;

/* Font Sizes */
--text-xs: 0.75rem;   /* 12px - Dense data tables */
--text-sm: 0.8125rem; /* 13px - Default table text */
--text-base: 0.875rem;/* 14px - Body text */
--text-lg: 1rem;      /* 16px - Headings */
--text-xl: 1.25rem;   /* 20px - Page titles */
```

### Grid/Table Styling
```css
/* Dense Data Grid */
.data-grid {
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  line-height: 1.2;
}

.data-grid th {
  background: var(--bg-tertiary);
  color: var(--bloomberg-orange);
  font-weight: 600;
  text-transform: uppercase;
  font-size: var(--text-xs);
  letter-spacing: 0.05em;
  padding: 8px 12px;
  border-bottom: 2px solid var(--border-primary);
}

.data-grid td {
  padding: 6px 12px;
  border-bottom: 1px solid var(--border-secondary);
}

.data-grid tr:hover {
  background: var(--bg-tertiary);
}

/* Numeric Columns - Right Aligned */
.data-grid td.numeric {
  text-align: right;
  font-feature-settings: 'tnum' 1;
}
```

### P&L Display Pattern
```typescript
const formatPnL = (value: number) => ({
  text: value >= 0 ? `+${value.toLocaleString()}` : value.toLocaleString(),
  color: value > 0 ? 'var(--price-positive)' : 
         value < 0 ? 'var(--price-negative)' : 
         'var(--text-secondary)'
});
```

---

## 🏗️ Technology Stack

### Frontend
```json
{
  "framework": "React 19",
  "language": "TypeScript 5.4+",
  "build": "Vite",
  "styling": "Tailwind CSS 3.4",
  "state": {
    "server": "TanStack Query v5",
    "client": "Zustand"
  },
  "tables": "AG Grid Enterprise",
  "charts": ["Recharts", "Lightweight Charts (TradingView)"],
  "graphs": "React Flow",
  "realtime": "Socket.io-client"
}
```

### Backend
```json
{
  "runtime": "Python 3.12+",
  "framework": "FastAPI",
  "orm": "SQLAlchemy 2.0 (async)",
  "database": "PostgreSQL 16",
  "cache": "Redis 7",
  "background": "Celery + Redis",
  "search": "Elasticsearch 8",
  "websocket": "FastAPI WebSocket + Redis Pub/Sub"
}
```

### Infrastructure
```json
{
  "containers": "Docker Compose",
  "storage": "MinIO (S3-compatible)",
  "monitoring": "Prometheus + Grafana"
}
```

---

## 👥 Multi-User Architecture

### Database Schema: Users & Auth
```sql
-- Core User Tables
CREATE TABLE firms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    settings JSONB DEFAULT '{}'
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID NOT NULL REFERENCES firms(id),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role VARCHAR(50) NOT NULL DEFAULT 'viewer',
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE,
    preferences JSONB DEFAULT '{}'
);

CREATE TYPE user_role AS ENUM (
    'admin',
    'portfolio_manager',
    'trader',
    'analyst',
    'compliance',
    'operations',
    'viewer'
);

-- Session Management
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token VARCHAR(512) NOT NULL UNIQUE,
    device_info JSONB,
    ip_address INET,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Activity Logging
CREATE TABLE activity_log (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    firm_id UUID REFERENCES firms(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id VARCHAR(255),
    metadata JSONB,
    ip_address INET,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Row-Level Security
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY firm_isolation ON accounts
    USING (firm_id = current_setting('app.current_firm_id')::UUID);
```

### Role Permissions Matrix
```typescript
const PERMISSIONS = {
  admin: {
    users: ['create', 'read', 'update', 'delete'],
    settings: ['read', 'update'],
    all_modules: ['full_access']
  },
  portfolio_manager: {
    portfolios: ['create', 'read', 'update'],
    trades: ['create', 'read', 'approve'],
    research: ['read', 'create'],
    risk: ['read'],
    optimization: ['execute']
  },
  trader: {
    orders: ['create', 'read', 'update', 'cancel'],
    executions: ['read'],
    baskets: ['create', 'read', 'update'],
    portfolios: ['read']
  },
  analyst: {
    research: ['create', 'read', 'update'],
    portfolios: ['read'],
    models: ['create', 'read', 'update']
  },
  compliance: {
    surveillance: ['read', 'update'],
    reports: ['create', 'read'],
    restrictions: ['create', 'read', 'update'],
    all_data: ['read']
  },
  operations: {
    settlements: ['read', 'update'],
    reconciliation: ['read', 'update'],
    data: ['import', 'export']
  },
  viewer: {
    portfolios: ['read'],
    research: ['read'],
    reports: ['read']
  }
};
```

---

## 📁 Project Structure

```
marketspine/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/
│   │   │   │   ├── DataGrid/           # AG Grid wrapper
│   │   │   │   ├── Charts/             # Recharts components
│   │   │   │   ├── Forms/              # Form components
│   │   │   │   ├── Layout/             # Shell, Sidebar, Header
│   │   │   │   └── Navigation/         # Tabs, Breadcrumbs
│   │   │   ├── trading/
│   │   │   │   ├── OrderBlotter/
│   │   │   │   ├── ExecutionAnalysis/
│   │   │   │   ├── BasketTrading/
│   │   │   │   ├── BrokerScorecard/
│   │   │   │   └── CommissionAnalysis/
│   │   │   ├── portfolio/
│   │   │   │   ├── Holdings/
│   │   │   │   ├── Characteristics/
│   │   │   │   ├── CashFlows/
│   │   │   │   ├── TradeSimulation/
│   │   │   │   └── Rebalancing/
│   │   │   ├── analytics/
│   │   │   │   ├── PerformanceAttribution/
│   │   │   │   ├── FactorAttribution/
│   │   │   │   └── Optimization/
│   │   │   ├── risk/
│   │   │   │   ├── RiskSummary/
│   │   │   │   ├── VaRAnalysis/
│   │   │   │   ├── TrackingError/
│   │   │   │   ├── LiquidityRisk/
│   │   │   │   └── ScenarioAnalysis/
│   │   │   ├── research/
│   │   │   │   ├── ResearchNotes/
│   │   │   │   ├── CompanyProfile/
│   │   │   │   └── KnowledgeGraph/
│   │   │   ├── compliance/
│   │   │   │   ├── Surveillance/
│   │   │   │   ├── Restrictions/
│   │   │   │   └── Reporting/
│   │   │   ├── jobs/
│   │   │   │   └── JobManager/
│   │   │   └── auth/
│   │   │       ├── Login/
│   │   │       ├── UserProfile/
│   │   │       └── UserManagement/
│   │   ├── hooks/
│   │   │   ├── useAuth.ts
│   │   │   ├── useWebSocket.ts
│   │   │   ├── usePortfolio.ts
│   │   │   ├── useRisk.ts
│   │   │   └── useRealTime.ts
│   │   ├── services/
│   │   │   ├── api.ts
│   │   │   ├── auth.ts
│   │   │   └── websocket.ts
│   │   ├── stores/
│   │   │   ├── authStore.ts
│   │   │   ├── portfolioStore.ts
│   │   │   └── uiStore.ts
│   │   ├── types/
│   │   │   ├── api.ts
│   │   │   ├── portfolio.ts
│   │   │   ├── risk.ts
│   │   │   └── trading.ts
│   │   └── utils/
│   │       ├── formatting.ts
│   │       ├── calculations.ts
│   │       └── constants.ts
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── v1/
│   │   │   │   ├── auth.py
│   │   │   │   ├── users.py
│   │   │   │   ├── portfolios.py
│   │   │   │   ├── holdings.py
│   │   │   │   ├── trading.py
│   │   │   │   ├── risk.py
│   │   │   │   ├── attribution.py
│   │   │   │   ├── optimization.py
│   │   │   │   ├── research.py
│   │   │   │   ├── jobs.py
│   │   │   │   └── compliance.py
│   │   │   └── deps.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   ├── security.py
│   │   │   └── permissions.py
│   │   ├── db/
│   │   │   ├── base.py
│   │   │   └── session.py
│   │   ├── models/
│   │   │   ├── user.py
│   │   │   ├── firm.py
│   │   │   ├── portfolio.py
│   │   │   ├── position.py
│   │   │   ├── order.py
│   │   │   ├── execution.py
│   │   │   └── research.py
│   │   ├── schemas/
│   │   │   └── (Pydantic models)
│   │   ├── services/
│   │   │   ├── auth_service.py
│   │   │   ├── portfolio_service.py
│   │   │   ├── risk_service.py
│   │   │   ├── attribution_service.py
│   │   │   └── optimization_service.py
│   │   ├── calculations/
│   │   │   ├── var.py
│   │   │   ├── attribution.py
│   │   │   ├── factor_model.py
│   │   │   ├── liquidity.py
│   │   │   └── optimization.py
│   │   ├── tasks/
│   │   │   ├── celery_app.py
│   │   │   ├── risk_tasks.py
│   │   │   └── report_tasks.py
│   │   └── main.py
│   ├── alembic/
│   ├── tests/
│   └── requirements.txt
│
├── docker/
│   ├── docker-compose.yml
│   ├── Dockerfile.frontend
│   ├── Dockerfile.backend
│   └── nginx.conf
│
└── docs/
    ├── features/           # Feature specs (01-16)
    └── marketspine/        # Module docs
```

---

## 🔌 API Endpoints

### Authentication
```
POST   /api/v1/auth/login          # Email/password login
POST   /api/v1/auth/logout         # Logout, invalidate tokens
POST   /api/v1/auth/refresh        # Refresh access token
POST   /api/v1/auth/password-reset # Request password reset
GET    /api/v1/auth/me             # Get current user
```

### User Management (Admin)
```
GET    /api/v1/users               # List users
POST   /api/v1/users               # Create user
GET    /api/v1/users/:id           # Get user
PATCH  /api/v1/users/:id           # Update user
DELETE /api/v1/users/:id           # Delete user
PATCH  /api/v1/users/:id/role      # Change role
```

### Portfolio & Holdings
```
GET    /api/v1/portfolios                    # List portfolios
GET    /api/v1/portfolios/:id                # Portfolio summary
GET    /api/v1/portfolios/:id/holdings       # Positions
GET    /api/v1/portfolios/:id/holdings/intraday   # Intraday changes
GET    /api/v1/portfolios/:id/characteristics # P/E, beta, etc.
GET    /api/v1/portfolios/:id/cash-flows     # Projected cash flows
POST   /api/v1/portfolios/:id/simulate       # Trade simulation
```

### Trading
```
GET    /api/v1/orders                        # Order blotter
POST   /api/v1/orders                        # Create order
PATCH  /api/v1/orders/:id                    # Update order
DELETE /api/v1/orders/:id                    # Cancel order
GET    /api/v1/orders/:id/executions         # Order fills
GET    /api/v1/baskets                       # List baskets
POST   /api/v1/baskets                       # Create basket
POST   /api/v1/baskets/:id/execute           # Execute basket
GET    /api/v1/brokers/scorecard             # Broker metrics
```

### Risk Analytics
```
GET    /api/v1/risk/:portfolio_id/summary    # Risk overview
GET    /api/v1/risk/:portfolio_id/var        # VaR calculation
GET    /api/v1/risk/:portfolio_id/tracking-error # TE vs benchmark
GET    /api/v1/risk/:portfolio_id/liquidity  # Liquidity analysis
GET    /api/v1/risk/:portfolio_id/scenarios  # Scenario results
POST   /api/v1/risk/scenarios/custom         # Run custom scenario
```

### Attribution
```
GET    /api/v1/attribution/:portfolio_id/performance  # Brinson
GET    /api/v1/attribution/:portfolio_id/factor       # Factor attribution
```

### Optimization
```
POST   /api/v1/optimization/run              # Run optimization
GET    /api/v1/optimization/results/:job_id  # Get results
GET    /api/v1/optimization/constraints      # Get constraints
```

### Jobs
```
GET    /api/v1/jobs                          # List jobs
POST   /api/v1/jobs                          # Create job
GET    /api/v1/jobs/:id                      # Job status/results
DELETE /api/v1/jobs/:id                      # Cancel job
GET    /api/v1/jobs/:id/progress             # Progress updates
```

### WebSocket
```
WS     /ws/market-data                       # Real-time prices
WS     /ws/portfolio/:id                     # Portfolio updates
WS     /ws/orders                            # Order status updates
WS     /ws/jobs/:id                          # Job progress
```

---

## 🧩 Module Specifications

### Module 1: Trading Center

See detailed wireframes and specs in:
- `docs/features/01_TRADEBOOK_STRATEGY_ANALYZER.md`
- `docs/features/02_LOW_TOUCH_OMS.md`
- `docs/features/03_BASKET_TRADING.md`
- `docs/marketspine/TRADING_CENTER.md`

#### Order Blotter Component
```tsx
interface OrderBlotterProps {
  portfolioId?: string;
  accountId?: string;
  dateRange?: DateRange;
}

// Columns
const columns = [
  'Order ID', 'Symbol', 'Side', 'Qty', 'Filled', 'Remaining',
  'Price', 'Avg Price', 'Status', 'Broker', 'Created', 'Updated'
];

// Real-time status via WebSocket
const useOrderUpdates = (orderId: string) => {
  const ws = useWebSocket(`/ws/orders/${orderId}`);
  return ws.lastMessage?.data;
};
```

#### Execution Analysis Component
```tsx
// VWAP comparison chart
<ExecutionChart
  orderId={selectedOrder.id}
  showVWAP={true}
  showTWAP={true}
  showMarketPrice={true}
/>

// Implementation shortfall breakdown
<ShortfallTable
  orderId={selectedOrder.id}
  components={['delay', 'market_impact', 'timing', 'commission']}
/>
```

---

### Module 2: Portfolio Manager

See detailed wireframes and specs in:
- `docs/features/04_PORT_HOLDINGS.md`
- `docs/features/08_PORTFOLIO_CHARACTERISTICS.md`
- `docs/features/09_CASH_FLOWS.md`
- `docs/features/14_TRADE_SIMULATION.md`
- `docs/marketspine/PORTFOLIO_MANAGER.md`

#### Holdings Grid
```tsx
// Hierarchical grid: Fund > Account > Position
<HoldingsGrid
  groupBy={['fund', 'account']}
  columns={[
    'symbol', 'name', 'quantity', 'price', 'market_value',
    'cost_basis', 'unrealized_pnl', 'unrealized_pct',
    'weight', 'weight_target', 'drift'
  ]}
  realTime={true}
/>
```

#### Characteristics View
```tsx
// Portfolio vs Benchmark characteristics
<CharacteristicsComparison
  portfolioId={portfolioId}
  benchmarkId="SPY"
  metrics={[
    'pe_ratio', 'pb_ratio', 'dividend_yield', 'beta',
    'market_cap_weighted', 'eps_growth', 'debt_equity'
  ]}
/>
```

---

### Module 3: Risk Analytics

See detailed wireframes and specs in:
- `docs/features/07_RISK_ANALYTICS.md`
- `docs/features/10_LIQUIDITY_RISK.md`
- `docs/features/11_SCENARIO_ANALYSIS.md`
- `docs/features/12_TRACKING_ERROR.md`
- `docs/features/13_VAR_METHODS.md`

#### VaR Dashboard
```tsx
// Multiple VaR methods comparison
<VaRComparison
  portfolioId={portfolioId}
  methods={['monte_carlo', 'historical', 'parametric']}
  confidenceLevel={0.95}
  horizon={1} // days
/>

// VaR contributors
<VaRContributors
  portfolioId={portfolioId}
  groupBy="sector"
  sortBy="contribution"
/>
```

#### Scenario Analysis
```tsx
// Historical + Hypothetical scenarios
<ScenarioGrid
  scenarios={[
    { type: 'historical', name: 'Lehman 2008' },
    { type: 'historical', name: 'COVID March 2020' },
    { type: 'hypothetical', name: 'VIX +50%' },
    { type: 'hypothetical', name: 'Rates +100bps' },
    { type: 'custom', name: 'My Scenario' }
  ]}
  showContributors={true}
/>
```

---

### Module 4: Attribution

See detailed wireframes and specs in:
- `docs/features/05_PERFORMANCE_ATTRIBUTION.md`
- `docs/features/06_FACTOR_ATTRIBUTION.md`

#### Brinson Attribution
```tsx
// Allocation + Selection + Interaction
<BrinsonAttribution
  portfolioId={portfolioId}
  benchmarkId="SPY"
  period="YTD"
  level="sector" // or 'security'
/>
```

#### Factor Attribution
```tsx
// Multi-factor decomposition
<FactorAttribution
  portfolioId={portfolioId}
  factors={['momentum', 'value', 'size', 'quality', 'volatility']}
  period="1Y"
  showExposures={true}
  showContributions={true}
/>
```

---

### Module 5: Optimization

See detailed wireframes and specs in:
- `docs/features/15_PORTFOLIO_OPTIMIZATION.md`

#### Efficient Frontier
```tsx
<EfficientFrontier
  portfolioId={portfolioId}
  constraints={constraints}
  showCurrentPortfolio={true}
  showMaxSharpe={true}
  showMinVariance={true}
  interactive={true}
  onPointClick={(point) => setTargetAllocation(point)}
/>
```

#### Optimization Results
```tsx
<OptimizationResults
  jobId={optimizationJobId}
  showSuggestedTrades={true}
  showImpactAnalysis={true}
  onSendToOMS={() => sendTradesToOMS(suggestedTrades)}
/>
```

---

### Module 6: Job Manager

See detailed wireframes and specs in:
- `docs/features/16_JOB_MANAGER.md`

#### Job Queue
```tsx
<JobQueue
  filters={{ status: ['pending', 'running'] }}
  columns={['job_id', 'name', 'type', 'status', 'progress', 'started', 'eta']}
  realTimeProgress={true}
/>
```

---

## 🔧 Implementation Phases

### Phase 1: Foundation (Weeks 1-4)
```
Priority: Auth + Core Layout + Basic Holdings

[ ] Multi-user authentication (login, logout, JWT)
[ ] Role-based access control
[ ] App shell with sidebar navigation
[ ] Basic dashboard with portfolio summary
[ ] Holdings grid with real-time P&L
[ ] Basic search functionality
```

### Phase 2: Trading Center (Weeks 5-8)
```
Priority: Order Management + Execution Analysis

[ ] Order blotter with filtering/sorting
[ ] Order entry form
[ ] Real-time order status (WebSocket)
[ ] Execution list view
[ ] VWAP/TWAP comparison
[ ] Broker scorecard
[ ] Commission analysis
```

### Phase 3: Portfolio Analytics (Weeks 9-12)
```
Priority: Holdings + Characteristics + Attribution

[ ] Portfolio characteristics (P/E, beta, etc.)
[ ] Performance attribution (Brinson)
[ ] Factor attribution
[ ] Cash flow projections
[ ] Trade simulation (what-if)
```

### Phase 4: Risk Management (Weeks 13-16)
```
Priority: VaR + Scenarios + Tracking Error

[ ] VaR calculation (Monte Carlo, Historical)
[ ] VaR contributors by sector/security
[ ] Scenario analysis (historical + hypothetical)
[ ] Tracking error analysis
[ ] Liquidity risk analysis
```

### Phase 5: Advanced Features (Weeks 17-20)
```
Priority: Optimization + Jobs + Compliance

[ ] Portfolio optimization
[ ] Efficient frontier visualization
[ ] Job manager
[ ] Basket trading
[ ] Compliance dashboards
```

### Phase 6: Polish & Enterprise (Weeks 21-24)
```
Priority: Research + Collaboration + Performance

[ ] Research notes with collaboration
[ ] Knowledge graph integration
[ ] Performance optimization
[ ] Comprehensive testing
[ ] Documentation
```

---

## 📊 Sample Data Model

### Position
```typescript
interface Position {
  id: string;
  portfolio_id: string;
  account_id: string;
  security_id: string;
  symbol: string;
  quantity: number;
  avg_cost: number;
  market_price: number;
  market_value: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  realized_pnl: number;
  weight: number;
  weight_target?: number;
  drift?: number;
  sector: string;
  industry: string;
  updated_at: string;
}
```

### Order
```typescript
interface Order {
  id: string;
  portfolio_id: string;
  account_id: string;
  symbol: string;
  side: 'buy' | 'sell';
  quantity: number;
  filled_quantity: number;
  price_type: 'market' | 'limit' | 'stop';
  limit_price?: number;
  status: 'pending' | 'open' | 'partial' | 'filled' | 'cancelled';
  broker_id: string;
  algo?: string;
  avg_fill_price?: number;
  vwap?: number;
  created_at: string;
  updated_at: string;
}
```

### RiskMetrics
```typescript
interface RiskMetrics {
  portfolio_id: string;
  as_of_date: string;
  var_95_1d: number;
  var_99_1d: number;
  cvar_95_1d: number;
  tracking_error: number;
  beta: number;
  sharpe_ratio: number;
  sortino_ratio: number;
  max_drawdown: number;
  volatility_30d: number;
  volatility_90d: number;
}
```

---

## ✅ Quality Standards

### TypeScript
- Strict mode enabled
- No `any` types
- Proper error handling
- Comprehensive interfaces

### Python
- Type hints on all functions
- Pydantic for validation
- Async/await properly
- Unit tests for calculations

### Testing
- Unit tests: 80% coverage
- Integration tests: API endpoints
- E2E tests: Critical user flows
- Performance tests: Large datasets

### Security
- JWT with short expiry + refresh
- HTTPS only
- CSRF protection
- Rate limiting
- Input sanitization
- Row-level security

---

## 🚀 Getting Started

When implementing, start with:

1. **Set up Docker environment** with PostgreSQL, Redis, and API server
2. **Implement auth** - Login, JWT, user table, permissions
3. **Build app shell** - Sidebar, header, routing
4. **Add holdings view** - First data grid with real-time updates
5. **Expand from there** following the phase plan

Refer to feature docs for detailed wireframes and specifications:
- `docs/features/01_TRADEBOOK_STRATEGY_ANALYZER.md` - Trading analytics
- `docs/features/04_PORT_HOLDINGS.md` - Holdings view
- `docs/features/07_RISK_ANALYTICS.md` - Risk dashboard
- `docs/features/13_VAR_METHODS.md` - VaR calculations
- `docs/features/15_PORTFOLIO_OPTIMIZATION.md` - Optimization

---

*This prompt provides the complete specification for building MarketSpine, an institutional investment management platform with 124+ features, multi-user support, and Bloomberg-style design.*
