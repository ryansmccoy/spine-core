# MarketSpine: Institutional Investment Management Platform

## Vision

MarketSpine is a comprehensive web-based platform for institutional investment managers, combining the analytical power of Bloomberg Terminal with modern web technologies and knowledge graph visualization. Built on the capture-spine architecture, it provides trading analytics, research management, compliance tools, and collaborative features in a unified ecosystem.

## Target Users

- **Portfolio Managers** - Track positions, analyze performance, prepare for meetings
- **Traders** - Best execution analysis, broker routing, commission tracking
- **Research Analysts** - Company research, sector analysis, knowledge management
- **Compliance Officers** - Trade surveillance, regulatory reporting, risk monitoring
- **Operations** - Settlement tracking, reconciliation, reporting

## Core Modules

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            MARKETSPINE PLATFORM                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │   TRADING   │  │  RESEARCH   │  │  PORTFOLIO  │  │ COMPLIANCE  │        │
│  │   CENTER    │  │    HUB      │  │   MANAGER   │  │   CONSOLE   │        │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │  INDUSTRY   │  │    NEWS     │  │  CALENDAR   │  │  MESSAGING  │        │
│  │  EXPLORER   │  │    FEED     │  │  & MEETINGS │  │   CENTER    │        │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────┐       │
│  │              KNOWLEDGE GRAPH ENGINE (EntitySpine)               │       │
│  │   Companies ←→ Trades ←→ Brokers ←→ Funds ←→ Strategies        │       │
│  └─────────────────────────────────────────────────────────────────┘       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Differentiators

### 1. **Unified Knowledge Graph**
Everything is connected - trades link to securities, which link to companies, which link to industries, which link to research notes, which link to meetings. Navigate relationships visually.

### 2. **Best Execution Visualization**
See broker performance at a glance. Compare fill prices, lot breakdowns, timing analysis across brokers for identical orders.

### 3. **Collaborative Research**
Share research notes, tag colleagues, build institutional knowledge. Everyone sees the same news but with personalized alerts.

### 4. **Modern Web Architecture**
No desktop install required. Real-time updates. Mobile-responsive. API-first design enables integrations.

## Entity Model

```
                    ┌──────────────┐
                    │     FIRM     │
                    │ (Am Century) │
                    └──────┬───────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
    ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
    │    FUND     │ │    FUND     │ │    FUND     │
    │  (Growth)   │ │   (Value)   │ │  (Income)   │
    └──────┬──────┘ └──────┬──────┘ └──────┬──────┘
           │               │               │
    ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
    │  ACCOUNTS   │ │  ACCOUNTS   │ │  ACCOUNTS   │
    │  (1, 2, 3)  │ │  (4, 5, 6)  │ │  (7, 8, 9)  │
    └──────┬──────┘ └──────┬──────┘ └──────┬──────┘
           │               │               │
           └───────────────┼───────────────┘
                           │
                    ┌──────▼──────┐
                    │   TRADES    │
                    │ (Executions)│
                    └──────┬──────┘
                           │
         ┌─────────────────┼─────────────────┐
         │                 │                 │
  ┌──────▼──────┐   ┌──────▼──────┐   ┌──────▼──────┐
  │   BROKER    │   │  SECURITY   │   │   VENUE     │
  │ (JP Morgan) │   │   (TSLA)    │   │  (NYSE)     │
  └─────────────┘   └──────┬──────┘   └─────────────┘
                           │
                    ┌──────▼──────┐
                    │   COMPANY   │
                    │   (Tesla)   │
                    └──────┬──────┘
                           │
         ┌─────────────────┼─────────────────┐
         │                 │                 │
  ┌──────▼──────┐   ┌──────▼──────┐   ┌──────▼──────┐
  │  INDUSTRY   │   │  RESEARCH   │   │    NEWS     │
  │  (EV/Auto)  │   │   NOTES     │   │  ARTICLES   │
  └─────────────┘   └─────────────┘   └─────────────┘
```

## Technology Stack

### Frontend
- **React 19** with TypeScript
- **TailwindCSS** for styling
- **react-force-graph-3d** for knowledge graph visualization
- **TanStack Query** for data fetching
- **Zustand** for state management
- **WebSocket** for real-time updates

### Backend
- **FastAPI** (Python) - High-performance async API
- **PostgreSQL** - Primary database
- **Redis** - Caching, pub/sub for real-time
- **Celery** - Background task processing
- **Elasticsearch** - Full-text search

### Infrastructure
- **Docker** - Containerization
- **Kubernetes** - Orchestration (production)
- **NGINX** - Reverse proxy, load balancing
- **Let's Encrypt** - SSL certificates

## Security Model

- **Multi-tenant** - Firm-level data isolation
- **Role-based access control (RBAC)** - Granular permissions
- **MFA** - Required for all users
- **Audit logging** - Every action tracked
- **Encryption** - At rest and in transit
- **SOC 2 Type II** - Compliance ready

## Document Index

1. [TRADING_CENTER.md](./TRADING_CENTER.md) - Best execution, broker routing, commission analysis
2. [RESEARCH_HUB.md](./RESEARCH_HUB.md) - Research notes, company analysis, knowledge management
3. [PORTFOLIO_MANAGER.md](./PORTFOLIO_MANAGER.md) - Holdings, risk, attribution, screening
4. [COMPLIANCE_CONSOLE.md](./COMPLIANCE_CONSOLE.md) - Surveillance, reporting, regulatory tools
5. [INDUSTRY_EXPLORER.md](./INDUSTRY_EXPLORER.md) - Supply chain, sector analysis, knowledge graph
6. [COLLABORATION.md](./COLLABORATION.md) - Messaging, sharing, alerts, calendar
7. [FRONTEND_ARCHITECTURE.md](./FRONTEND_ARCHITECTURE.md) - React components, state, routing
8. [BACKEND_API.md](./BACKEND_API.md) - FastAPI endpoints, authentication, WebSocket
9. [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md) - PostgreSQL tables, indexes, migrations
10. [FEATURE_TIERS.md](./FEATURE_TIERS.md) - Basic → Mindblowing feature progression
11. [IMPLEMENTATION_PROMPT.md](./IMPLEMENTATION_PROMPT.md) - Claude Opus implementation prompt
12. [ENTITYSPINE_INTEGRATION.md](./ENTITYSPINE_INTEGRATION.md) - **NEW** Social feed, knowledge graph, company profiles
