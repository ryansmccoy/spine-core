# Capture Spine Vision Document

> The Ultimate Unified Data Feed Capture & Knowledge Management Platform

**Version:** 1.0  
**Last Updated:** January 27, 2026  
**Status:** Living Document

---

## Executive Summary

Capture Spine is a comprehensive platform for capturing, organizing, and sharing content from any data source. Whether you're tracking SEC filings, monitoring news feeds, aggregating research, or building a team knowledge base, Capture Spine provides a unified interface for all your data capture needs.

---

## Table of Contents

1. [Core Philosophy](#1-core-philosophy)
2. [Data Feed Types](#2-data-feed-types)
3. [Content Capture Engine](#3-content-capture-engine)
4. [Knowledge Management](#4-knowledge-management)
5. [Multi-User Collaboration](#5-multi-user-collaboration)
6. [Financial Data Features](#6-financial-data-features)
7. [Alerting & Intelligence](#7-alerting--intelligence)
8. [Integration Ecosystem](#8-integration-ecosystem)
9. [User Experience](#9-user-experience)
10. [Analytics & Insights](#10-analytics--insights)
11. [Security & Privacy](#11-security--privacy)
12. [Platform Architecture](#12-platform-architecture)
13. [Implementation Roadmap](#13-implementation-roadmap)

---

## 1. Core Philosophy

### 1.1 Unified Data Model

Every piece of content, regardless of source, is captured as a **Record** with:
- Consistent metadata structure
- Automatic deduplication
- Full-text search
- Cross-source linking

### 1.2 Source Agnostic

Capture Spine doesn't care where data comes from:
- RSS/Atom feeds
- API endpoints (REST, GraphQL)
- Web scraping
- Email digests
- Webhooks
- Manual entry
- File imports (CSV, JSON, OPML)

### 1.3 User First

- Zero-configuration getting started
- Power features accessible but not overwhelming
- Keyboard-driven for efficiency
- Mobile-friendly for consumption anywhere

### 1.4 Open & Extensible

- Open data formats (export everything)
- Plugin architecture for custom feeds
- API-first design
- Self-hostable option

---

## 2. Data Feed Types

### 2.1 Currently Supported

| Feed Type | Description | Status |
|-----------|-------------|--------|
| **RSS/Atom** | Standard syndication feeds | ✅ Implemented |
| **SEC EDGAR** | US securities filings | ✅ Implemented |
| **Hacker News** | Tech news API | ✅ Implemented |
| **Generic API** | REST API polling | ✅ Implemented |
| **Index Pages** | Web page scraping | ✅ Implemented |

### 2.2 Planned Feed Types

| Feed Type | Description | Use Case |
|-----------|-------------|----------|
| **Email Digest** | Parse incoming emails | Newsletter aggregation |
| **Twitter/X** | Social media monitoring | Brand monitoring, trends |
| **Reddit** | Subreddit monitoring | Community tracking |
| **YouTube** | Channel subscriptions | Video content tracking |
| **Podcast** | Audio feed tracking | Podcast management |
| **ArXiv** | Academic papers | Research monitoring |
| **GitHub** | Repository activity | Open source tracking |
| **Product Hunt** | Product launches | Startup monitoring |
| **Crunchbase** | Company data | Investment research |
| **LinkedIn** | Professional updates | Industry tracking |
| **Google Alerts** | Custom web monitoring | Topic tracking |
| **Slack/Discord** | Channel monitoring | Community insights |
| **Notion/Roam** | Note imports | Knowledge capture |
| **Pocket/Instapaper** | Read later imports | Cross-platform sync |

### 2.3 Custom Feed Development

```yaml
# Example custom feed configuration
name: "My Custom API"
type: api
config:
  base_url: "https://api.example.com/v1/articles"
  auth:
    type: bearer
    token_env: "EXAMPLE_API_TOKEN"
  pagination:
    type: cursor
    param: "cursor"
    response_path: "data.next_cursor"
  items_path: "data.articles"
  mapping:
    natural_key: "id"
    title: "headline"
    url: "link"
    author: "author.name"
    published_at: "published_date"
    content:
      body: "content.html"
      category: "category.name"
```

---

## 3. Content Capture Engine

### 3.1 Intelligent Deduplication

```
┌─────────────────────────────────────────────────────────────┐
│                    Record Deduplication                      │
├─────────────────────────────────────────────────────────────┤
│  1. Natural Key Match (exact)                               │
│     └─ Same source + same ID = same record                  │
│                                                             │
│  2. URL Normalization                                       │
│     └─ Remove tracking params, canonicalize                 │
│                                                             │
│  3. Content Hash (fuzzy)                                    │
│     └─ SimHash for near-duplicate detection                 │
│                                                             │
│  4. Title + Date Match                                      │
│     └─ Same title within 24h = likely duplicate             │
│                                                             │
│  5. Cross-Source Linking                                    │
│     └─ Same story from multiple sources linked              │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Content Extraction

- **Full Article Extraction**: Mercury Parser / Readability
- **Metadata Extraction**: OpenGraph, Twitter Cards, JSON-LD
- **Media Extraction**: Images, videos, embedded content
- **PDF Processing**: Text extraction, page thumbnails
- **Table Extraction**: Structured data from HTML/PDF tables

### 3.3 Content Enhancement

| Enhancement | Description |
|-------------|-------------|
| **Summary Generation** | AI-powered article summarization |
| **Entity Extraction** | Companies, people, places, dates |
| **Sentiment Analysis** | Positive/negative/neutral scoring |
| **Topic Classification** | Auto-categorization |
| **Language Detection** | Multi-language support |
| **Translation** | Auto-translate foreign content |
| **Related Content** | Link similar articles |

### 3.4 Capture Scheduling

```
Polling Strategies:
├── Fixed Interval (every N seconds)
├── Adaptive (faster when active)
├── Schedule (cron expression)
├── Webhook (push-based)
└── Manual (on-demand only)
```

---

## 4. Knowledge Management

### 4.1 Organization Hierarchy

```
Workspace
├── Groups (folders)
│   ├── Feeds
│   │   └── Records
│   └── Smart Groups (filtered views)
├── Collections (manual curation)
│   └── Records
├── Tags (cross-cutting labels)
└── Saved Searches
```

### 4.2 Smart Groups (Dynamic Filters)

```yaml
# Example: "Unread SEC 10-K Filings"
smart_group:
  name: "Unread 10-K Filings"
  rules:
    all:
      - field: record_type
        equals: sec_filing
      - field: content.form_type
        equals: "10-K"
      - field: is_read
        equals: false
  sort: published_at DESC
```

### 4.3 Collections (Manual Curation)

- **Research Projects**: Group articles for a project
- **Reading Lists**: Curated content to read later
- **Share Libraries**: Public collections for team
- **Archive**: Long-term storage with notes

### 4.4 Annotations & Highlights

```
┌─────────────────────────────────────────────────────────────┐
│ Article: "Q3 Earnings Report Analysis"                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Revenue increased by 15% year-over-year, driven primarily   │
│ by ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [📝 +1]              │
│      └── Highlight with comment: "Key growth driver"        │
│                                                             │
│ The company announced a new partnership with...             │
│                                                             │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ 💬 Comments (3)                                        │  │
│ │ @john: "Worth discussing in Monday's meeting"          │  │
│ │ @sarah: "Related to our Q2 analysis"                   │  │
│ │ @mike: "See also: link to related article"             │  │
│ └────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 4.5 Cross-Referencing

- **Automatic**: Link articles mentioning same company/topic
- **Manual**: User creates explicit links between records
- **Bi-directional**: "See also" and "Referenced by"
- **Graph View**: Visual knowledge map

---

## 5. Multi-User Collaboration

### 5.1 User Roles & Permissions

```yaml
roles:
  viewer:
    - Read shared content
    - Personal bookmarks
    
  member:
    - Create personal feeds
    - Share to team
    - Comment & annotate
    
  power_user:
    - Create team feeds
    - Manage alerts
    - API access
    
  admin:
    - User management
    - Team settings
    - Audit logs
    
  owner:
    - Billing & plan
    - Delete team
    - Transfer ownership
```

### 5.2 Sharing Model

```
┌─────────────────────────────────────────────────────────────┐
│                     Sharing Scopes                          │
├─────────────────────────────────────────────────────────────┤
│  Private          Only you can see                          │
│  Team             All team members can see                  │
│  Specific Users   Share with named individuals              │
│  Link Sharing     Anyone with link (optional expiry)        │
│  Public           Listed publicly (opt-in)                  │
└─────────────────────────────────────────────────────────────┘
```

### 5.3 Team Features

| Feature | Description |
|---------|-------------|
| **Shared Feeds** | Team-wide subscriptions |
| **Shared Collections** | Collaborative curation |
| **Team Comments** | Discussion threads |
| **@Mentions** | Notify team members |
| **Activity Feed** | Team activity stream |
| **Assignments** | Assign articles for review |
| **Approval Workflows** | Content review process |

### 5.4 Real-Time Collaboration

- Live presence (who's online)
- Typing indicators in comments
- Real-time updates when content changes
- Collaborative annotations (Google Docs-style)

### 5.5 Messaging System

```
┌─────────────────────────────────────────────────────────────┐
│ Messages                                            [@New]  │
├─────────────────────────────────────────────────────────────┤
│ 📧 Direct Messages                                          │
│    └── 1:1 private conversations                            │
│                                                             │
│ 👥 Group Chats                                              │
│    └── Named groups for project teams                       │
│                                                             │
│ 📎 Article Shares                                           │
│    └── Share articles with notes                            │
│                                                             │
│ 🔔 Notifications                                            │
│    └── System alerts, mentions, replies                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Financial Data Features

### 6.1 SEC EDGAR Integration

| Feature | Description |
|---------|-------------|
| **Form Types** | 10-K, 10-Q, 8-K, 4, 13F, S-1, etc. |
| **Company Tracking** | Follow specific CIKs |
| **Filing Alerts** | Instant notification on new filings |
| **Document Links** | Direct links to HTML, PDF, exhibits |
| **XBRL Parsing** | Structured financial data |
| **Filing Search** | Full-text search across filings |
| **Historical Data** | Access to all past filings |

### 6.2 Company Intelligence

```yaml
company_profile:
  cik: "0000320193"
  name: "Apple Inc."
  tickers: ["AAPL"]
  industry: "Technology"
  
  metrics:
    market_cap: "$2.8T"
    employees: 164,000
    founded: 1976
    
  recent_filings:
    - type: "10-K"
      date: "2025-11-01"
      highlights:
        - "Revenue: $394B (+8% YoY)"
        - "New AI initiatives disclosed"
        
  alerts:
    - "Any new filing"
    - "10-K or 10-Q only"
    - "Insider transactions (Form 4)"
```

### 6.3 Market Data Integration

- **Stock Prices**: Real-time/delayed quotes
- **Charts**: Historical price charts
- **Earnings Calendar**: Upcoming earnings dates
- **Dividend Data**: Dividend history
- **Analyst Ratings**: Consensus estimates

### 6.4 Financial News Aggregation

- SEC EDGAR (official filings)
- Bloomberg
- Reuters
- WSJ
- Financial Times
- Seeking Alpha
- Yahoo Finance
- Company newsrooms

---

## 7. Alerting & Intelligence

### 7.1 Alert Types

| Alert Type | Trigger |
|------------|---------|
| **Keyword** | Content matches keywords |
| **Company** | New content about company |
| **Form Type** | Specific SEC form filed |
| **Author** | New content from author |
| **Feed Error** | Feed stops working |
| **Volume Spike** | Unusual activity |
| **Sentiment Change** | Sentiment shifts |
| **Price Movement** | Stock price change |

### 7.2 Alert Conditions

```yaml
alert:
  name: "Insider Selling Alert"
  conditions:
    all:
      - type: form_type
        value: "4"
      - type: company
        value: ["AAPL", "GOOGL", "MSFT"]
      - type: content_match
        field: transaction_type
        value: "Sale"
      - type: threshold
        field: shares_traded
        operator: ">"
        value: 10000
        
  actions:
    - type: email
      immediate: true
    - type: slack
      channel: "#trading-alerts"
    - type: push_notification
```

### 7.3 Delivery Channels

- **In-App**: Notification center
- **Email**: Individual or digest
- **Push**: Mobile notifications
- **Slack**: Channel or DM
- **Discord**: Webhook
- **Teams**: Connector
- **SMS**: Critical alerts
- **Webhook**: Custom integration

### 7.4 AI-Powered Insights

| Feature | Description |
|---------|-------------|
| **Summary Generation** | TL;DR for long documents |
| **Key Point Extraction** | Bullet point highlights |
| **Change Detection** | What's different from last filing |
| **Risk Identification** | Potential red flags |
| **Topic Clustering** | Group related articles |
| **Trend Detection** | Emerging topics over time |

---

## 8. Integration Ecosystem

### 8.1 Import/Export

| Format | Import | Export |
|--------|--------|--------|
| OPML | ✅ | ✅ |
| CSV | ✅ | ✅ |
| JSON | ✅ | ✅ |
| PDF | - | ✅ |
| Markdown | ✅ | ✅ |
| HTML | - | ✅ |

### 8.2 Third-Party Integrations

```
┌─────────────────────────────────────────────────────────────┐
│                    Integrations                             │
├─────────────────────────────────────────────────────────────┤
│  📊 Productivity                                            │
│     Notion, Obsidian, Roam, Evernote                       │
│                                                             │
│  💬 Communication                                           │
│     Slack, Discord, Teams, Email                           │
│                                                             │
│  📁 Storage                                                 │
│     Dropbox, Google Drive, OneDrive, S3                    │
│                                                             │
│  🔄 Automation                                              │
│     Zapier, Make, n8n, IFTTT                               │
│                                                             │
│  📈 Analytics                                               │
│     Google Analytics, Mixpanel, Amplitude                  │
│                                                             │
│  🔐 Auth                                                    │
│     Google, Microsoft, Okta, Auth0                         │
└─────────────────────────────────────────────────────────────┘
```

### 8.3 API Access

```http
# Example API Usage

# List feeds
GET /api/v1/feeds
Authorization: Bearer csp_live_xxxxx

# Create alert
POST /api/v1/alerts
Content-Type: application/json
{
  "name": "New 10-K Filings",
  "conditions": {
    "form_type": "10-K"
  },
  "actions": {
    "webhook": "https://my-app.com/webhook"
  }
}

# Search records
GET /api/v1/records/search?q=earnings&type=sec_filing&limit=50
```

### 8.4 Webhook Events

```yaml
events:
  - record.created
  - record.updated
  - feed.error
  - feed.recovered
  - alert.triggered
  - user.signup
  - user.login
  - comment.created
  - share.created
```

---

## 9. User Experience

### 9.1 Views

| View | Description |
|------|-------------|
| **List View** | Compact article list |
| **Card View** | Visual cards with images |
| **Table View** | Spreadsheet-like with columns |
| **Magazine View** | Newspaper-style layout |
| **Reader View** | Distraction-free reading |
| **Split View** | List + preview panel |
| **Graph View** | Knowledge relationship map |

### 9.2 Keyboard Shortcuts

```
Navigation
j/k         Next/Previous item
o/Enter     Open item
v           Toggle preview
g then h    Go to Home
g then s    Go to Starred
g then u    Go to Unread

Actions
s           Star/Unstar
m           Mark read/unread
b           Add to collection
e           Edit/Annotate
/           Search
?           Show shortcuts
```

### 9.3 Mobile Experience

- **Native Apps**: iOS & Android (React Native)
- **PWA**: Installable web app
- **Offline**: Read cached articles offline
- **Sync**: Real-time sync across devices
- **Widgets**: Home screen widgets
- **Share Extension**: Save from other apps

### 9.4 Accessibility

- Full keyboard navigation
- Screen reader support
- High contrast mode
- Adjustable font sizes
- Reduced motion option
- Color blind friendly

---

## 10. Analytics & Insights

### 10.1 Personal Analytics

| Metric | Description |
|--------|-------------|
| Articles Read | Daily/weekly/monthly count |
| Reading Time | Time spent reading |
| Top Sources | Most read feeds |
| Reading Patterns | When you read most |
| Completion Rate | % of articles finished |
| Topics | What you read about |

### 10.2 Team Analytics

| Metric | Description |
|--------|-------------|
| Team Activity | Who's reading what |
| Popular Articles | Most viewed by team |
| Coverage | Topics team follows |
| Knowledge Gaps | Underserved areas |
| Collaboration | Sharing patterns |

### 10.3 Content Analytics

| Metric | Description |
|--------|-------------|
| Feed Health | Error rates, update frequency |
| Content Volume | Articles per feed |
| Duplicates | Cross-source duplicates |
| Trending | Hot topics over time |
| Sentiment | Overall sentiment trends |

### 10.4 Admin Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│ Admin Dashboard                                             │
├─────────────────────────────────────────────────────────────┤
│  📊 System Health                                           │
│     CPU: 23%  Memory: 45%  Disk: 67%  Queue: 142           │
│                                                             │
│  👥 Users                                                   │
│     Total: 1,234  Active: 892  New (7d): 45                │
│                                                             │
│  📰 Content                                                 │
│     Feeds: 5,678  Records: 2.3M  Today: 12,456             │
│                                                             │
│  🔔 Alerts                                                  │
│     Active: 3,456  Triggered (24h): 892  Errors: 3         │
│                                                             │
│  🔐 Security                                                │
│     Failed Logins (24h): 12  Locked Accounts: 2            │
└─────────────────────────────────────────────────────────────┘
```

---

## 11. Security & Privacy

### 11.1 Security Features

- [x] Password hashing (bcrypt/Argon2)
- [x] Multi-factor authentication
- [x] Session management
- [x] Account lockout
- [x] Security audit logs
- [x] API key management
- [x] Rate limiting
- [x] HTTPS everywhere
- [ ] SOC 2 compliance
- [ ] GDPR compliance

### 11.2 Data Privacy

| Data Type | Retention | Deletion |
|-----------|-----------|----------|
| User data | Until account deleted | 30-day grace |
| Content | Configurable | On request |
| Logs | 90 days | Automatic |
| Backups | 30 days | Encrypted |

### 11.3 Self-Hosting

For privacy-conscious users:
- Docker deployment
- Kubernetes helm chart
- SQLite option for single-user
- Air-gapped installation

See: [SECURITY_MANIFESTO.md](./SECURITY_MANIFESTO.md)

---

## 12. Platform Architecture

### 12.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Clients                              │
│   Web App (React)  │  Mobile (React Native)  │  CLI         │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│                     API Gateway                             │
│            (Authentication, Rate Limiting, CORS)            │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│                    Core Services                            │
├─────────────────────────────────────────────────────────────┤
│  Auth Service   │  Feed Service   │  Record Service         │
│  User Service   │  Alert Service  │  Search Service         │
│  Team Service   │  Message Service│  Integration Service    │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│                   Background Workers                        │
├─────────────────────────────────────────────────────────────┤
│  Feed Poller    │  Alert Processor │  Content Enhancer      │
│  Email Sender   │  Webhook Sender  │  Cleanup Worker        │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│                      Data Layer                             │
├─────────────────────────────────────────────────────────────┤
│  PostgreSQL (primary)  │  Redis (cache/queue)  │  S3 (media)│
│  Elasticsearch (search)│  ClickHouse (analytics)            │
└─────────────────────────────────────────────────────────────┘
```

### 12.2 Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 19, TypeScript, Tailwind CSS, TanStack Query |
| Mobile | React Native |
| API | FastAPI (Python) or Node.js |
| Database | PostgreSQL 15+ |
| Cache | Redis |
| Search | PostgreSQL FTS or Elasticsearch |
| Queue | Redis + Bull or Celery |
| Storage | S3-compatible (MinIO for self-host) |

### 12.3 Scalability

```
Single User → Small Team → Large Team → Enterprise
    │            │             │            │
    ▼            ▼             ▼            ▼
  SQLite    PostgreSQL    PostgreSQL    Distributed
   +           +            + Redis       PostgreSQL
  Local       Redis        + Workers     + Kafka
                           + CDN         + K8s
```

---

## 13. Implementation Roadmap

### Phase 1: Foundation (Current)
- [x] Core feed capture (RSS, SEC EDGAR, API)
- [x] Basic user authentication
- [x] Read/star/filter functionality
- [x] Feed groups and organization
- [x] Basic alerts
- [ ] Full-text search

### Phase 2: Collaboration
- [ ] Multi-user teams
- [ ] Sharing and permissions
- [ ] Comments and annotations
- [ ] Internal messaging
- [ ] Real-time updates

### Phase 3: Intelligence
- [ ] AI summarization
- [ ] Entity extraction
- [ ] Sentiment analysis
- [ ] Trend detection
- [ ] Related content

### Phase 4: Scale
- [ ] Advanced API
- [ ] Webhooks
- [ ] Third-party integrations
- [ ] Mobile apps
- [ ] Enterprise features

### Phase 5: Platform
- [ ] Plugin marketplace
- [ ] Custom feed types
- [ ] White-label option
- [ ] Self-hosted enterprise

---

## Appendix A: Database Tables

See: [schema_complete.sql](../backend/db/schema_complete.sql)

| Section | Tables |
|---------|--------|
| Core | feeds, records, sightings, feed_groups, feed_checkpoints |
| Users | users, sessions, user_mfa, mfa_backup_codes, trusted_devices |
| Permissions | roles, user_roles, permission_grants |
| Teams | teams, team_members, team_invitations |
| Content | user_read_state, starred_records, collections, collection_items, read_later |
| Alerts | alerts, alert_triggers, notifications, notification_preferences |
| Messaging | message_threads, messages, message_read_state, article_shares, comments, annotations |
| API | api_keys, webhooks, webhook_deliveries, integrations |
| Audit | security_audit, activity_log, api_logs |
| System | settings, system_health |
| Search | saved_searches, search_history, trending |

---

## Appendix B: Glossary

| Term | Definition |
|------|------------|
| **Feed** | A data source that produces records |
| **Record** | A single piece of captured content |
| **Sighting** | An observation of a record in a feed |
| **Natural Key** | Unique identifier from source (not UUID) |
| **Collection** | User-curated group of records |
| **Smart Group** | Dynamic group based on filter rules |
| **Alert** | Rule that triggers notifications |

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-27 | Initial vision document |

---

*Capture Spine: Capture Everything. Miss Nothing.*
