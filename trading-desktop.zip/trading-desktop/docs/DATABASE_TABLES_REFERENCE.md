# Capture Spine Database Tables Reference

> Quick reference for all database tables with permissions

**Version:** 1.0  
**Last Updated:** January 27, 2026

---

## Table Summary

| # | Table | Section | Owner Column | RLS | Description |
|---|-------|---------|--------------|-----|-------------|
| 1 | feeds | Core | `user_id` | ✅ | Data source definitions |
| 2 | feed_checkpoints | Core | - | - | Poll resume positions |
| 3 | records | Core | - | - | Captured content |
| 4 | sightings | Core | - | - | Record observation tracking |
| 5 | feed_groups | Core | `user_id` | ✅ | Feed organization folders |
| 6 | users | Auth | - | - | User accounts |
| 7 | sessions | Auth | `user_id` | - | Authentication sessions |
| 8 | user_mfa | Auth | `user_id` | - | MFA configurations |
| 9 | mfa_backup_codes | Auth | `user_id` | - | Recovery codes |
| 10 | trusted_devices | Auth | `user_id` | - | MFA-trusted devices |
| 11 | password_resets | Auth | `user_id` | - | Reset tokens |
| 12 | email_verifications | Auth | `user_id` | - | Email verification |
| 13 | roles | Permissions | - | - | Role definitions |
| 14 | user_roles | Permissions | `user_id` | - | Custom role assignments |
| 15 | permission_grants | Permissions | `grantor_user_id` | - | Resource sharing |
| 16 | teams | Teams | `owner_user_id` | - | Team/org definitions |
| 17 | team_members | Teams | - | - | Team membership |
| 18 | team_invitations | Teams | - | - | Pending invitations |
| 19 | user_read_state | Content | `user_id` | ✅ | Read tracking |
| 20 | starred_records | Content | `user_id` | ✅ | Bookmarks |
| 21 | collections | Content | `user_id` | ✅ | User collections |
| 22 | collection_items | Content | - | - | Collection contents |
| 23 | user_settings | Content | `user_id` | ✅ | Per-user settings |
| 24 | read_later | Content | `user_id` | - | Read later queue |
| 25 | alerts | Alerts | `user_id` | ✅ | Alert rules |
| 26 | alert_triggers | Alerts | - | - | Trigger history |
| 27 | notifications | Alerts | `user_id` | - | User notifications |
| 28 | notification_preferences | Alerts | `user_id` | - | Delivery preferences |
| 29 | message_threads | Messaging | - | - | Conversation threads |
| 30 | messages | Messaging | `sender_id` | - | Individual messages |
| 31 | message_read_state | Messaging | `user_id` | - | Message read tracking |
| 32 | article_shares | Messaging | `from_user_id` | - | Shared articles |
| 33 | comments | Messaging | `user_id` | - | Article comments |
| 34 | annotations | Messaging | `user_id` | - | Text highlights |
| 35 | api_keys | API | `user_id` | ✅ | API key management |
| 36 | webhooks | API | `user_id` | - | Outgoing webhooks |
| 37 | webhook_deliveries | API | - | - | Delivery logs |
| 38 | integrations | API | `user_id` | - | Third-party integrations |
| 39 | security_audit | Audit | - | - | Security events |
| 40 | activity_log | Audit | - | - | User activity |
| 41 | api_logs | Audit | - | - | API request logs |
| 42 | settings | System | - | - | System settings |
| 43 | system_health | System | - | - | Health metrics |
| 44 | saved_searches | Search | `user_id` | - | Saved queries |
| 45 | search_history | Search | `user_id` | - | Search history |
| 46 | trending | Search | - | - | Trending calculations |

---

## Table Access Matrix by Role

### Core Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| feeds (own) | read | read | CRUD | CRUD | CRUD |
| feeds (shared) | read | read | read | CRUD | CRUD |
| feeds (system) | read | read | read | CRUD | CRUD |
| records | read | read | read | read+delete | CRUD |
| feed_groups | read | read | CRUD | CRUD | CRUD |

### User Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| users (self) | read | read+update | read+update | read+update | CRUD |
| users (others) | - | - | - | read+update | CRUD |
| sessions (own) | - | read+delete | read+delete | read+delete | CRUD |
| user_mfa (own) | - | CRUD | CRUD | CRUD | CRUD |

### Content Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| user_read_state | - | CRUD | CRUD | CRUD | CRUD |
| starred_records | - | CRUD | CRUD | CRUD | CRUD |
| collections (own) | - | CRUD | CRUD | CRUD | CRUD |
| read_later | - | CRUD | CRUD | CRUD | CRUD |

### Collaboration Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| alerts (own) | - | CRUD | CRUD | CRUD | CRUD |
| notifications (own) | read | read+update | read+update | read+update | CRUD |
| messages | - | create+read | create+read | create+read | CRUD |
| comments | - | CRUD | CRUD | CRUD | CRUD |
| article_shares | - | create+read | create+read | create+read | CRUD |

### API Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| api_keys (own) | - | - | CRUD | CRUD | CRUD |
| webhooks (own) | - | - | CRUD | CRUD | CRUD |
| integrations (own) | - | - | CRUD | CRUD | CRUD |

### Admin Tables

| Table | viewer | user | power_user | admin | super_admin |
|-------|--------|------|------------|-------|-------------|
| settings | - | - | - | read+update | CRUD |
| security_audit | - | - | - | read | CRUD |
| activity_log | - | - | - | read | CRUD |
| roles | - | - | - | read | CRUD |

---

## Entity Relationship Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CAPTURE SPINE DATA MODEL                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────┐     owns      ┌─────────────┐     contains    ┌─────────────┐
│    users    │──────────────▶│    feeds    │◀───────────────│ feed_groups │
└─────────────┘               └─────────────┘                 └─────────────┘
       │                             │                               │
       │ has                         │ captures                      │ owned by
       ▼                             ▼                               │
┌─────────────┐               ┌─────────────┐                        │
│  sessions   │               │   records   │◀───────────────────────┘
│  user_mfa   │               └─────────────┘
│  api_keys   │                      │
└─────────────┘                      │ tracked in
       │                             ▼
       │ participates         ┌─────────────┐
       ▼                      │  sightings  │
┌─────────────┐               └─────────────┘
│   teams     │                      │
│ team_members│                      │ user state
└─────────────┘                      ▼
       │                      ┌─────────────────────────┐
       │ shares               │  user_read_state        │
       ▼                      │  starred_records        │
┌─────────────────┐           │  collections            │
│permission_grants│           │  read_later             │
└─────────────────┘           │  comments               │
                              │  annotations            │
                              └─────────────────────────┘
                                     │
                                     │ triggers
                                     ▼
                              ┌─────────────────────────┐
                              │  alerts                 │
                              │  alert_triggers         │
                              │  notifications          │
                              └─────────────────────────┘
```

---

## Key Foreign Key Relationships

### User References
- `feeds.user_id` → `users.user_id`
- `feed_groups.user_id` → `users.user_id`
- `sessions.user_id` → `users.user_id`
- `alerts.user_id` → `users.user_id`
- `collections.user_id` → `users.user_id`
- `api_keys.user_id` → `users.user_id`
- `messages.sender_id` → `users.user_id`

### Record References
- `sightings.record_id` → `records.record_id`
- `user_read_state.record_id` → `records.record_id`
- `starred_records.record_id` → `records.record_id`
- `collection_items.record_id` → `records.record_id`
- `comments.record_id` → `records.record_id`
- `article_shares.record_id` → `records.record_id`

### Feed References
- `sightings.feed_id` → `feeds.feed_id`
- `feed_checkpoints.feed_id` → `feeds.feed_id`
- `feeds.group_id` → `feed_groups.group_id`

### Team References
- `team_members.team_id` → `teams.team_id`
- `team_invitations.team_id` → `teams.team_id`
- `alerts.team_id` → `teams.team_id`

---

## Indexes for Performance

### Critical Indexes

| Table | Index | Purpose |
|-------|-------|---------|
| users | `idx_users_email` | Login lookup |
| sessions | `idx_sessions_token` | Token validation |
| records | `idx_records_published` | Timeline queries |
| records | `idx_records_search` | Full-text search |
| notifications | `idx_notifications_unread` | Unread badge |
| permission_grants | `idx_permission_grants_resource` | Access check |

### Composite Indexes

| Table | Columns | Purpose |
|-------|---------|---------|
| records | `(region, record_type, natural_key)` | Deduplication |
| sightings | `(record_id, feed_id)` | Unique sighting |
| user_read_state | `(user_id, record_id)` | Read state lookup |
| permission_grants | `(resource_type, resource_id, grantee_id)` | Permission check |

---

## Data Retention Policies

| Table | Retention | Cleanup Strategy |
|-------|-----------|------------------|
| sessions | 30 days after expiry | Automatic purge |
| password_resets | 7 days | Automatic purge |
| email_verifications | 7 days | Automatic purge |
| security_audit | 2 years | Archive then purge |
| activity_log | 90 days | Automatic purge |
| api_logs | 30 days | Automatic purge |
| webhook_deliveries | 30 days | Automatic purge |
| search_history | 90 days | Automatic purge |
| notifications | 90 days | Automatic purge |
| records | Configurable | User setting |

---

## Quick SQL Snippets

### Check User Permission
```sql
SELECT EXISTS(
    SELECT 1 FROM permission_grants
    WHERE resource_type = 'feed'
      AND resource_id = $1
      AND grantee_type = 'user'
      AND grantee_id = $2
      AND revoked_at IS NULL
      AND (expires_at IS NULL OR expires_at > NOW())
);
```

### Get User's Accessible Feeds
```sql
SELECT f.* FROM feeds f
WHERE f.user_id = $1  -- Owned
   OR f.is_shared = true  -- System shared
   OR EXISTS (  -- Explicitly shared
       SELECT 1 FROM permission_grants pg
       WHERE pg.resource_type = 'feed'
         AND pg.resource_id = f.feed_id
         AND pg.grantee_id = $1
         AND pg.revoked_at IS NULL
   )
ORDER BY f.name;
```

### Get Unread Count per Feed
```sql
SELECT 
    f.feed_id,
    f.name,
    COUNT(CASE WHEN urs.read_at IS NULL THEN 1 END) as unread_count
FROM feeds f
JOIN sightings s ON s.feed_id = f.feed_id
JOIN records r ON r.record_id = s.record_id
LEFT JOIN user_read_state urs ON urs.record_id = r.record_id AND urs.user_id = $1
WHERE f.user_id = $1 OR f.is_shared = true
GROUP BY f.feed_id, f.name;
```

---

## Document References

- [SECURITY_MANIFESTO.md](./SECURITY_MANIFESTO.md) - Security best practices
- [PERMISSIONS_MODEL.md](./PERMISSIONS_MODEL.md) - RBAC implementation details
- [CAPTURE_SPINE_VISION.md](./CAPTURE_SPINE_VISION.md) - Full feature vision
- [schema_complete.sql](../backend/db/schema_complete.sql) - Full SQL schema
