import { useState, useRef, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { useLayout } from '../../layouts/AdminLayout'
import {
  Menu,
  Search,
  Bell,
  Sun,
  Moon,
  User,
  Settings,
  LogOut,
  ChevronDown,
  X,
  Clock,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  HelpCircle,
} from 'lucide-react'
import { clsx } from 'clsx'

// Sample notifications
const sampleNotifications = [
  {
    id: '1',
    title: 'Order Filled',
    message: 'Buy 100 AAPL @ $189.50 filled',
    time: '2 min ago',
    read: false,
    type: 'order',
  },
  {
    id: '2',
    title: 'Price Alert',
    message: 'NVDA crossed above $900',
    time: '15 min ago',
    read: false,
    type: 'alert',
  },
  {
    id: '3',
    title: 'Market Open',
    message: 'NYSE markets are now open',
    time: '9:30 AM',
    read: true,
    type: 'system',
  },
]

// Page titles
const pageTitles: Record<string, { title: string; description: string }> = {
  '/dashboard': { title: 'Dashboard', description: 'Overview of your portfolio and market activity' },
  '/portfolio': { title: 'Portfolio', description: 'Manage your holdings and track performance' },
  '/positions': { title: 'Positions', description: 'View and manage your current positions' },
  '/orders': { title: 'Orders', description: 'Track order status and execution' },
  '/trading': { title: 'Trading', description: 'Execute trades and manage orders' },
  '/market': { title: 'Market Data', description: 'Real-time market data and quotes' },
  '/research': { title: 'Research', description: 'Company research and analysis' },
  '/companies': { title: 'Companies', description: 'Browse and analyze companies' },
  '/news': { title: 'News', description: 'Latest market news and updates' },
  '/analytics': { title: 'Analytics', description: 'Performance and risk analytics' },
  '/alerts': { title: 'Alerts', description: 'Configure price and event alerts' },
  '/admin': { title: 'Admin', description: 'System administration' },
  '/profile': { title: 'Profile', description: 'Your account settings' },
  '/settings': { title: 'Settings', description: 'Application preferences' },
}

// Mock market indices
const marketIndices = [
  { name: 'S&P 500', value: '5,234.18', change: '+1.24%', positive: true },
  { name: 'NASDAQ', value: '16,832.45', change: '+1.67%', positive: true },
  { name: 'DOW', value: '38,654.32', change: '-0.12%', positive: false },
]

export function Header() {
  const location = useLocation()
  const { setSidebarOpen, darkMode, setDarkMode } = useLayout()
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [notifications, setNotifications] = useState(sampleNotifications)

  const searchRef = useRef<HTMLInputElement>(null)
  const notificationsRef = useRef<HTMLDivElement>(null)
  const userMenuRef = useRef<HTMLDivElement>(null)

  const unreadCount = notifications.filter((n) => !n.read).length
  const pageInfo = pageTitles[location.pathname] || { title: 'Page', description: '' }

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false)
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Focus search on open
  useEffect(() => {
    if (searchOpen && searchRef.current) {
      searchRef.current.focus()
    }
  }, [searchOpen])

  const markAllRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const currentTime = new Date().toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: true 
  })

  return (
    <header className="sticky top-0 z-30 bg-white dark:bg-[#1E1E2D] border-b border-gray-200 dark:border-[#2D2D43]">
      <div className="flex h-[70px] items-center justify-between px-4 lg:px-8">
        {/* Left side */}
        <div className="flex items-center gap-4">
          {/* Mobile menu button */}
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43] lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Page Title */}
          <div className="hidden sm:block">
            <h1 className="text-lg font-semibold text-gray-900 dark:text-white">{pageInfo.title}</h1>
            <p className="text-xs text-gray-500 dark:text-[#565674]">{pageInfo.description}</p>
          </div>
        </div>

        {/* Center - Market Indices Ticker */}
        <div className="hidden lg:flex items-center gap-6 px-6">
          {marketIndices.map((index) => (
            <div key={index.name} className="flex items-center gap-2">
              <span className="text-xs text-gray-500 dark:text-[#565674]">{index.name}</span>
              <span className="text-sm font-medium text-gray-900 dark:text-white">{index.value}</span>
              <span className={clsx(
                'flex items-center text-xs font-medium',
                index.positive ? 'text-success' : 'text-danger'
              )}>
                {index.positive ? <TrendingUp className="h-3 w-3 mr-0.5" /> : <TrendingDown className="h-3 w-3 mr-0.5" />}
                {index.change}
              </span>
            </div>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Time */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-[#1B1B29]">
            <Clock className="h-4 w-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{currentTime}</span>
          </div>

          {/* Search */}
          <div className="relative hidden md:block">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search symbols..."
                className="h-10 w-[180px] lg:w-[220px] rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 text-sm text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-primary-500 dark:border-[#2D2D43] dark:bg-[#1B1B29] dark:text-white dark:placeholder-[#565674] dark:focus:border-primary-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Mobile Search Toggle */}
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43] md:hidden"
          >
            <Search className="h-5 w-5" />
          </button>

          {/* Refresh */}
          <button className="flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43]">
            <RefreshCw className="h-5 w-5" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43]"
          >
            {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>

          {/* Help */}
          <button className="hidden sm:flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43]">
            <HelpCircle className="h-5 w-5" />
          </button>

          {/* Notifications */}
          <div className="relative" ref={notificationsRef}>
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="relative flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-[#2D2D43]"
            >
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-danger text-[10px] font-bold text-white">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 rounded-xl bg-white dark:bg-[#1E1E2D] shadow-lg border border-gray-200 dark:border-[#2D2D43] animate-fade-in">
                <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-4 py-3">
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Notifications</h3>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-xs font-medium text-primary-600 hover:text-primary-700"
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={clsx(
                        'flex gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-[#1B1B29] cursor-pointer transition-colors',
                        !notification.read && 'bg-primary-50/50 dark:bg-primary-900/10'
                      )}
                    >
                      <div className={clsx(
                        'flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full',
                        notification.type === 'order' && 'bg-success/20 text-success',
                        notification.type === 'alert' && 'bg-warning/20 text-warning',
                        notification.type === 'system' && 'bg-primary-100 dark:bg-primary-900/30 text-primary-600'
                      )}>
                        {notification.type === 'order' && <TrendingUp className="h-4 w-4" />}
                        {notification.type === 'alert' && <Bell className="h-4 w-4" />}
                        {notification.type === 'system' && <Settings className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{notification.title}</p>
                        <p className="text-xs text-gray-500 dark:text-[#565674] truncate">{notification.message}</p>
                        <p className="mt-1 text-[10px] text-gray-400">{notification.time}</p>
                      </div>
                      {!notification.read && (
                        <div className="flex h-2 w-2 flex-shrink-0 rounded-full bg-primary-500 mt-2" />
                      )}
                    </div>
                  ))}
                </div>
                <div className="border-t border-gray-100 dark:border-[#2D2D43] p-2">
                  <button className="w-full rounded-lg px-4 py-2 text-sm font-medium text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors">
                    View all notifications
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Menu */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-gray-100 dark:hover:bg-[#2D2D43] transition-colors"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-primary-600 text-white text-sm font-bold">
                JD
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-sm font-medium text-gray-900 dark:text-white">John Doe</p>
                <p className="text-[11px] text-gray-500 dark:text-[#565674]">Portfolio Manager</p>
              </div>
              <ChevronDown className="hidden lg:block h-4 w-4 text-gray-400" />
            </button>

            {/* User Dropdown */}
            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-[#1E1E2D] shadow-lg border border-gray-200 dark:border-[#2D2D43] animate-fade-in">
                <div className="border-b border-gray-100 dark:border-[#2D2D43] px-4 py-3">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">John Doe</p>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">john.doe@firm.com</p>
                </div>
                <div className="p-2">
                  <a href="/profile" className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#1B1B29]">
                    <User className="h-4 w-4" />
                    My Profile
                  </a>
                  <a href="/settings" className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#1B1B29]">
                    <Settings className="h-4 w-4" />
                    Settings
                  </a>
                </div>
                <div className="border-t border-gray-100 dark:border-[#2D2D43] p-2">
                  <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-danger hover:bg-danger/10">
                    <LogOut className="h-4 w-4" />
                    Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Search Bar */}
      {searchOpen && (
        <div className="border-t border-gray-200 dark:border-[#2D2D43] px-4 py-3 md:hidden">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              ref={searchRef}
              type="text"
              placeholder="Search symbols..."
              className="h-10 w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-10 text-sm text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-primary-500 dark:border-[#2D2D43] dark:bg-[#1B1B29] dark:text-white dark:placeholder-[#565674] dark:focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button
              onClick={() => {
                setSearchQuery('')
                setSearchOpen(false)
              }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  )
}
