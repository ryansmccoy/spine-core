import { NavLink } from 'react-router-dom'
import { useLayout } from '../../layouts/AdminLayout'
import {
  LayoutDashboard,
  Briefcase,
  FileText,
  ChevronLeft,
  X,
  Activity,
  TrendingUp,
  ShoppingCart,
  PieChart,
  BarChart3,
  Settings,
  User,
  ShieldCheck,
  Bell,
  Search,
  Building2,
  Newspaper,
  LineChart,
  Layers,
  AlertTriangle,
  Target,
  GitCompare,
} from 'lucide-react'
import { clsx } from 'clsx'

const portfolioNav = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Portfolio', href: '/portfolio', icon: Briefcase, badge: 'Live' },
  { name: 'Holdings', href: '/holdings', icon: Layers },
  { name: 'Positions', href: '/positions', icon: PieChart },
]

const tradingNav = [
  { name: 'Orders', href: '/orders', icon: ShoppingCart },
  { name: 'Trading', href: '/trading', icon: TrendingUp, badge: 'Pro' },
]

const analyticsNav = [
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  { name: 'Risk', href: '/risk', icon: AlertTriangle },
  { name: 'Attribution', href: '/attribution', icon: GitCompare },
  { name: 'Optimization', href: '/optimization', icon: Target },
]

const researchNav = [
  { name: 'Market Data', href: '/market-data', icon: LineChart },
  { name: 'Research', href: '/research', icon: FileText },
  { name: 'Companies', href: '/companies', icon: Building2 },
  { name: 'News', href: '/news', icon: Newspaper },
  { name: 'Alerts', href: '/alerts', icon: Bell },
]

const systemNav = [
  { name: 'Admin', href: '/admin', icon: ShieldCheck },
  { name: 'Profile', href: '/profile', icon: User },
  { name: 'Settings', href: '/settings', icon: Settings },
]

// Helper component to render navigation sections
const NavSection = ({
  title,
  items,
  sidebarCollapsed,
  isMobile,
  setSidebarOpen,
}: {
  title: string
  items: typeof portfolioNav
  sidebarCollapsed: boolean
  isMobile: boolean
  setSidebarOpen: (open: boolean) => void
}) => (
  <>
    {(!sidebarCollapsed || isMobile) && (
      <div className="mb-2 px-3 mt-4 first:mt-0">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[#565674]">
          {title}
        </span>
      </div>
    )}
    {items.map((item) => (
      <NavLink
        key={item.name}
        to={item.href}
        onClick={() => isMobile && setSidebarOpen(false)}
        className={({ isActive }) =>
          clsx(
            'group flex items-center rounded-lg px-3 py-2 text-[13px] font-medium transition-all duration-200',
            isActive
              ? 'bg-[#1B1B29] text-white'
              : 'text-[#9D9DA6] hover:bg-[#1B1B29] hover:text-white',
            sidebarCollapsed && !isMobile && 'justify-center px-2'
          )
        }
      >
        {({ isActive }) => (
          <>
            <item.icon
              className={clsx(
                'h-[18px] w-[18px] flex-shrink-0 transition-colors',
                !sidebarCollapsed && !isMobile && 'mr-3',
                isActive ? 'text-primary-500' : 'text-[#565674] group-hover:text-primary-400'
              )}
            />
            {(!sidebarCollapsed || isMobile) && (
              <>
                <span className="flex-1">{item.name}</span>
                {'badge' in item && item.badge && (
                  <span className="ml-2 rounded bg-primary-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-primary-400">
                    {item.badge}
                  </span>
                )}
              </>
            )}
          </>
        )}
      </NavLink>
    ))}
  </>
)

export function Sidebar() {
  const { sidebarOpen, setSidebarOpen, sidebarCollapsed, setSidebarCollapsed } = useLayout()

  const SidebarContent = ({ isMobile = false }: { isMobile?: boolean }) => (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex h-[70px] items-center justify-between px-5 border-b border-[#2D2D43]">
        {(!sidebarCollapsed || isMobile) && (
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-primary-600">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-[15px] font-semibold text-white">MarketSpine</h1>
              <span className="text-[11px] font-medium text-[#565674]">Trading Desktop</span>
            </div>
          </div>
        )}
        {sidebarCollapsed && !isMobile && (
          <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-primary-600">
            <TrendingUp className="h-5 w-5 text-white" />
          </div>
        )}
        {isMobile ? (
          <button
            onClick={() => setSidebarOpen(false)}
            className="rounded-lg p-1.5 text-[#565674] hover:bg-[#2D2D43] hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        ) : (
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className={clsx(
              'hidden lg:flex rounded-lg p-1.5 text-[#565674] hover:bg-[#2D2D43] hover:text-white transition-colors',
              sidebarCollapsed && 'mx-auto mt-2'
            )}
          >
            <ChevronLeft
              className={clsx(
                'h-4 w-4 transition-transform',
                sidebarCollapsed && 'rotate-180'
              )}
            />
          </button>
        )}
      </div>

      {/* Search (when not collapsed) */}
      {(!sidebarCollapsed || isMobile) && (
        <div className="px-4 py-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#565674]" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full rounded-lg bg-[#1B1B29] border border-[#2D2D43] py-2 pl-10 pr-4 text-sm text-white placeholder-[#565674] focus:border-primary-500 focus:outline-none"
            />
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-4 py-2 overflow-y-auto">
        <NavSection
          title="Portfolio"
          items={portfolioNav}
          sidebarCollapsed={sidebarCollapsed}
          isMobile={isMobile}
          setSidebarOpen={setSidebarOpen}
        />
        
        <NavSection
          title="Trading"
          items={tradingNav}
          sidebarCollapsed={sidebarCollapsed}
          isMobile={isMobile}
          setSidebarOpen={setSidebarOpen}
        />
        
        <NavSection
          title="Analytics"
          items={analyticsNav}
          sidebarCollapsed={sidebarCollapsed}
          isMobile={isMobile}
          setSidebarOpen={setSidebarOpen}
        />
        
        <NavSection
          title="Research"
          items={researchNav}
          sidebarCollapsed={sidebarCollapsed}
          isMobile={isMobile}
          setSidebarOpen={setSidebarOpen}
        />

        <div className="my-4 border-t border-[#2D2D43]" />

        <NavSection
          title="System"
          items={systemNav}
          sidebarCollapsed={sidebarCollapsed}
          isMobile={isMobile}
          setSidebarOpen={setSidebarOpen}
        />
      </nav>

      {/* Market Status Card */}
      {(!sidebarCollapsed || isMobile) && (
        <div className="border-t border-[#2D2D43] p-4">
          <div className="rounded-lg bg-gradient-to-br from-[#1B1B29] to-[#2D2D43] p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-success/20">
                <Activity className="h-4 w-4 text-success" />
              </div>
              <div>
                <p className="text-xs font-medium text-white">Market Status</p>
                <p className="text-[10px] text-[#565674]">NYSE Open</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#565674]">S&P 500</span>
                <span className="text-success">+1.24%</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#565674]">NASDAQ</span>
                <span className="text-success">+1.67%</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#565674]">DOW</span>
                <span className="text-danger">-0.12%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={clsx(
          'hidden lg:flex flex-col bg-[#1E1E2D] transition-all duration-300',
          sidebarCollapsed ? 'w-[70px]' : 'w-[280px]'
        )}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      <aside
        className={clsx(
          'fixed inset-y-0 left-0 z-50 flex w-[280px] flex-col bg-[#1E1E2D] transition-transform duration-300 lg:hidden',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <SidebarContent isMobile />
      </aside>
    </>
  )
}
