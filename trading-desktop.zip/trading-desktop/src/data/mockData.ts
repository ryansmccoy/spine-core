// Mock trading data for the trading desktop application

// Portfolio Holdings
export interface Position {
  id: string
  symbol: string
  name: string
  shares: number
  avgCost: number
  currentPrice: number
  marketValue: number
  unrealizedPnL: number
  unrealizedPnLPercent: number
  dayChange: number
  dayChangePercent: number
  weight: number
  sector: string
}

export const mockPositions: Position[] = [
  { id: '1', symbol: 'AAPL', name: 'Apple Inc.', shares: 500, avgCost: 175.50, currentPrice: 189.84, marketValue: 94920, unrealizedPnL: 7170, unrealizedPnLPercent: 8.17, dayChange: 2.34, dayChangePercent: 1.25, weight: 18.5, sector: 'Technology' },
  { id: '2', symbol: 'MSFT', name: 'Microsoft Corp.', shares: 300, avgCost: 380.25, currentPrice: 415.50, marketValue: 124650, unrealizedPnL: 10575, unrealizedPnLPercent: 9.27, dayChange: 5.67, dayChangePercent: 1.38, weight: 24.3, sector: 'Technology' },
  { id: '3', symbol: 'NVDA', name: 'NVIDIA Corp.', shares: 100, avgCost: 750.00, currentPrice: 903.25, marketValue: 90325, unrealizedPnL: 15325, unrealizedPnLPercent: 20.43, dayChange: 15.50, dayChangePercent: 1.74, weight: 17.6, sector: 'Technology' },
  { id: '4', symbol: 'GOOGL', name: 'Alphabet Inc.', shares: 200, avgCost: 140.75, currentPrice: 152.30, marketValue: 30460, unrealizedPnL: 2310, unrealizedPnLPercent: 8.20, dayChange: -1.20, dayChangePercent: -0.78, weight: 5.9, sector: 'Communication' },
  { id: '5', symbol: 'AMZN', name: 'Amazon.com Inc.', shares: 150, avgCost: 165.00, currentPrice: 185.75, marketValue: 27862.50, unrealizedPnL: 3112.50, unrealizedPnLPercent: 12.58, dayChange: 3.45, dayChangePercent: 1.89, weight: 5.4, sector: 'Consumer Discretionary' },
  { id: '6', symbol: 'META', name: 'Meta Platforms', shares: 100, avgCost: 450.00, currentPrice: 505.25, marketValue: 50525, unrealizedPnL: 5525, unrealizedPnLPercent: 12.28, dayChange: 8.30, dayChangePercent: 1.67, weight: 9.8, sector: 'Communication' },
  { id: '7', symbol: 'JPM', name: 'JPMorgan Chase', shares: 200, avgCost: 175.50, currentPrice: 198.45, marketValue: 39690, unrealizedPnL: 4590, unrealizedPnLPercent: 13.08, dayChange: -0.85, dayChangePercent: -0.43, weight: 7.7, sector: 'Financials' },
  { id: '8', symbol: 'JNJ', name: 'Johnson & Johnson', shares: 150, avgCost: 155.25, currentPrice: 158.90, marketValue: 23835, unrealizedPnL: 547.50, unrealizedPnLPercent: 2.35, dayChange: 0.45, dayChangePercent: 0.28, weight: 4.6, sector: 'Healthcare' },
  { id: '9', symbol: 'V', name: 'Visa Inc.', shares: 100, avgCost: 265.00, currentPrice: 285.50, marketValue: 28550, unrealizedPnL: 2050, unrealizedPnLPercent: 7.74, dayChange: 1.25, dayChangePercent: 0.44, weight: 5.6, sector: 'Financials' },
  { id: '10', symbol: 'UNH', name: 'UnitedHealth Group', shares: 25, avgCost: 510.00, currentPrice: 485.75, marketValue: 12143.75, unrealizedPnL: -606.25, unrealizedPnLPercent: -4.76, dayChange: -3.50, dayChangePercent: -0.72, weight: 2.4, sector: 'Healthcare' },
]

// Orders
export interface Order {
  id: string
  symbol: string
  side: 'buy' | 'sell'
  orderType: 'market' | 'limit' | 'stop' | 'stop_limit'
  quantity: number
  filledQuantity: number
  price: number | null
  avgFillPrice: number | null
  status: 'pending' | 'working' | 'filled' | 'partial' | 'cancelled' | 'rejected'
  account: string
  timestamp: string
  broker: string
}

export const mockOrders: Order[] = [
  { id: 'ORD001', symbol: 'AAPL', side: 'buy', orderType: 'limit', quantity: 100, filledQuantity: 100, price: 188.50, avgFillPrice: 188.45, status: 'filled', account: 'Growth Fund', timestamp: '2024-01-28T14:32:15', broker: 'Goldman Sachs' },
  { id: 'ORD002', symbol: 'TSLA', side: 'buy', orderType: 'market', quantity: 50, filledQuantity: 50, price: null, avgFillPrice: 185.75, status: 'filled', account: 'Growth Fund', timestamp: '2024-01-28T14:28:00', broker: 'JP Morgan' },
  { id: 'ORD003', symbol: 'NVDA', side: 'sell', orderType: 'limit', quantity: 25, filledQuantity: 15, price: 910.00, avgFillPrice: 908.50, status: 'partial', account: 'Tech Fund', timestamp: '2024-01-28T14:25:30', broker: 'Morgan Stanley' },
  { id: 'ORD004', symbol: 'MSFT', side: 'buy', orderType: 'limit', quantity: 75, filledQuantity: 0, price: 410.00, avgFillPrice: null, status: 'working', account: 'Value Fund', timestamp: '2024-01-28T14:20:00', broker: 'Goldman Sachs' },
  { id: 'ORD005', symbol: 'AMZN', side: 'buy', orderType: 'stop_limit', quantity: 100, filledQuantity: 0, price: 190.00, avgFillPrice: null, status: 'pending', account: 'Growth Fund', timestamp: '2024-01-28T14:15:00', broker: 'Citadel' },
  { id: 'ORD006', symbol: 'META', side: 'sell', orderType: 'market', quantity: 30, filledQuantity: 30, price: null, avgFillPrice: 504.85, status: 'filled', account: 'Tech Fund', timestamp: '2024-01-28T13:55:00', broker: 'JP Morgan' },
  { id: 'ORD007', symbol: 'GOOGL', side: 'buy', orderType: 'limit', quantity: 200, filledQuantity: 0, price: 150.00, avgFillPrice: null, status: 'cancelled', account: 'Growth Fund', timestamp: '2024-01-28T13:45:00', broker: 'Morgan Stanley' },
  { id: 'ORD008', symbol: 'JPM', side: 'sell', orderType: 'limit', quantity: 50, filledQuantity: 0, price: 202.00, avgFillPrice: null, status: 'working', account: 'Value Fund', timestamp: '2024-01-28T13:30:00', broker: 'Goldman Sachs' },
]

// Watchlist
export interface WatchlistItem {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume: string
  marketCap: string
}

export const mockWatchlist: WatchlistItem[] = [
  { symbol: 'AAPL', name: 'Apple Inc.', price: 189.84, change: 2.34, changePercent: 1.25, volume: '52.3M', marketCap: '2.95T' },
  { symbol: 'MSFT', name: 'Microsoft', price: 415.50, change: 5.67, changePercent: 1.38, volume: '18.7M', marketCap: '3.09T' },
  { symbol: 'NVDA', name: 'NVIDIA', price: 903.25, change: 15.50, changePercent: 1.74, volume: '38.2M', marketCap: '2.23T' },
  { symbol: 'GOOGL', name: 'Alphabet', price: 152.30, change: -1.20, changePercent: -0.78, volume: '24.1M', marketCap: '1.89T' },
  { symbol: 'AMZN', name: 'Amazon', price: 185.75, change: 3.45, changePercent: 1.89, volume: '45.6M', marketCap: '1.93T' },
  { symbol: 'TSLA', name: 'Tesla', price: 185.10, change: -4.25, changePercent: -2.24, volume: '89.4M', marketCap: '589B' },
  { symbol: 'META', name: 'Meta', price: 505.25, change: 8.30, changePercent: 1.67, volume: '12.8M', marketCap: '1.29T' },
  { symbol: 'BRK.B', name: 'Berkshire', price: 405.80, change: 1.15, changePercent: 0.28, volume: '3.2M', marketCap: '876B' },
]

// Portfolio Summary
export interface PortfolioSummary {
  totalValue: number
  dayChange: number
  dayChangePercent: number
  totalGain: number
  totalGainPercent: number
  cashBalance: number
  buyingPower: number
}

export const mockPortfolioSummary: PortfolioSummary = {
  totalValue: 512961.25,
  dayChange: 6845.75,
  dayChangePercent: 1.35,
  totalGain: 47599.75,
  totalGainPercent: 10.23,
  cashBalance: 87250.00,
  buyingPower: 174500.00,
}

// Sector Allocation
export interface SectorAllocation {
  sector: string
  value: number
  weight: number
  change: number
}

export const mockSectorAllocation: SectorAllocation[] = [
  { sector: 'Technology', value: 310895, weight: 60.6, change: 1.52 },
  { sector: 'Communication', value: 80985, weight: 15.8, change: 0.89 },
  { sector: 'Financials', value: 68240, weight: 13.3, change: -0.15 },
  { sector: 'Healthcare', value: 35978.75, weight: 7.0, change: -0.22 },
  { sector: 'Consumer Discretionary', value: 27862.50, weight: 5.4, change: 1.89 },
]

// Recent Trades
export interface Trade {
  id: string
  timestamp: string
  symbol: string
  side: 'buy' | 'sell'
  quantity: number
  price: number
  total: number
  broker: string
}

export const mockRecentTrades: Trade[] = [
  { id: 'T001', timestamp: '2024-01-28T14:32:15', symbol: 'AAPL', side: 'buy', quantity: 100, price: 188.45, total: 18845, broker: 'Goldman Sachs' },
  { id: 'T002', timestamp: '2024-01-28T14:28:00', symbol: 'TSLA', side: 'buy', quantity: 50, price: 185.75, total: 9287.50, broker: 'JP Morgan' },
  { id: 'T003', timestamp: '2024-01-28T14:25:30', symbol: 'NVDA', side: 'sell', quantity: 15, price: 908.50, total: 13627.50, broker: 'Morgan Stanley' },
  { id: 'T004', timestamp: '2024-01-28T13:55:00', symbol: 'META', side: 'sell', quantity: 30, price: 504.85, total: 15145.50, broker: 'JP Morgan' },
  { id: 'T005', timestamp: '2024-01-28T11:30:00', symbol: 'MSFT', side: 'buy', quantity: 25, price: 412.30, total: 10307.50, broker: 'Goldman Sachs' },
]

// News Items
export interface NewsItem {
  id: string
  title: string
  source: string
  timestamp: string
  symbols: string[]
  sentiment: 'positive' | 'negative' | 'neutral'
  summary: string
}

export const mockNews: NewsItem[] = [
  { id: 'N001', title: 'Apple Reports Record Q1 Revenue, iPhone Sales Beat Expectations', source: 'Bloomberg', timestamp: '2024-01-28T14:30:00', symbols: ['AAPL'], sentiment: 'positive', summary: 'Apple Inc. reported quarterly revenue of $119.6 billion, beating analyst estimates...' },
  { id: 'N002', title: 'NVIDIA Announces New AI Chip Architecture at GTC Conference', source: 'Reuters', timestamp: '2024-01-28T13:45:00', symbols: ['NVDA'], sentiment: 'positive', summary: 'NVIDIA unveiled its next-generation Blackwell architecture, promising 5x performance...' },
  { id: 'N003', title: 'Fed Signals Potential Rate Cuts in Q2 Amid Cooling Inflation', source: 'WSJ', timestamp: '2024-01-28T12:15:00', symbols: [], sentiment: 'positive', summary: 'Federal Reserve officials indicated openness to cutting interest rates as early as Q2...' },
  { id: 'N004', title: 'Tesla Misses Delivery Targets, Cites Supply Chain Issues', source: 'CNBC', timestamp: '2024-01-28T11:00:00', symbols: ['TSLA'], sentiment: 'negative', summary: 'Tesla delivered 435,000 vehicles in Q4, below the 470,000 expected by analysts...' },
  { id: 'N005', title: 'Microsoft Azure Revenue Grows 29% YoY, Cloud Demand Surges', source: 'Financial Times', timestamp: '2024-01-28T09:30:00', symbols: ['MSFT'], sentiment: 'positive', summary: 'Microsoft reported strong cloud growth driven by AI workloads and enterprise adoption...' },
]

// Performance metrics
export interface PerformanceMetric {
  period: string
  return: number
  benchmark: number
  alpha: number
}

export const mockPerformance: PerformanceMetric[] = [
  { period: '1D', return: 1.35, benchmark: 1.24, alpha: 0.11 },
  { period: '1W', return: 3.24, benchmark: 2.87, alpha: 0.37 },
  { period: '1M', return: 5.67, benchmark: 4.92, alpha: 0.75 },
  { period: '3M', return: 12.45, benchmark: 10.23, alpha: 2.22 },
  { period: 'YTD', return: 8.92, benchmark: 7.15, alpha: 1.77 },
  { period: '1Y', return: 24.56, benchmark: 21.34, alpha: 3.22 },
]

// Broker analytics
export interface BrokerMetric {
  broker: string
  fills: number
  avgFillRate: number
  avgSlippage: number
  commission: number
  volume: number
}

export const mockBrokerMetrics: BrokerMetric[] = [
  { broker: 'Goldman Sachs', fills: 145, avgFillRate: 98.5, avgSlippage: 0.02, commission: 4250, volume: 2450000 },
  { broker: 'JP Morgan', fills: 128, avgFillRate: 97.8, avgSlippage: 0.03, commission: 3850, volume: 1980000 },
  { broker: 'Morgan Stanley', fills: 98, avgFillRate: 99.1, avgSlippage: 0.01, commission: 2950, volume: 1560000 },
  { broker: 'Citadel', fills: 75, avgFillRate: 99.5, avgSlippage: 0.01, commission: 2100, volume: 1250000 },
]

// Re-exports with common aliases used by pages
export const positions = mockPositions.map(p => ({
  ...p,
  unrealizedPL: p.unrealizedPnL,
  unrealizedPLPercent: p.unrealizedPnLPercent,
}))
export const orders = mockOrders
export const watchlistItems = mockWatchlist
export const portfolioSummary = {
  ...mockPortfolioSummary,
  totalGainLoss: mockPortfolioSummary.totalGain,
  totalGainLossPercent: mockPortfolioSummary.totalGainPercent,
  dayGainLoss: mockPortfolioSummary.dayChange,
  dayGainLossPercent: mockPortfolioSummary.dayChangePercent,
}
export const sectorAllocation = mockSectorAllocation.map(s => ({
  sector: s.sector,
  percentage: s.weight,
  value: s.value,
  color: s.sector === 'Technology' ? '#3B82F6' :
         s.sector === 'Communication' ? '#8B5CF6' :
         s.sector === 'Financials' ? '#10B981' :
         s.sector === 'Healthcare' ? '#F59E0B' :
         '#EC4899'
}))
export const newsItems = mockNews.map(n => ({
  id: n.id,
  title: n.title,
  source: n.source,
  time: new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  tickers: n.symbols,
  sentiment: n.sentiment,
  summary: n.summary,
  category: n.symbols.length > 0 ? 'Earnings' : 'Market',
}))
export const performanceMetrics = mockPerformance.map(p => ({
  label: p.period + ' Return',
  value: p.return.toFixed(2) + '%',
  change: (p.alpha >= 0 ? '+' : '') + p.alpha.toFixed(2) + '%',
  trend: p.alpha >= 0 ? 'up' : 'down' as const,
}))
export const brokerMetrics = mockBrokerMetrics.map(b => ({
  label: b.broker,
  value: b.avgFillRate.toFixed(1) + '%',
  trend: b.avgFillRate >= 98 ? 'up' : 'neutral' as const,
}))
