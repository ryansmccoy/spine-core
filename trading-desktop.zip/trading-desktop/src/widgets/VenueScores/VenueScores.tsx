/**
 * VenueScores Widget
 * 
 * Shows venue quality scores for order routing
 */

import { useAppStore } from '../../store';
import { useVenues } from '../../api';

function formatPercent(n: number): string {
  return (n * 100).toFixed(1) + '%';
}

function getScoreColor(score: number): string {
  if (score >= 0.8) return 'var(--accent-green)';
  if (score >= 0.6) return 'var(--accent-yellow)';
  return 'var(--accent-red)';
}

export function VenueScores() {
  const { activeSymbol } = useAppStore();
  const { data: venues, isLoading, error } = useVenues(activeSymbol || undefined);
  
  // Get latest scores per venue
  const latestVenues = venues
    ?.reduce((acc, v) => {
      if (!acc[v.venue] || new Date(v.event_time) > new Date(acc[v.venue].event_time)) {
        acc[v.venue] = v;
      }
      return acc;
    }, {} as Record<string, typeof venues[0]>);
  
  const venueList = Object.values(latestVenues || {}).sort((a, b) => b.score - a.score);
  
  return (
    <div className="widget-panel">
      <div className="widget-header">
        Venue Quality {activeSymbol && `— ${activeSymbol}`}
      </div>
      <div className="widget-body">
        {!activeSymbol && (
          <div style={{ color: 'var(--text-muted)' }}>Select a symbol</div>
        )}
        
        {isLoading && <div className="spinner" />}
        
        {error && (
          <div style={{ color: 'var(--accent-red)' }}>Error loading venues</div>
        )}
        
        {venueList && venueList.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Venue</th>
                <th style={{ textAlign: 'right' }}>Fill Rate</th>
                <th style={{ textAlign: 'right' }}>Slippage</th>
                <th style={{ textAlign: 'right' }}>Latency</th>
                <th style={{ textAlign: 'right' }}>Score</th>
              </tr>
            </thead>
            <tbody>
              {venueList.map((v) => (
                <tr key={v.venue}>
                  <td style={{ fontWeight: 600 }}>{v.venue}</td>
                  <td style={{ textAlign: 'right', fontFamily: 'monospace' }}>
                    {formatPercent(v.fill_rate)}
                  </td>
                  <td
                    style={{ textAlign: 'right', fontFamily: 'monospace' }}
                    className={v.slippage > 1 ? 'price-down' : v.slippage < 0 ? 'price-up' : ''}
                  >
                    {v.slippage.toFixed(2)} bps
                  </td>
                  <td style={{ textAlign: 'right', fontFamily: 'monospace' }}>
                    {v.latency.toFixed(1)} ms
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <span
                      style={{
                        display: 'inline-block',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        backgroundColor: getScoreColor(v.score),
                        color: '#000',
                        fontWeight: 600,
                        fontSize: '11px',
                      }}
                    >
                      {(v.score * 100).toFixed(0)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        
        {activeSymbol && !isLoading && venueList?.length === 0 && (
          <div style={{ color: 'var(--text-muted)' }}>No venue data available</div>
        )}
      </div>
    </div>
  );
}

export default VenueScores;
