/**
 * PriceChart Widget
 * 
 * Displays candlestick chart using Lightweight Charts
 */

import { useEffect, useRef } from 'react';
import { createChart, CandlestickSeries } from 'lightweight-charts';
import type { IChartApi, CandlestickData, Time } from 'lightweight-charts';
import { useAppStore } from '../../store';
import { usePrices } from '../../api';

export function PriceChart() {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const { activeSymbol } = useAppStore();
  
  const { data: prices, isLoading, error } = usePrices(activeSymbol || undefined, 90);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    // Create chart
    const chart = createChart(containerRef.current, {
      layout: {
        background: { color: '#12121a' },
        textColor: '#a1a1aa',
      },
      grid: {
        vertLines: { color: '#2a2a3a' },
        horzLines: { color: '#2a2a3a' },
      },
      crosshair: {
        mode: 0,
      },
      rightPriceScale: {
        borderColor: '#2a2a3a',
      },
      timeScale: {
        borderColor: '#2a2a3a',
        timeVisible: true,
      },
    });
    
    chartRef.current = chart;
    
    // Handle resize
    const handleResize = () => {
      if (containerRef.current) {
        chart.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        });
      }
    };
    
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);
    
    return () => {
      resizeObserver.disconnect();
      chart.remove();
    };
  }, []);
  
  useEffect(() => {
    if (!chartRef.current || !prices || prices.length === 0) return;
    
    // Clear existing series
    chartRef.current.timeScale().fitContent();
    
    // Format data for Lightweight Charts
    const candleData: CandlestickData<Time>[] = prices.map((p) => ({
      time: p.time.split('T')[0] as Time,
      open: p.open,
      high: p.high,
      low: p.low,
      close: p.close,
    }));
    
    // Remove old series and add new one (v5 API)
    const series = chartRef.current.addSeries(CandlestickSeries, {
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    });
    
    series.setData(candleData);
    chartRef.current.timeScale().fitContent();
    
    return () => {
      if (chartRef.current) {
        chartRef.current.removeSeries(series);
      }
    };
  }, [prices]);
  
  return (
    <div className="widget-panel">
      <div className="widget-header">
        Chart {activeSymbol && `— ${activeSymbol}`}
      </div>
      <div className="widget-body" style={{ padding: 0, position: 'relative' }}>
        {isLoading && (
          <div style={{ 
            position: 'absolute', 
            inset: 0, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            background: 'rgba(10, 10, 15, 0.8)',
            zIndex: 10,
          }}>
            <div className="spinner" />
          </div>
        )}
        {error && (
          <div style={{ 
            padding: '20px', 
            color: 'var(--accent-red)',
            textAlign: 'center',
          }}>
            Error loading chart data
          </div>
        )}
        {!activeSymbol && (
          <div style={{ 
            padding: '20px', 
            color: 'var(--text-muted)',
            textAlign: 'center',
          }}>
            Select a symbol to view chart
          </div>
        )}
        <div 
          ref={containerRef} 
          style={{ 
            width: '100%', 
            height: '100%',
            minHeight: '300px',
          }} 
        />
      </div>
    </div>
  );
}

export default PriceChart;
