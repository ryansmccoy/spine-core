/**
 * TickerInput Widget
 * 
 * Controls the active symbol for context linking
 */

import { useState, useCallback } from 'react';
import type { KeyboardEvent } from 'react';
import { useAppStore } from '../../store';
import { useSymbols } from '../../api';

export function TickerInput() {
  const { activeSymbol, setActiveSymbol } = useAppStore();
  const [inputValue, setInputValue] = useState(activeSymbol || '');
  const [showDropdown, setShowDropdown] = useState(false);
  
  const { data: symbols } = useSymbols();
  
  const filteredSymbols = symbols?.filter((s) =>
    s.symbol.toLowerCase().includes(inputValue.toLowerCase()) ||
    s.name.toLowerCase().includes(inputValue.toLowerCase())
  ).slice(0, 8);
  
  const handleSubmit = useCallback(() => {
    if (inputValue.trim()) {
      setActiveSymbol(inputValue.trim());
      setShowDropdown(false);
    }
  }, [inputValue, setActiveSymbol]);
  
  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
    if (e.key === 'Escape') {
      setShowDropdown(false);
    }
  };
  
  const handleSelect = (symbol: string) => {
    setInputValue(symbol);
    setActiveSymbol(symbol);
    setShowDropdown(false);
  };
  
  return (
    <div className="widget-panel">
      <div className="widget-header">Symbol Search</div>
      <div className="widget-body">
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', gap: '8px' }}>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => {
                setInputValue(e.target.value.toUpperCase());
                setShowDropdown(true);
              }}
              onKeyDown={handleKeyDown}
              onFocus={() => setShowDropdown(true)}
              placeholder="Enter symbol..."
              style={{ flex: 1, fontWeight: 600, fontSize: '16px' }}
            />
            <button onClick={handleSubmit}>Go</button>
          </div>
          
          {showDropdown && filteredSymbols && filteredSymbols.length > 0 && (
            <div
              style={{
                position: 'absolute',
                top: '100%',
                left: 0,
                right: 0,
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-color)',
                borderRadius: '4px',
                marginTop: '4px',
                maxHeight: '200px',
                overflow: 'auto',
                zIndex: 100,
              }}
            >
              {filteredSymbols.map((s) => (
                <div
                  key={s.symbol}
                  onClick={() => handleSelect(s.symbol)}
                  style={{
                    padding: '8px 12px',
                    cursor: 'pointer',
                    borderBottom: '1px solid var(--border-color)',
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'var(--bg-secondary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  <span style={{ fontWeight: 600 }}>{s.symbol}</span>
                  <span style={{ color: 'var(--text-muted)', fontSize: '12px' }}>
                    {s.name}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {activeSymbol && (
          <div style={{ marginTop: '16px', color: 'var(--text-muted)' }}>
            Active: <span style={{ color: 'var(--accent-blue)', fontWeight: 600 }}>{activeSymbol}</span>
          </div>
        )}
      </div>
    </div>
  );
}

export default TickerInput;
