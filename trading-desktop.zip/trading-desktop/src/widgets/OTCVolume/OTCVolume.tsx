/**
 * OTC Volume Widget
 * 
 * Shows weekly OTC transparency data
 */

import { useAppStore } from '../../store';
import { useOTCData, useOTCTopVolume } from '../../api';

function formatNumber(n: number): string {
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1) + 'B';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K';
  return n.toString();
}

function formatPercent(n: number | null): string {
  if (n === null || n === undefined) return '—';
  const sign = n >= 0 ? '+' : '';
  return sign + (n * 100).toFixed(1) + '%';
}

export function OTCVolume() {
  const { activeSymbol, setActiveSymbol } = useAppStore();
  
  const { data: symbolData, isLoading: loadingSymbol } = useOTCData(
    activeSymbol || undefined,
    8
  );
  
  const { data: topVolume, isLoading: loadingTop } = useOTCTopVolume(10);
  
  return (
    <div className="widget-panel">
      <div className="widget-header">
        OTC Weekly Volume {activeSymbol && `— ${activeSymbol}`}
      </div>
      <div className="widget-body">
        {/* Symbol History */}
        {activeSymbol && (
          <div style={{ marginBottom: '20px' }}>
            <h4 style={{ margin: '0 0 8px', fontSize: '12px', color: 'var(--text-muted)' }}>
              Weekly History
            </h4>
            {loadingSymbol ? (
              <div className="spinner" />
            ) : symbolData && symbolData.length > 0 ? (
              <table>
                <thead>
                  <tr>
                    <th>Week</th>
                    <th style={{ textAlign: 'right' }}>Shares</th>
                    <th style={{ textAlign: 'right' }}>WoW</th>
                    <th style={{ textAlign: 'right' }}>Rank</th>
                  </tr>
                </thead>
                <tbody>
                  {symbolData.map((row) => (
                    <tr key={row.week_start_date}>
                      <td>{row.week_start_date.split('T')[0]}</td>
                      <td style={{ textAlign: 'right', fontFamily: 'monospace' }}>
                        {formatNumber(row.shares)}
                      </td>
                      <td
                        style={{ textAlign: 'right', fontFamily: 'monospace' }}
                        className={
                          row.pct_change_wow > 0
                            ? 'price-up'
                            : row.pct_change_wow < 0
                            ? 'price-down'
                            : ''
                        }
                      >
                        {formatPercent(row.pct_change_wow)}
                      </td>
                      <td style={{ textAlign: 'right' }}>#{row.volume_rank}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div style={{ color: 'var(--text-muted)' }}>No OTC data available</div>
            )}
          </div>
        )}
        
        {/* Top Volume */}
        <div>
          <h4 style={{ margin: '0 0 8px', fontSize: '12px', color: 'var(--text-muted)' }}>
            Top OTC Volume (Latest Week)
          </h4>
          {loadingTop ? (
            <div className="spinner" />
          ) : topVolume && topVolume.length > 0 ? (
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Symbol</th>
                  <th style={{ textAlign: 'right' }}>Shares</th>
                  <th style={{ textAlign: 'right' }}>WoW</th>
                </tr>
              </thead>
              <tbody>
                {topVolume.map((row) => (
                  <tr
                    key={row.symbol}
                    onClick={() => setActiveSymbol(row.symbol)}
                    style={{ cursor: 'pointer' }}
                  >
                    <td>{row.volume_rank}</td>
                    <td style={{ fontWeight: row.symbol === activeSymbol ? 700 : 400 }}>
                      {row.symbol}
                    </td>
                    <td style={{ textAlign: 'right', fontFamily: 'monospace' }}>
                      {formatNumber(row.shares)}
                    </td>
                    <td
                      style={{ textAlign: 'right', fontFamily: 'monospace' }}
                      className={
                        row.pct_change_wow > 0
                          ? 'price-up'
                          : row.pct_change_wow < 0
                          ? 'price-down'
                          : ''
                      }
                    >
                      {formatPercent(row.pct_change_wow)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div style={{ color: 'var(--text-muted)' }}>No data available</div>
          )}
        </div>
      </div>
    </div>
  );
}

export default OTCVolume;
