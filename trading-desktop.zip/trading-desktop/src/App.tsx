/**
 * MarketSpine Application Root
 * Bloomberg-style institutional investment management platform
 */

import { Routes, Route, Navigate } from 'react-router-dom'
import AdminLayout from './layouts/AdminLayout'
import { ProtectedRoute, PublicRoute } from './components/auth/ProtectedRoute'

// Auth Pages
import LoginPage from './pages/auth/LoginPage'

// Main Pages
import DashboardPage from './pages/DashboardPage'
import PortfolioPage from './pages/PortfolioPage'
import PositionsPage from './pages/PositionsPage'
import OrdersPage from './pages/OrdersPage'
import TradingPage from './pages/TradingPage'
import MarketDataPage from './pages/MarketDataPage'
import ResearchPage from './pages/ResearchPage'
import CompaniesPage from './pages/CompaniesPage'
import NewsPage from './pages/NewsPage'
import AnalyticsPage from './pages/AnalyticsPage'
import AlertsPage from './pages/AlertsPage'
import AdminPage from './pages/AdminPage'
import ProfilePage from './pages/ProfilePage'
import SettingsPage from './pages/SettingsPage'

// New MarketSpine Pages
import HoldingsPage from './pages/HoldingsPage'
import RiskPage from './pages/RiskPage'
import AttributionPage from './pages/AttributionPage'
import OptimizationPage from './pages/OptimizationPage'

export default function App() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route
        path="/login"
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        }
      />

      {/* Protected Admin Layout Routes */}
      <Route
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<DashboardPage />} />
        
        {/* Portfolio Management */}
        <Route path="portfolio" element={<PortfolioPage />} />
        <Route path="holdings" element={<HoldingsPage />} />
        <Route path="positions" element={<PositionsPage />} />
        
        {/* Trading */}
        <Route path="orders" element={<OrdersPage />} />
        <Route path="trading" element={<TradingPage />} />
        
        {/* Analytics */}
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="attribution" element={<AttributionPage />} />
        <Route path="optimization" element={<OptimizationPage />} />
        
        {/* Risk */}
        <Route path="risk" element={<RiskPage />} />
        
        {/* Research */}
        <Route path="market-data" element={<MarketDataPage />} />
        <Route path="research" element={<ResearchPage />} />
        <Route path="companies" element={<CompaniesPage />} />
        <Route path="news" element={<NewsPage />} />
        
        {/* System */}
        <Route path="alerts" element={<AlertsPage />} />
        <Route
          path="admin"
          element={
            <ProtectedRoute roles={['admin']}>
              <AdminPage />
            </ProtectedRoute>
          }
        />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>

      {/* Catch all - redirect to dashboard or login */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
