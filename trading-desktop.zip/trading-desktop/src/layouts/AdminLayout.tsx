import { useState, createContext, useContext, useEffect } from 'react'
import { Outlet } from 'react-router-dom'
import { Sidebar } from '../components/layout/Sidebar'
import { Header } from '../components/layout/Header'

interface LayoutContextType {
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
  sidebarCollapsed: boolean
  setSidebarCollapsed: (collapsed: boolean) => void
  darkMode: boolean
  setDarkMode: (dark: boolean) => void
}

const LayoutContext = createContext<LayoutContextType | null>(null)

export function useLayout() {
  const context = useContext(LayoutContext)
  if (!context) {
    throw new Error('useLayout must be used within LayoutProvider')
  }
  return context
}

export function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false) // Mobile drawer
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false) // Desktop collapsed
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('tradingDeskDarkMode')
      if (stored !== null) return stored === 'true'
      // Default to dark mode for trading terminal
      return true
    }
    return true
  })

  // Apply dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [darkMode])

  const handleDarkModeChange = (dark: boolean) => {
    setDarkMode(dark)
    localStorage.setItem('tradingDeskDarkMode', String(dark))
  }

  return (
    <LayoutContext.Provider
      value={{
        sidebarOpen,
        setSidebarOpen,
        sidebarCollapsed,
        setSidebarCollapsed,
        darkMode,
        setDarkMode: handleDarkModeChange,
      }}
    >
      <div className="flex h-screen overflow-hidden bg-[#f5f8fa] dark:bg-[#151521]">
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content Area */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Header */}
          <Header />

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto">
            <div className="mx-auto max-w-[1580px] px-4 py-6 lg:px-8">
              <Outlet />
            </div>
          </main>
        </div>

        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </div>
    </LayoutContext.Provider>
  )
}

export default AdminLayout
