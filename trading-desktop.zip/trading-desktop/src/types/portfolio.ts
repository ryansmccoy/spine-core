/**
 * Portfolio and Position Types for MarketSpine
 * Bloomberg PORT-style holdings and position management
 */

// Asset classes
export type AssetClass = 'equity' | 'fixed_income' | 'cash' | 'derivative' | 'alternative' | 'fx';

// Security type
export interface Security {
  id: string;
  symbol: string;
  name: string;
  asset_class: AssetClass;
  sector: string;
  industry: string;
  exchange: string;
  currency: string;
  country: string;
  market_cap?: number;
  pe_ratio?: number;
  pb_ratio?: number;
  dividend_yield?: number;
  beta?: number;
}

// Position from implementation prompt
export interface Position {
  id: string;
  portfolio_id: string;
  account_id: string;
  security_id: string;
  symbol: string;
  name: string;
  asset_class: AssetClass;
  quantity: number;
  avg_cost: number;
  market_price: number;
  market_value: number;
  cost_basis: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  realized_pnl: number;
  day_change: number;
  day_change_pct: number;
  weight: number;
  weight_target?: number;
  drift?: number;
  sector: string;
  industry: string;
  currency: string;
  updated_at: string;
}

// Account entity
export interface Account {
  id: string;
  portfolio_id: string;
  name: string;
  account_number: string;
  custodian: string;
  account_type: 'cash' | 'margin' | 'ira' | 'trust' | 'corporate';
  currency: string;
  created_at: string;
}

// Portfolio entity
export interface Portfolio {
  id: string;
  firm_id: string;
  name: string;
  description?: string;
  benchmark_id?: string;
  benchmark_name?: string;
  currency: string;
  inception_date: string;
  strategy: string;
  manager_id: string;
  manager_name: string;
  accounts: Account[];
  created_at: string;
  updated_at: string;
}

// Portfolio summary with aggregated metrics
export interface PortfolioSummary {
  id: string;
  name: string;
  benchmark_name?: string;
  total_market_value: number;
  cash_balance: number;
  total_cost_basis: number;
  total_unrealized_pnl: number;
  total_unrealized_pnl_pct: number;
  total_realized_pnl: number;
  day_change: number;
  day_change_pct: number;
  mtd_return: number;
  qtd_return: number;
  ytd_return: number;
  inception_return: number;
  positions_count: number;
  sector_exposure: SectorExposure[];
  asset_allocation: AssetAllocation[];
  top_holdings: Position[];
  last_updated: string;
}

// Sector exposure
export interface SectorExposure {
  sector: string;
  weight: number;
  weight_target?: number;
  drift?: number;
  market_value: number;
  unrealized_pnl: number;
  contribution_to_return: number;
}

// Asset allocation
export interface AssetAllocation {
  asset_class: AssetClass;
  weight: number;
  weight_target?: number;
  drift?: number;
  market_value: number;
}

// Portfolio characteristics (F08)
export interface PortfolioCharacteristics {
  portfolio_id: string;
  as_of_date: string;
  // Valuation metrics
  pe_ratio: number;
  pe_ratio_benchmark?: number;
  pb_ratio: number;
  pb_ratio_benchmark?: number;
  ps_ratio: number;
  ps_ratio_benchmark?: number;
  // Growth metrics
  eps_growth_1y: number;
  eps_growth_1y_benchmark?: number;
  eps_growth_5y: number;
  eps_growth_5y_benchmark?: number;
  revenue_growth_1y: number;
  revenue_growth_1y_benchmark?: number;
  // Income metrics
  dividend_yield: number;
  dividend_yield_benchmark?: number;
  payout_ratio: number;
  payout_ratio_benchmark?: number;
  // Risk metrics
  beta: number;
  beta_benchmark?: number;
  volatility_30d: number;
  volatility_30d_benchmark?: number;
  sharpe_ratio: number;
  sharpe_ratio_benchmark?: number;
  // Quality metrics
  roe: number;
  roe_benchmark?: number;
  roa: number;
  roa_benchmark?: number;
  debt_to_equity: number;
  debt_to_equity_benchmark?: number;
  current_ratio: number;
  current_ratio_benchmark?: number;
  // Size metrics
  avg_market_cap: number;
  avg_market_cap_benchmark?: number;
  median_market_cap: number;
  median_market_cap_benchmark?: number;
}

// Holdings request/response
export interface HoldingsRequest {
  portfolio_id: string;
  account_id?: string;
  as_of_date?: string;
  group_by?: 'account' | 'sector' | 'asset_class' | 'country';
}

export interface HoldingsResponse {
  portfolio_id: string;
  as_of_date: string;
  positions: Position[];
  summary: PortfolioSummary;
}

// Intraday holdings changes
export interface IntradayChange {
  position_id: string;
  symbol: string;
  time: string;
  price_change: number;
  price_change_pct: number;
  value_change: number;
  volume: number;
}

// Holdings grouping for hierarchical display
export interface HoldingsGroup {
  key: string;
  label: string;
  level: number;
  market_value: number;
  weight: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  day_change: number;
  day_change_pct: number;
  positions_count: number;
  children?: HoldingsGroup[];
  positions?: Position[];
}

// Contribution to return
export interface ContributionToReturn {
  symbol: string;
  name: string;
  weight_start: number;
  weight_end: number;
  return_contribution: number;
  return_pct: number;
  allocation_effect: number;
  selection_effect: number;
  interaction_effect: number;
}
