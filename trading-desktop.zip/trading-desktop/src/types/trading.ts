/**
 * Trading Types for MarketSpine
 * Order management, execution analysis, basket trading
 */

// Order side
export type OrderSide = 'buy' | 'sell' | 'short' | 'cover';

// Order type
export type OrderType = 'market' | 'limit' | 'stop' | 'stop_limit' | 'trail_stop' | 'vwap' | 'twap';

// Order status
export type OrderStatus = 
  | 'pending'      // Created but not submitted
  | 'submitted'    // Sent to broker
  | 'acknowledged' // Broker acknowledged
  | 'open'         // Active in market
  | 'partial'      // Partially filled
  | 'filled'       // Completely filled
  | 'cancelled'    // User cancelled
  | 'rejected'     // Broker rejected
  | 'expired';     // Time-in-force expired

// Time in force
export type TimeInForce = 'day' | 'gtc' | 'ioc' | 'fok' | 'opg' | 'cls';

// Order from implementation prompt
export interface Order {
  id: string;
  portfolio_id: string;
  account_id: string;
  basket_id?: string;
  symbol: string;
  name: string;
  side: OrderSide;
  quantity: number;
  filled_quantity: number;
  remaining_quantity: number;
  price_type: OrderType;
  limit_price?: number;
  stop_price?: number;
  status: OrderStatus;
  broker_id: string;
  broker_name: string;
  algo?: string;
  algo_params?: Record<string, unknown>;
  avg_fill_price?: number;
  vwap?: number;
  twap?: number;
  time_in_force: TimeInForce;
  trader_id: string;
  trader_name: string;
  created_at: string;
  updated_at: string;
  submitted_at?: string;
  filled_at?: string;
  notes?: string;
}

// Execution/Fill
export interface Execution {
  id: string;
  order_id: string;
  symbol: string;
  side: OrderSide;
  quantity: number;
  price: number;
  notional: number;
  commission: number;
  fees: number;
  venue: string;
  liquidity_flag: 'add' | 'remove' | 'other';
  exec_time: string;
  settlement_date: string;
  trade_id: string;
}

// Order with executions
export interface OrderWithExecutions extends Order {
  executions: Execution[];
  total_commission: number;
  total_fees: number;
  total_notional: number;
  execution_count: number;
}

// Order create request
export interface CreateOrderRequest {
  portfolio_id: string;
  account_id: string;
  symbol: string;
  side: OrderSide;
  quantity: number;
  price_type: OrderType;
  limit_price?: number;
  stop_price?: number;
  broker_id: string;
  algo?: string;
  algo_params?: Record<string, unknown>;
  time_in_force: TimeInForce;
  notes?: string;
}

// Basket entity (F03)
export interface Basket {
  id: string;
  portfolio_id: string;
  name: string;
  description?: string;
  status: 'draft' | 'pending' | 'executing' | 'completed' | 'cancelled';
  created_by: string;
  created_at: string;
  updated_at: string;
  executed_at?: string;
  orders: BasketOrder[];
  summary: BasketSummary;
}

export interface BasketOrder {
  id: string;
  basket_id: string;
  symbol: string;
  name: string;
  side: OrderSide;
  quantity: number;
  price_type: OrderType;
  limit_price?: number;
  weight?: number;
  status: OrderStatus;
  order_id?: string; // Linked order once submitted
}

export interface BasketSummary {
  total_orders: number;
  total_buy_orders: number;
  total_sell_orders: number;
  total_buy_notional: number;
  total_sell_notional: number;
  net_notional: number;
  sectors: BasketSectorBreakdown[];
}

export interface BasketSectorBreakdown {
  sector: string;
  buy_count: number;
  sell_count: number;
  buy_notional: number;
  sell_notional: number;
  net_notional: number;
}

// Broker entity
export interface Broker {
  id: string;
  name: string;
  short_name: string;
  type: 'full_service' | 'electronic' | 'dark_pool';
  status: 'active' | 'inactive';
  commission_rate: number;
  algos_available: string[];
}

// Broker scorecard metrics
export interface BrokerScorecard {
  broker_id: string;
  broker_name: string;
  period: string;
  // Volume metrics
  total_orders: number;
  total_shares: number;
  total_notional: number;
  // Fill metrics
  fill_rate: number;
  avg_fill_time_ms: number;
  partial_fill_rate: number;
  // Price quality
  vwap_performance: number;
  twap_performance: number;
  arrival_price_performance: number;
  implementation_shortfall: number;
  // Cost metrics
  total_commission: number;
  avg_commission_bps: number;
  total_market_impact: number;
  avg_market_impact_bps: number;
  // Quality scores (0-100)
  execution_quality_score: number;
  speed_score: number;
  cost_score: number;
  overall_score: number;
}

// Commission analysis
export interface CommissionSummary {
  period: string;
  total_commission: number;
  total_trades: number;
  avg_commission_per_trade: number;
  avg_commission_bps: number;
  by_broker: CommissionByBroker[];
  by_fund: CommissionByFund[];
  trend: CommissionTrend[];
}

export interface CommissionByBroker {
  broker_id: string;
  broker_name: string;
  commission: number;
  trades: number;
  notional: number;
  avg_bps: number;
  pct_of_total: number;
}

export interface CommissionByFund {
  portfolio_id: string;
  portfolio_name: string;
  commission: number;
  trades: number;
  notional: number;
  avg_bps: number;
}

export interface CommissionTrend {
  date: string;
  commission: number;
  trades: number;
  avg_bps: number;
}

// Execution analysis (F01 - Tradebook)
export interface ExecutionAnalysis {
  order_id: string;
  symbol: string;
  side: OrderSide;
  total_quantity: number;
  total_filled: number;
  avg_price: number;
  // Benchmark comparisons
  arrival_price: number;
  vwap: number;
  twap: number;
  close_price: number;
  // Performance vs benchmarks (bps)
  vs_arrival: number;
  vs_vwap: number;
  vs_twap: number;
  vs_close: number;
  // Implementation shortfall components
  delay_cost: number;
  market_impact: number;
  timing_cost: number;
  opportunity_cost: number;
  total_implementation_shortfall: number;
  // Execution timeline
  timeline: ExecutionTimelinePoint[];
}

export interface ExecutionTimelinePoint {
  time: string;
  cum_quantity: number;
  cum_pct: number;
  price: number;
  vwap_at_time: number;
  market_price: number;
}
