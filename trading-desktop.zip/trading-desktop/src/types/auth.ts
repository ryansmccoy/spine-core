/**
 * Authentication and User Types for MarketSpine
 * Bloomberg-style institutional investment management platform
 */

// User Roles based on implementation prompt
export type UserRole = 
  | 'admin'
  | 'portfolio_manager'
  | 'trader'
  | 'analyst'
  | 'compliance'
  | 'operations'
  | 'viewer';

export type UserStatus = 'active' | 'inactive' | 'suspended' | 'pending';

// Firm entity
export interface Firm {
  id: string;
  name: string;
  created_at: string;
  settings: Record<string, unknown>;
}

// User entity
export interface User {
  id: string;
  firm_id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: UserRole;
  status: UserStatus;
  created_at: string;
  last_login: string | null;
  preferences: UserPreferences;
  firm?: Firm;
}

export interface UserPreferences {
  theme: 'dark' | 'light';
  default_portfolio_id?: string;
  default_benchmark?: string;
  notifications_enabled: boolean;
  keyboard_shortcuts_enabled: boolean;
  grid_density: 'compact' | 'normal' | 'comfortable';
}

// Session entity
export interface Session {
  id: string;
  user_id: string;
  refresh_token: string;
  device_info: DeviceInfo;
  ip_address: string;
  expires_at: string;
  created_at: string;
}

export interface DeviceInfo {
  browser: string;
  os: string;
  device_type: 'desktop' | 'tablet' | 'mobile';
}

// Auth request/response types
export interface LoginRequest {
  email: string;
  password: string;
  remember_me?: boolean;
}

export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: 'bearer';
  expires_in: number;
  user: User;
}

export interface RefreshTokenRequest {
  refresh_token: string;
}

export interface RefreshTokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
}

export interface PasswordResetRequest {
  email: string;
}

export interface PasswordResetConfirmRequest {
  token: string;
  new_password: string;
}

// Permission types
export type Permission = 'create' | 'read' | 'update' | 'delete' | 'approve' | 'cancel' | 'execute' | 'import' | 'export' | 'full_access';

export type Resource = 
  | 'users'
  | 'settings'
  | 'portfolios'
  | 'trades'
  | 'orders'
  | 'executions'
  | 'baskets'
  | 'research'
  | 'models'
  | 'surveillance'
  | 'reports'
  | 'restrictions'
  | 'settlements'
  | 'reconciliation'
  | 'data'
  | 'risk'
  | 'optimization'
  | 'all_modules'
  | 'all_data';

export type RolePermissions = {
  [role in UserRole]: Partial<Record<Resource, Permission[]>>;
};

// Role permission matrix from implementation prompt
export const ROLE_PERMISSIONS: RolePermissions = {
  admin: {
    users: ['create', 'read', 'update', 'delete'],
    settings: ['read', 'update'],
    all_modules: ['full_access']
  },
  portfolio_manager: {
    portfolios: ['create', 'read', 'update'],
    trades: ['create', 'read', 'approve'],
    research: ['read', 'create'],
    risk: ['read'],
    optimization: ['execute']
  },
  trader: {
    orders: ['create', 'read', 'update', 'cancel'],
    executions: ['read'],
    baskets: ['create', 'read', 'update'],
    portfolios: ['read']
  },
  analyst: {
    research: ['create', 'read', 'update'],
    portfolios: ['read'],
    models: ['create', 'read', 'update']
  },
  compliance: {
    surveillance: ['read', 'update'],
    reports: ['create', 'read'],
    restrictions: ['create', 'read', 'update'],
    all_data: ['read']
  },
  operations: {
    settlements: ['read', 'update'],
    reconciliation: ['read', 'update'],
    data: ['import', 'export']
  },
  viewer: {
    portfolios: ['read'],
    research: ['read'],
    reports: ['read']
  }
};

// Helper to check if user has permission
export function hasPermission(
  user: User | null,
  resource: Resource,
  permission: Permission
): boolean {
  if (!user) return false;
  
  const rolePerms = ROLE_PERMISSIONS[user.role];
  
  // Admin with full_access can do anything
  if (rolePerms.all_modules?.includes('full_access')) {
    return true;
  }
  
  // Check all_data permission for compliance
  if (rolePerms.all_data?.includes('read') && permission === 'read') {
    return true;
  }
  
  // Check specific resource permission
  const resourcePerms = rolePerms[resource];
  return resourcePerms?.includes(permission) ?? false;
}

// Activity log entry
export interface ActivityLogEntry {
  id: number;
  user_id: string;
  firm_id: string;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  ip_address: string;
  created_at: string;
}
