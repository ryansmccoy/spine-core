/**
 * MarketSpine Type Exports
 * Bloomberg PORT-style institutional investment management
 */

// Auth & Users
export * from './auth';

// Portfolio & Holdings
export * from './portfolio';

// Trading & Execution
export * from './trading';

// Risk Analytics
export * from './risk';

// Attribution & Optimization
export * from './attribution';

// Common utility types
export interface DateRange {
  start: string;
  end: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

// Formatting helpers
export type NumberFormat = 'currency' | 'percent' | 'number' | 'compact';

export interface FormatOptions {
  decimals?: number;
  showSign?: boolean;
  compact?: boolean;
  currency?: string;
}
