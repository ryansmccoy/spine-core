/**
 * Risk Analytics Types for MarketSpine
 * VaR, scenarios, tracking error, liquidity risk
 */

// Risk metrics from implementation prompt
export interface RiskMetrics {
  portfolio_id: string;
  as_of_date: string;
  // VaR metrics
  var_95_1d: number;
  var_99_1d: number;
  var_95_10d: number;
  var_99_10d: number;
  cvar_95_1d: number;
  cvar_99_1d: number;
  // Tracking error
  tracking_error: number;
  tracking_error_ex_ante: number;
  information_ratio: number;
  // Market risk
  beta: number;
  beta_adjusted: number;
  delta: number;
  gamma: number;
  // Performance metrics
  sharpe_ratio: number;
  sortino_ratio: number;
  treynor_ratio: number;
  calmar_ratio: number;
  // Volatility
  volatility_30d: number;
  volatility_60d: number;
  volatility_90d: number;
  volatility_1y: number;
  // Drawdown
  max_drawdown: number;
  current_drawdown: number;
  drawdown_duration_days: number;
}

// VaR calculation methods (F13)
export type VaRMethod = 'monte_carlo' | 'historical' | 'parametric';

export interface VaRResult {
  portfolio_id: string;
  as_of_date: string;
  method: VaRMethod;
  confidence_level: number;  // 0.95, 0.99
  horizon_days: number;      // 1, 10
  var_amount: number;
  var_pct: number;
  cvar_amount: number;
  cvar_pct: number;
  // VaR contributors by grouping
  contributors_by_sector: VaRContributor[];
  contributors_by_security: VaRContributor[];
  contributors_by_factor: VaRContributor[];
  // For Monte Carlo
  simulation_count?: number;
  distribution?: VaRDistribution;
}

export interface VaRContributor {
  name: string;
  key: string;
  var_contribution: number;
  var_contribution_pct: number;
  marginal_var: number;
  component_var: number;
  weight: number;
}

export interface VaRDistribution {
  percentiles: number[];      // [1, 5, 10, 25, 50, 75, 90, 95, 99]
  values: number[];           // Corresponding P&L values
  histogram: HistogramBin[];
}

export interface HistogramBin {
  bin_start: number;
  bin_end: number;
  count: number;
  frequency: number;
}

// Tracking Error Analysis (F12)
export interface TrackingErrorAnalysis {
  portfolio_id: string;
  benchmark_id: string;
  as_of_date: string;
  // Tracking error metrics
  tracking_error_ex_ante: number;
  tracking_error_realized: number;
  information_ratio: number;
  active_return: number;
  // Risk decomposition
  country_risk: number;
  industry_risk: number;
  style_risk: number;
  specific_risk: number;
  // Contribution breakdown
  factor_contributions: TrackingErrorContributor[];
  sector_contributions: TrackingErrorContributor[];
  top_security_contributors: TrackingErrorContributor[];
}

export interface TrackingErrorContributor {
  name: string;
  key: string;
  active_weight: number;
  contribution_to_te: number;
  contribution_pct: number;
}

// Liquidity Risk (F10)
export interface LiquidityRiskAnalysis {
  portfolio_id: string;
  as_of_date: string;
  // Summary metrics
  total_market_value: number;
  avg_daily_volume: number;
  days_to_liquidate_100pct: number;
  days_to_liquidate_95pct: number;
  // Liquidity buckets
  liquidity_buckets: LiquidityBucket[];
  // Position-level liquidity
  position_liquidity: PositionLiquidity[];
  // Participation rate analysis
  participation_matrix: ParticipationMatrix;
  // Market impact
  estimated_market_impact: number;
  estimated_market_impact_pct: number;
}

export interface LiquidityBucket {
  bucket: string;  // '< 1 day', '1-3 days', '3-5 days', '5-10 days', '> 10 days'
  market_value: number;
  weight: number;
  position_count: number;
}

export interface PositionLiquidity {
  symbol: string;
  name: string;
  market_value: number;
  weight: number;
  avg_daily_volume: number;
  position_volume_ratio: number;
  days_to_liquidate: number;
  estimated_impact_bps: number;
}

export interface ParticipationMatrix {
  rates: number[];           // [5, 10, 15, 20, 25] percent participation
  days_to_liquidate: number[];
  market_impact_bps: number[];
}

// Scenario Analysis (F11)
export type ScenarioType = 'historical' | 'hypothetical' | 'custom';

export interface Scenario {
  id: string;
  name: string;
  description: string;
  type: ScenarioType;
  category: string;
  // Factor shocks
  shocks: FactorShock[];
  // For historical scenarios
  start_date?: string;
  end_date?: string;
  // Metadata
  created_by?: string;
  created_at: string;
  is_system: boolean;
}

export interface FactorShock {
  factor: string;
  factor_type: 'equity_market' | 'sector' | 'interest_rate' | 'credit_spread' | 'fx' | 'volatility' | 'commodity';
  shock_value: number;
  shock_type: 'absolute' | 'relative';
}

export interface ScenarioResult {
  scenario_id: string;
  scenario_name: string;
  scenario_type: ScenarioType;
  portfolio_id: string;
  as_of_date: string;
  // P&L impact
  portfolio_pnl: number;
  portfolio_pnl_pct: number;
  benchmark_pnl?: number;
  benchmark_pnl_pct?: number;
  active_pnl?: number;
  // Contributors
  sector_contributions: ScenarioContributor[];
  security_contributions: ScenarioContributor[];
  factor_contributions: ScenarioContributor[];
}

export interface ScenarioContributor {
  name: string;
  key: string;
  weight: number;
  shock_applied: number;
  pnl_contribution: number;
  pnl_contribution_pct: number;
}

// Pre-defined historical scenarios
export const HISTORICAL_SCENARIOS: Partial<Scenario>[] = [
  {
    name: 'Lehman Crisis (2008)',
    description: 'Sept-Oct 2008 Lehman Brothers bankruptcy',
    type: 'historical',
    category: 'Market Crash',
    start_date: '2008-09-15',
    end_date: '2008-10-10',
    is_system: true,
  },
  {
    name: 'Flash Crash (2010)',
    description: 'May 6, 2010 Flash Crash',
    type: 'historical',
    category: 'Market Crash',
    start_date: '2010-05-06',
    end_date: '2010-05-06',
    is_system: true,
  },
  {
    name: 'Taper Tantrum (2013)',
    description: 'May-June 2013 rate spike',
    type: 'historical',
    category: 'Interest Rate',
    start_date: '2013-05-22',
    end_date: '2013-06-25',
    is_system: true,
  },
  {
    name: 'COVID Crash (2020)',
    description: 'Feb-Mar 2020 pandemic selloff',
    type: 'historical',
    category: 'Market Crash',
    start_date: '2020-02-19',
    end_date: '2020-03-23',
    is_system: true,
  },
  {
    name: 'Brexit Vote (2016)',
    description: 'June 23-24, 2016 Brexit referendum',
    type: 'historical',
    category: 'Political',
    start_date: '2016-06-23',
    end_date: '2016-06-24',
    is_system: true,
  },
];

// Pre-defined hypothetical scenarios
export const HYPOTHETICAL_SCENARIOS: Partial<Scenario>[] = [
  {
    name: 'Equity -10%',
    description: 'Global equity markets decline 10%',
    type: 'hypothetical',
    category: 'Market Stress',
    shocks: [{ factor: 'SPX', factor_type: 'equity_market', shock_value: -10, shock_type: 'relative' }],
    is_system: true,
  },
  {
    name: 'Equity -20%',
    description: 'Global equity markets decline 20%',
    type: 'hypothetical',
    category: 'Market Stress',
    shocks: [{ factor: 'SPX', factor_type: 'equity_market', shock_value: -20, shock_type: 'relative' }],
    is_system: true,
  },
  {
    name: 'VIX +50%',
    description: 'Volatility spike of 50%',
    type: 'hypothetical',
    category: 'Volatility',
    shocks: [{ factor: 'VIX', factor_type: 'volatility', shock_value: 50, shock_type: 'relative' }],
    is_system: true,
  },
  {
    name: 'Rates +100bps',
    description: 'Parallel rate shift up 100 basis points',
    type: 'hypothetical',
    category: 'Interest Rate',
    shocks: [{ factor: 'UST10Y', factor_type: 'interest_rate', shock_value: 1.0, shock_type: 'absolute' }],
    is_system: true,
  },
  {
    name: 'Rates -100bps',
    description: 'Parallel rate shift down 100 basis points',
    type: 'hypothetical',
    category: 'Interest Rate',
    shocks: [{ factor: 'UST10Y', factor_type: 'interest_rate', shock_value: -1.0, shock_type: 'absolute' }],
    is_system: true,
  },
  {
    name: 'USD Strengthening',
    description: 'USD appreciates 10% vs major currencies',
    type: 'hypothetical',
    category: 'Currency',
    shocks: [{ factor: 'DXY', factor_type: 'fx', shock_value: 10, shock_type: 'relative' }],
    is_system: true,
  },
];

// Factor exposure for factor risk models
export interface FactorExposure {
  factor: string;
  factor_type: 'style' | 'industry' | 'country' | 'currency';
  exposure: number;
  exposure_benchmark?: number;
  active_exposure?: number;
  factor_return?: number;
  contribution_to_return?: number;
}

// Risk limits and alerts
export interface RiskLimit {
  id: string;
  portfolio_id: string;
  metric: string;
  limit_type: 'max' | 'min' | 'range';
  warning_threshold: number;
  breach_threshold: number;
  current_value: number;
  status: 'ok' | 'warning' | 'breach';
}
