/**
 * Attribution Types for MarketSpine
 * Performance attribution (Brinson) and Factor attribution
 */

// Performance Attribution (F05 - Brinson Model)
export interface PerformanceAttribution {
  portfolio_id: string;
  benchmark_id: string;
  period: AttributionPeriod;
  start_date: string;
  end_date: string;
  // Summary returns
  portfolio_return: number;
  benchmark_return: number;
  active_return: number;
  // Brinson decomposition
  allocation_effect: number;
  selection_effect: number;
  interaction_effect: number;
  currency_effect?: number;
  // Attribution by level
  attribution_by_sector: SectorAttribution[];
  attribution_by_security: SecurityAttribution[];
}

export type AttributionPeriod = '1D' | '1W' | 'MTD' | 'QTD' | 'YTD' | '1Y' | '3Y' | '5Y' | 'ITD' | 'custom';

export interface SectorAttribution {
  sector: string;
  // Weights
  portfolio_weight_start: number;
  portfolio_weight_end: number;
  portfolio_weight_avg: number;
  benchmark_weight_start: number;
  benchmark_weight_end: number;
  benchmark_weight_avg: number;
  active_weight: number;
  // Returns
  portfolio_return: number;
  benchmark_return: number;
  active_return: number;
  // Brinson effects
  allocation_effect: number;
  selection_effect: number;
  interaction_effect: number;
  total_effect: number;
  // Contribution
  contribution_to_return: number;
}

export interface SecurityAttribution {
  symbol: string;
  name: string;
  sector: string;
  // Weights
  portfolio_weight_start: number;
  portfolio_weight_end: number;
  portfolio_weight_avg: number;
  benchmark_weight_start?: number;
  benchmark_weight_end?: number;
  benchmark_weight_avg?: number;
  active_weight: number;
  // Returns
  security_return: number;
  benchmark_return?: number;
  // Attribution
  allocation_effect: number;
  selection_effect: number;
  total_effect: number;
  contribution_to_return: number;
}

// Factor Attribution (F06)
export interface FactorAttribution {
  portfolio_id: string;
  benchmark_id?: string;
  period: AttributionPeriod;
  start_date: string;
  end_date: string;
  // Summary
  portfolio_return: number;
  benchmark_return?: number;
  active_return?: number;
  // Factor decomposition
  factor_return: number;          // Return explained by factors
  specific_return: number;        // Security-specific return
  total_return: number;
  // Factor contributions
  style_factors: FactorContribution[];
  industry_factors: FactorContribution[];
  country_factors: FactorContribution[];
  currency_factors: FactorContribution[];
}

export interface FactorContribution {
  factor: string;
  factor_type: 'style' | 'industry' | 'country' | 'currency';
  // Exposure
  exposure_start: number;
  exposure_end: number;
  exposure_avg: number;
  benchmark_exposure?: number;
  active_exposure?: number;
  // Returns
  factor_return: number;
  // Attribution
  contribution_to_return: number;
  contribution_pct: number;
}

// Common style factors
export const STYLE_FACTORS = [
  { id: 'momentum', name: 'Momentum', description: '12-month price momentum' },
  { id: 'value', name: 'Value', description: 'Book-to-price ratio' },
  { id: 'size', name: 'Size', description: 'Market capitalization' },
  { id: 'quality', name: 'Quality', description: 'ROE and earnings stability' },
  { id: 'volatility', name: 'Volatility', description: 'Historical price volatility' },
  { id: 'growth', name: 'Growth', description: 'Earnings growth rate' },
  { id: 'dividend_yield', name: 'Dividend Yield', description: 'Dividend yield' },
  { id: 'leverage', name: 'Leverage', description: 'Debt-to-equity ratio' },
  { id: 'liquidity', name: 'Liquidity', description: 'Trading volume and bid-ask' },
  { id: 'beta', name: 'Beta', description: 'Market sensitivity' },
];

// Attribution time series for trend analysis
export interface AttributionTimeSeries {
  dates: string[];
  cumulative_portfolio_return: number[];
  cumulative_benchmark_return: number[];
  cumulative_active_return: number[];
  cumulative_allocation_effect: number[];
  cumulative_selection_effect: number[];
  cumulative_interaction_effect: number[];
}

// Trade Simulation (F14)
export interface TradeSimulation {
  id: string;
  portfolio_id: string;
  name: string;
  description?: string;
  created_at: string;
  created_by: string;
  // Proposed trades
  proposed_trades: SimulatedTrade[];
  // Impact analysis
  impact_summary: SimulationImpactSummary;
  // Factor changes
  factor_changes: FactorChange[];
  // Risk changes
  risk_changes: RiskChange[];
}

export interface SimulatedTrade {
  symbol: string;
  name: string;
  side: 'buy' | 'sell';
  quantity: number;
  estimated_price: number;
  notional: number;
  weight_before: number;
  weight_after: number;
  weight_change: number;
  // Cost estimates
  estimated_commission: number;
  estimated_market_impact: number;
  estimated_total_cost: number;
}

export interface SimulationImpactSummary {
  total_buy_notional: number;
  total_sell_notional: number;
  net_notional: number;
  total_trades: number;
  estimated_total_cost: number;
  estimated_tracking_error_change: number;
  estimated_beta_change: number;
  estimated_var_change: number;
}

export interface FactorChange {
  factor: string;
  factor_type: string;
  exposure_before: number;
  exposure_after: number;
  exposure_change: number;
  benchmark_exposure?: number;
}

export interface RiskChange {
  metric: string;
  value_before: number;
  value_after: number;
  change: number;
  change_pct: number;
}

// Portfolio Optimization (F15)
export type OptimizationObjective = 
  | 'max_sharpe'
  | 'min_variance'
  | 'risk_parity'
  | 'max_return'
  | 'target_tracking_error';

export interface OptimizationRequest {
  portfolio_id: string;
  objective: OptimizationObjective;
  constraints: OptimizationConstraints;
  universe?: string[];  // Symbols to include
  benchmark_id?: string;
  target_tracking_error?: number;
  risk_aversion?: number;
}

export interface OptimizationConstraints {
  // Weight constraints
  min_weight?: number;           // e.g., 0
  max_weight?: number;           // e.g., 0.10 (10%)
  max_position_count?: number;
  // Sector constraints
  sector_min?: Record<string, number>;
  sector_max?: Record<string, number>;
  // Factor constraints
  factor_min?: Record<string, number>;
  factor_max?: Record<string, number>;
  // Turnover constraints
  max_turnover?: number;         // e.g., 0.20 (20%)
  max_one_way_turnover?: number;
  // Other
  long_only?: boolean;
  min_market_cap?: number;
}

export interface OptimizationResult {
  job_id: string;
  portfolio_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  objective: OptimizationObjective;
  // Results
  optimal_weights: OptimalWeight[];
  efficient_frontier?: EfficientFrontierPoint[];
  // Metrics comparison
  current_metrics: OptimizationMetrics;
  optimal_metrics: OptimizationMetrics;
  // Suggested trades
  suggested_trades: SuggestedTrade[];
  // Metadata
  created_at: string;
  completed_at?: string;
  computation_time_ms?: number;
}

export interface OptimalWeight {
  symbol: string;
  name: string;
  sector: string;
  current_weight: number;
  optimal_weight: number;
  weight_change: number;
  shares_to_trade: number;
  trade_direction: 'buy' | 'sell' | 'hold';
}

export interface EfficientFrontierPoint {
  expected_return: number;
  expected_volatility: number;
  sharpe_ratio: number;
  weights: Record<string, number>;
  is_current_portfolio?: boolean;
  is_max_sharpe?: boolean;
  is_min_variance?: boolean;
}

export interface OptimizationMetrics {
  expected_return: number;
  expected_volatility: number;
  sharpe_ratio: number;
  tracking_error?: number;
  information_ratio?: number;
  var_95?: number;
  position_count: number;
  max_weight: number;
  sector_concentration: number;
}

export interface SuggestedTrade {
  symbol: string;
  name: string;
  side: 'buy' | 'sell';
  shares: number;
  notional: number;
  current_weight: number;
  target_weight: number;
  priority: 'high' | 'medium' | 'low';
}
