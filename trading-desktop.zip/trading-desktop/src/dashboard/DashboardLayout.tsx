import { NavLink, Outlet, Link } from 'react-router-dom';
import {
  HomeIcon,
  RectangleStackIcon,
  QueueListIcon,
  CircleStackIcon,
  ServerStackIcon,
  ExclamationTriangleIcon,
  Cog6ToothIcon,
  ArrowPathIcon,
  ClockIcon,
  BeakerIcon,
} from '@heroicons/react/24/outline';
import { useTemporalContext } from './hooks/useTemporalContext';

const navigation = [
  { name: 'Overview', href: '/dashboard', icon: HomeIcon, end: true },
  { name: 'Pipelines', href: '/dashboard/pipelines', icon: RectangleStackIcon },
  { name: 'Jobs', href: '/dashboard/jobs', icon: QueueListIcon },
  { name: 'Queues', href: '/dashboard/queues', icon: ServerStackIcon },
  { name: 'Data Assets', href: '/dashboard/data', icon: CircleStackIcon },
  { name: 'Orchestrator Lab', href: '/dashboard/orchestrator', icon: BeakerIcon },
  { name: 'Incidents', href: '/dashboard/incidents', icon: ExclamationTriangleIcon },
  { name: 'Settings', href: '/dashboard/settings', icon: Cog6ToothIcon },
];

export default function DashboardLayout() {
  const { mode, asOf, setMode, refresh, lastRefresh } = useTemporalContext();

  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <aside className="dashboard-sidebar">
        <div className="sidebar-header">
          <Link to="/dashboard" className="logo">
            <span className="logo-icon">◈</span>
            <span className="logo-text">Market Spine</span>
          </Link>
          <span className="logo-subtitle">Control Plane</span>
        </div>

        <nav className="sidebar-nav">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              end={item.end}
              className={({ isActive }) =>
                `nav-item ${isActive ? 'nav-item-active' : ''}`
              }
            >
              <item.icon className="nav-icon" />
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <Link to="/trading" className="nav-item trading-link">
            <span className="nav-icon">📊</span>
            <span>Trading Desktop</span>
          </Link>
        </div>
      </aside>

      {/* Main content area */}
      <div className="dashboard-main">
        {/* Temporal Context Bar */}
        <header className="temporal-bar">
          <div className="temporal-mode">
            <ClockIcon className="temporal-icon" />
            <span className="temporal-label">VIEWING:</span>
            <select
              value={mode}
              onChange={(e) => setMode(e.target.value as 'live' | 'as_of')}
              className="temporal-select"
            >
              <option value="live">Live</option>
              <option value="as_of">Historical</option>
            </select>
            {mode === 'as_of' && (
              <input
                type="datetime-local"
                value={asOf?.slice(0, 16) || ''}
                className="temporal-input"
              />
            )}
          </div>

          {mode === 'as_of' && (
            <div className="temporal-warning">
              ⚠️ Viewing historical snapshot. Actions disabled.
            </div>
          )}

          <div className="temporal-refresh">
            <span className="refresh-time">
              Updated: {lastRefresh.toLocaleTimeString()}
            </span>
            <button onClick={refresh} className="refresh-btn" title="Refresh data">
              <ArrowPathIcon className="refresh-icon" />
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="dashboard-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
