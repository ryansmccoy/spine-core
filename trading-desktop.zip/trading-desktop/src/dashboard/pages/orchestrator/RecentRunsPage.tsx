/**
 * Orchestrator Lab - Recent Runs Page
 * 
 * Lists recent pipeline executions across all orchestrators.
 */
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { PlayIcon, XMarkIcon, ArrowPathIcon, ArrowTopRightOnSquareIcon } from '@heroicons/react/24/outline';
import { 
  listRuns, 
  createRun, 
  cancelRun,
  type ExecutionStatus, 
  type ExecutionSummary 
} from '../../../api/orchestratorLab';

// Status color mapping
const statusColors: Record<ExecutionStatus, string> = {
  pending: 'bg-gray-500',
  queued: 'bg-blue-400',
  running: 'bg-blue-500 animate-pulse',
  success: 'bg-green-500',
  failed: 'bg-red-500',
  cancelled: 'bg-yellow-500',
  timeout: 'bg-orange-500',
};

const statusLabels: Record<ExecutionStatus, string> = {
  pending: 'Pending',
  queued: 'Queued',
  running: 'Running',
  success: 'Success',
  failed: 'Failed',
  cancelled: 'Cancelled',
  timeout: 'Timeout',
};

function StatusBadge({ status }: { status: ExecutionStatus }) {
  return (
    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white ${statusColors[status]}`}>
      {statusLabels[status]}
    </span>
  );
}

function formatDuration(ms: number | null): string {
  if (ms === null) return '-';
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
}

function formatTimestamp(ts: string | null): string {
  if (!ts) return '-';
  return new Date(ts).toLocaleString();
}

export default function RecentRunsPage() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<ExecutionStatus | ''>('');
  const [orchestratorFilter, setOrchestratorFilter] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Fetch runs with auto-refresh
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['runs', statusFilter, orchestratorFilter],
    queryFn: () => listRuns({
      status: statusFilter || undefined,
      orchestrator: orchestratorFilter || undefined,
      limit: 50,
    }),
    refetchInterval: 5000, // Auto-refresh every 5s
  });

  // Cancel mutation
  const cancelMutation = useMutation({
    mutationFn: cancelRun,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['runs'] });
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: createRun,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['runs'] });
      setShowCreateModal(false);
    },
  });

  const handleCancel = (executionId: string, e: React.MouseEvent) => {
    e.preventDefault();
    if (confirm('Cancel this run?')) {
      cancelMutation.mutate(executionId);
    }
  };

  if (error) {
    return (
      <div className="p-8 text-red-500">
        Error loading runs: {(error as Error).message}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-100">Orchestrator Lab</h1>
          <p className="text-gray-400 mt-1">
            Monitor and manage pipeline executions across all orchestrators
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => refetch()}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition"
            title="Refresh"
          >
            <ArrowPathIcon className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
          >
            <PlayIcon className="w-5 h-5" />
            New Run
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 p-4 bg-gray-800/50 rounded-lg">
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-400">Status:</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as ExecutionStatus | '')}
            className="bg-gray-700 text-gray-200 rounded px-3 py-1.5 text-sm border border-gray-600 focus:outline-none focus:border-blue-500"
          >
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="queued">Queued</option>
            <option value="running">Running</option>
            <option value="success">Success</option>
            <option value="failed">Failed</option>
            <option value="cancelled">Cancelled</option>
            <option value="timeout">Timeout</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-400">Orchestrator:</label>
          <select
            value={orchestratorFilter}
            onChange={(e) => setOrchestratorFilter(e.target.value)}
            className="bg-gray-700 text-gray-200 rounded px-3 py-1.5 text-sm border border-gray-600 focus:outline-none focus:border-blue-500"
          >
            <option value="">All</option>
            <option value="dagster">Dagster</option>
            <option value="celery">Celery</option>
            <option value="temporal">Temporal</option>
            <option value="airflow">Airflow</option>
          </select>
        </div>
        <div className="ml-auto text-sm text-gray-500">
          {data?.total ?? 0} executions
        </div>
      </div>

      {/* Runs Table */}
      <div className="bg-gray-800/30 rounded-lg border border-gray-700 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-800/50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Execution ID
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Pipeline
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Orchestrator
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Backend Run
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Status
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Progress
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Duration
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Started
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {isLoading ? (
              <tr>
                <td colSpan={9} className="px-4 py-8 text-center text-gray-500">
                  Loading...
                </td>
              </tr>
            ) : data?.executions.length === 0 ? (
              <tr>
                <td colSpan={9} className="px-4 py-8 text-center text-gray-500">
                  No executions found
                </td>
              </tr>
            ) : (
              data?.executions.map((run: ExecutionSummary) => (
                <tr key={run.execution_id} className="hover:bg-gray-700/30 transition">
                  <td className="px-4 py-3">
                    <Link
                      to={`/dashboard/orchestrator/${run.execution_id}`}
                      className="font-mono text-sm text-blue-400 hover:text-blue-300"
                    >
                      {run.execution_id.slice(0, 8)}...
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-gray-200">
                    {run.pipeline}
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 bg-gray-700 text-gray-300 rounded text-xs">
                      {run.orchestrator}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {run.external_run_id ? (
                      run.external_url ? (
                        <a
                          href={run.external_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 font-mono text-xs text-blue-400 hover:text-blue-300"
                          title={`View in ${run.orchestrator}`}
                        >
                          {run.external_run_id.slice(0, 8)}...
                          <ArrowTopRightOnSquareIcon className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="font-mono text-xs text-gray-400" title={run.external_run_id}>
                          {run.external_run_id.slice(0, 8)}...
                        </span>
                      )
                    ) : (
                      <span className="text-xs text-gray-500">-</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={run.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${run.status === 'failed' ? 'bg-red-500' : 'bg-green-500'}`}
                          style={{
                            width: run.task_count > 0
                              ? `${((run.completed_task_count + run.failed_task_count) / run.task_count) * 100}%`
                              : '0%',
                          }}
                        />
                      </div>
                      <span className="text-xs text-gray-400">
                        {run.completed_task_count}/{run.task_count}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400">
                    {formatDuration(run.duration_ms)}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400">
                    {formatTimestamp(run.started_at)}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {(run.status === 'running' || run.status === 'queued') && (
                      <button
                        onClick={(e) => handleCancel(run.execution_id, e)}
                        className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded transition"
                        title="Cancel"
                        disabled={cancelMutation.isPending}
                      >
                        <XMarkIcon className="w-4 h-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Create Run Modal */}
      {showCreateModal && (
        <CreateRunModal
          onClose={() => setShowCreateModal(false)}
          onCreate={(data) => createMutation.mutate(data)}
          isLoading={createMutation.isPending}
        />
      )}
    </div>
  );
}

// Simple Create Run Modal
function CreateRunModal({
  onClose,
  onCreate,
  isLoading,
}: {
  onClose: () => void;
  onCreate: (data: { orchestrator: string; pipeline: string; params: Record<string, unknown> }) => void;
  isLoading: boolean;
}) {
  const [orchestrator, setOrchestrator] = useState('dagster');
  const [pipeline, setPipeline] = useState('');
  const [paramsText, setParamsText] = useState('{}');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const params = JSON.parse(paramsText);
      onCreate({ orchestrator, pipeline, params });
    } catch {
      alert('Invalid JSON in params');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md border border-gray-700">
        <h2 className="text-xl font-semibold text-gray-100 mb-4">New Pipeline Run</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Orchestrator</label>
            <select
              value={orchestrator}
              onChange={(e) => setOrchestrator(e.target.value)}
              className="w-full bg-gray-700 text-gray-200 rounded px-3 py-2 border border-gray-600 focus:outline-none focus:border-blue-500"
            >
              <option value="dagster">Dagster</option>
              <option value="celery">Celery</option>
              <option value="temporal">Temporal</option>
              <option value="airflow">Airflow</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Pipeline Name</label>
            <input
              type="text"
              value={pipeline}
              onChange={(e) => setPipeline(e.target.value)}
              placeholder="e.g., market_data_ingest"
              className="w-full bg-gray-700 text-gray-200 rounded px-3 py-2 border border-gray-600 focus:outline-none focus:border-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Parameters (JSON)</label>
            <textarea
              value={paramsText}
              onChange={(e) => setParamsText(e.target.value)}
              rows={4}
              className="w-full bg-gray-700 text-gray-200 rounded px-3 py-2 border border-gray-600 focus:outline-none focus:border-blue-500 font-mono text-sm"
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-400 hover:text-gray-200 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
            >
              {isLoading ? 'Starting...' : 'Start Run'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
