/**
 * Orchestrator Lab - Run Detail Page
 * 
 * Shows detailed view of a single execution including tasks, events, and artifacts.
 */
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeftIcon,
  ArrowPathIcon,
  XMarkIcon,
  ArrowTopRightOnSquareIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  ForwardIcon,
  MinusCircleIcon,
} from '@heroicons/react/24/outline';
import { getRun, cancelRun, retryRun, type TaskStatus, type ExecutionStatus } from '../../../api/orchestratorLab';

// Status icons for tasks
const taskStatusIcons: Record<TaskStatus, React.ComponentType<{ className?: string }>> = {
  pending: ClockIcon,
  running: ArrowPathIcon,
  success: CheckCircleIcon,
  failed: XCircleIcon,
  skipped: ForwardIcon,
  cancelled: MinusCircleIcon,
};

const taskStatusColors: Record<TaskStatus, string> = {
  pending: 'text-gray-400',
  running: 'text-blue-400 animate-spin',
  success: 'text-green-400',
  failed: 'text-red-400',
  skipped: 'text-yellow-400',
  cancelled: 'text-orange-400',
};

const executionStatusColors: Record<ExecutionStatus, string> = {
  pending: 'bg-gray-600',
  queued: 'bg-blue-600',
  running: 'bg-blue-600',
  success: 'bg-green-600',
  failed: 'bg-red-600',
  cancelled: 'bg-yellow-600',
  timeout: 'bg-orange-600',
};

function formatDuration(ms: number | null): string {
  if (ms === null) return '-';
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
  return `${Math.floor(ms / 3600000)}h ${Math.floor((ms % 3600000) / 60000)}m`;
}

function formatTimestamp(ts: string | null): string {
  if (!ts) return '-';
  return new Date(ts).toLocaleString();
}

export default function RunDetailPage() {
  const { executionId } = useParams<{ executionId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: run, isLoading, error } = useQuery({
    queryKey: ['run', executionId],
    queryFn: () => getRun(executionId!),
    enabled: !!executionId,
    refetchInterval: (query) => {
      // Auto-refresh while running
      const status = query.state.data?.status;
      return status === 'running' || status === 'queued' ? 2000 : false;
    },
  });

  const cancelMutation = useMutation({
    mutationFn: () => cancelRun(executionId!),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['run', executionId] });
    },
  });

  const retryMutation = useMutation({
    mutationFn: () => retryRun(executionId!, true),
    onSuccess: (newRun) => {
      queryClient.invalidateQueries({ queryKey: ['runs'] });
      navigate(`/dashboard/orchestrator/${newRun.execution_id}`);
    },
  });

  if (isLoading) {
    return (
      <div className="p-8 flex items-center justify-center">
        <ArrowPathIcon className="w-8 h-8 text-gray-400 animate-spin" />
      </div>
    );
  }

  if (error || !run) {
    return (
      <div className="p-8">
        <div className="text-red-500 mb-4">
          Error loading run: {(error as Error)?.message || 'Not found'}
        </div>
        <Link to="/dashboard/orchestrator" className="text-blue-400 hover:text-blue-300">
          ← Back to runs
        </Link>
      </div>
    );
  }

  const isActive = run.status === 'running' || run.status === 'queued';
  const isFailed = run.status === 'failed';

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <Link
            to="/dashboard/orchestrator"
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-semibold text-gray-100 flex items-center gap-3">
              {run.pipeline}
              <span className={`px-3 py-1 rounded-full text-sm font-medium text-white ${executionStatusColors[run.status]}`}>
                {run.status.toUpperCase()}
              </span>
            </h1>
            <div className="flex items-center gap-4 mt-1 text-sm text-gray-400">
              <span className="font-mono">{run.execution_id}</span>
              <span>•</span>
              <span className="px-2 py-0.5 bg-gray-700 rounded">{run.orchestrator}</span>
              {run.external_url && (
                <>
                  <span>•</span>
                  <a
                    href={run.external_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-blue-400 hover:text-blue-300"
                  >
                    View in {run.orchestrator}
                    <ArrowTopRightOnSquareIcon className="w-4 h-4" />
                  </a>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isActive && (
            <button
              onClick={() => cancelMutation.mutate()}
              disabled={cancelMutation.isPending}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition disabled:opacity-50"
            >
              <XMarkIcon className="w-5 h-5" />
              Cancel
            </button>
          )}
          {isFailed && (
            <button
              onClick={() => retryMutation.mutate()}
              disabled={retryMutation.isPending}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
            >
              <ArrowPathIcon className="w-5 h-5" />
              Retry from failure
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
          <div className="text-sm text-gray-400">Duration</div>
          <div className="text-2xl font-semibold text-gray-100 mt-1">
            {formatDuration(run.duration_ms)}
          </div>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
          <div className="text-sm text-gray-400">Started</div>
          <div className="text-lg text-gray-100 mt-1">
            {formatTimestamp(run.started_at)}
          </div>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
          <div className="text-sm text-gray-400">Ended</div>
          <div className="text-lg text-gray-100 mt-1">
            {formatTimestamp(run.ended_at)}
          </div>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
          <div className="text-sm text-gray-400">Tasks</div>
          <div className="text-2xl font-semibold text-gray-100 mt-1">
            {run.tasks.filter(t => t.status === 'success').length} / {run.tasks.length}
            <span className="text-sm text-gray-400 ml-2">completed</span>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {run.error_message && (
        <div className="bg-red-900/20 border border-red-800 rounded-lg p-4 flex items-start gap-3">
          <ExclamationTriangleIcon className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-red-400 font-medium">Execution Failed</div>
            <pre className="text-red-300 text-sm mt-1 whitespace-pre-wrap font-mono">
              {run.error_message}
            </pre>
          </div>
        </div>
      )}

      {/* Parameters */}
      {Object.keys(run.params).length > 0 && (
        <div className="bg-gray-800/30 rounded-lg border border-gray-700 p-4">
          <h2 className="text-lg font-medium text-gray-200 mb-3">Parameters</h2>
          <pre className="text-sm text-gray-300 font-mono bg-gray-900/50 rounded p-3 overflow-x-auto">
            {JSON.stringify(run.params, null, 2)}
          </pre>
        </div>
      )}

      {/* Tasks */}
      <div className="bg-gray-800/30 rounded-lg border border-gray-700">
        <div className="px-4 py-3 border-b border-gray-700">
          <h2 className="text-lg font-medium text-gray-200">Tasks</h2>
        </div>
        <div className="divide-y divide-gray-700">
          {run.tasks.length === 0 ? (
            <div className="px-4 py-8 text-center text-gray-500">
              No tasks recorded yet
            </div>
          ) : (
            run.tasks.map((task) => {
              const StatusIcon = taskStatusIcons[task.status];
              return (
                <div key={task.task_id} className="px-4 py-3 hover:bg-gray-700/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <StatusIcon className={`w-5 h-5 ${taskStatusColors[task.status]}`} />
                      <span className="text-gray-200 font-medium">{task.task_name}</span>
                      {task.skip_reason && (
                        <span className="px-2 py-0.5 bg-yellow-900/30 text-yellow-400 rounded text-xs">
                          {task.skip_reason.replace('_', ' ')}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <span>{formatDuration(task.duration_ms)}</span>
                      <span>{formatTimestamp(task.started_at)}</span>
                    </div>
                  </div>
                  
                  {/* Task error */}
                  {task.error_message && (
                    <div className="mt-2 ml-8 text-sm text-red-400 font-mono bg-red-900/10 rounded p-2">
                      {task.error_message}
                    </div>
                  )}

                  {/* Task artifacts */}
                  {task.artifacts.length > 0 && (
                    <div className="mt-2 ml-8 flex flex-wrap gap-2">
                      {task.artifacts.map((artifact, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-gray-700 text-gray-300 rounded text-xs"
                          title={artifact.artifact_value}
                        >
                          {artifact.artifact_type}: {artifact.artifact_key}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
