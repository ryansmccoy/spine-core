import { useQuery } from '@tanstack/react-query';
import {
  ExclamationTriangleIcon,
  CheckCircleIcon,
  BellSlashIcon,
} from '@heroicons/react/24/outline';
import { dashboardApi } from '../api';
import type { Incident } from '../api';

export default function IncidentsPage() {
  const { data: incidents, isLoading } = useQuery({
    queryKey: ['incidents'],
    queryFn: () => dashboardApi.getIncidents(),
    refetchInterval: 10000,
  });

  const openIncidents = incidents?.filter((i) => i.status === 'open') || [];
  const ackedIncidents = incidents?.filter((i) => i.status === 'acknowledged') || [];
  const resolvedIncidents = incidents?.filter((i) => i.status === 'resolved') || [];

  return (
    <div className="incidents-page">
      <header className="page-header">
        <h1 className="page-title">
          Incidents
          {openIncidents.length > 0 && (
            <span className="page-subtitle incident-count">
              — {openIncidents.length} open
            </span>
          )}
        </h1>
      </header>

      <div className="tabs">
        <button className="tab active">Open ({openIncidents.length})</button>
        <button className="tab">Acknowledged ({ackedIncidents.length})</button>
        <button className="tab">Resolved ({resolvedIncidents.length})</button>
        <button className="tab">All</button>
      </div>

      {isLoading ? (
        <div className="loading-state">
          <div className="spinner" />
          Loading incidents...
        </div>
      ) : openIncidents.length === 0 ? (
        <div className="empty-state success">
          <CheckCircleIcon className="empty-icon" />
          <h3>No Open Incidents</h3>
          <p>All systems operational</p>
        </div>
      ) : (
        <div className="incident-list">
          {openIncidents.map((incident) => (
            <IncidentCard key={incident.id} incident={incident} />
          ))}
        </div>
      )}
    </div>
  );
}

function IncidentCard({ incident }: { incident: Incident }) {
  const handleAcknowledge = async () => {
    const reason = prompt('Acknowledgment reason (optional):');
    await dashboardApi.acknowledgeIncident(incident.id, reason || undefined);
  };

  const handleResolve = async () => {
    const resolution = prompt('Resolution notes:');
    if (resolution) {
      await dashboardApi.resolveIncident(incident.id, resolution);
    }
  };

  return (
    <div className={`incident-card severity-${incident.severity}`}>
      <div className="incident-header">
        <div className="incident-icon">
          <ExclamationTriangleIcon />
        </div>
        <div className="incident-title">
          <span className="incident-id">{incident.id}</span>
          <h3>{incident.title}</h3>
        </div>
        <span className={`severity-badge ${incident.severity}`}>
          {incident.severity}
        </span>
      </div>

      <div className="incident-body">
        <div className="incident-detail">
          <label>Category:</label>
          <span>{incident.category}</span>
        </div>
        {incident.root_cause && (
          <div className="incident-detail">
            <label>Root Cause:</label>
            <span className="root-cause">{incident.root_cause}</span>
          </div>
        )}
        <div className="incident-detail">
          <label>Impact:</label>
          <span>{incident.impact_summary}</span>
        </div>
        <div className="incident-detail">
          <label>Related:</label>
          <span>{incident.related_executions.length} executions</span>
        </div>
        <div className="incident-detail">
          <label>Created:</label>
          <span>{formatTime(incident.created_at)}</span>
        </div>
      </div>

      <div className="incident-actions">
        <button className="btn" onClick={handleAcknowledge}>
          <CheckCircleIcon className="btn-icon" />
          Acknowledge
        </button>
        <button className="btn">
          <BellSlashIcon className="btn-icon" />
          Mute 1h
        </button>
        <button className="btn btn-primary" onClick={handleResolve}>
          Resolve
        </button>
      </div>
    </div>
  );
}

function formatTime(isoString: string): string {
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
  return date.toLocaleDateString();
}
