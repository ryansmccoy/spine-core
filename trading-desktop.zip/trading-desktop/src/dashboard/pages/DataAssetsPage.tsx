export default function DataAssetsPage() {
  return (
    <div className="data-assets-page">
      <header className="page-header">
        <h1 className="page-title">Data Assets</h1>
      </header>

      <div className="tabs">
        <button className="tab active">Prices</button>
        <button className="tab">Quotes</button>
        <button className="tab">Analytics</button>
        <button className="tab">Raw</button>
      </div>

      <div className="filters-bar">
        <div className="filter-group">
          <label>Symbol</label>
          <input type="text" placeholder="AAPL" className="filter-input" />
        </div>
        <div className="filter-group">
          <label>Date Range</label>
          <input type="date" className="filter-input" />
          <span className="filter-separator">to</span>
          <input type="date" className="filter-input" />
        </div>
        <div className="filter-group">
          <label>As-Of</label>
          <input type="datetime-local" className="filter-input" />
        </div>
        <button className="btn btn-primary">Query</button>
      </div>

      <section className="card">
        <header className="card-header">
          <h2>Results</h2>
          <button className="btn btn-sm">Export CSV</button>
        </header>
        <div className="card-body">
          <div className="empty-state">
            <p>Select filters and click Query to browse data</p>
          </div>
        </div>
      </section>

      <section className="card">
        <header className="card-header">
          <h2>Data Lineage</h2>
        </header>
        <div className="card-body">
          <div className="lineage-placeholder">
            <p>Click on any capture_id to view lineage</p>
          </div>
        </div>
      </section>
    </div>
  );
}
