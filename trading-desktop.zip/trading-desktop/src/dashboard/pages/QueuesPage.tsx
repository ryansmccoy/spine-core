import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '../api';

export default function QueuesPage() {
  const { data: queues, isLoading } = useQuery({
    queryKey: ['queues'],
    queryFn: dashboardApi.getQueuesStats,
    refetchInterval: 5000,
  });

  return (
    <div className="queues-page">
      <header className="page-header">
        <h1 className="page-title">
          Queues
          <span className="page-subtitle">
            — {queues?.total_depth ?? 0} messages, {queues?.total_consumers ?? 0} consumers
          </span>
        </h1>
      </header>

      {isLoading ? (
        <div className="loading-state">
          <div className="spinner" />
          Loading queue stats...
        </div>
      ) : (
        <>
          {/* Queue Overview Cards */}
          <div className="queue-cards">
            {queues?.queues.map((queue) => (
              <div key={queue.name} className={`queue-card ${queue.status}`}>
                <div className="queue-card-header">
                  <span className="queue-name">{queue.name}</span>
                  <span className={`status-badge ${queue.status}`}>{queue.status}</span>
                </div>
                <div className="queue-card-stats">
                  <div className="queue-stat">
                    <span className="stat-value">{queue.depth}</span>
                    <span className="stat-label">Depth</span>
                  </div>
                  <div className="queue-stat">
                    <span className="stat-value">{queue.consumers}</span>
                    <span className="stat-label">Consumers</span>
                  </div>
                  <div className="queue-stat">
                    <span className="stat-value">{queue.rate}</span>
                    <span className="stat-label">msg/s</span>
                  </div>
                </div>
                <div className="queue-bar">
                  <div
                    className={`queue-fill ${queue.status}`}
                    style={{ width: `${Math.min((queue.depth / 500) * 100, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Depth Chart Placeholder */}
          <section className="card">
            <header className="card-header">
              <h2>Queue Depth (24h)</h2>
            </header>
            <div className="card-body chart-placeholder">
              <p>📊 Chart coming soon</p>
              <p className="chart-note">Will show queue depth over time with publish/consume rates</p>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
