import { useQuery } from '@tanstack/react-query';
import {
  StopIcon,
  ArrowPathIcon,
} from '@heroicons/react/24/outline';
import { dashboardApi } from '../api';
import type { Execution } from '../api';

export default function JobsPage() {
  const { data: jobs, isLoading } = useQuery({
    queryKey: ['jobs'],
    queryFn: () => dashboardApi.getExecutions({ type: 'job', limit: 50 }),
    refetchInterval: 5000,
  });

  const runningJobs = jobs?.filter((j) => j.status === 'running') || [];
  const pendingJobs = jobs?.filter((j) => j.status === 'pending') || [];
  const recentJobs = jobs?.filter((j) => j.status !== 'running' && j.status !== 'pending').slice(0, 20) || [];

  return (
    <div className="jobs-page">
      <header className="page-header">
        <h1 className="page-title">
          Jobs
          <span className="page-subtitle">
            — {runningJobs.length} running, {pendingJobs.length} queued
          </span>
        </h1>
      </header>

      <div className="tabs">
        <button className="tab active">Active ({runningJobs.length})</button>
        <button className="tab">Pending ({pendingJobs.length})</button>
        <button className="tab">History</button>
        <button className="tab">Scheduled</button>
      </div>

      {isLoading ? (
        <div className="loading-state">
          <div className="spinner" />
          Loading jobs...
        </div>
      ) : (
        <>
          {/* Active Jobs */}
          <section className="section">
            <h2 className="section-title">Active Jobs</h2>
            {runningJobs.length > 0 ? (
              <div className="job-grid">
                {runningJobs.map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </div>
            ) : (
              <div className="empty-state">No jobs currently running</div>
            )}
          </section>

          {/* Recent Jobs */}
          <section className="section">
            <h2 className="section-title">Recent Jobs</h2>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Job</th>
                  <th>Status</th>
                  <th>Started</th>
                  <th>Duration</th>
                  <th>Trigger</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentJobs.map((job) => (
                  <JobRow key={job.id} job={job} />
                ))}
              </tbody>
            </table>
          </section>
        </>
      )}
    </div>
  );
}

function JobCard({ job }: { job: Execution }) {
  const progress = job.progress ?? 0;

  return (
    <div className="job-card">
      <div className="job-card-header">
        <span className="job-name">{job.name}</span>
        <span className={`status-dot ${job.status}`} />
      </div>
      <div className="job-card-body">
        <div className="progress-container">
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
          <span className="progress-text">{progress}%</span>
        </div>
        <div className="job-meta">
          <span>Started: {job.started_at ? formatTime(job.started_at) : '--'}</span>
          <span>Worker: {job.triggered_by}</span>
        </div>
      </div>
      <div className="job-card-actions">
        <button className="icon-btn" title="Cancel">
          <StopIcon className="btn-icon" />
        </button>
      </div>
    </div>
  );
}

function JobRow({ job }: { job: Execution }) {
  const handleRetry = async () => {
    if (confirm(`Retry job ${job.name}?`)) {
      await dashboardApi.retryExecution(job.id);
    }
  };

  return (
    <tr>
      <td>
        <span className="job-name">{job.name}</span>
        <span className="job-id">{job.id.slice(0, 8)}</span>
      </td>
      <td>
        <span className={`status-badge ${job.status}`}>{job.status}</span>
      </td>
      <td>{job.started_at ? formatTime(job.started_at) : '--'}</td>
      <td>{job.duration_ms ? formatDuration(job.duration_ms) : '--'}</td>
      <td>{job.trigger}</td>
      <td>
        <div className="action-buttons">
          {job.status === 'failed' && (
            <button className="icon-btn" title="Retry" onClick={handleRetry}>
              <ArrowPathIcon className="btn-icon" />
            </button>
          )}
        </div>
      </td>
    </tr>
  );
}

function formatTime(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}m ${remainingSeconds}s`;
}
