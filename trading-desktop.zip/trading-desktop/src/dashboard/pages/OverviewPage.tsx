import { useQuery } from '@tanstack/react-query';
import {
  CheckCircleIcon,
  ExclamationCircleIcon,
  ClockIcon,
  ArrowTrendingUpIcon,
} from '@heroicons/react/24/solid';
import { dashboardApi } from '../api';
import type { SystemHealth, ExecutionSummary } from '../api';

export default function OverviewPage() {
  const { data: health, isLoading: healthLoading } = useQuery({
    queryKey: ['system-health'],
    queryFn: dashboardApi.getSystemHealth,
    refetchInterval: 10000,
  });

  const { data: executions } = useQuery({
    queryKey: ['executions-summary'],
    queryFn: dashboardApi.getExecutionsSummary,
    refetchInterval: 5000,
  });

  const { data: queues } = useQuery({
    queryKey: ['queues-stats'],
    queryFn: dashboardApi.getQueuesStats,
    refetchInterval: 5000,
  });

  const { data: recentFailures } = useQuery({
    queryKey: ['recent-failures'],
    queryFn: () => dashboardApi.getRecentFailures(5),
    refetchInterval: 10000,
  });

  return (
    <div className="overview-page">
      <header className="page-header">
        <h1 className="page-title">
          Overview
          {executions && (
            <span className="page-subtitle">
              — {executions.running} running, {executions.failed} failing
            </span>
          )}
        </h1>
      </header>

      {/* System Status Banner */}
      <SystemStatusBanner health={health} isLoading={healthLoading} />

      {/* Stats Grid */}
      <div className="stats-grid">
        <StatCard
          title="Active Jobs"
          value={executions?.running ?? 0}
          icon={ArrowTrendingUpIcon}
          trend={executions?.running_change}
          color="blue"
        />
        <StatCard
          title="Queued"
          value={queues?.total_depth ?? 0}
          icon={ClockIcon}
          trend={queues?.depth_change}
          color="yellow"
        />
        <StatCard
          title="Success Rate (24h)"
          value={`${executions?.success_rate ?? 100}%`}
          icon={CheckCircleIcon}
          color="green"
        />
        <StatCard
          title="Incidents"
          value={executions?.failed ?? 0}
          icon={ExclamationCircleIcon}
          color={executions?.failed ? 'red' : 'gray'}
        />
      </div>

      {/* Two-column layout */}
      <div className="overview-grid">
        {/* Recent Failures */}
        <section className="card">
          <header className="card-header">
            <h2>Recent Failures</h2>
            <span className="card-count">{recentFailures?.length ?? 0}</span>
          </header>
          <div className="card-body">
            {recentFailures && recentFailures.length > 0 ? (
              <ul className="failure-list">
                {recentFailures.map((failure) => (
                  <FailureCard key={failure.id} failure={failure} />
                ))}
              </ul>
            ) : (
              <div className="empty-state">
                <CheckCircleIcon className="empty-icon success" />
                <p>No recent failures</p>
              </div>
            )}
          </div>
        </section>

        {/* Queue Overview */}
        <section className="card">
          <header className="card-header">
            <h2>Queue Depths</h2>
          </header>
          <div className="card-body">
            {queues?.queues ? (
              <ul className="queue-list">
                {queues.queues.map((q) => (
                  <QueueRow key={q.name} queue={q} />
                ))}
              </ul>
            ) : (
              <div className="empty-state">
                <p>No queue data</p>
              </div>
            )}
          </div>
        </section>

        {/* Data Freshness */}
        <section className="card">
          <header className="card-header">
            <h2>Data Freshness</h2>
          </header>
          <div className="card-body">
            <FreshnessTable />
          </div>
        </section>

        {/* Active Pipelines */}
        <section className="card">
          <header className="card-header">
            <h2>Active Pipelines</h2>
          </header>
          <div className="card-body">
            <ActivePipelinesList executions={executions} />
          </div>
        </section>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────

function SystemStatusBanner({ health, isLoading }: { health?: SystemHealth; isLoading: boolean }) {
  if (isLoading) {
    return (
      <div className="status-banner status-loading">
        <div className="spinner" /> Checking system health...
      </div>
    );
  }

  const allHealthy = health?.services.every((s) => s.status === 'healthy');

  return (
    <div className={`status-banner ${allHealthy ? 'status-healthy' : 'status-degraded'}`}>
      <div className="status-icon">
        {allHealthy ? (
          <CheckCircleIcon className="icon-healthy" />
        ) : (
          <ExclamationCircleIcon className="icon-degraded" />
        )}
      </div>
      <div className="status-text">
        <strong>{allHealthy ? 'All Systems Operational' : 'System Degraded'}</strong>
        <span className="status-services">
          {health?.services.map((s) => (
            <span key={s.name} className={`service-badge ${s.status}`}>
              {s.name}
            </span>
          ))}
        </span>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  icon: Icon,
  trend,
  color,
}: {
  title: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  trend?: number;
  color: string;
}) {
  return (
    <div className={`stat-card stat-${color}`}>
      <div className="stat-icon">
        <Icon className="icon" />
      </div>
      <div className="stat-content">
        <span className="stat-value">{value}</span>
        <span className="stat-title">{title}</span>
        {trend !== undefined && (
          <span className={`stat-trend ${trend >= 0 ? 'up' : 'down'}`}>
            {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}
          </span>
        )}
      </div>
    </div>
  );
}

interface Failure {
  id: string;
  name: string;
  error: string;
  timestamp: string;
  impact?: string;
}

function FailureCard({ failure }: { failure: Failure }) {
  const timeAgo = getTimeAgo(failure.timestamp);

  return (
    <li className="failure-card">
      <div className="failure-header">
        <ExclamationCircleIcon className="failure-icon" />
        <span className="failure-name">{failure.name}</span>
        <span className="failure-time">{timeAgo}</span>
      </div>
      <p className="failure-error">{failure.error}</p>
      {failure.impact && <p className="failure-impact">Impact: {failure.impact}</p>}
      <div className="failure-actions">
        <button className="btn-sm">View Logs</button>
        <button className="btn-sm btn-primary">Retry</button>
      </div>
    </li>
  );
}

interface Queue {
  name: string;
  depth: number;
  consumers: number;
  rate: number;
  status: 'healthy' | 'warning' | 'backlogged';
}

function QueueRow({ queue }: { queue: Queue }) {
  const maxDepth = 1000; // For progress bar visualization
  const fillPercent = Math.min((queue.depth / maxDepth) * 100, 100);

  return (
    <li className="queue-row">
      <div className="queue-info">
        <span className="queue-name">{queue.name}</span>
        <span className={`queue-status ${queue.status}`}>{queue.depth}</span>
      </div>
      <div className="queue-bar">
        <div
          className={`queue-fill ${queue.status}`}
          style={{ width: `${fillPercent}%` }}
        />
      </div>
      <div className="queue-meta">
        <span>{queue.consumers} consumers</span>
        <span>{queue.rate} msg/s</span>
      </div>
    </li>
  );
}

function FreshnessTable() {
  // Mock data - will be replaced with API call
  const datasets = [
    { name: 'prices', lastEvent: '2024-12-31 09:30', lastIngest: '2024-12-31 09:35', status: 'fresh' },
    { name: 'quotes', lastEvent: '2024-12-31 09:30', lastIngest: '2024-12-31 09:31', status: 'fresh' },
    { name: 'sec_13f', lastEvent: '2024-12-20', lastIngest: '2024-12-21', status: 'stale' },
    { name: 'venue_scores', lastEvent: '2024-12-30', lastIngest: '2024-12-31 08:00', status: 'fresh' },
  ];

  return (
    <table className="freshness-table">
      <thead>
        <tr>
          <th>Dataset</th>
          <th>Last Event</th>
          <th>Last Ingest</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {datasets.map((ds) => (
          <tr key={ds.name}>
            <td className="dataset-name">{ds.name}</td>
            <td>{ds.lastEvent}</td>
            <td>{ds.lastIngest}</td>
            <td>
              <span className={`freshness-badge ${ds.status}`}>{ds.status}</span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ActivePipelinesList({ }: { executions?: ExecutionSummary }) {
  // Mock data - will be replaced with API call
  const pipelines = [
    { name: 'price-daily', status: 'running', progress: 45, started: '09:30' },
    { name: 'quote-stream', status: 'running', progress: 100, started: '06:00' },
    { name: 'venue-scores', status: 'idle', progress: 0, started: '--' },
  ];

  return (
    <ul className="pipeline-list">
      {pipelines.map((p) => (
        <li key={p.name} className="pipeline-row">
          <span className={`pipeline-status ${p.status}`}>●</span>
          <span className="pipeline-name">{p.name}</span>
          {p.status === 'running' && (
            <div className="pipeline-progress">
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${p.progress}%` }} />
              </div>
              <span className="progress-text">{p.progress}%</span>
            </div>
          )}
          <span className="pipeline-time">{p.started}</span>
        </li>
      ))}
    </ul>
  );
}

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────

function getTimeAgo(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
  return `${Math.floor(diffMins / 1440)}d ago`;
}
