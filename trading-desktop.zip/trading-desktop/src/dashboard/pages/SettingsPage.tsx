export default function SettingsPage() {
  return (
    <div className="settings-page">
      <header className="page-header">
        <h1 className="page-title">Settings</h1>
      </header>

      <div className="settings-grid">
        {/* User Settings */}
        <section className="card">
          <header className="card-header">
            <h2>User Preferences</h2>
          </header>
          <div className="card-body">
            <div className="setting-row">
              <div className="setting-info">
                <label>Theme</label>
                <span className="setting-desc">Dashboard color theme</span>
              </div>
              <select className="setting-input">
                <option value="dark">Dark</option>
                <option value="light">Light</option>
              </select>
            </div>
            <div className="setting-row">
              <div className="setting-info">
                <label>Timezone</label>
                <span className="setting-desc">Display timezone for timestamps</span>
              </div>
              <select className="setting-input">
                <option value="America/New_York">America/New_York</option>
                <option value="UTC">UTC</option>
                <option value="America/Chicago">America/Chicago</option>
                <option value="America/Los_Angeles">America/Los_Angeles</option>
              </select>
            </div>
            <div className="setting-row">
              <div className="setting-info">
                <label>Auto-refresh</label>
                <span className="setting-desc">Automatically refresh dashboard data</span>
              </div>
              <label className="toggle">
                <input type="checkbox" defaultChecked />
                <span className="toggle-slider"></span>
              </label>
            </div>
          </div>
        </section>

        {/* System Settings */}
        <section className="card">
          <header className="card-header">
            <h2>System Settings</h2>
            <span className="card-badge">Admin Only</span>
          </header>
          <div className="card-body">
            <div className="setting-row">
              <div className="setting-info">
                <label>Data Retention</label>
                <span className="setting-desc">Days to retain historical data</span>
              </div>
              <input type="number" className="setting-input" defaultValue={90} />
            </div>
            <div className="setting-row">
              <div className="setting-info">
                <label>Alert Email</label>
                <span className="setting-desc">Email for critical alerts</span>
              </div>
              <input type="email" className="setting-input" placeholder="ops@company.com" />
            </div>
          </div>
        </section>

        {/* API Keys */}
        <section className="card">
          <header className="card-header">
            <h2>API Keys</h2>
          </header>
          <div className="card-body">
            <div className="api-key-list">
              <div className="api-key-row">
                <div className="key-info">
                  <span className="key-name">Production Key</span>
                  <code className="key-value">ms_prod_••••••••••••</code>
                </div>
                <button className="btn btn-sm">Rotate</button>
              </div>
              <div className="api-key-row">
                <div className="key-info">
                  <span className="key-name">Development Key</span>
                  <code className="key-value">ms_dev_••••••••••••</code>
                </div>
                <button className="btn btn-sm">Rotate</button>
              </div>
            </div>
            <button className="btn btn-primary">Generate New Key</button>
          </div>
        </section>

        {/* About */}
        <section className="card">
          <header className="card-header">
            <h2>About</h2>
          </header>
          <div className="card-body">
            <div className="about-info">
              <div className="about-row">
                <label>Version</label>
                <span>1.0.0-dev</span>
              </div>
              <div className="about-row">
                <label>API Endpoint</label>
                <span>{import.meta.env.VITE_API_URL || 'http://localhost:8001'}</span>
              </div>
              <div className="about-row">
                <label>Build</label>
                <span>{new Date().toISOString().split('T')[0]}</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
