import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  PlayIcon,
  StopIcon,
  EyeIcon,
} from '@heroicons/react/24/outline';
import { dashboardApi } from '../api';
import type { Pipeline } from '../api';
import { useState } from 'react';

export default function PipelinesPage() {
  const { data: pipelines, isLoading } = useQuery({
    queryKey: ['pipelines'],
    queryFn: dashboardApi.getPipelines,
    refetchInterval: 10000,
  });

  return (
    <div className="pipelines-page">
      <header className="page-header">
        <h1 className="page-title">Pipelines</h1>
        <div className="page-actions">
          <select className="filter-select">
            <option value="all">All Status</option>
            <option value="running">Running</option>
            <option value="idle">Idle</option>
            <option value="failed">Failed</option>
          </select>
          <button className="btn btn-primary">
            <PlayIcon className="btn-icon" />
            New Pipeline
          </button>
        </div>
      </header>

      <div className="view-toggle">
        <button className="view-btn active">List</button>
        <button className="view-btn">Grid</button>
        <button className="view-btn">DAG</button>
      </div>

      {isLoading ? (
        <div className="loading-state">
          <div className="spinner" />
          Loading pipelines...
        </div>
      ) : (
        <div className="pipeline-table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Pipeline</th>
                <th>Status</th>
                <th>Last Run</th>
                <th>Duration</th>
                <th>Schedule</th>
                <th>Success Rate</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pipelines?.map((pipeline) => (
                <PipelineRow key={pipeline.id} pipeline={pipeline} />
              )) ?? (
                <tr>
                  <td colSpan={7} className="empty-row">
                    No pipelines configured
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function PipelineRow({ pipeline }: { pipeline: Pipeline }) {
  const queryClient = useQueryClient();
  const [triggering, setTriggering] = useState(false);
  
  const triggerMutation = useMutation({
    mutationFn: () => dashboardApi.triggerPipeline(pipeline.id),
    onMutate: () => setTriggering(true),
    onSettled: () => setTriggering(false),
    onSuccess: (execution) => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['pipelines'] });
      queryClient.invalidateQueries({ queryKey: ['executions'] });
      alert(`Pipeline triggered! Execution ID: ${execution.id}`);
    },
    onError: (error: Error) => {
      alert(`Failed to trigger pipeline: ${error.message}`);
    },
  });
  
  const handleTrigger = async () => {
    if (confirm(`Trigger ${pipeline.name}?`)) {
      triggerMutation.mutate();
    }
  };

  return (
    <tr>
      <td>
        <div className="pipeline-name-cell">
          <span className="pipeline-name">{pipeline.name}</span>
          {pipeline.description && (
            <span className="pipeline-desc">{pipeline.description}</span>
          )}
        </div>
      </td>
      <td>
        <span className={`status-badge ${pipeline.last_status || 'idle'}`}>
          {pipeline.last_status || 'Idle'}
        </span>
      </td>
      <td>{pipeline.last_run ? formatTime(pipeline.last_run) : '--'}</td>
      <td>{pipeline.avg_duration_ms ? formatDuration(pipeline.avg_duration_ms) : '--'}</td>
      <td>
        <code className="schedule-code">{pipeline.schedule || 'Manual'}</code>
      </td>
      <td>
        {pipeline.success_rate !== undefined ? (
          <span className={`rate-badge ${pipeline.success_rate >= 95 ? 'good' : pipeline.success_rate >= 80 ? 'warn' : 'bad'}`}>
            {pipeline.success_rate}%
          </span>
        ) : (
          '--'
        )}
      </td>
      <td>
        <div className="action-buttons">
          <button className="icon-btn" title="View Details">
            <EyeIcon className="btn-icon" />
          </button>
          <button 
            className="icon-btn" 
            title="Run Now" 
            onClick={handleTrigger}
            disabled={triggering}
          >
            {triggering ? (
              <span className="spinner-sm" />
            ) : (
              <PlayIcon className="btn-icon" />
            )}
          </button>
          <button className="icon-btn" title="Stop" disabled>
            <StopIcon className="btn-icon" />
          </button>
        </div>
      </td>
    </tr>
  );
}

function formatTime(isoString: string): string {
  const date = new Date(isoString);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  
  if (isToday) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  if (minutes < 60) return `${minutes}m ${remainingSeconds}s`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours}h ${remainingMinutes}m`;
}
