/**
 * API Service for MarketSpine
 * Centralized API client with auth token handling
 */

import { useAuthStore } from '../store/authStore';
import type { ApiError, PaginatedResponse } from '../types';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

// Custom error class for API errors
export class ApiRequestError extends Error {
  code: string;
  status: number;
  details?: Record<string, unknown>;

  constructor(message: string, code: string, status: number, details?: Record<string, unknown>) {
    super(message);
    this.name = 'ApiRequestError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

// Request options type
interface RequestOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
  skipAuth?: boolean;
}

// Core fetch wrapper with auth and error handling
async function request<T>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<T> {
  const { params, skipAuth = false, ...fetchOptions } = options;
  
  // Build URL with query params
  let url = `${API_BASE}${endpoint}`;
  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.append(key, String(value));
      }
    });
    const queryString = searchParams.toString();
    if (queryString) {
      url += `?${queryString}`;
    }
  }

  // Get auth token
  const { accessToken, tokenExpiresAt, refreshAccessToken, clearAuth } = useAuthStore.getState();
  
  // Check if token needs refresh
  if (!skipAuth && accessToken && tokenExpiresAt) {
    const needsRefresh = Date.now() > tokenExpiresAt - 60000; // 1 minute buffer
    if (needsRefresh) {
      const refreshed = await refreshAccessToken();
      if (!refreshed) {
        clearAuth();
        throw new ApiRequestError('Session expired', 'SESSION_EXPIRED', 401);
      }
    }
  }

  // Build headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(fetchOptions.headers as Record<string, string>),
  };

  if (!skipAuth && accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }

  // Make request
  const response = await fetch(url, {
    ...fetchOptions,
    headers,
  });

  // Handle response
  if (!response.ok) {
    let errorData: ApiError;
    try {
      errorData = await response.json();
    } catch {
      errorData = {
        code: 'UNKNOWN_ERROR',
        message: `Request failed with status ${response.status}`,
      };
    }

    // Handle 401 - clear auth state
    if (response.status === 401) {
      clearAuth();
    }

    throw new ApiRequestError(
      errorData.message,
      errorData.code,
      response.status,
      errorData.details
    );
  }

  // Return empty object for 204 No Content
  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

// HTTP method helpers
export const api = {
  get: <T>(endpoint: string, options?: RequestOptions) =>
    request<T>(endpoint, { ...options, method: 'GET' }),

  post: <T>(endpoint: string, data?: unknown, options?: RequestOptions) =>
    request<T>(endpoint, {
      ...options,
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    }),

  put: <T>(endpoint: string, data?: unknown, options?: RequestOptions) =>
    request<T>(endpoint, {
      ...options,
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    }),

  patch: <T>(endpoint: string, data?: unknown, options?: RequestOptions) =>
    request<T>(endpoint, {
      ...options,
      method: 'PATCH',
      body: data ? JSON.stringify(data) : undefined,
    }),

  delete: <T>(endpoint: string, options?: RequestOptions) =>
    request<T>(endpoint, { ...options, method: 'DELETE' }),
};

// Paginated request helper
export async function paginatedRequest<T>(
  endpoint: string,
  page: number = 1,
  pageSize: number = 50,
  options?: RequestOptions
): Promise<PaginatedResponse<T>> {
  return api.get<PaginatedResponse<T>>(endpoint, {
    ...options,
    params: {
      ...options?.params,
      page,
      page_size: pageSize,
    },
  });
}
