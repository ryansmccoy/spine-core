/**
 * Authentication Service for MarketSpine
 * API calls for auth endpoints
 */

import { api } from './api';
import type {
  User,
  LoginRequest,
  LoginResponse,
  RefreshTokenResponse,
  PasswordResetRequest,
} from '../types/auth';

export const authService = {
  /**
   * Login with email and password
   */
  login: (credentials: LoginRequest): Promise<LoginResponse> =>
    api.post<LoginResponse>('/auth/login', credentials, { skipAuth: true }),

  /**
   * Logout current session
   */
  logout: (): Promise<void> =>
    api.post<void>('/auth/logout'),

  /**
   * Refresh access token using refresh token
   */
  refresh: (refreshToken: string): Promise<RefreshTokenResponse> =>
    api.post<RefreshTokenResponse>(
      '/auth/refresh',
      { refresh_token: refreshToken },
      { skipAuth: true }
    ),

  /**
   * Get current user profile
   */
  getCurrentUser: (): Promise<User> =>
    api.get<User>('/auth/me'),

  /**
   * Request password reset email
   */
  requestPasswordReset: (data: PasswordResetRequest): Promise<{ message: string }> =>
    api.post<{ message: string }>('/auth/password-reset', data, { skipAuth: true }),

  /**
   * Confirm password reset with token
   */
  confirmPasswordReset: (token: string, newPassword: string): Promise<{ message: string }> =>
    api.post<{ message: string }>(
      '/auth/password-reset/confirm',
      { token, new_password: newPassword },
      { skipAuth: true }
    ),

  /**
   * Change password (when logged in)
   */
  changePassword: (currentPassword: string, newPassword: string): Promise<{ message: string }> =>
    api.post<{ message: string }>('/auth/change-password', {
      current_password: currentPassword,
      new_password: newPassword,
    }),

  /**
   * Update user preferences
   */
  updatePreferences: (preferences: Partial<User['preferences']>): Promise<User> =>
    api.patch<User>('/auth/me/preferences', preferences),
};
