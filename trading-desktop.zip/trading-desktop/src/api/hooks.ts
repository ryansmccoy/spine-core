/**
 * React Query hooks for Market-Spine API
 */

import { useQuery } from '@tanstack/react-query';
import type { UseQueryOptions } from '@tanstack/react-query';
import api from './client';
import type { Price, OTCData, VenueScore, Liquidity, Symbol } from './client';

// ─────────────────────────────────────────────────────────────
// Query Keys (for cache invalidation)
// ─────────────────────────────────────────────────────────────

export const queryKeys = {
  symbols: ['symbols'] as const,
  prices: (symbol: string) => ['prices', symbol] as const,
  otc: (symbol: string) => ['otc', symbol] as const,
  otcTopVolume: ['otc-top-volume'] as const,
  venues: (symbol: string) => ['venues', symbol] as const,
  liquidity: (symbol: string) => ['liquidity', symbol] as const,
};

// ─────────────────────────────────────────────────────────────
// Hooks
// ─────────────────────────────────────────────────────────────

export function useSymbols(options?: Partial<UseQueryOptions<Symbol[]>>) {
  return useQuery({
    queryKey: queryKeys.symbols,
    queryFn: () => api.getSymbols(),
    staleTime: 5 * 60 * 1000, // 5 minutes
    ...options,
  });
}

export function usePrices(
  symbol: string | undefined,
  days: number = 30,
  options?: Partial<UseQueryOptions<Price[]>>
) {
  return useQuery({
    queryKey: queryKeys.prices(symbol || ''),
    queryFn: () => api.getPrices(symbol!, days),
    enabled: !!symbol,
    staleTime: 60 * 1000, // 1 minute
    ...options,
  });
}

export function useOTCData(
  symbol: string | undefined,
  limit: number = 12,
  options?: Partial<UseQueryOptions<OTCData[]>>
) {
  return useQuery({
    queryKey: queryKeys.otc(symbol || ''),
    queryFn: () => api.getOTCData(symbol!, limit),
    enabled: !!symbol,
    staleTime: 5 * 60 * 1000, // 5 minutes
    ...options,
  });
}

export function useOTCTopVolume(
  limit: number = 15,
  options?: Partial<UseQueryOptions<OTCData[]>>
) {
  return useQuery({
    queryKey: queryKeys.otcTopVolume,
    queryFn: () => api.getOTCTopVolume(limit),
    staleTime: 5 * 60 * 1000, // 5 minutes
    ...options,
  });
}

export function useVenues(
  symbol: string | undefined,
  options?: Partial<UseQueryOptions<VenueScore[]>>
) {
  return useQuery({
    queryKey: queryKeys.venues(symbol || ''),
    queryFn: () => api.getVenues(symbol!),
    enabled: !!symbol,
    staleTime: 60 * 1000, // 1 minute
    ...options,
  });
}

export function useLiquidity(
  symbol: string | undefined,
  options?: Partial<UseQueryOptions<Liquidity[]>>
) {
  return useQuery({
    queryKey: queryKeys.liquidity(symbol || ''),
    queryFn: () => api.getLiquidity(symbol!),
    enabled: !!symbol,
    staleTime: 60 * 1000, // 1 minute
    ...options,
  });
}
