/**
 * Optimization Page for MarketSpine
 * Bloomberg-style Portfolio Optimization, Efficient Frontier, Rebalancing
 */

import { useState } from 'react';
import {
  Target,
  TrendingUp,
  Sliders,
  Download,
  RefreshCw,
  Play,
  CheckCircle,
  AlertCircle,
  Info,
  Settings2,
  ArrowRight,
} from 'lucide-react';
import { clsx } from 'clsx';

// Mock optimization data
const mockOptimizationResult = {
  status: 'optimal',
  objective: 'maximize_sharpe',
  expectedReturn: 12.5,
  expectedRisk: 16.2,
  sharpeRatio: 0.77,
  turnover: 8.5,
  numTrades: 24,
  tradeCost: 12500,
};

const mockCurrentVsOptimal = {
  current: {
    return: 10.8,
    risk: 18.5,
    sharpe: 0.58,
  },
  optimal: {
    return: 12.5,
    risk: 16.2,
    sharpe: 0.77,
  },
};

const mockRebalanceTrades = [
  { ticker: 'AAPL', action: 'BUY', shares: 150, value: 27450, fromWeight: 8.5, toWeight: 10.2, deltaWeight: 1.7 },
  { ticker: 'MSFT', action: 'BUY', shares: 85, value: 31875, fromWeight: 7.2, toWeight: 8.5, deltaWeight: 1.3 },
  { ticker: 'XOM', action: 'SELL', shares: 200, value: -22400, fromWeight: 1.5, toWeight: 0.5, deltaWeight: -1.0 },
  { ticker: 'CVX', action: 'SELL', shares: 150, value: -23250, fromWeight: 1.2, toWeight: 0.4, deltaWeight: -0.8 },
  { ticker: 'NVDA', action: 'BUY', shares: 50, value: 42500, fromWeight: 4.5, toWeight: 5.8, deltaWeight: 1.3 },
  { ticker: 'WMT', action: 'SELL', shares: 100, value: -15800, fromWeight: 0.8, toWeight: 0.3, deltaWeight: -0.5 },
];

const mockConstraints = [
  { name: 'Max Single Position', value: '10%', status: 'active' },
  { name: 'Min Sector Weight', value: '2%', status: 'active' },
  { name: 'Max Sector Weight', value: '35%', status: 'active' },
  { name: 'Max Turnover', value: '15%', status: 'active' },
  { name: 'Cash Reserve', value: '2%', status: 'active' },
  { name: 'Beta Range', value: '0.8-1.2', status: 'warning' },
];

const mockEfficientFrontier = [
  { risk: 10, return: 6.5 },
  { risk: 12, return: 8.2 },
  { risk: 14, return: 9.8 },
  { risk: 16.2, return: 12.5 }, // Optimal
  { risk: 18, return: 13.8 },
  { risk: 20, return: 14.5 },
  { risk: 22, return: 15.0 },
  { risk: 24, return: 15.2 },
];

const mockSectorAllocation = [
  { sector: 'Technology', current: 32.5, optimal: 35.0, delta: 2.5 },
  { sector: 'Healthcare', current: 14.2, optimal: 15.5, delta: 1.3 },
  { sector: 'Financials', current: 12.8, optimal: 12.0, delta: -0.8 },
  { sector: 'Consumer Disc', current: 11.5, optimal: 12.5, delta: 1.0 },
  { sector: 'Industrials', current: 9.2, optimal: 8.5, delta: -0.7 },
  { sector: 'Energy', current: 4.2, optimal: 2.0, delta: -2.2 },
  { sector: 'Other', current: 15.6, optimal: 14.5, delta: -1.1 },
];

export default function OptimizationPage() {
  const [activeTab, setActiveTab] = useState<'optimizer' | 'frontier' | 'rebalance'>('optimizer');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [objective, setObjective] = useState('maximize_sharpe');

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => setIsOptimizing(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Portfolio Optimization</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Mean-Variance Optimization, Efficient Frontier, Rebalancing
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleOptimize}
            disabled={isOptimizing}
            className={clsx(
              'btn text-sm flex items-center gap-1.5',
              isOptimizing ? 'bg-[#565674] text-white' : 'bg-[#FF6B35] hover:bg-[#FF8C42] text-white'
            )}
          >
            {isOptimizing ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Run Optimization
              </>
            )}
          </button>
          <button className="btn btn-secondary text-sm">
            <Download className="h-4 w-4 mr-1.5" />
            Export
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 p-1 bg-[#1B1B29] rounded-lg w-fit">
        {[
          { id: 'optimizer', label: 'Optimizer', icon: Target },
          { id: 'frontier', label: 'Efficient Frontier', icon: TrendingUp },
          { id: 'rebalance', label: 'Rebalance Trades', icon: Sliders },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={clsx(
              'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
              activeTab === tab.id
                ? 'bg-[#FF6B35] text-white'
                : 'text-[#8B949E] hover:text-white hover:bg-[#21262D]'
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Optimizer Tab */}
      {activeTab === 'optimizer' && (
        <div className="space-y-4">
          {/* Configuration */}
          <div className="grid gap-4 lg:grid-cols-3">
            {/* Objective Function */}
            <div className="card rounded-lg p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Objective Function</h3>
              <div className="space-y-2">
                {[
                  { id: 'maximize_sharpe', label: 'Maximize Sharpe Ratio' },
                  { id: 'maximize_return', label: 'Maximize Return' },
                  { id: 'minimize_risk', label: 'Minimize Risk' },
                  { id: 'min_tracking_error', label: 'Minimize Tracking Error' },
                ].map((obj) => (
                  <label key={obj.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="objective"
                      value={obj.id}
                      checked={objective === obj.id}
                      onChange={(e) => setObjective(e.target.value)}
                      className="accent-[#FF6B35]"
                    />
                    <span className="text-sm text-[#E6EDF3]">{obj.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Constraints */}
            <div className="card rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-white">Constraints</h3>
                <button className="text-[#565674] hover:text-white">
                  <Settings2 className="h-4 w-4" />
                </button>
              </div>
              <div className="space-y-2">
                {mockConstraints.map((constraint, idx) => (
                  <div key={idx} className="flex items-center justify-between py-1">
                    <span className="text-xs text-[#8B949E]">{constraint.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-[#E6EDF3] font-mono">{constraint.value}</span>
                      {constraint.status === 'warning' && (
                        <AlertCircle className="h-3 w-3 text-[#FFD700]" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Result Summary */}
            <div className="card rounded-lg p-4 border-l-4 border-l-[#3FB950]">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-white">Optimization Result</h3>
                <CheckCircle className="h-4 w-4 text-[#3FB950]" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs text-[#8B949E]">Expected Return</span>
                  <span className="text-sm text-[#3FB950] font-mono">{mockOptimizationResult.expectedReturn}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-[#8B949E]">Expected Risk</span>
                  <span className="text-sm text-white font-mono">{mockOptimizationResult.expectedRisk}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-[#8B949E]">Sharpe Ratio</span>
                  <span className="text-sm text-[#FFD700] font-mono">{mockOptimizationResult.sharpeRatio}</span>
                </div>
                <hr className="border-[#21262D] my-2" />
                <div className="flex justify-between">
                  <span className="text-xs text-[#8B949E]">Turnover</span>
                  <span className="text-sm text-white font-mono">{mockOptimizationResult.turnover}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-[#8B949E]">Trade Cost</span>
                  <span className="text-sm text-[#F85149] font-mono">${mockOptimizationResult.tradeCost.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Current vs Optimal Comparison */}
          <div className="card rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-4">Current vs Optimal Portfolio</h3>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="text-center">
                <p className="text-xs text-[#565674] uppercase tracking-wider mb-2">Expected Return</p>
                <div className="flex items-center justify-center gap-3">
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#8B949E]">{mockCurrentVsOptimal.current.return}%</p>
                    <p className="text-[10px] text-[#565674]">Current</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#3FB950]" />
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#3FB950]">{mockCurrentVsOptimal.optimal.return}%</p>
                    <p className="text-[10px] text-[#565674]">Optimal</p>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#565674] uppercase tracking-wider mb-2">Expected Risk</p>
                <div className="flex items-center justify-center gap-3">
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#8B949E]">{mockCurrentVsOptimal.current.risk}%</p>
                    <p className="text-[10px] text-[#565674]">Current</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#3FB950]" />
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#3FB950]">{mockCurrentVsOptimal.optimal.risk}%</p>
                    <p className="text-[10px] text-[#565674]">Optimal</p>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#565674] uppercase tracking-wider mb-2">Sharpe Ratio</p>
                <div className="flex items-center justify-center gap-3">
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#8B949E]">{mockCurrentVsOptimal.current.sharpe}</p>
                    <p className="text-[10px] text-[#565674]">Current</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#3FB950]" />
                  <div className="text-center">
                    <p className="text-xl font-mono text-[#FFD700]">{mockCurrentVsOptimal.optimal.sharpe}</p>
                    <p className="text-[10px] text-[#565674]">Optimal</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sector Allocation Changes */}
          <div className="card rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-4">Sector Allocation Changes</h3>
            <div className="space-y-3">
              {mockSectorAllocation.map((sector, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-[#E6EDF3]">{sector.sector}</span>
                    <div className="flex items-center gap-4">
                      <span className="text-[#8B949E] font-mono">{sector.current.toFixed(1)}%</span>
                      <ArrowRight className="h-3 w-3 text-[#565674]" />
                      <span className="text-white font-mono">{sector.optimal.toFixed(1)}%</span>
                      <span className={clsx(
                        'text-xs font-mono w-16 text-right',
                        sector.delta >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                      )}>
                        {sector.delta >= 0 ? '+' : ''}{sector.delta.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  <div className="h-2 bg-[#21262D] rounded-full overflow-hidden relative">
                    <div
                      className="absolute h-full bg-[#565674] rounded-full"
                      style={{ width: `${sector.current * 2.5}%` }}
                    />
                    <div
                      className={clsx(
                        'absolute h-full rounded-full',
                        sector.delta >= 0 ? 'bg-[#3FB950]' : 'bg-[#F85149]'
                      )}
                      style={{ width: `${sector.optimal * 2.5}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Efficient Frontier Tab */}
      {activeTab === 'frontier' && (
        <div className="space-y-4">
          <div className="card rounded-lg p-4">
            <div className="flex items-center gap-2 mb-4">
              <h3 className="text-sm font-semibold text-white">Efficient Frontier</h3>
              <div className="flex items-center gap-1 text-[#565674]">
                <Info className="h-3 w-3" />
                <span className="text-xs">Click a point to see portfolio composition</span>
              </div>
            </div>
            {/* Chart Placeholder */}
            <div className="h-80 flex items-center justify-center bg-[#1B1B29] rounded-lg relative">
              {/* Simple visual representation */}
              <div className="absolute inset-4">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {/* Axes */}
                  <line x1="40" y1="260" x2="380" y2="260" stroke="#30363D" strokeWidth="1" />
                  <line x1="40" y1="260" x2="40" y2="20" stroke="#30363D" strokeWidth="1" />
                  
                  {/* X Axis Label */}
                  <text x="210" y="290" fill="#565674" fontSize="12" textAnchor="middle">Risk (%)</text>
                  
                  {/* Y Axis Label */}
                  <text x="15" y="140" fill="#565674" fontSize="12" textAnchor="middle" transform="rotate(-90, 15, 140)">Return (%)</text>
                  
                  {/* Frontier Curve */}
                  <path
                    d="M60,220 Q120,180 160,140 Q200,100 240,75 Q300,55 360,50"
                    fill="none"
                    stroke="#FF6B35"
                    strokeWidth="2"
                  />
                  
                  {/* Current Portfolio Point */}
                  <circle cx="200" cy="150" r="8" fill="#F85149" />
                  <text x="200" y="170" fill="#F85149" fontSize="10" textAnchor="middle">Current</text>
                  
                  {/* Optimal Portfolio Point */}
                  <circle cx="160" cy="100" r="8" fill="#3FB950" />
                  <text x="160" y="90" fill="#3FB950" fontSize="10" textAnchor="middle">Optimal</text>
                  
                  {/* Arrow from Current to Optimal */}
                  <line x1="195" y1="145" x2="168" y2="108" stroke="#FFD700" strokeWidth="1.5" strokeDasharray="4,2" />
                  <polygon points="168,108 172,115 165,113" fill="#FFD700" />
                </svg>
              </div>
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#FF6B35]" />
                <span className="text-xs text-[#8B949E]">Efficient Frontier</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#F85149]" />
                <span className="text-xs text-[#8B949E]">Current Portfolio</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#3FB950]" />
                <span className="text-xs text-[#8B949E]">Optimal Portfolio</span>
              </div>
            </div>
          </div>

          {/* Frontier Points Table */}
          <div className="card rounded-lg overflow-hidden">
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="bg-[#21262D]">
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Risk (%)</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Return (%)</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Sharpe</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Status</th>
                </tr>
              </thead>
              <tbody>
                {mockEfficientFrontier.map((point, idx) => {
                  const sharpe = (point.return - 2) / point.risk; // Assuming 2% risk-free
                  const isOptimal = point.risk === 16.2;
                  return (
                    <tr key={idx} className={clsx(
                      'border-b border-[#21262D]/50 hover:bg-[#21262D]/30 cursor-pointer',
                      isOptimal && 'bg-[#3FB950]/10'
                    )}>
                      <td className="py-2 px-3 text-[#E6EDF3]">{point.risk.toFixed(1)}</td>
                      <td className="py-2 px-3 text-[#3FB950]">{point.return.toFixed(1)}</td>
                      <td className="py-2 px-3 text-[#FFD700]">{sharpe.toFixed(2)}</td>
                      <td className="py-2 px-3">
                        {isOptimal && (
                          <span className="px-2 py-0.5 rounded text-xs bg-[#3FB950]/20 text-[#3FB950]">
                            Max Sharpe
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Rebalance Trades Tab */}
      {activeTab === 'rebalance' && (
        <div className="space-y-4">
          {/* Trade Summary */}
          <div className="grid gap-3 sm:grid-cols-4">
            <div className="card rounded-lg p-3">
              <p className="text-xs text-[#565674]">Total Trades</p>
              <p className="text-xl font-bold text-white font-mono">{mockRebalanceTrades.length}</p>
            </div>
            <div className="card rounded-lg p-3">
              <p className="text-xs text-[#565674]">Buy Value</p>
              <p className="text-xl font-bold text-[#3FB950] font-mono">
                ${mockRebalanceTrades.filter(t => t.action === 'BUY').reduce((s, t) => s + t.value, 0).toLocaleString()}
              </p>
            </div>
            <div className="card rounded-lg p-3">
              <p className="text-xs text-[#565674]">Sell Value</p>
              <p className="text-xl font-bold text-[#F85149] font-mono">
                ${Math.abs(mockRebalanceTrades.filter(t => t.action === 'SELL').reduce((s, t) => s + t.value, 0)).toLocaleString()}
              </p>
            </div>
            <div className="card rounded-lg p-3">
              <p className="text-xs text-[#565674]">Est. Cost</p>
              <p className="text-xl font-bold text-[#FFD700] font-mono">${mockOptimizationResult.tradeCost.toLocaleString()}</p>
            </div>
          </div>

          {/* Trade List */}
          <div className="card rounded-lg overflow-hidden">
            <div className="bg-[#21262D] px-4 py-3 border-b border-[#30363D] flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Rebalancing Trades</h3>
              <button className="btn btn-secondary text-xs">
                <Play className="h-3 w-3 mr-1" />
                Execute All
              </button>
            </div>
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="border-b border-[#21262D]">
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Ticker</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Action</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Shares</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Value</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">From Wt</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">To Wt</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Δ Wt</th>
                </tr>
              </thead>
              <tbody>
                {mockRebalanceTrades.map((trade, idx) => (
                  <tr key={idx} className="border-b border-[#21262D]/50 hover:bg-[#21262D]/30">
                    <td className="py-2.5 px-3 text-[#E6EDF3] font-medium">{trade.ticker}</td>
                    <td className="py-2.5 px-3">
                      <span className={clsx(
                        'px-2 py-0.5 rounded text-xs font-semibold',
                        trade.action === 'BUY'
                          ? 'bg-[#3FB950]/20 text-[#3FB950]'
                          : 'bg-[#F85149]/20 text-[#F85149]'
                      )}>
                        {trade.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#E6EDF3]">{trade.shares.toLocaleString()}</td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right',
                      trade.value >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {trade.value >= 0 ? '+' : ''}${trade.value.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#8B949E]">{trade.fromWeight.toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-right text-white">{trade.toWeight.toFixed(1)}%</td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right font-semibold',
                      trade.deltaWeight >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {trade.deltaWeight >= 0 ? '+' : ''}{trade.deltaWeight.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
