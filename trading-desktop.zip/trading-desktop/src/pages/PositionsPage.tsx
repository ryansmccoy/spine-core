import { useState } from 'react'
import {
  TrendingUp,
  TrendingDown,
  ArrowUpDown,
  Filter,
  Download,
  Search,
  MoreVertical,
} from 'lucide-react'
import { clsx } from 'clsx'
import { mockPositions } from '../data/mockData'

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

type SortField = 'symbol' | 'marketValue' | 'unrealizedPnL' | 'weight' | 'dayChange'
type SortDirection = 'asc' | 'desc'

export default function PositionsPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [sortField, setSortField] = useState<SortField>('marketValue')
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc')
  const [selectedSector, setSelectedSector] = useState<string>('all')

  // Get unique sectors
  const sectors = ['all', ...new Set(mockPositions.map(p => p.sector))]

  // Filter and sort positions
  const filteredPositions = mockPositions
    .filter(p => {
      const matchesSearch = p.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.name.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesSector = selectedSector === 'all' || p.sector === selectedSector
      return matchesSearch && matchesSector
    })
    .sort((a, b) => {
      const aVal = a[sortField]
      const bVal = b[sortField]
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal)
      }
      return sortDirection === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number)
    })

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('desc')
    }
  }

  // Calculate totals
  const totalMarketValue = filteredPositions.reduce((sum, p) => sum + p.marketValue, 0)
  const totalUnrealizedPnL = filteredPositions.reduce((sum, p) => sum + p.unrealizedPnL, 0)
  const totalDayChange = filteredPositions.reduce((sum, p) => sum + (p.dayChange * p.shares), 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Positions</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            {filteredPositions.length} positions • {formatCurrency(totalMarketValue)} total value
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="card rounded-xl p-5">
          <p className="text-sm text-gray-500 dark:text-[#565674]">Total Market Value</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
            {formatCurrency(totalMarketValue)}
          </p>
        </div>
        <div className="card rounded-xl p-5">
          <p className="text-sm text-gray-500 dark:text-[#565674]">Unrealized P&L</p>
          <p className={clsx(
            'text-2xl font-bold mt-1',
            totalUnrealizedPnL >= 0 ? 'text-success' : 'text-danger'
          )}>
            {totalUnrealizedPnL >= 0 ? '+' : ''}{formatCurrency(totalUnrealizedPnL)}
          </p>
        </div>
        <div className="card rounded-xl p-5">
          <p className="text-sm text-gray-500 dark:text-[#565674]">Day Change</p>
          <p className={clsx(
            'text-2xl font-bold mt-1',
            totalDayChange >= 0 ? 'text-success' : 'text-danger'
          )}>
            {totalDayChange >= 0 ? '+' : ''}{formatCurrency(totalDayChange)}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="card rounded-xl p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search positions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pl-10"
            />
          </div>
          <div className="flex items-center gap-3">
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="input w-auto"
            >
              {sectors.map(sector => (
                <option key={sector} value={sector}>
                  {sector === 'all' ? 'All Sectors' : sector}
                </option>
              ))}
            </select>
            <button className="btn btn-secondary">
              <Filter className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Positions Table */}
      <div className="card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 dark:bg-[#1B1B29] border-b border-gray-100 dark:border-[#2D2D43]">
                <th 
                  className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider cursor-pointer hover:text-gray-700 dark:hover:text-gray-300"
                  onClick={() => handleSort('symbol')}
                >
                  <div className="flex items-center gap-1">
                    Symbol
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Shares
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Avg Cost
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Price
                </th>
                <th 
                  className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider cursor-pointer hover:text-gray-700 dark:hover:text-gray-300"
                  onClick={() => handleSort('marketValue')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Market Value
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th 
                  className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider cursor-pointer hover:text-gray-700 dark:hover:text-gray-300"
                  onClick={() => handleSort('unrealizedPnL')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Unrealized P&L
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th 
                  className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider cursor-pointer hover:text-gray-700 dark:hover:text-gray-300"
                  onClick={() => handleSort('dayChange')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Day Change
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th 
                  className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider cursor-pointer hover:text-gray-700 dark:hover:text-gray-300"
                  onClick={() => handleSort('weight')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Weight
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-[#2D2D43]">
              {filteredPositions.map((position) => (
                <tr 
                  key={position.id}
                  className="hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43] font-semibold text-sm text-gray-700 dark:text-gray-300">
                        {position.symbol.slice(0, 2)}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white">{position.symbol}</p>
                        <p className="text-xs text-gray-500 dark:text-[#565674]">{position.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-medium text-gray-900 dark:text-white">
                    {position.shares.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-right text-gray-600 dark:text-gray-400">
                    ${position.avgCost.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-right font-medium text-gray-900 dark:text-white">
                    ${position.currentPrice.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-right font-semibold text-gray-900 dark:text-white">
                    {formatCurrency(position.marketValue)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className={clsx(
                      'flex flex-col items-end',
                      position.unrealizedPnL >= 0 ? 'text-success' : 'text-danger'
                    )}>
                      <span className="font-semibold flex items-center gap-1">
                        {position.unrealizedPnL >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {position.unrealizedPnL >= 0 ? '+' : ''}{formatCurrency(position.unrealizedPnL)}
                      </span>
                      <span className="text-xs">
                        {position.unrealizedPnLPercent >= 0 ? '+' : ''}{position.unrealizedPnLPercent.toFixed(2)}%
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className={clsx(
                      'flex flex-col items-end',
                      position.dayChange >= 0 ? 'text-success' : 'text-danger'
                    )}>
                      <span className="font-medium">
                        {position.dayChange >= 0 ? '+' : ''}${position.dayChange.toFixed(2)}
                      </span>
                      <span className="text-xs">
                        {position.dayChangePercent >= 0 ? '+' : ''}{position.dayChangePercent.toFixed(2)}%
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right text-gray-600 dark:text-gray-400">
                    {position.weight.toFixed(1)}%
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 hover:bg-gray-100 dark:hover:bg-[#2D2D43] rounded-lg transition-colors">
                      <MoreVertical className="h-4 w-4 text-gray-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
