import { useState } from 'react'
import { Clock, ExternalLink, Tag, Search, Filter } from 'lucide-react'
import { clsx } from 'clsx'
import { newsItems } from '../data/mockData'

const categories = ['All', 'Earnings', 'M&A', 'Market', 'Economy', 'Technology', 'Healthcare']

export default function NewsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedArticle, setSelectedArticle] = useState<typeof newsItems[0] | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  const filteredNews = newsItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.summary.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Market News</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Stay updated with the latest financial news
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search news..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input pl-10 w-full"
          />
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={clsx(
                'px-3 py-1.5 text-sm font-medium rounded-lg transition-colors',
                selectedCategory === category
                  ? 'bg-primary-500 text-white'
                  : 'bg-gray-100 dark:bg-[#1B1B29] text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-[#2D2D43]'
              )}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* News List */}
        <div className="lg:col-span-2 space-y-4">
          {filteredNews.length === 0 ? (
            <div className="card rounded-xl p-12 text-center">
              <p className="text-gray-500 dark:text-[#565674]">No news articles found</p>
            </div>
          ) : (
            filteredNews.map((item) => (
              <article
                key={item.id}
                onClick={() => setSelectedArticle(item)}
                className={clsx(
                  'card rounded-xl p-5 cursor-pointer transition-all hover:shadow-md',
                  selectedArticle?.id === item.id && 'ring-2 ring-primary-500'
                )}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={clsx(
                        'badge',
                        item.sentiment === 'positive' ? 'badge-success' :
                        item.sentiment === 'negative' ? 'badge-danger' :
                        'badge-secondary'
                      )}>
                        {item.category}
                      </span>
                      {item.tickers.slice(0, 3).map((ticker) => (
                        <span
                          key={ticker}
                          className="px-2 py-0.5 text-xs font-medium bg-primary-100 dark:bg-primary-900/30 text-primary-600 rounded"
                        >
                          {ticker}
                        </span>
                      ))}
                      {item.tickers.length > 3 && (
                        <span className="text-xs text-gray-500 dark:text-[#565674]">
                          +{item.tickers.length - 3} more
                        </span>
                      )}
                    </div>
                    <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                      {item.summary}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-[#565674]">
                      <span className="font-medium">{item.source}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {item.time}
                      </span>
                    </div>
                  </div>
                </div>
              </article>
            ))
          )}
        </div>

        {/* Article Detail */}
        <div className="lg:col-span-1">
          {selectedArticle ? (
            <div className="card rounded-xl p-6 sticky top-6">
              <div className="mb-4">
                <span className={clsx(
                  'badge mb-3',
                  selectedArticle.sentiment === 'positive' ? 'badge-success' :
                  selectedArticle.sentiment === 'negative' ? 'badge-danger' :
                  'badge-secondary'
                )}>
                  {selectedArticle.category}
                </span>
                <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                  {selectedArticle.title}
                </h2>
                <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-[#565674]">
                  <span className="font-medium">{selectedArticle.source}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {selectedArticle.time}
                  </span>
                </div>
              </div>

              <div className="prose prose-sm dark:prose-invert max-w-none mb-6">
                <p className="text-gray-600 dark:text-gray-400">{selectedArticle.summary}</p>
                <p className="text-gray-600 dark:text-gray-400 mt-4">
                  This is a mock article preview. In a real application, the full article content
                  would be displayed here with proper formatting, images, and related data.
                </p>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Related Symbols</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedArticle.tickers.map((ticker) => (
                    <button
                      key={ticker}
                      className="px-3 py-1.5 text-sm font-medium bg-primary-100 dark:bg-primary-900/30 text-primary-600 rounded-lg hover:bg-primary-200 dark:hover:bg-primary-900/50 transition-colors"
                    >
                      {ticker}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button className="btn btn-primary flex-1 flex items-center justify-center gap-2">
                  <ExternalLink className="h-4 w-4" />
                  Read Full Article
                </button>
              </div>
            </div>
          ) : (
            <div className="card rounded-xl p-12 text-center">
              <div className="text-gray-400 dark:text-[#565674]">
                <Tag className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select an article to read</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
