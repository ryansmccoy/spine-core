import { useState } from 'react'
import {
  Users,
  Settings,
  Database,
  Activity,
  Shield,
  Server,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  FileText,
  RefreshCw,
} from 'lucide-react'
import { clsx } from 'clsx'

const systemMetrics = [
  { name: 'API Latency', value: '45ms', status: 'healthy', icon: Activity },
  { name: 'Database', value: 'Connected', status: 'healthy', icon: Database },
  { name: 'Market Feed', value: 'Active', status: 'healthy', icon: TrendingUp },
  { name: 'Auth Service', value: 'Online', status: 'healthy', icon: Shield },
]

const recentActivity = [
  { action: 'User login', user: 'admin@trading.com', time: '2 min ago', status: 'success' },
  { action: 'API key generated', user: 'john@company.com', time: '15 min ago', status: 'success' },
  { action: 'Failed login attempt', user: 'unknown@test.com', time: '1 hour ago', status: 'warning' },
  { action: 'Data export', user: 'analyst@trading.com', time: '2 hours ago', status: 'success' },
  { action: 'Settings changed', user: 'admin@trading.com', time: '3 hours ago', status: 'success' },
]

const users = [
  { name: 'John Smith', email: 'john@company.com', role: 'Trader', status: 'active', lastActive: '5 min ago' },
  { name: 'Jane Doe', email: 'jane@company.com', role: 'Analyst', status: 'active', lastActive: '1 hour ago' },
  { name: 'Bob Wilson', email: 'bob@company.com', role: 'Admin', status: 'active', lastActive: '10 min ago' },
  { name: 'Alice Brown', email: 'alice@company.com', role: 'Viewer', status: 'inactive', lastActive: '2 days ago' },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'system' | 'logs'>('overview')

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            System monitoring and user management
          </p>
        </div>
        <button className="btn btn-primary flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh Status
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-[#2D2D43]">
        <nav className="flex gap-6">
          {[
            { id: 'overview', name: 'Overview', icon: Activity },
            { id: 'users', name: 'Users', icon: Users },
            { id: 'system', name: 'System', icon: Server },
            { id: 'logs', name: 'Logs', icon: FileText },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={clsx(
                'flex items-center gap-2 pb-3 text-sm font-medium border-b-2 -mb-px transition-colors',
                activeTab === tab.id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              )}
            >
              <tab.icon className="h-4 w-4" />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* System Status Cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {systemMetrics.map((metric) => (
              <div key={metric.name} className="card rounded-xl p-5">
                <div className="flex items-center gap-4">
                  <div className={clsx(
                    'flex h-12 w-12 items-center justify-center rounded-lg',
                    metric.status === 'healthy' ? 'bg-success/10' : 'bg-danger/10'
                  )}>
                    <metric.icon className={clsx(
                      'h-6 w-6',
                      metric.status === 'healthy' ? 'text-success' : 'text-danger'
                    )} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">{metric.name}</p>
                    <div className="flex items-center gap-2">
                      <p className="text-lg font-semibold text-gray-900 dark:text-white">
                        {metric.value}
                      </p>
                      <span className={clsx(
                        'status-dot',
                        metric.status === 'healthy' ? 'bg-success' : 'bg-danger'
                      )} />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary Cards */}
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Quick Stats */}
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Quick Stats</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">24</p>
                  <p className="text-sm text-gray-500 dark:text-[#565674]">Active Users</p>
                </div>
                <div className="p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">1,247</p>
                  <p className="text-sm text-gray-500 dark:text-[#565674]">API Calls Today</p>
                </div>
                <div className="p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">99.9%</p>
                  <p className="text-sm text-gray-500 dark:text-[#565674]">Uptime</p>
                </div>
                <div className="p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">3</p>
                  <p className="text-sm text-gray-500 dark:text-[#565674]">Warnings</p>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {recentActivity.slice(0, 4).map((activity, index) => (
                  <div key={index} className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-3">
                      {activity.status === 'success' ? (
                        <CheckCircle className="h-4 w-4 text-success" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-warning" />
                      )}
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.action}</p>
                        <p className="text-xs text-gray-500 dark:text-[#565674]">{activity.user}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 dark:text-[#565674]">{activity.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <input
                type="text"
                placeholder="Search users..."
                className="input w-64"
              />
            </div>
            <button className="btn btn-primary">Add User</button>
          </div>

          <div className="card rounded-xl overflow-hidden">
            <table className="table w-full">
              <thead>
                <tr>
                  <th className="text-left">User</th>
                  <th className="text-left">Role</th>
                  <th className="text-left">Status</th>
                  <th className="text-left">Last Active</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={index}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900/30">
                          <span className="text-sm font-medium text-primary-600">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{user.name}</p>
                          <p className="text-xs text-gray-500 dark:text-[#565674]">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={clsx(
                        'badge',
                        user.role === 'Admin' ? 'badge-primary' :
                        user.role === 'Trader' ? 'badge-success' :
                        user.role === 'Analyst' ? 'badge-info' :
                        'badge-secondary'
                      )}>
                        {user.role}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <span className={clsx(
                          'status-dot',
                          user.status === 'active' ? 'bg-success' : 'bg-gray-400'
                        )} />
                        <span className="text-sm capitalize text-gray-600 dark:text-gray-400">{user.status}</span>
                      </div>
                    </td>
                    <td className="text-sm text-gray-600 dark:text-gray-400">{user.lastActive}</td>
                    <td className="text-right">
                      <button className="text-sm text-primary-600 hover:text-primary-700">Edit</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* System Tab */}
      {activeTab === 'system' && (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card rounded-xl p-6">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Server Status</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">CPU Usage</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-success rounded-full" style={{ width: '35%' }} />
                  </div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">35%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Memory</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-warning rounded-full" style={{ width: '62%' }} />
                  </div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">62%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Disk</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-info rounded-full" style={{ width: '45%' }} />
                  </div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">45%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="card rounded-xl p-6">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Services</h3>
            <div className="space-y-3">
              {[
                { name: 'Trading Engine', status: 'running' },
                { name: 'Market Data Feed', status: 'running' },
                { name: 'Order Router', status: 'running' },
                { name: 'Risk Manager', status: 'running' },
                { name: 'Report Generator', status: 'stopped' },
              ].map((service, index) => (
                <div key={index} className="flex items-center justify-between py-2">
                  <span className="text-sm text-gray-900 dark:text-white">{service.name}</span>
                  <div className="flex items-center gap-2">
                    <span className={clsx(
                      'status-dot',
                      service.status === 'running' ? 'bg-success' : 'bg-gray-400'
                    )} />
                    <span className={clsx(
                      'text-xs capitalize',
                      service.status === 'running' ? 'text-success' : 'text-gray-500'
                    )}>
                      {service.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Logs Tab */}
      {activeTab === 'logs' && (
        <div className="card rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">System Logs</h3>
            <select className="input w-40">
              <option>All Levels</option>
              <option>Error</option>
              <option>Warning</option>
              <option>Info</option>
            </select>
          </div>
          <div className="font-mono text-sm bg-gray-900 text-green-400 p-4 rounded-lg max-h-96 overflow-y-auto">
            <div className="space-y-1">
              <p><span className="text-gray-500">[2024-01-15 09:45:12]</span> <span className="text-info">[INFO]</span> Market data feed connected</p>
              <p><span className="text-gray-500">[2024-01-15 09:45:10]</span> <span className="text-info">[INFO]</span> Trading engine started</p>
              <p><span className="text-gray-500">[2024-01-15 09:44:58]</span> <span className="text-info">[INFO]</span> Database connection established</p>
              <p><span className="text-gray-500">[2024-01-15 09:44:45]</span> <span className="text-warning">[WARN]</span> High memory usage detected</p>
              <p><span className="text-gray-500">[2024-01-15 09:44:30]</span> <span className="text-info">[INFO]</span> User session started: admin@trading.com</p>
              <p><span className="text-gray-500">[2024-01-15 09:43:22]</span> <span className="text-danger">[ERROR]</span> Failed to connect to backup server</p>
              <p><span className="text-gray-500">[2024-01-15 09:42:15]</span> <span className="text-info">[INFO]</span> System startup complete</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
