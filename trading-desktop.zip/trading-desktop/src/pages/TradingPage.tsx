import { useState } from 'react'
import {
  ArrowUpCircle,
  ArrowDownCircle,
  RefreshCw,
  Clock,
  DollarSign,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react'
import { clsx } from 'clsx'
import { watchlistItems } from '../data/mockData'

type OrderSide = 'buy' | 'sell'
type OrderType = 'market' | 'limit' | 'stop' | 'stopLimit'
type TimeInForce = 'day' | 'gtc' | 'ioc' | 'fok'

export default function TradingPage() {
  const [selectedSymbol, setSelectedSymbol] = useState(watchlistItems[0])
  const [orderSide, setOrderSide] = useState<OrderSide>('buy')
  const [orderType, setOrderType] = useState<OrderType>('market')
  const [quantity, setQuantity] = useState('')
  const [limitPrice, setLimitPrice] = useState('')
  const [stopPrice, setStopPrice] = useState('')
  const [timeInForce, setTimeInForce] = useState<TimeInForce>('day')

  const estimatedCost = selectedSymbol && quantity
    ? parseFloat(quantity) * selectedSymbol.price
    : 0

  const handleSubmitOrder = () => {
    alert(`Order submitted: ${orderSide.toUpperCase()} ${quantity} ${selectedSymbol.symbol} @ ${orderType === 'market' ? 'Market' : `$${limitPrice}`}`)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Trade</h1>
        <p className="text-sm text-gray-500 dark:text-[#565674]">
          Execute buy and sell orders
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Symbol Selector */}
        <div className="lg:col-span-1 space-y-4">
          <div className="card rounded-xl p-4">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Select Symbol</h3>
            <input
              type="text"
              placeholder="Search symbol..."
              className="input w-full mb-3"
            />
            <div className="max-h-64 overflow-y-auto space-y-1">
              {watchlistItems.map((item) => (
                <button
                  key={item.symbol}
                  onClick={() => setSelectedSymbol(item)}
                  className={clsx(
                    'w-full flex items-center justify-between p-3 rounded-lg transition-colors',
                    selectedSymbol.symbol === item.symbol
                      ? 'bg-primary-50 dark:bg-primary-900/20'
                      : 'hover:bg-gray-50 dark:hover:bg-[#1B1B29]'
                  )}
                >
                  <div className="text-left">
                    <p className="font-medium text-gray-900 dark:text-white">{item.symbol}</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">{item.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900 dark:text-white">${item.price.toFixed(2)}</p>
                    <p className={clsx(
                      'text-xs',
                      item.changePercent >= 0 ? 'pnl-positive' : 'pnl-negative'
                    )}>
                      {item.changePercent >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Order Entry */}
        <div className="lg:col-span-2">
          <div className="card rounded-xl p-6">
            {/* Selected Symbol Info */}
            <div className="flex items-center justify-between mb-6 pb-6 border-b border-gray-200 dark:border-[#2D2D43]">
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">{selectedSymbol.symbol}</h2>
                <p className="text-sm text-gray-500 dark:text-[#565674]">{selectedSymbol.name}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  ${selectedSymbol.price.toFixed(2)}
                </p>
                <p className={clsx(
                  'text-sm',
                  selectedSymbol.changePercent >= 0 ? 'pnl-positive' : 'pnl-negative'
                )}>
                  {selectedSymbol.change >= 0 ? '+' : ''}${selectedSymbol.change.toFixed(2)} ({selectedSymbol.changePercent.toFixed(2)}%)
                </p>
              </div>
            </div>

            {/* Order Side */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                onClick={() => setOrderSide('buy')}
                className={clsx(
                  'flex items-center justify-center gap-2 py-3 rounded-lg font-semibold transition-all',
                  orderSide === 'buy'
                    ? 'bg-success text-white'
                    : 'bg-gray-100 dark:bg-[#1B1B29] text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-[#2D2D43]'
                )}
              >
                <ArrowUpCircle className="h-5 w-5" />
                Buy
              </button>
              <button
                onClick={() => setOrderSide('sell')}
                className={clsx(
                  'flex items-center justify-center gap-2 py-3 rounded-lg font-semibold transition-all',
                  orderSide === 'sell'
                    ? 'bg-danger text-white'
                    : 'bg-gray-100 dark:bg-[#1B1B29] text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-[#2D2D43]'
                )}
              >
                <ArrowDownCircle className="h-5 w-5" />
                Sell
              </button>
            </div>

            {/* Order Type */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Order Type
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['market', 'limit', 'stop', 'stopLimit'] as OrderType[]).map((type) => (
                  <button
                    key={type}
                    onClick={() => setOrderType(type)}
                    className={clsx(
                      'py-2 px-3 text-sm font-medium rounded-lg transition-colors',
                      orderType === type
                        ? 'bg-primary-500 text-white'
                        : 'bg-gray-100 dark:bg-[#1B1B29] text-gray-600 dark:text-gray-400'
                    )}
                  >
                    {type === 'stopLimit' ? 'Stop Limit' : type.charAt(0).toUpperCase() + type.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity & Price */}
            <div className="grid gap-4 sm:grid-cols-2 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Quantity
                </label>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="0"
                  className="input w-full"
                />
              </div>

              {(orderType === 'limit' || orderType === 'stopLimit') && (
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Limit Price
                  </label>
                  <input
                    type="number"
                    value={limitPrice}
                    onChange={(e) => setLimitPrice(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    className="input w-full"
                  />
                </div>
              )}

              {(orderType === 'stop' || orderType === 'stopLimit') && (
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Stop Price
                  </label>
                  <input
                    type="number"
                    value={stopPrice}
                    onChange={(e) => setStopPrice(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    className="input w-full"
                  />
                </div>
              )}
            </div>

            {/* Time in Force */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Time in Force
              </label>
              <select
                value={timeInForce}
                onChange={(e) => setTimeInForce(e.target.value as TimeInForce)}
                className="input w-full"
              >
                <option value="day">Day</option>
                <option value="gtc">Good Till Cancelled (GTC)</option>
                <option value="ioc">Immediate or Cancel (IOC)</option>
                <option value="fok">Fill or Kill (FOK)</option>
              </select>
            </div>

            {/* Order Summary */}
            <div className="bg-gray-50 dark:bg-[#1B1B29] rounded-lg p-4 mb-6">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Order Summary</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-[#565674]">Symbol</span>
                  <span className="font-medium text-gray-900 dark:text-white">{selectedSymbol.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-[#565674]">Side</span>
                  <span className={clsx(
                    'font-medium uppercase',
                    orderSide === 'buy' ? 'text-success' : 'text-danger'
                  )}>
                    {orderSide}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-[#565674]">Quantity</span>
                  <span className="font-medium text-gray-900 dark:text-white">{quantity || '0'} shares</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-[#565674]">Type</span>
                  <span className="font-medium text-gray-900 dark:text-white capitalize">{orderType}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-gray-200 dark:border-[#2D2D43]">
                  <span className="text-gray-500 dark:text-[#565674]">Estimated {orderSide === 'buy' ? 'Cost' : 'Proceeds'}</span>
                  <span className="font-bold text-gray-900 dark:text-white">
                    ${estimatedCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleSubmitOrder}
              disabled={!quantity || parseFloat(quantity) <= 0}
              className={clsx(
                'w-full py-4 rounded-lg font-semibold text-white transition-all',
                orderSide === 'buy'
                  ? 'bg-success hover:bg-success/90 disabled:bg-success/50'
                  : 'bg-danger hover:bg-danger/90 disabled:bg-danger/50',
                (!quantity || parseFloat(quantity) <= 0) && 'cursor-not-allowed'
              )}
            >
              {orderSide === 'buy' ? 'Buy' : 'Sell'} {selectedSymbol.symbol}
            </button>

            {/* Risk Warning */}
            <div className="flex items-start gap-2 mt-4 p-3 bg-warning/10 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
              <p className="text-xs text-warning">
                Trading involves risk. Make sure you understand the risks before placing an order.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
