/**
 * Risk Page for MarketSpine
 * Bloomberg-style VaR, Tracking Error, Scenarios Dashboard
 */

import { useState } from 'react';
import {
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Activity,
  RefreshCw,
  Download,
  Settings2,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { clsx } from 'clsx';

// Mock risk data
const mockRiskMetrics = {
  var95_1d: -2850000,
  var95_1d_pct: -1.42,
  var99_1d: -4125000,
  var99_1d_pct: -2.06,
  cvar95_1d: -3750000,
  cvar95_1d_pct: -1.87,
  trackingError: 3.25,
  informationRatio: 0.85,
  beta: 1.12,
  sharpeRatio: 1.45,
  sortinoRatio: 1.82,
  volatility30d: 18.5,
  maxDrawdown: -12.4,
};

const mockVaRContributors = [
  { name: 'Technology', contribution: -1140000, pct: 40 },
  { name: 'Financials', contribution: -570000, pct: 20 },
  { name: 'Healthcare', contribution: -427500, pct: 15 },
  { name: 'Consumer Disc', contribution: -356250, pct: 12.5 },
  { name: 'Other', contribution: -356250, pct: 12.5 },
];

const mockScenarios = [
  { name: 'Lehman 2008', type: 'Historical', pnl: -8250000, pnlPct: -4.12, category: 'Market Crash' },
  { name: 'COVID Mar 2020', type: 'Historical', pnl: -6500000, pnlPct: -3.25, category: 'Market Crash' },
  { name: 'Flash Crash 2010', type: 'Historical', pnl: -4200000, pnlPct: -2.10, category: 'Market Crash' },
  { name: 'Equity -10%', type: 'Hypothetical', pnl: -2000000, pnlPct: -1.00, category: 'Stress' },
  { name: 'Equity -20%', type: 'Hypothetical', pnl: -4000000, pnlPct: -2.00, category: 'Stress' },
  { name: 'VIX +50%', type: 'Hypothetical', pnl: -1850000, pnlPct: -0.92, category: 'Volatility' },
  { name: 'Rates +100bps', type: 'Hypothetical', pnl: -750000, pnlPct: -0.38, category: 'Interest Rate' },
  { name: 'USD +10%', type: 'Hypothetical', pnl: -425000, pnlPct: -0.21, category: 'Currency' },
];

const mockTrackingErrorDecomp = [
  { factor: 'Style', value: 1.82, pct: 56 },
  { factor: 'Industry', value: 0.97, pct: 30 },
  { factor: 'Country', value: 0.32, pct: 10 },
  { factor: 'Specific', value: 0.14, pct: 4 },
];

const formatCurrency = (value: number) => {
  const absValue = Math.abs(value);
  if (absValue >= 1000000) {
    return `${value < 0 ? '-' : ''}$${(absValue / 1000000).toFixed(2)}M`;
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export default function RiskPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'var' | 'scenarios' | 'tracking'>('overview');
  const [varMethod, setVarMethod] = useState<'monte_carlo' | 'historical' | 'parametric'>('monte_carlo');

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Risk Analytics</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            VaR, Scenarios, and Risk Decomposition
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn btn-secondary text-sm">
            <RefreshCw className="h-4 w-4 mr-1.5" />
            Recalculate
          </button>
          <button className="btn btn-secondary text-sm">
            <Download className="h-4 w-4 mr-1.5" />
            Export
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 p-1 bg-[#1B1B29] rounded-lg w-fit">
        {[
          { id: 'overview', label: 'Overview', icon: BarChart3 },
          { id: 'var', label: 'VaR Analysis', icon: Activity },
          { id: 'scenarios', label: 'Scenarios', icon: Zap },
          { id: 'tracking', label: 'Tracking Error', icon: TrendingUp },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={clsx(
              'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
              activeTab === tab.id
                ? 'bg-[#FF6B35] text-white'
                : 'text-[#8B949E] hover:text-white hover:bg-[#21262D]'
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* Key Risk Metrics */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {/* VaR Card */}
            <div className="card rounded-lg p-4 border-l-4 border-l-[#F85149]">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-[#F85149] uppercase tracking-wider">VaR (95%, 1D)</p>
                <AlertTriangle className="h-4 w-4 text-[#F85149]" />
              </div>
              <p className="text-2xl font-bold text-[#F85149] mt-2 font-mono">
                {formatCurrency(mockRiskMetrics.var95_1d)}
              </p>
              <p className="text-xs text-[#565674] mt-1">
                {mockRiskMetrics.var95_1d_pct.toFixed(2)}% of portfolio
              </p>
            </div>

            {/* CVaR Card */}
            <div className="card rounded-lg p-4 border-l-4 border-l-[#FFD700]">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-[#FFD700] uppercase tracking-wider">CVaR (95%, 1D)</p>
                <Activity className="h-4 w-4 text-[#FFD700]" />
              </div>
              <p className="text-2xl font-bold text-[#FFD700] mt-2 font-mono">
                {formatCurrency(mockRiskMetrics.cvar95_1d)}
              </p>
              <p className="text-xs text-[#565674] mt-1">
                {mockRiskMetrics.cvar95_1d_pct.toFixed(2)}% expected shortfall
              </p>
            </div>

            {/* Tracking Error Card */}
            <div className="card rounded-lg p-4 border-l-4 border-l-[#58A6FF]">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-[#58A6FF] uppercase tracking-wider">Tracking Error</p>
                <TrendingUp className="h-4 w-4 text-[#58A6FF]" />
              </div>
              <p className="text-2xl font-bold text-white mt-2 font-mono">
                {mockRiskMetrics.trackingError.toFixed(2)}%
              </p>
              <p className="text-xs text-[#565674] mt-1">
                IR: {mockRiskMetrics.informationRatio.toFixed(2)}
              </p>
            </div>

            {/* Beta Card */}
            <div className="card rounded-lg p-4 border-l-4 border-l-[#3FB950]">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-[#3FB950] uppercase tracking-wider">Portfolio Beta</p>
                <BarChart3 className="h-4 w-4 text-[#3FB950]" />
              </div>
              <p className="text-2xl font-bold text-white mt-2 font-mono">
                {mockRiskMetrics.beta.toFixed(2)}
              </p>
              <p className="text-xs text-[#565674] mt-1">
                vs. S&P 500
              </p>
            </div>
          </div>

          {/* Risk Metrics Grid */}
          <div className="grid gap-4 lg:grid-cols-2">
            {/* VaR Contributors */}
            <div className="card rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-white">VaR Contributors by Sector</h3>
                <button className="text-[#565674] hover:text-white">
                  <Settings2 className="h-4 w-4" />
                </button>
              </div>
              <div className="space-y-3">
                {mockVaRContributors.map((item, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-[#E6EDF3]">{item.name}</span>
                      <span className="text-[#F85149] font-mono">{formatCurrency(item.contribution)}</span>
                    </div>
                    <div className="h-2 bg-[#21262D] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#F85149] to-[#F85149]/60 rounded-full"
                        style={{ width: `${item.pct}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="card rounded-lg p-4">
              <h3 className="text-sm font-semibold text-white mb-4">Risk-Adjusted Metrics</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Sharpe Ratio', value: mockRiskMetrics.sharpeRatio.toFixed(2), good: true },
                  { label: 'Sortino Ratio', value: mockRiskMetrics.sortinoRatio.toFixed(2), good: true },
                  { label: 'Volatility (30D)', value: `${mockRiskMetrics.volatility30d.toFixed(1)}%`, good: false },
                  { label: 'Max Drawdown', value: `${mockRiskMetrics.maxDrawdown.toFixed(1)}%`, good: false },
                ].map((metric, idx) => (
                  <div key={idx} className="bg-[#1B1B29] rounded-lg p-3">
                    <p className="text-xs text-[#565674]">{metric.label}</p>
                    <p className={clsx(
                      'text-xl font-bold font-mono mt-1',
                      metric.good ? 'text-[#3FB950]' : 'text-white'
                    )}>
                      {metric.value}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Scenario Analysis Summary */}
          <div className="card rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">Scenario Analysis</h3>
              <button className="text-sm text-[#FF6B35] hover:text-[#FF8C42] flex items-center gap-1">
                View All <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] font-mono">
                <thead>
                  <tr className="border-b border-[#21262D]">
                    <th className="text-left py-2 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Scenario</th>
                    <th className="text-left py-2 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Type</th>
                    <th className="text-left py-2 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Category</th>
                    <th className="text-right py-2 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">P&L Impact</th>
                    <th className="text-right py-2 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">% Impact</th>
                  </tr>
                </thead>
                <tbody>
                  {mockScenarios.slice(0, 5).map((scenario, idx) => (
                    <tr key={idx} className="border-b border-[#21262D]/50 hover:bg-[#21262D]/30">
                      <td className="py-2 px-3 text-[#E6EDF3]">{scenario.name}</td>
                      <td className="py-2 px-3">
                        <span className={clsx(
                          'px-2 py-0.5 rounded text-xs',
                          scenario.type === 'Historical'
                            ? 'bg-[#58A6FF]/20 text-[#58A6FF]'
                            : 'bg-[#FFD700]/20 text-[#FFD700]'
                        )}>
                          {scenario.type}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-[#8B949E]">{scenario.category}</td>
                      <td className="py-2 px-3 text-right text-[#F85149]">{formatCurrency(scenario.pnl)}</td>
                      <td className="py-2 px-3 text-right text-[#F85149]">{scenario.pnlPct.toFixed(2)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VaR Analysis Tab */}
      {activeTab === 'var' && (
        <div className="space-y-4">
          {/* VaR Method Selector */}
          <div className="card rounded-lg p-4">
            <div className="flex items-center gap-4">
              <span className="text-sm text-[#8B949E]">Method:</span>
              <div className="flex gap-2">
                {[
                  { id: 'monte_carlo', label: 'Monte Carlo' },
                  { id: 'historical', label: 'Historical' },
                  { id: 'parametric', label: 'Parametric' },
                ].map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setVarMethod(method.id as typeof varMethod)}
                    className={clsx(
                      'px-3 py-1.5 rounded text-sm font-medium transition-all',
                      varMethod === method.id
                        ? 'bg-[#FF6B35] text-white'
                        : 'bg-[#21262D] text-[#8B949E] hover:text-white'
                    )}
                  >
                    {method.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* VaR Results */}
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">95% VaR (1-Day)</h4>
              <p className="text-3xl font-bold text-[#F85149] font-mono">{formatCurrency(mockRiskMetrics.var95_1d)}</p>
              <p className="text-sm text-[#8B949E] mt-1">{mockRiskMetrics.var95_1d_pct.toFixed(2)}% of NAV</p>
            </div>
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">99% VaR (1-Day)</h4>
              <p className="text-3xl font-bold text-[#F85149] font-mono">{formatCurrency(mockRiskMetrics.var99_1d)}</p>
              <p className="text-sm text-[#8B949E] mt-1">{mockRiskMetrics.var99_1d_pct.toFixed(2)}% of NAV</p>
            </div>
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">95% CVaR (1-Day)</h4>
              <p className="text-3xl font-bold text-[#FFD700] font-mono">{formatCurrency(mockRiskMetrics.cvar95_1d)}</p>
              <p className="text-sm text-[#8B949E] mt-1">Expected Shortfall</p>
            </div>
          </div>

          {/* VaR Distribution Placeholder */}
          <div className="card rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-4">P&L Distribution (Monte Carlo)</h3>
            <div className="h-64 flex items-center justify-center bg-[#1B1B29] rounded-lg">
              <p className="text-[#565674]">Histogram chart would render here</p>
            </div>
          </div>
        </div>
      )}

      {/* Scenarios Tab */}
      {activeTab === 'scenarios' && (
        <div className="space-y-4">
          <div className="card rounded-lg overflow-hidden">
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="bg-[#21262D] border-b-2 border-[#FF6B35]/30">
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Scenario</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Type</th>
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Category</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Portfolio P&L</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">% Impact</th>
                </tr>
              </thead>
              <tbody>
                {mockScenarios.map((scenario, idx) => (
                  <tr key={idx} className="border-b border-[#21262D] hover:bg-[#21262D]/30 cursor-pointer">
                    <td className="py-2.5 px-3 text-[#E6EDF3] font-medium">{scenario.name}</td>
                    <td className="py-2.5 px-3">
                      <span className={clsx(
                        'px-2 py-0.5 rounded text-xs',
                        scenario.type === 'Historical'
                          ? 'bg-[#58A6FF]/20 text-[#58A6FF]'
                          : 'bg-[#FFD700]/20 text-[#FFD700]'
                      )}>
                        {scenario.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-[#8B949E]">{scenario.category}</td>
                    <td className="py-2.5 px-3 text-right text-[#F85149]">{formatCurrency(scenario.pnl)}</td>
                    <td className="py-2.5 px-3 text-right text-[#F85149]">{scenario.pnlPct.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tracking Error Tab */}
      {activeTab === 'tracking' && (
        <div className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">Ex-Ante TE</h4>
              <p className="text-3xl font-bold text-white font-mono">{mockRiskMetrics.trackingError.toFixed(2)}%</p>
            </div>
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">Information Ratio</h4>
              <p className="text-3xl font-bold text-[#3FB950] font-mono">{mockRiskMetrics.informationRatio.toFixed(2)}</p>
            </div>
            <div className="card rounded-lg p-4">
              <h4 className="text-xs text-[#565674] uppercase tracking-wider mb-2">Benchmark</h4>
              <p className="text-3xl font-bold text-[#58A6FF] font-mono">S&P 500</p>
            </div>
          </div>

          {/* TE Decomposition */}
          <div className="card rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-4">Tracking Error Decomposition</h3>
            <div className="space-y-3">
              {mockTrackingErrorDecomp.map((item, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-[#E6EDF3]">{item.factor} Risk</span>
                    <span className="text-white font-mono">{item.value.toFixed(2)}% ({item.pct}%)</span>
                  </div>
                  <div className="h-2 bg-[#21262D] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#58A6FF] to-[#58A6FF]/60 rounded-full"
                      style={{ width: `${item.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
