import { TrendingUp, TrendingDown, DollarSign, PieChart, Activity, Calendar, ArrowUpRight, ArrowDownRight } from 'lucide-react'
import { clsx } from 'clsx'
import { portfolioSummary, sectorAllocation, positions } from '../data/mockData'

const performanceData = {
  daily: { value: 1247.53, percent: 0.52 },
  weekly: { value: 4892.31, percent: 2.04 },
  monthly: { value: -2156.78, percent: -0.89 },
  ytd: { value: 48523.67, percent: 20.34 },
  allTime: { value: 142847.23, percent: 59.52 },
}

const topPerformers = positions
  .filter(p => p.unrealizedPL > 0)
  .sort((a, b) => b.unrealizedPLPercent - a.unrealizedPLPercent)
  .slice(0, 5)

const topLosers = positions
  .filter(p => p.unrealizedPL < 0)
  .sort((a, b) => a.unrealizedPLPercent - b.unrealizedPLPercent)
  .slice(0, 5)

export default function PortfolioPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Portfolio Overview</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Track your investment performance
          </p>
        </div>
        <select className="input w-40">
          <option>All Accounts</option>
          <option>Trading</option>
          <option>Retirement</option>
        </select>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-500 dark:text-[#565674]">Total Value</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-100 dark:bg-primary-900/30">
              <DollarSign className="h-5 w-5 text-primary-600" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            ${portfolioSummary.totalValue.toLocaleString()}
          </p>
          <div className="flex items-center gap-1 mt-1 pnl-positive">
            <ArrowUpRight className="h-4 w-4" />
            <span className="text-sm font-medium">+${portfolioSummary.totalGainLoss.toLocaleString()}</span>
          </div>
        </div>

        <div className="card rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-500 dark:text-[#565674]">Day's P&L</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
              <TrendingUp className="h-5 w-5 text-success" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            ${portfolioSummary.dayGainLoss.toLocaleString()}
          </p>
          <span className="text-sm pnl-positive">+{portfolioSummary.dayGainLossPercent}%</span>
        </div>

        <div className="card rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-500 dark:text-[#565674]">Buying Power</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
              <Activity className="h-5 w-5 text-info" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            ${portfolioSummary.buyingPower.toLocaleString()}
          </p>
          <span className="text-sm text-gray-500 dark:text-[#565674]">Available to trade</span>
        </div>

        <div className="card rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-500 dark:text-[#565674]">Cash Balance</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
              <DollarSign className="h-5 w-5 text-warning" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            ${portfolioSummary.cashBalance.toLocaleString()}
          </p>
          <span className="text-sm text-gray-500 dark:text-[#565674]">
            {((portfolioSummary.cashBalance / portfolioSummary.totalValue) * 100).toFixed(1)}% of portfolio
          </span>
        </div>
      </div>

      {/* Performance & Allocation */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Performance by Period */}
        <div className="card rounded-xl p-6">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Performance</h3>
          <div className="space-y-3">
            {Object.entries(performanceData).map(([period, data]) => (
              <div key={period} className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-[#2D2D43] last:border-0">
                <span className="text-sm capitalize text-gray-600 dark:text-gray-400">
                  {period === 'ytd' ? 'Year to Date' : period === 'allTime' ? 'All Time' : period}
                </span>
                <div className="text-right">
                  <p className={clsx(
                    'font-semibold',
                    data.value >= 0 ? 'pnl-positive' : 'pnl-negative'
                  )}>
                    {data.value >= 0 ? '+' : ''}${Math.abs(data.value).toLocaleString()}
                  </p>
                  <p className={clsx(
                    'text-xs',
                    data.percent >= 0 ? 'pnl-positive' : 'pnl-negative'
                  )}>
                    {data.percent >= 0 ? '+' : ''}{data.percent.toFixed(2)}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sector Allocation */}
        <div className="card rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">Sector Allocation</h3>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {sectorAllocation.map((sector) => (
              <div key={sector.sector} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">{sector.sector}</span>
                  <span className="font-medium text-gray-900 dark:text-white">{sector.percentage}%</span>
                </div>
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${sector.percentage}%`,
                      backgroundColor: sector.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Performers & Losers */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Top Performers */}
        <div className="card rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-success" />
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">Top Performers</h3>
          </div>
          <div className="space-y-3">
            {topPerformers.map((position) => (
              <div key={position.symbol} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                    <span className="text-sm font-bold text-success">{position.symbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{position.symbol}</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">{position.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium pnl-positive">+${position.unrealizedPL.toLocaleString()}</p>
                  <p className="text-xs pnl-positive">+{position.unrealizedPLPercent.toFixed(2)}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Losers */}
        <div className="card rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingDown className="h-5 w-5 text-danger" />
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">Underperformers</h3>
          </div>
          <div className="space-y-3">
            {topLosers.map((position) => (
              <div key={position.symbol} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-danger/10">
                    <span className="text-sm font-bold text-danger">{position.symbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{position.symbol}</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">{position.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium pnl-negative">${position.unrealizedPL.toLocaleString()}</p>
                  <p className="text-xs pnl-negative">{position.unrealizedPLPercent.toFixed(2)}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
