/**
 * Holdings Page for MarketSpine
 * Bloomberg PORT-style hierarchical position viewer with real-time P&L
 */

import { useState, useMemo } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Download,
  Filter,
  Settings2,
  ChevronDown,
  ChevronRight,
  RefreshCw,
  LayoutGrid,
  List,
} from 'lucide-react';
import { clsx } from 'clsx';

// Mock data - in production this would come from API
const mockHoldings = [
  {
    id: '1',
    fund: 'Main Equity Fund',
    account: 'Prime Brokerage - GS',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    sector: 'Technology',
    quantity: 15000,
    avgCost: 145.50,
    marketPrice: 178.25,
    marketValue: 2673750,
    costBasis: 2182500,
    unrealizedPnL: 491250,
    unrealizedPnLPct: 22.51,
    dayChange: 8250,
    dayChangePct: 0.31,
    weight: 12.5,
    weightTarget: 12.0,
  },
  {
    id: '2',
    fund: 'Main Equity Fund',
    account: 'Prime Brokerage - GS',
    symbol: 'MSFT',
    name: 'Microsoft Corp.',
    sector: 'Technology',
    quantity: 8500,
    avgCost: 285.00,
    marketPrice: 378.50,
    marketValue: 3217250,
    costBasis: 2422500,
    unrealizedPnL: 794750,
    unrealizedPnLPct: 32.81,
    dayChange: -12750,
    dayChangePct: -0.39,
    weight: 15.0,
    weightTarget: 14.0,
  },
  {
    id: '3',
    fund: 'Main Equity Fund',
    account: 'Prime Brokerage - GS',
    symbol: 'NVDA',
    name: 'NVIDIA Corp.',
    sector: 'Technology',
    quantity: 5000,
    avgCost: 450.00,
    marketPrice: 875.25,
    marketValue: 4376250,
    costBasis: 2250000,
    unrealizedPnL: 2126250,
    unrealizedPnLPct: 94.50,
    dayChange: 87625,
    dayChangePct: 2.04,
    weight: 20.4,
    weightTarget: 18.0,
  },
  {
    id: '4',
    fund: 'Main Equity Fund',
    account: 'Prime Brokerage - MS',
    symbol: 'JPM',
    name: 'JPMorgan Chase',
    sector: 'Financials',
    quantity: 12000,
    avgCost: 142.00,
    marketPrice: 195.50,
    marketValue: 2346000,
    costBasis: 1704000,
    unrealizedPnL: 642000,
    unrealizedPnLPct: 37.68,
    dayChange: 23460,
    dayChangePct: 1.01,
    weight: 11.0,
    weightTarget: 10.0,
  },
  {
    id: '5',
    fund: 'Main Equity Fund',
    account: 'Prime Brokerage - MS',
    symbol: 'JNJ',
    name: 'Johnson & Johnson',
    sector: 'Healthcare',
    quantity: 7500,
    avgCost: 165.00,
    marketPrice: 158.75,
    marketValue: 1190625,
    costBasis: 1237500,
    unrealizedPnL: -46875,
    unrealizedPnLPct: -3.79,
    dayChange: -5953,
    dayChangePct: -0.50,
    weight: 5.6,
    weightTarget: 6.0,
  },
  {
    id: '6',
    fund: 'Fixed Income Fund',
    account: 'Custody - BNY',
    symbol: 'TLT',
    name: 'iShares 20+ Year Treasury',
    sector: 'Fixed Income',
    quantity: 25000,
    avgCost: 98.50,
    marketPrice: 92.25,
    marketValue: 2306250,
    costBasis: 2462500,
    unrealizedPnL: -156250,
    unrealizedPnLPct: -6.35,
    dayChange: -11531,
    dayChangePct: -0.50,
    weight: 10.8,
    weightTarget: 12.0,
  },
];

type GroupBy = 'none' | 'fund' | 'account' | 'sector';
type ViewMode = 'table' | 'cards';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const formatPercent = (value: number) => {
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
};

const formatPnL = (value: number) => {
  const sign = value >= 0 ? '+' : '';
  return sign + formatCurrency(value);
};

export default function HoldingsPage() {
  const [groupBy, setGroupBy] = useState<GroupBy>('fund');
  const [viewMode, setViewMode] = useState<ViewMode>('table');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(['Main Equity Fund', 'Fixed Income Fund']));
  const [selectedHolding, setSelectedHolding] = useState<string | null>(null);

  // Calculate totals
  const totals = useMemo(() => {
    return mockHoldings.reduce(
      (acc, h) => ({
        marketValue: acc.marketValue + h.marketValue,
        costBasis: acc.costBasis + h.costBasis,
        unrealizedPnL: acc.unrealizedPnL + h.unrealizedPnL,
        dayChange: acc.dayChange + h.dayChange,
      }),
      { marketValue: 0, costBasis: 0, unrealizedPnL: 0, dayChange: 0 }
    );
  }, []);

  // Group holdings
  const groupedHoldings = useMemo(() => {
    if (groupBy === 'none') {
      return { '': mockHoldings };
    }
    
    const groups: Record<string, typeof mockHoldings> = {};
    mockHoldings.forEach((h) => {
      const key = h[groupBy as keyof typeof h] as string;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(h);
    });
    return groups;
  }, [groupBy]);

  const toggleGroup = (key: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(key)) {
      newExpanded.delete(key);
    } else {
      newExpanded.add(key);
    }
    setExpandedGroups(newExpanded);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Holdings</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            {mockHoldings.length} positions • Real-time P&L
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn btn-secondary text-sm">
            <RefreshCw className="h-4 w-4 mr-1.5" />
            Refresh
          </button>
          <button className="btn btn-secondary text-sm">
            <Download className="h-4 w-4 mr-1.5" />
            Export
          </button>
        </div>
      </div>

      {/* Summary Cards - Bloomberg Style */}
      <div className="grid gap-3 sm:grid-cols-4">
        <div className="card rounded-lg p-4 border-l-4 border-l-[#FF6B35]">
          <p className="text-xs font-medium text-[#FF6B35] uppercase tracking-wider">Market Value</p>
          <p className="text-xl font-bold text-gray-900 dark:text-white mt-1 font-mono">
            {formatCurrency(totals.marketValue)}
          </p>
        </div>
        <div className="card rounded-lg p-4 border-l-4 border-l-[#58A6FF]">
          <p className="text-xs font-medium text-[#58A6FF] uppercase tracking-wider">Cost Basis</p>
          <p className="text-xl font-bold text-gray-900 dark:text-white mt-1 font-mono">
            {formatCurrency(totals.costBasis)}
          </p>
        </div>
        <div className={clsx(
          'card rounded-lg p-4 border-l-4',
          totals.unrealizedPnL >= 0 ? 'border-l-[#3FB950]' : 'border-l-[#F85149]'
        )}>
          <p className="text-xs font-medium text-gray-500 dark:text-[#565674] uppercase tracking-wider">
            Unrealized P&L
          </p>
          <p className={clsx(
            'text-xl font-bold mt-1 font-mono',
            totals.unrealizedPnL >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
          )}>
            {formatPnL(totals.unrealizedPnL)}
          </p>
          <p className={clsx(
            'text-xs mt-0.5 font-mono',
            totals.unrealizedPnL >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
          )}>
            {formatPercent((totals.unrealizedPnL / totals.costBasis) * 100)}
          </p>
        </div>
        <div className={clsx(
          'card rounded-lg p-4 border-l-4',
          totals.dayChange >= 0 ? 'border-l-[#3FB950]' : 'border-l-[#F85149]'
        )}>
          <p className="text-xs font-medium text-gray-500 dark:text-[#565674] uppercase tracking-wider">
            Day Change
          </p>
          <p className={clsx(
            'text-xl font-bold mt-1 font-mono',
            totals.dayChange >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
          )}>
            {formatPnL(totals.dayChange)}
          </p>
        </div>
      </div>

      {/* Filters & View Controls */}
      <div className="card rounded-lg p-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-gray-500 dark:text-[#565674]">Group by:</span>
              <select
                value={groupBy}
                onChange={(e) => setGroupBy(e.target.value as GroupBy)}
                className="input text-sm py-1.5 w-auto min-w-[120px]"
              >
                <option value="none">None</option>
                <option value="fund">Fund</option>
                <option value="account">Account</option>
                <option value="sector">Sector</option>
              </select>
            </div>
            <button className="btn btn-secondary text-sm py-1.5">
              <Filter className="h-4 w-4" />
            </button>
            <button className="btn btn-secondary text-sm py-1.5">
              <Settings2 className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center gap-1 bg-gray-100 dark:bg-[#1B1B29] rounded-lg p-1">
            <button
              onClick={() => setViewMode('table')}
              className={clsx(
                'p-1.5 rounded',
                viewMode === 'table'
                  ? 'bg-white dark:bg-[#2D2D43] text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-[#565674] hover:text-gray-900 dark:hover:text-white'
              )}
            >
              <List className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={clsx(
                'p-1.5 rounded',
                viewMode === 'cards'
                  ? 'bg-white dark:bg-[#2D2D43] text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-[#565674] hover:text-gray-900 dark:hover:text-white'
              )}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Holdings Table - Bloomberg Dense Style */}
      <div className="card rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px] font-mono">
            <thead>
              <tr className="bg-[#21262D] border-b-2 border-[#FF6B35]/30">
                <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Symbol
                </th>
                <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Name
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Quantity
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Price
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Market Value
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Unrealized P&L
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Day Chg
                </th>
                <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px] tracking-wider">
                  Weight
                </th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(groupedHoldings).map(([groupKey, holdings]) => (
                <>
                  {/* Group Header */}
                  {groupBy !== 'none' && (
                    <tr
                      key={`group-${groupKey}`}
                      className="bg-[#1B1B29] cursor-pointer hover:bg-[#21262D]"
                      onClick={() => toggleGroup(groupKey)}
                    >
                      <td colSpan={8} className="py-2 px-3">
                        <div className="flex items-center gap-2">
                          {expandedGroups.has(groupKey) ? (
                            <ChevronDown className="h-4 w-4 text-[#FF6B35]" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-[#565674]" />
                          )}
                          <span className="font-semibold text-white">{groupKey}</span>
                          <span className="text-[#565674] text-xs ml-2">
                            ({holdings.length} positions)
                          </span>
                          <span className="ml-auto text-[#8B949E]">
                            {formatCurrency(holdings.reduce((sum, h) => sum + h.marketValue, 0))}
                          </span>
                        </div>
                      </td>
                    </tr>
                  )}
                  
                  {/* Position Rows */}
                  {(groupBy === 'none' || expandedGroups.has(groupKey)) &&
                    holdings.map((holding) => (
                      <tr
                        key={holding.id}
                        className={clsx(
                          'border-b border-[#21262D] transition-colors cursor-pointer',
                          selectedHolding === holding.id
                            ? 'bg-[#FF6B35]/10'
                            : 'hover:bg-[#21262D]/50'
                        )}
                        onClick={() => setSelectedHolding(holding.id)}
                      >
                        <td className="py-2 px-3">
                          <span className="font-semibold text-[#58A6FF]">{holding.symbol}</span>
                        </td>
                        <td className="py-2 px-3 text-[#E6EDF3]">
                          {holding.name}
                        </td>
                        <td className="py-2 px-3 text-right text-[#E6EDF3] tabular-nums">
                          {holding.quantity.toLocaleString()}
                        </td>
                        <td className="py-2 px-3 text-right text-[#E6EDF3] tabular-nums">
                          ${holding.marketPrice.toFixed(2)}
                        </td>
                        <td className="py-2 px-3 text-right text-[#E6EDF3] tabular-nums">
                          {formatCurrency(holding.marketValue)}
                        </td>
                        <td className="py-2 px-3 text-right">
                          <div className={clsx(
                            'tabular-nums',
                            holding.unrealizedPnL >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                          )}>
                            {formatPnL(holding.unrealizedPnL)}
                          </div>
                          <div className={clsx(
                            'text-[11px] tabular-nums',
                            holding.unrealizedPnLPct >= 0 ? 'text-[#3FB950]/70' : 'text-[#F85149]/70'
                          )}>
                            {formatPercent(holding.unrealizedPnLPct)}
                          </div>
                        </td>
                        <td className="py-2 px-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {holding.dayChange >= 0 ? (
                              <TrendingUp className="h-3 w-3 text-[#3FB950]" />
                            ) : (
                              <TrendingDown className="h-3 w-3 text-[#F85149]" />
                            )}
                            <span className={clsx(
                              'tabular-nums',
                              holding.dayChange >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                            )}>
                              {formatPercent(holding.dayChangePct)}
                            </span>
                          </div>
                        </td>
                        <td className="py-2 px-3 text-right">
                          <div className="tabular-nums text-[#E6EDF3]">
                            {holding.weight.toFixed(1)}%
                          </div>
                          {holding.weightTarget && (
                            <div className={clsx(
                              'text-[11px] tabular-nums',
                              Math.abs(holding.weight - holding.weightTarget) > 2
                                ? 'text-[#FFD700]'
                                : 'text-[#565674]'
                            )}>
                              tgt: {holding.weightTarget}%
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                </>
              ))}
            </tbody>
            {/* Totals Footer */}
            <tfoot>
              <tr className="bg-[#21262D] border-t-2 border-[#FF6B35]/30 font-semibold">
                <td colSpan={4} className="py-2.5 px-3 text-[#FF6B35] uppercase text-[11px]">
                  Total
                </td>
                <td className="py-2.5 px-3 text-right text-white tabular-nums">
                  {formatCurrency(totals.marketValue)}
                </td>
                <td className={clsx(
                  'py-2.5 px-3 text-right tabular-nums',
                  totals.unrealizedPnL >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                )}>
                  {formatPnL(totals.unrealizedPnL)}
                </td>
                <td className={clsx(
                  'py-2.5 px-3 text-right tabular-nums',
                  totals.dayChange >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                )}>
                  {formatPnL(totals.dayChange)}
                </td>
                <td className="py-2.5 px-3 text-right text-white tabular-nums">
                  100.0%
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}
