import {
  Briefcase,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  PieChart,
  Clock,
  FileText,
  ExternalLink,
  BarChart3,
} from 'lucide-react'
import { clsx } from 'clsx'
import { 
  mockPortfolioSummary, 
  mockPositions, 
  mockRecentTrades, 
  mockNews,
  mockPerformance,
  mockSectorAllocation 
} from '../data/mockData'

// Stat card component
interface StatCardProps {
  title: string
  value: string
  change?: string
  changeType?: 'increase' | 'decrease'
  icon: React.ElementType
  iconColor: string
  iconBg: string
}

function StatCard({ title, value, change, changeType, icon: Icon, iconColor, iconBg }: StatCardProps) {
  return (
    <div className="card rounded-xl p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[13px] font-medium text-gray-500 dark:text-[#565674]">{title}</p>
          <h3 className="mt-2 text-2xl font-bold text-gray-900 dark:text-white">{value}</h3>
          {change && (
            <div className="mt-2 flex items-center gap-1">
              {changeType === 'increase' ? (
                <ArrowUpRight className="h-4 w-4 text-success" />
              ) : (
                <ArrowDownRight className="h-4 w-4 text-danger" />
              )}
              <span className={clsx('text-xs font-medium', changeType === 'increase' ? 'text-success' : 'text-danger')}>
                {change}
              </span>
              <span className="text-xs text-gray-400">today</span>
            </div>
          )}
        </div>
        <div className={clsx('flex h-12 w-12 items-center justify-center rounded-lg', iconBg)}>
          <Icon className={clsx('h-6 w-6', iconColor)} />
        </div>
      </div>
    </div>
  )
}

// Format currency
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

const formatCurrencyFull = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

export default function DashboardPage() {
  const topPositions = mockPositions.slice(0, 5)
  const recentTrades = mockRecentTrades.slice(0, 5)
  const latestNews = mockNews.slice(0, 4)

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Portfolio Value"
          value={formatCurrency(mockPortfolioSummary.totalValue)}
          change={`${mockPortfolioSummary.dayChangePercent > 0 ? '+' : ''}${mockPortfolioSummary.dayChangePercent.toFixed(2)}%`}
          changeType={mockPortfolioSummary.dayChangePercent >= 0 ? 'increase' : 'decrease'}
          icon={Briefcase}
          iconColor="text-primary-600"
          iconBg="bg-primary-100 dark:bg-primary-900/30"
        />
        <StatCard
          title="Day P&L"
          value={formatCurrencyFull(mockPortfolioSummary.dayChange)}
          change={`${mockPortfolioSummary.dayChangePercent > 0 ? '+' : ''}${mockPortfolioSummary.dayChangePercent.toFixed(2)}%`}
          changeType={mockPortfolioSummary.dayChange >= 0 ? 'increase' : 'decrease'}
          icon={mockPortfolioSummary.dayChange >= 0 ? TrendingUp : TrendingDown}
          iconColor={mockPortfolioSummary.dayChange >= 0 ? 'text-success' : 'text-danger'}
          iconBg={mockPortfolioSummary.dayChange >= 0 ? 'bg-success-light dark:bg-success/20' : 'bg-danger-light dark:bg-danger/20'}
        />
        <StatCard
          title="Total Gain"
          value={formatCurrencyFull(mockPortfolioSummary.totalGain)}
          change={`${mockPortfolioSummary.totalGainPercent > 0 ? '+' : ''}${mockPortfolioSummary.totalGainPercent.toFixed(2)}%`}
          changeType={mockPortfolioSummary.totalGain >= 0 ? 'increase' : 'decrease'}
          icon={Activity}
          iconColor="text-info"
          iconBg="bg-info-light dark:bg-info/20"
        />
        <StatCard
          title="Cash Balance"
          value={formatCurrency(mockPortfolioSummary.cashBalance)}
          icon={DollarSign}
          iconColor="text-warning"
          iconBg="bg-warning-light dark:bg-warning/20"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Top Positions */}
        <div className="card rounded-xl lg:col-span-2">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-6 py-4">
            <div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">Top Positions</h3>
              <p className="text-xs text-gray-500 dark:text-[#565674]">Your largest holdings by market value</p>
            </div>
            <a
              href="/positions"
              className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700"
            >
              View all
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 dark:text-[#565674] border-b border-gray-100 dark:border-[#2D2D43]">
                  <th className="px-6 py-3 text-left font-semibold">Symbol</th>
                  <th className="px-6 py-3 text-right font-semibold">Shares</th>
                  <th className="px-6 py-3 text-right font-semibold">Price</th>
                  <th className="px-6 py-3 text-right font-semibold">Market Value</th>
                  <th className="px-6 py-3 text-right font-semibold">P&L</th>
                  <th className="px-6 py-3 text-right font-semibold">Weight</th>
                </tr>
              </thead>
              <tbody>
                {topPositions.map((position) => (
                  <tr
                    key={position.id}
                    className="border-b border-gray-50 dark:border-[#2D2D43]/50 hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43] font-semibold text-xs text-gray-700 dark:text-gray-300">
                          {position.symbol.slice(0, 2)}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{position.symbol}</p>
                          <p className="text-xs text-gray-500 dark:text-[#565674]">{position.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right text-gray-700 dark:text-gray-300">
                      {position.shares.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right text-gray-700 dark:text-gray-300">
                      ${position.currentPrice.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-gray-900 dark:text-white">
                      {formatCurrency(position.marketValue)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className={clsx(
                        'flex flex-col items-end',
                        position.unrealizedPnL >= 0 ? 'text-success' : 'text-danger'
                      )}>
                        <span className="font-medium">
                          {position.unrealizedPnL >= 0 ? '+' : ''}{formatCurrencyFull(position.unrealizedPnL)}
                        </span>
                        <span className="text-xs">
                          {position.unrealizedPnLPercent >= 0 ? '+' : ''}{position.unrealizedPnLPercent.toFixed(2)}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right text-gray-700 dark:text-gray-300">
                      {position.weight.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Performance Summary */}
        <div className="card rounded-xl">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-6 py-4">
            <div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">Performance</h3>
              <p className="text-xs text-gray-500 dark:text-[#565674]">vs S&P 500 Benchmark</p>
            </div>
            <BarChart3 className="h-5 w-5 text-gray-400" />
          </div>
          <div className="p-6 space-y-4">
            {mockPerformance.map((metric) => (
              <div key={metric.period} className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500 dark:text-[#565674]">{metric.period}</span>
                <div className="flex items-center gap-4">
                  <span className={clsx(
                    'text-sm font-semibold',
                    metric.return >= 0 ? 'text-success' : 'text-danger'
                  )}>
                    {metric.return >= 0 ? '+' : ''}{metric.return.toFixed(2)}%
                  </span>
                  <span className={clsx(
                    'text-xs px-1.5 py-0.5 rounded',
                    metric.alpha >= 0 ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'
                  )}>
                    α {metric.alpha >= 0 ? '+' : ''}{metric.alpha.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Second Row */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent Trades */}
        <div className="card rounded-xl">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-6 py-4">
            <div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">Recent Trades</h3>
              <p className="text-xs text-gray-500 dark:text-[#565674]">Latest executed orders</p>
            </div>
            <a
              href="/orders"
              className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700"
            >
              View all
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-[#2D2D43]">
            {recentTrades.map((trade) => (
              <div key={trade.id} className="px-6 py-4 hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={clsx(
                      'flex h-8 w-8 items-center justify-center rounded-full',
                      trade.side === 'buy' ? 'bg-success/10' : 'bg-danger/10'
                    )}>
                      {trade.side === 'buy' ? (
                        <TrendingUp className="h-4 w-4 text-success" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-danger" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {trade.side === 'buy' ? 'Buy' : 'Sell'} {trade.symbol}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-[#565674]">
                        {trade.quantity} @ ${trade.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {formatCurrencyFull(trade.total)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">{trade.broker}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sector Allocation */}
        <div className="card rounded-xl">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-6 py-4">
            <div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">Sector Allocation</h3>
              <p className="text-xs text-gray-500 dark:text-[#565674]">Portfolio by sector</p>
            </div>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          <div className="p-6 space-y-4">
            {mockSectorAllocation.map((sector) => (
              <div key={sector.sector}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-700 dark:text-gray-300">{sector.sector}</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{sector.weight.toFixed(1)}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-gray-100 dark:bg-[#2D2D43] rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary-500 rounded-full"
                      style={{ width: `${sector.weight}%` }}
                    />
                  </div>
                  <span className={clsx(
                    'text-xs font-medium w-12 text-right',
                    sector.change >= 0 ? 'text-success' : 'text-danger'
                  )}>
                    {sector.change >= 0 ? '+' : ''}{sector.change.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Latest News */}
        <div className="card rounded-xl">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-[#2D2D43] px-6 py-4">
            <div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">Market News</h3>
              <p className="text-xs text-gray-500 dark:text-[#565674]">Latest headlines</p>
            </div>
            <a
              href="/news"
              className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700"
            >
              View all
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-[#2D2D43]">
            {latestNews.map((news) => (
              <div key={news.id} className="px-6 py-4 hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className={clsx(
                    'mt-0.5 w-1 h-1 rounded-full flex-shrink-0',
                    news.sentiment === 'positive' ? 'bg-success' : news.sentiment === 'negative' ? 'bg-danger' : 'bg-gray-400'
                  )} />
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">{news.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500 dark:text-[#565674]">{news.source}</span>
                      {news.symbols.length > 0 && (
                        <span className="text-xs font-medium text-primary-600">{news.symbols.join(', ')}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
