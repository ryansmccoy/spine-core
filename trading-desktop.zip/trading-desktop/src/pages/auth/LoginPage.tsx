/**
 * Login Page for MarketSpine
 * Bloomberg-style dark themed authentication
 */

import { useState, type FormEvent } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { TrendingUp, AlertCircle, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { clsx } from 'clsx';

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isLoading } = useAuthStore();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get redirect path from location state
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/dashboard';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      await login({ email, password, remember_me: rememberMe });
      navigate(from, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex bg-[#0D1117]">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#161B22] to-[#0D1117] p-12 flex-col justify-between relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Logo & Title */}
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#FF8C42] shadow-lg shadow-orange-500/20">
              <TrendingUp className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white tracking-tight">MarketSpine</h1>
              <p className="text-[#8B949E] text-sm font-medium">Institutional Investment Management</p>
            </div>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="relative z-10 space-y-6">
          <h2 className="text-2xl font-semibold text-white">
            Bloomberg-Grade Analytics
          </h2>
          <div className="space-y-4">
            {[
              { title: 'Portfolio Management', desc: 'Real-time positions, P&L, and attribution' },
              { title: 'Risk Analytics', desc: 'VaR, scenarios, tracking error analysis' },
              { title: 'Trade Execution', desc: 'Order management and TCA' },
              { title: 'Research Hub', desc: 'Notes, models, and knowledge graph' },
            ].map((feature, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="mt-1 h-2 w-2 rounded-full bg-[#FF6B35]" />
                <div>
                  <p className="text-white font-medium">{feature.title}</p>
                  <p className="text-[#8B949E] text-sm">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Market Data Decoration */}
        <div className="relative z-10">
          <div className="flex items-center gap-6 text-[13px] font-mono">
            <div>
              <span className="text-[#8B949E]">S&P 500</span>
              <span className="ml-2 text-[#3FB950]">+1.24%</span>
            </div>
            <div>
              <span className="text-[#8B949E]">NASDAQ</span>
              <span className="ml-2 text-[#3FB950]">+1.67%</span>
            </div>
            <div>
              <span className="text-[#8B949E]">VIX</span>
              <span className="ml-2 text-[#F85149]">-3.2%</span>
            </div>
          </div>
          <p className="text-[#6E7681] text-xs mt-4">
            © 2026 MarketSpine. All rights reserved.
          </p>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-10">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#FF8C42]">
              <TrendingUp className="h-7 w-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">MarketSpine</span>
          </div>

          {/* Form Header */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white">Welcome back</h2>
            <p className="text-[#8B949E] mt-2">Sign in to access your portfolio</p>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="mb-6 flex items-center gap-3 rounded-lg bg-[#F85149]/10 border border-[#F85149]/20 px-4 py-3">
              <AlertCircle className="h-5 w-5 text-[#F85149] flex-shrink-0" />
              <p className="text-sm text-[#F85149]">{error}</p>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[#E6EDF3] mb-2">
                Email address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
                placeholder="you@company.com"
                className={clsx(
                  'w-full rounded-lg border bg-[#161B22] px-4 py-3 text-white',
                  'placeholder-[#6E7681] text-sm',
                  'border-[#30363D] focus:border-[#FF6B35] focus:ring-1 focus:ring-[#FF6B35]',
                  'outline-none transition-colors'
                )}
              />
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-[#E6EDF3] mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  placeholder="••••••••"
                  className={clsx(
                    'w-full rounded-lg border bg-[#161B22] px-4 py-3 pr-12 text-white',
                    'placeholder-[#6E7681] text-sm',
                    'border-[#30363D] focus:border-[#FF6B35] focus:ring-1 focus:ring-[#FF6B35]',
                    'outline-none transition-colors'
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6E7681] hover:text-[#E6EDF3] transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5" />
                  ) : (
                    <Eye className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className={clsx(
                    'h-4 w-4 rounded border-[#30363D] bg-[#161B22]',
                    'text-[#FF6B35] focus:ring-[#FF6B35] focus:ring-offset-0'
                  )}
                />
                <span className="text-sm text-[#8B949E]">Remember me</span>
              </label>
              <a
                href="/forgot-password"
                className="text-sm text-[#FF6B35] hover:text-[#FF8C42] transition-colors"
              >
                Forgot password?
              </a>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className={clsx(
                'w-full flex items-center justify-center gap-2 rounded-lg px-4 py-3',
                'bg-gradient-to-r from-[#FF6B35] to-[#FF8C42] text-white font-semibold',
                'hover:from-[#FF8C42] hover:to-[#FFA726] transition-all',
                'disabled:opacity-50 disabled:cursor-not-allowed',
                'shadow-lg shadow-orange-500/20'
              )}
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Signing in...
                </>
              ) : (
                'Sign in'
              )}
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-8 p-4 rounded-lg border border-dashed border-[#30363D] bg-[#161B22]/50">
            <p className="text-xs text-[#8B949E] mb-2 font-medium">Demo Credentials</p>
            <div className="space-y-1 text-xs font-mono text-[#6E7681]">
              <p>Portfolio Manager: pm@demo.com / demo123</p>
              <p>Trader: trader@demo.com / demo123</p>
              <p>Analyst: analyst@demo.com / demo123</p>
            </div>
          </div>

          {/* Footer */}
          <p className="mt-8 text-center text-sm text-[#6E7681]">
            Need an account?{' '}
            <a href="/contact" className="text-[#FF6B35] hover:text-[#FF8C42]">
              Contact your admin
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
