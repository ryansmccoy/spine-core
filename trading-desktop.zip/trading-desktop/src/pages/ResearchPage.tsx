import { useState } from 'react'
import {
  FileText,
  Search,
  Filter,
  Star,
  Clock,
  ExternalLink,
  Tag,
  Building2,
} from 'lucide-react'
import { clsx } from 'clsx'
import { mockNews } from '../data/mockData'

// Extended research data
const researchReports = [
  {
    id: 'R001',
    title: 'Apple Q1 2024 Earnings Preview: Services Growth to Drive Upside',
    company: 'Apple Inc.',
    symbol: 'AAPL',
    analyst: 'Sarah Chen',
    firm: 'Goldman Sachs',
    date: '2024-01-26',
    rating: 'Buy',
    priceTarget: 210,
    summary: 'We expect Apple to report strong Q1 results driven by Services segment growth and iPhone 15 momentum...',
    tags: ['Earnings', 'Services', 'iPhone'],
    isStarred: true,
  },
  {
    id: 'R002',
    title: 'NVIDIA: AI Demand Remains Robust, Raising Estimates',
    company: 'NVIDIA Corp.',
    symbol: 'NVDA',
    analyst: 'Mark Liu',
    firm: 'Morgan Stanley',
    date: '2024-01-25',
    rating: 'Overweight',
    priceTarget: 1000,
    summary: 'Data center AI demand continues to exceed expectations. We raise our FY25 revenue estimates by 15%...',
    tags: ['AI', 'Data Center', 'Semiconductors'],
    isStarred: true,
  },
  {
    id: 'R003',
    title: 'Microsoft: Azure AI Integration Accelerating Enterprise Adoption',
    company: 'Microsoft Corp.',
    symbol: 'MSFT',
    analyst: 'David Park',
    firm: 'JP Morgan',
    date: '2024-01-24',
    rating: 'Overweight',
    priceTarget: 450,
    summary: 'Copilot integration across Microsoft 365 suite is driving accelerated cloud adoption...',
    tags: ['Cloud', 'AI', 'Enterprise'],
    isStarred: false,
  },
  {
    id: 'R004',
    title: 'Tesla: Margin Pressure to Continue in Near-Term',
    company: 'Tesla Inc.',
    symbol: 'TSLA',
    analyst: 'Alex Morgan',
    firm: 'Barclays',
    date: '2024-01-23',
    rating: 'Equal Weight',
    priceTarget: 180,
    summary: 'Price cuts and increasing competition in EV market likely to pressure margins through H1 2024...',
    tags: ['EV', 'Margins', 'Competition'],
    isStarred: false,
  },
  {
    id: 'R005',
    title: 'Amazon: AWS Re-acceleration Thesis Intact',
    company: 'Amazon.com Inc.',
    symbol: 'AMZN',
    analyst: 'Jennifer Lee',
    firm: 'Citi',
    date: '2024-01-22',
    rating: 'Buy',
    priceTarget: 200,
    summary: 'Cloud optimization headwinds subsiding, AI workloads driving renewed growth in AWS...',
    tags: ['Cloud', 'AWS', 'AI'],
    isStarred: false,
  },
]

const getRatingColor = (rating: string) => {
  switch (rating.toLowerCase()) {
    case 'buy':
    case 'overweight':
      return 'text-success bg-success/10'
    case 'sell':
    case 'underweight':
      return 'text-danger bg-danger/10'
    default:
      return 'text-warning bg-warning/10'
  }
}

export default function ResearchPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedReport, setSelectedReport] = useState<typeof researchReports[0] | null>(researchReports[0])

  const filteredReports = researchReports.filter(report =>
    report.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    report.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    report.symbol.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Research</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            {filteredReports.length} research reports
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Report List */}
        <div className="lg:col-span-1 card rounded-xl">
          <div className="p-4 border-b border-gray-100 dark:border-[#2D2D43]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search research..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input pl-10"
              />
            </div>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-[#2D2D43] max-h-[600px] overflow-y-auto">
            {filteredReports.map((report) => (
              <button
                key={report.id}
                onClick={() => setSelectedReport(report)}
                className={clsx(
                  'w-full px-4 py-4 text-left hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors',
                  selectedReport?.id === report.id && 'bg-primary-50 dark:bg-primary-900/20'
                )}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-primary-600">{report.symbol}</span>
                      <span className={clsx(
                        'text-xs font-semibold px-2 py-0.5 rounded',
                        getRatingColor(report.rating)
                      )}>
                        {report.rating}
                      </span>
                      {report.isStarred && <Star className="h-3.5 w-3.5 text-warning fill-warning" />}
                    </div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">{report.title}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-500 dark:text-[#565674]">
                      <span>{report.firm}</span>
                      <span>•</span>
                      <span>{report.date}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Report Detail */}
        <div className="lg:col-span-2">
          {selectedReport ? (
            <div className="space-y-6">
              {/* Report Header */}
              <div className="card rounded-xl p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                      <Building2 className="h-6 w-6 text-gray-500" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-primary-600">{selectedReport.symbol}</span>
                        <span className={clsx(
                          'text-xs font-semibold px-2 py-0.5 rounded',
                          getRatingColor(selectedReport.rating)
                        )}>
                          {selectedReport.rating}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-[#565674]">{selectedReport.company}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-gray-100 dark:hover:bg-[#2D2D43] rounded-lg">
                      <Star className={clsx(
                        'h-5 w-5',
                        selectedReport.isStarred ? 'text-warning fill-warning' : 'text-gray-400'
                      )} />
                    </button>
                    <button className="p-2 hover:bg-gray-100 dark:hover:bg-[#2D2D43] rounded-lg">
                      <ExternalLink className="h-5 w-5 text-gray-400" />
                    </button>
                  </div>
                </div>

                <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                  {selectedReport.title}
                </h2>

                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 dark:text-[#565674]">
                  <div className="flex items-center gap-1">
                    <span className="font-medium">{selectedReport.analyst}</span>
                    <span>•</span>
                    <span>{selectedReport.firm}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{selectedReport.date}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mt-4">
                  {selectedReport.tags.map((tag) => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-gray-100 dark:bg-[#2D2D43] text-gray-600 dark:text-gray-400"
                    >
                      <Tag className="h-3 w-3" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Price Target */}
              <div className="card rounded-xl p-6">
                <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Price Target</h3>
                <div className="flex items-end gap-6">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Target Price</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">${selectedReport.priceTarget}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Implied Upside</p>
                    <p className="text-xl font-semibold text-success">+10.6%</p>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="card rounded-xl p-6">
                <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Summary</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  {selectedReport.summary}
                </p>
              </div>

              {/* Related News */}
              <div className="card rounded-xl">
                <div className="px-6 py-4 border-b border-gray-100 dark:border-[#2D2D43]">
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white">Related News</h3>
                </div>
                <div className="divide-y divide-gray-100 dark:divide-[#2D2D43]">
                  {mockNews.filter(n => n.symbols.includes(selectedReport.symbol)).slice(0, 3).map((news) => (
                    <div key={news.id} className="px-6 py-4 hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors cursor-pointer">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{news.title}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-gray-500 dark:text-[#565674]">
                        <span>{news.source}</span>
                        <span>•</span>
                        <span>{new Date(news.timestamp).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="card rounded-xl p-12 flex flex-col items-center justify-center">
              <FileText className="h-12 w-12 text-gray-300 dark:text-gray-600 mb-4" />
              <p className="text-gray-500 dark:text-[#565674]">Select a report to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
