import { BarChart3, TrendingUp, TrendingDown, DollarSign, Activity, Calendar, PieChart, Target } from 'lucide-react'
import { clsx } from 'clsx'
import { performanceMetrics, brokerMetrics, sectorAllocation, positions } from '../data/mockData'

const monthlyReturns = [
  { month: 'Jan', return: 4.2 },
  { month: 'Feb', return: -1.3 },
  { month: 'Mar', return: 2.8 },
  { month: 'Apr', return: 1.5 },
  { month: 'May', return: -0.8 },
  { month: 'Jun', return: 3.2 },
  { month: 'Jul', return: 2.1 },
  { month: 'Aug', return: -2.4 },
  { month: 'Sep', return: 1.9 },
  { month: 'Oct', return: 4.5 },
  { month: 'Nov', return: 2.7 },
  { month: 'Dec', return: 1.8 },
]

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Analytics</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Performance analytics and insights
          </p>
        </div>
        <select className="input w-40">
          <option>Last 12 Months</option>
          <option>Year to Date</option>
          <option>Last 30 Days</option>
          <option>All Time</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {performanceMetrics.map((metric) => (
          <div key={metric.label} className="card rounded-xl p-5">
            <p className="text-sm text-gray-500 dark:text-[#565674] mb-2">{metric.label}</p>
            <div className="flex items-end justify-between">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{metric.value}</p>
              <span className={clsx(
                'text-sm font-medium',
                metric.trend === 'up' ? 'pnl-positive' : 'pnl-negative'
              )}>
                {metric.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Monthly Returns */}
      <div className="card rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">Monthly Returns</h3>
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-success rounded" />
              Positive
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-danger rounded" />
              Negative
            </span>
          </div>
        </div>
        <div className="flex items-end justify-between gap-2 h-40">
          {monthlyReturns.map((item) => {
            const maxReturn = Math.max(...monthlyReturns.map(r => Math.abs(r.return)))
            const height = (Math.abs(item.return) / maxReturn) * 100
            return (
              <div key={item.month} className="flex-1 flex flex-col items-center gap-2">
                <div className="relative w-full flex justify-center" style={{ height: '100px' }}>
                  <div
                    className={clsx(
                      'w-full max-w-8 rounded-t',
                      item.return >= 0 ? 'bg-success' : 'bg-danger'
                    )}
                    style={{
                      height: `${height}%`,
                      position: 'absolute',
                      bottom: 0,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-500 dark:text-[#565674]">{item.month}</span>
              </div>
            )
          })}
        </div>
        <div className="grid grid-cols-4 gap-4 mt-6 pt-6 border-t border-gray-200 dark:border-[#2D2D43]">
          <div className="text-center">
            <p className="text-2xl font-bold pnl-positive">20.2%</p>
            <p className="text-xs text-gray-500 dark:text-[#565674]">Annual Return</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900 dark:text-white">8</p>
            <p className="text-xs text-gray-500 dark:text-[#565674]">Winning Months</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900 dark:text-white">4</p>
            <p className="text-xs text-gray-500 dark:text-[#565674]">Losing Months</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900 dark:text-white">2:1</p>
            <p className="text-xs text-gray-500 dark:text-[#565674]">Win/Loss Ratio</p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Risk Metrics */}
        <div className="card rounded-xl p-6">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Risk Metrics</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Sharpe Ratio</p>
                <p className="text-xs text-gray-500 dark:text-[#565674]">Risk-adjusted return</p>
              </div>
              <span className="text-lg font-bold text-gray-900 dark:text-white">1.85</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Max Drawdown</p>
                <p className="text-xs text-gray-500 dark:text-[#565674]">Largest peak-to-trough decline</p>
              </div>
              <span className="text-lg font-bold pnl-negative">-8.4%</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Volatility</p>
                <p className="text-xs text-gray-500 dark:text-[#565674]">Standard deviation of returns</p>
              </div>
              <span className="text-lg font-bold text-gray-900 dark:text-white">12.3%</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Beta</p>
                <p className="text-xs text-gray-500 dark:text-[#565674]">Market sensitivity</p>
              </div>
              <span className="text-lg font-bold text-gray-900 dark:text-white">1.12</span>
            </div>
          </div>
        </div>

        {/* Broker Performance */}
        <div className="card rounded-xl p-6">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Execution Quality</h3>
          <div className="space-y-4">
            {brokerMetrics.map((metric) => (
              <div key={metric.label} className="flex items-center justify-between py-2">
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{metric.label}</p>
                </div>
                <span className={clsx(
                  'text-lg font-bold',
                  metric.trend === 'up' ? 'pnl-positive' : 
                  metric.trend === 'down' ? 'pnl-negative' : 
                  'text-gray-900 dark:text-white'
                )}>
                  {metric.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sector Performance */}
      <div className="card rounded-xl p-6">
        <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Sector Performance</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sectorAllocation.map((sector) => {
            const sectorPositions = positions.filter(p => p.sector === sector.sector)
            const sectorReturn = sectorPositions.length > 0
              ? sectorPositions.reduce((sum, p) => sum + p.unrealizedPLPercent, 0) / sectorPositions.length
              : 0
            
            return (
              <div key={sector.sector} className="p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{sector.sector}</span>
                  <span className="text-xs text-gray-500 dark:text-[#565674]">{sector.percentage}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="h-2 flex-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mr-4">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${sector.percentage}%`, backgroundColor: sector.color }}
                    />
                  </div>
                  <span className={clsx(
                    'text-sm font-bold',
                    sectorReturn >= 0 ? 'pnl-positive' : 'pnl-negative'
                  )}>
                    {sectorReturn >= 0 ? '+' : ''}{sectorReturn.toFixed(1)}%
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
