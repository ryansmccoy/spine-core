import { useState } from 'react'
import {
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  Filter,
  Search,
  MoreVertical,
  Plus,
} from 'lucide-react'
import { clsx } from 'clsx'
import { mockOrders } from '../data/mockData'

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

const formatTime = (timestamp: string) => {
  return new Date(timestamp).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}

const getStatusConfig = (status: string) => {
  switch (status) {
    case 'filled':
      return { icon: CheckCircle2, color: 'text-success', bg: 'bg-success/10', label: 'Filled' }
    case 'partial':
      return { icon: RefreshCw, color: 'text-primary-500', bg: 'bg-primary-500/10', label: 'Partial' }
    case 'working':
      return { icon: Clock, color: 'text-warning', bg: 'bg-warning/10', label: 'Working' }
    case 'pending':
      return { icon: AlertCircle, color: 'text-info', bg: 'bg-info/10', label: 'Pending' }
    case 'cancelled':
      return { icon: XCircle, color: 'text-gray-400', bg: 'bg-gray-400/10', label: 'Cancelled' }
    case 'rejected':
      return { icon: XCircle, color: 'text-danger', bg: 'bg-danger/10', label: 'Rejected' }
    default:
      return { icon: AlertCircle, color: 'text-gray-400', bg: 'bg-gray-400/10', label: status }
  }
}

type OrderFilter = 'all' | 'working' | 'filled' | 'pending' | 'cancelled'

export default function OrdersPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<OrderFilter>('all')
  const [sideFilter, setSideFilter] = useState<'all' | 'buy' | 'sell'>('all')

  // Filter orders
  const filteredOrders = mockOrders.filter(order => {
    const matchesSearch = order.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter
    const matchesSide = sideFilter === 'all' || order.side === sideFilter
    return matchesSearch && matchesStatus && matchesSide
  })

  // Calculate stats
  const workingOrders = mockOrders.filter(o => o.status === 'working' || o.status === 'pending').length
  const filledToday = mockOrders.filter(o => o.status === 'filled' || o.status === 'partial').length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Orders</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            {workingOrders} working • {filledToday} filled today
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn btn-primary">
            <Plus className="h-4 w-4 mr-2" />
            New Order
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 sm:grid-cols-4">
        <button 
          onClick={() => setStatusFilter('all')}
          className={clsx(
            'card rounded-xl p-4 text-left transition-all',
            statusFilter === 'all' && 'ring-2 ring-primary-500'
          )}
        >
          <p className="text-sm text-gray-500 dark:text-[#565674]">All Orders</p>
          <p className="text-xl font-bold text-gray-900 dark:text-white mt-1">{mockOrders.length}</p>
        </button>
        <button 
          onClick={() => setStatusFilter('working')}
          className={clsx(
            'card rounded-xl p-4 text-left transition-all',
            statusFilter === 'working' && 'ring-2 ring-warning'
          )}
        >
          <p className="text-sm text-gray-500 dark:text-[#565674]">Working</p>
          <p className="text-xl font-bold text-warning mt-1">
            {mockOrders.filter(o => o.status === 'working').length}
          </p>
        </button>
        <button 
          onClick={() => setStatusFilter('filled')}
          className={clsx(
            'card rounded-xl p-4 text-left transition-all',
            statusFilter === 'filled' && 'ring-2 ring-success'
          )}
        >
          <p className="text-sm text-gray-500 dark:text-[#565674]">Filled</p>
          <p className="text-xl font-bold text-success mt-1">
            {mockOrders.filter(o => o.status === 'filled').length}
          </p>
        </button>
        <button 
          onClick={() => setStatusFilter('pending')}
          className={clsx(
            'card rounded-xl p-4 text-left transition-all',
            statusFilter === 'pending' && 'ring-2 ring-info'
          )}
        >
          <p className="text-sm text-gray-500 dark:text-[#565674]">Pending</p>
          <p className="text-xl font-bold text-info mt-1">
            {mockOrders.filter(o => o.status === 'pending').length}
          </p>
        </button>
      </div>

      {/* Filters */}
      <div className="card rounded-xl p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search orders..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pl-10"
            />
          </div>
          <div className="flex items-center gap-3">
            <select
              value={sideFilter}
              onChange={(e) => setSideFilter(e.target.value as 'all' | 'buy' | 'sell')}
              className="input w-auto"
            >
              <option value="all">All Sides</option>
              <option value="buy">Buy</option>
              <option value="sell">Sell</option>
            </select>
            <button className="btn btn-secondary">
              <Filter className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 dark:bg-[#1B1B29] border-b border-gray-100 dark:border-[#2D2D43]">
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Order ID
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Symbol
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Side
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Qty
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Filled
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Price
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Avg Fill
                </th>
                <th className="px-6 py-4 text-center text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Account
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Time
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 dark:text-[#565674] uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-[#2D2D43]">
              {filteredOrders.map((order) => {
                const statusConfig = getStatusConfig(order.status)
                const StatusIcon = statusConfig.icon
                return (
                  <tr 
                    key={order.id}
                    className="hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors"
                  >
                    <td className="px-6 py-4 font-mono text-xs text-gray-500 dark:text-[#565674]">
                      {order.id}
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-semibold text-gray-900 dark:text-white">{order.symbol}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={clsx(
                        'px-2 py-1 rounded text-xs font-semibold uppercase',
                        order.side === 'buy' ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'
                      )}>
                        {order.side}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-600 dark:text-gray-400 capitalize">
                      {order.orderType.replace('_', ' ')}
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-gray-900 dark:text-white">
                      {order.quantity.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right text-gray-600 dark:text-gray-400">
                      {order.filledQuantity.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right text-gray-600 dark:text-gray-400">
                      {order.price ? `$${order.price.toFixed(2)}` : '—'}
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-gray-900 dark:text-white">
                      {order.avgFillPrice ? `$${order.avgFillPrice.toFixed(2)}` : '—'}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-center">
                        <span className={clsx(
                          'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
                          statusConfig.bg,
                          statusConfig.color
                        )}>
                          <StatusIcon className="h-3.5 w-3.5" />
                          {statusConfig.label}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                      {order.account}
                    </td>
                    <td className="px-6 py-4 text-gray-600 dark:text-gray-400 font-mono text-xs">
                      {formatTime(order.timestamp)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 hover:bg-gray-100 dark:hover:bg-[#2D2D43] rounded-lg transition-colors">
                        <MoreVertical className="h-4 w-4 text-gray-400" />
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
