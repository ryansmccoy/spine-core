import { useState } from 'react'
import {
  TrendingUp,
  TrendingDown,
  Search,
  Star,
  Plus,
  Settings,
  MoreVertical,
} from 'lucide-react'
import { clsx } from 'clsx'
import { mockWatchlist } from '../data/mockData'

export default function MarketDataPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>('AAPL')

  const filteredWatchlist = mockWatchlist.filter(item =>
    item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const selectedItem = mockWatchlist.find(item => item.symbol === selectedSymbol)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Market Data</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Real-time quotes and market information
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary">
            <Settings className="h-4 w-4 mr-2" />
            Manage Lists
          </button>
          <button className="btn btn-primary">
            <Plus className="h-4 w-4 mr-2" />
            Add Symbol
          </button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Watchlist */}
        <div className="lg:col-span-1 card rounded-xl">
          <div className="p-4 border-b border-gray-100 dark:border-[#2D2D43]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search symbols..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input pl-10"
              />
            </div>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-[#2D2D43] max-h-[600px] overflow-y-auto">
            {filteredWatchlist.map((item) => (
              <button
                key={item.symbol}
                onClick={() => setSelectedSymbol(item.symbol)}
                className={clsx(
                  'w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-[#1B1B29] transition-colors',
                  selectedSymbol === item.symbol && 'bg-primary-50 dark:bg-primary-900/20'
                )}
              >
                <div className="flex items-center gap-3">
                  <Star className={clsx(
                    'h-4 w-4',
                    selectedSymbol === item.symbol ? 'text-warning fill-warning' : 'text-gray-300 dark:text-gray-600'
                  )} />
                  <div className="text-left">
                    <p className="font-semibold text-gray-900 dark:text-white">{item.symbol}</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">{item.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900 dark:text-white">${item.price.toFixed(2)}</p>
                  <p className={clsx(
                    'text-xs font-medium flex items-center justify-end gap-0.5',
                    item.change >= 0 ? 'text-success' : 'text-danger'
                  )}>
                    {item.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {item.change >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Quote Details */}
        <div className="lg:col-span-2 space-y-6">
          {selectedItem ? (
            <>
              {/* Quote Header */}
              <div className="card rounded-xl p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{selectedItem.symbol}</h2>
                      <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-[#2D2D43] rounded-lg">
                        <Star className="h-5 w-5 text-warning fill-warning" />
                      </button>
                    </div>
                    <p className="text-gray-500 dark:text-[#565674]">{selectedItem.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">${selectedItem.price.toFixed(2)}</p>
                    <p className={clsx(
                      'text-lg font-semibold flex items-center justify-end gap-1',
                      selectedItem.change >= 0 ? 'text-success' : 'text-danger'
                    )}>
                      {selectedItem.change >= 0 ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
                      {selectedItem.change >= 0 ? '+' : ''}{selectedItem.change.toFixed(2)} ({selectedItem.changePercent.toFixed(2)}%)
                    </p>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-gray-100 dark:border-[#2D2D43]">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Volume</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{selectedItem.volume}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Market Cap</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{selectedItem.marketCap}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Day High</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">${(selectedItem.price * 1.02).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-[#565674]">Day Low</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">${(selectedItem.price * 0.98).toFixed(2)}</p>
                  </div>
                </div>
              </div>

              {/* Chart Placeholder */}
              <div className="card rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white">Price Chart</h3>
                  <div className="flex items-center gap-2">
                    {['1D', '1W', '1M', '3M', '1Y', 'ALL'].map((period) => (
                      <button
                        key={period}
                        className={clsx(
                          'px-3 py-1 text-xs font-medium rounded-lg transition-colors',
                          period === '1D'
                            ? 'bg-primary-500 text-white'
                            : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-[#2D2D43]'
                        )}
                      >
                        {period}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-gray-500 dark:text-[#565674]">Chart visualization would go here</p>
                </div>
              </div>

              {/* Additional Info */}
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="card rounded-xl p-6">
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Key Statistics</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-[#565674]">P/E Ratio</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">28.5</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-[#565674]">EPS (TTM)</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">$6.65</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-[#565674]">Dividend Yield</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">0.51%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-[#565674]">52 Week High</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">$199.62</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-[#565674]">52 Week Low</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">$164.08</span>
                    </div>
                  </div>
                </div>

                <div className="card rounded-xl p-6">
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Analyst Ratings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-success">Buy</span>
                          <span className="text-gray-500">32</span>
                        </div>
                        <div className="h-2 bg-gray-100 dark:bg-[#2D2D43] rounded-full overflow-hidden">
                          <div className="h-full bg-success rounded-full" style={{ width: '65%' }} />
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-warning">Hold</span>
                          <span className="text-gray-500">14</span>
                        </div>
                        <div className="h-2 bg-gray-100 dark:bg-[#2D2D43] rounded-full overflow-hidden">
                          <div className="h-full bg-warning rounded-full" style={{ width: '28%' }} />
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-danger">Sell</span>
                          <span className="text-gray-500">3</span>
                        </div>
                        <div className="h-2 bg-gray-100 dark:bg-[#2D2D43] rounded-full overflow-hidden">
                          <div className="h-full bg-danger rounded-full" style={{ width: '7%' }} />
                        </div>
                      </div>
                    </div>
                    <div className="pt-2 border-t border-gray-100 dark:border-[#2D2D43]">
                      <p className="text-sm text-gray-500 dark:text-[#565674]">Average Price Target</p>
                      <p className="text-lg font-semibold text-gray-900 dark:text-white">$205.00</p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="card rounded-xl p-12 flex flex-col items-center justify-center">
              <Search className="h-12 w-12 text-gray-300 dark:text-gray-600 mb-4" />
              <p className="text-gray-500 dark:text-[#565674]">Select a symbol to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
