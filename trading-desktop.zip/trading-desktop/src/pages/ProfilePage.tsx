import {
  User,
  Mail,
  Phone,
  Building2,
  MapPin,
  Calendar,
  Shield,
  Key,
  Bell,
  Settings,
  Edit2,
  Camera,
} from 'lucide-react'

export default function ProfilePage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Profile</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Manage your account settings and preferences
          </p>
        </div>
        <button className="btn btn-primary">
          <Edit2 className="h-4 w-4 mr-2" />
          Edit Profile
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Profile Card */}
        <div className="card rounded-xl p-6 text-center">
          <div className="relative inline-block">
            <div className="h-24 w-24 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center text-3xl font-bold text-white mx-auto">
              JD
            </div>
            <button className="absolute bottom-0 right-0 p-2 bg-white dark:bg-[#2D2D43] rounded-full shadow-lg hover:shadow-xl transition-shadow">
              <Camera className="h-4 w-4 text-gray-500" />
            </button>
          </div>
          <h2 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">John Doe</h2>
          <p className="text-gray-500 dark:text-[#565674]">Portfolio Manager</p>
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-success/10 text-success">
              <Shield className="h-3 w-3" />
              Verified
            </span>
            <span className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-primary-100 dark:bg-primary-900/30 text-primary-600">
              Pro Member
            </span>
          </div>
        </div>

        {/* Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="card rounded-xl p-6">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Personal Information</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <User className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Full Name</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">John Doe</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <Mail className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Email</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">john.doe@firm.com</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <Phone className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Phone</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">+1 (555) 123-4567</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <Building2 className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Department</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Portfolio Management</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <MapPin className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Location</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">New York, NY</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 dark:bg-[#2D2D43]">
                  <Calendar className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Joined</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">January 2022</p>
                </div>
              </div>
            </div>
          </div>

          <div className="card rounded-xl p-6">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Security</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                <div className="flex items-center gap-3">
                  <Key className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Password</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Last changed 30 days ago</p>
                  </div>
                </div>
                <button className="text-sm font-medium text-primary-600 hover:text-primary-700">Change</button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Two-Factor Authentication</p>
                    <p className="text-xs text-success">Enabled</p>
                  </div>
                </div>
                <button className="text-sm font-medium text-primary-600 hover:text-primary-700">Manage</button>
              </div>
            </div>
          </div>

          <div className="card rounded-xl p-6">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4">Quick Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="h-5 w-5 text-gray-500" />
                  <span className="text-sm text-gray-900 dark:text-white">Email Notifications</span>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="h-5 w-5 text-gray-500" />
                  <span className="text-sm text-gray-900 dark:text-white">Push Notifications</span>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-gray-500" />
                  <span className="text-sm text-gray-900 dark:text-white">Trading Confirmations</span>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
