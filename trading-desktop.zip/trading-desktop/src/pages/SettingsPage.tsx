import { useState } from 'react'
import {
  Settings,
  Bell,
  Moon,
  Sun,
  Globe,
  Shield,
  Database,
  Zap,
  Monitor,
  Palette,
} from 'lucide-react'
import { clsx } from 'clsx'
import { useLayout } from '../layouts/AdminLayout'

interface SettingSection {
  id: string
  name: string
  icon: React.ElementType
}

const sections: SettingSection[] = [
  { id: 'appearance', name: 'Appearance', icon: Palette },
  { id: 'notifications', name: 'Notifications', icon: Bell },
  { id: 'trading', name: 'Trading', icon: Zap },
  { id: 'data', name: 'Data & Display', icon: Monitor },
  { id: 'privacy', name: 'Privacy', icon: Shield },
  { id: 'advanced', name: 'Advanced', icon: Database },
]

export default function SettingsPage() {
  const { darkMode, setDarkMode } = useLayout()
  const [activeSection, setActiveSection] = useState('appearance')

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-sm text-gray-500 dark:text-[#565674]">
          Customize your trading desktop experience
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Sidebar */}
        <div className="card rounded-xl p-2">
          <nav className="space-y-1">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={clsx(
                  'w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors',
                  activeSection === section.id
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-[#1B1B29]'
                )}
              >
                <section.icon className="h-5 w-5" />
                {section.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="lg:col-span-3 space-y-6">
          {activeSection === 'appearance' && (
            <>
              <div className="card rounded-xl p-6">
                <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Theme</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <button
                    onClick={() => setDarkMode(false)}
                    className={clsx(
                      'p-4 rounded-lg border-2 transition-all',
                      !darkMode
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-gray-200 dark:border-[#2D2D43] hover:border-gray-300'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white shadow">
                        <Sun className="h-5 w-5 text-warning" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900 dark:text-white">Light Mode</p>
                        <p className="text-xs text-gray-500 dark:text-[#565674]">Clean and bright interface</p>
                      </div>
                    </div>
                  </button>
                  <button
                    onClick={() => setDarkMode(true)}
                    className={clsx(
                      'p-4 rounded-lg border-2 transition-all',
                      darkMode
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-gray-200 dark:border-[#2D2D43] hover:border-gray-300'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-800 shadow">
                        <Moon className="h-5 w-5 text-primary-400" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900 dark:text-white">Dark Mode</p>
                        <p className="text-xs text-gray-500 dark:text-[#565674]">Easy on the eyes</p>
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="card rounded-xl p-6">
                <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Display</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Compact Mode</p>
                      <p className="text-xs text-gray-500 dark:text-[#565674]">Show more data in less space</p>
                    </div>
                    <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                      <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Sidebar Collapsed</p>
                      <p className="text-xs text-gray-500 dark:text-[#565674]">Minimize sidebar by default</p>
                    </div>
                    <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                      <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeSection === 'notifications' && (
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Notification Preferences</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Order Fills</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Get notified when orders are filled</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Price Alerts</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Notify when price targets are hit</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Market News</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Breaking news for watchlist symbols</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Research Updates</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">New research reports available</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Sound Alerts</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Play sound on important notifications</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'trading' && (
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Trading Preferences</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Default Order Type
                  </label>
                  <select className="input">
                    <option>Market</option>
                    <option>Limit</option>
                    <option>Stop</option>
                    <option>Stop Limit</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Default Time in Force
                  </label>
                  <select className="input">
                    <option>Day</option>
                    <option>GTC (Good Till Cancelled)</option>
                    <option>IOC (Immediate or Cancel)</option>
                    <option>FOK (Fill or Kill)</option>
                  </select>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Confirm Orders</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Show confirmation dialog before submitting</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'data' && (
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Data & Display Settings</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Price Display
                  </label>
                  <select className="input">
                    <option>2 Decimal Places</option>
                    <option>3 Decimal Places</option>
                    <option>4 Decimal Places</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Number Format
                  </label>
                  <select className="input">
                    <option>1,234,567.89 (US)</option>
                    <option>1.234.567,89 (EU)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Timezone
                  </label>
                  <select className="input">
                    <option>Eastern Time (ET)</option>
                    <option>Pacific Time (PT)</option>
                    <option>UTC</option>
                    <option>Local Time</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'privacy' && (
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Privacy Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Hide Account Values</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Mask portfolio values on screen</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Activity Tracking</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Allow usage analytics</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-500">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'advanced' && (
            <div className="card rounded-xl p-6">
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-6">Advanced Settings</h3>
              <div className="space-y-4">
                <div className="p-4 bg-warning/10 rounded-lg">
                  <p className="text-sm text-warning font-medium">⚠️ These settings are for advanced users</p>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Developer Mode</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Enable developer tools and logging</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                  </button>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">WebSocket Debug</p>
                    <p className="text-xs text-gray-500 dark:text-[#565674]">Show real-time data stream logs</p>
                  </div>
                  <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-300 dark:bg-gray-600">
                    <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
