import { useState } from 'react'
import { Search, Building2, TrendingUp, TrendingDown, ExternalLink, Star, Filter } from 'lucide-react'
import { clsx } from 'clsx'

const companies = [
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    sector: 'Technology',
    industry: 'Consumer Electronics',
    marketCap: '$2.89T',
    price: 189.95,
    change: 2.34,
    changePercent: 1.25,
    pe: 31.2,
    eps: 6.09,
    dividend: 0.96,
    isWatchlisted: true,
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    sector: 'Technology',
    industry: 'Software',
    marketCap: '$2.78T',
    price: 374.51,
    change: -1.23,
    changePercent: -0.33,
    pe: 36.8,
    eps: 10.18,
    dividend: 3.00,
    isWatchlisted: true,
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    sector: 'Technology',
    industry: 'Internet Services',
    marketCap: '$1.74T',
    price: 141.80,
    change: 3.45,
    changePercent: 2.50,
    pe: 25.4,
    eps: 5.58,
    dividend: 0,
    isWatchlisted: false,
  },
  {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    sector: 'Consumer Cyclical',
    industry: 'E-Commerce',
    marketCap: '$1.56T',
    price: 151.94,
    change: 0.87,
    changePercent: 0.58,
    pe: 62.3,
    eps: 2.44,
    dividend: 0,
    isWatchlisted: false,
  },
  {
    symbol: 'JPM',
    name: 'JPMorgan Chase & Co.',
    sector: 'Financial Services',
    industry: 'Banking',
    marketCap: '$502B',
    price: 172.96,
    change: -2.15,
    changePercent: -1.23,
    pe: 11.2,
    eps: 15.44,
    dividend: 4.40,
    isWatchlisted: true,
  },
  {
    symbol: 'JNJ',
    name: 'Johnson & Johnson',
    sector: 'Healthcare',
    industry: 'Pharmaceuticals',
    marketCap: '$384B',
    price: 159.55,
    change: 0.45,
    changePercent: 0.28,
    pe: 15.8,
    eps: 10.10,
    dividend: 4.76,
    isWatchlisted: false,
  },
]

const sectors = ['All', 'Technology', 'Financial Services', 'Healthcare', 'Consumer Cyclical', 'Energy']

export default function CompaniesPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSector, setSelectedSector] = useState('All')
  const [selectedCompany, setSelectedCompany] = useState<typeof companies[0] | null>(null)

  const filteredCompanies = companies.filter((company) => {
    const matchesSector = selectedSector === 'All' || company.sector === selectedSector
    const matchesSearch =
      company.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSector && matchesSearch
  })

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Companies</h1>
        <p className="text-sm text-gray-500 dark:text-[#565674]">
          Browse and analyze company fundamentals
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search by symbol or name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input pl-10 w-full"
          />
        </div>
        <select
          value={selectedSector}
          onChange={(e) => setSelectedSector(e.target.value)}
          className="input w-full sm:w-48"
        >
          {sectors.map((sector) => (
            <option key={sector} value={sector}>{sector}</option>
          ))}
        </select>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Companies List */}
        <div className="lg:col-span-2">
          <div className="card rounded-xl overflow-hidden">
            <table className="table w-full">
              <thead>
                <tr>
                  <th className="text-left">Company</th>
                  <th className="text-right">Price</th>
                  <th className="text-right">Change</th>
                  <th className="text-right">Market Cap</th>
                  <th className="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCompanies.map((company) => (
                  <tr
                    key={company.symbol}
                    onClick={() => setSelectedCompany(company)}
                    className={clsx(
                      'cursor-pointer',
                      selectedCompany?.symbol === company.symbol && 'bg-primary-50 dark:bg-primary-900/10'
                    )}
                  >
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-100 dark:bg-primary-900/30">
                          <span className="text-sm font-bold text-primary-600">{company.symbol.slice(0, 2)}</span>
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-white">{company.symbol}</p>
                          <p className="text-xs text-gray-500 dark:text-[#565674] truncate max-w-[150px]">{company.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="text-right font-medium text-gray-900 dark:text-white">
                      ${company.price.toFixed(2)}
                    </td>
                    <td className="text-right">
                      <span className={clsx(
                        'font-medium',
                        company.change >= 0 ? 'pnl-positive' : 'pnl-negative'
                      )}>
                        {company.change >= 0 ? '+' : ''}{company.changePercent.toFixed(2)}%
                      </span>
                    </td>
                    <td className="text-right text-gray-600 dark:text-gray-400">{company.marketCap}</td>
                    <td className="text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          // Toggle watchlist
                        }}
                        className={clsx(
                          'p-1.5 rounded-lg transition-colors',
                          company.isWatchlisted
                            ? 'text-warning bg-warning/10'
                            : 'text-gray-400 hover:text-warning hover:bg-warning/10'
                        )}
                      >
                        <Star className={clsx('h-4 w-4', company.isWatchlisted && 'fill-current')} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Company Detail */}
        <div className="lg:col-span-1">
          {selectedCompany ? (
            <div className="card rounded-xl p-6 sticky top-6 space-y-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      {selectedCompany.symbol}
                    </h2>
                    <button className={clsx(
                      'p-1 rounded',
                      selectedCompany.isWatchlisted
                        ? 'text-warning'
                        : 'text-gray-400 hover:text-warning'
                    )}>
                      <Star className={clsx('h-5 w-5', selectedCompany.isWatchlisted && 'fill-current')} />
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-[#565674]">{selectedCompany.name}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    ${selectedCompany.price.toFixed(2)}
                  </p>
                  <div className={clsx(
                    'flex items-center gap-1 justify-end',
                    selectedCompany.change >= 0 ? 'pnl-positive' : 'pnl-negative'
                  )}>
                    {selectedCompany.change >= 0 ? (
                      <TrendingUp className="h-4 w-4" />
                    ) : (
                      <TrendingDown className="h-4 w-4" />
                    )}
                    <span className="font-medium">
                      {selectedCompany.change >= 0 ? '+' : ''}{selectedCompany.change.toFixed(2)} ({selectedCompany.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Market Cap</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">{selectedCompany.marketCap}</p>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-[#565674]">P/E Ratio</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">{selectedCompany.pe.toFixed(2)}</p>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-[#565674]">EPS</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">${selectedCompany.eps.toFixed(2)}</p>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-[#1B1B29] rounded-lg">
                  <p className="text-xs text-gray-500 dark:text-[#565674]">Dividend</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {selectedCompany.dividend > 0 ? `$${selectedCompany.dividend.toFixed(2)}` : '-'}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Classification</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">{selectedCompany.sector}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">{selectedCompany.industry}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button className="btn btn-primary flex-1">View Details</button>
                <button className="btn bg-gray-100 dark:bg-[#1B1B29] text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-[#2D2D43]">
                  <ExternalLink className="h-4 w-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="card rounded-xl p-12 text-center">
              <Building2 className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
              <p className="text-gray-500 dark:text-[#565674]">Select a company to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
