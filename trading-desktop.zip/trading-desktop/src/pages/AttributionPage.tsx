/**
 * Attribution Page for MarketSpine
 * Bloomberg-style Brinson Attribution, Factor Analysis, Performance Contribution
 */

import { useState } from 'react';
import {
  PieChart,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Download,
  RefreshCw,
  Calendar,
  ChevronDown,
  ChevronRight,
  Layers,
} from 'lucide-react';
import { clsx } from 'clsx';

// Mock attribution data
const mockBrinsonAttribution = {
  totalReturn: 2.45,
  benchmarkReturn: 1.82,
  activeReturn: 0.63,
  allocation: 0.28,
  selection: 0.35,
  interaction: 0.00,
};

const mockSectorAttribution = [
  { sector: 'Technology', portfolioWeight: 32.5, benchmarkWeight: 28.0, allocation: 0.15, selection: 0.22, total: 0.37 },
  { sector: 'Healthcare', portfolioWeight: 14.2, benchmarkWeight: 13.5, allocation: 0.02, selection: 0.08, total: 0.10 },
  { sector: 'Financials', portfolioWeight: 12.8, benchmarkWeight: 11.2, allocation: 0.05, selection: 0.05, total: 0.10 },
  { sector: 'Consumer Disc', portfolioWeight: 11.5, benchmarkWeight: 10.8, allocation: 0.02, selection: 0.04, total: 0.06 },
  { sector: 'Industrials', portfolioWeight: 9.2, benchmarkWeight: 8.5, allocation: 0.02, selection: -0.02, total: 0.00 },
  { sector: 'Consumer Staples', portfolioWeight: 5.8, benchmarkWeight: 6.5, allocation: -0.01, selection: 0.01, total: 0.00 },
  { sector: 'Energy', portfolioWeight: 4.2, benchmarkWeight: 4.5, allocation: 0.00, selection: -0.03, total: -0.03 },
  { sector: 'Other', portfolioWeight: 9.8, benchmarkWeight: 17.0, allocation: 0.03, selection: 0.00, total: 0.03 },
];

const mockFactorExposures = [
  { factor: 'Market', exposure: 1.12, contribution: 1.85, color: '#58A6FF' },
  { factor: 'Size', exposure: 0.25, contribution: 0.18, color: '#3FB950' },
  { factor: 'Value', exposure: -0.15, contribution: -0.08, color: '#F85149' },
  { factor: 'Momentum', exposure: 0.42, contribution: 0.32, color: '#FFD700' },
  { factor: 'Quality', exposure: 0.35, contribution: 0.22, color: '#A371F7' },
  { factor: 'Volatility', exposure: -0.28, contribution: -0.12, color: '#FF6B35' },
];

const mockTopContributors = [
  { ticker: 'AAPL', name: 'Apple Inc', contribution: 0.45, weight: 8.5, return: 5.3 },
  { ticker: 'MSFT', name: 'Microsoft Corp', contribution: 0.38, weight: 7.2, return: 5.1 },
  { ticker: 'NVDA', name: 'NVIDIA Corp', contribution: 0.32, weight: 4.5, return: 7.1 },
  { ticker: 'GOOGL', name: 'Alphabet Inc', contribution: 0.18, weight: 3.8, return: 4.7 },
  { ticker: 'AMZN', name: 'Amazon.com', contribution: 0.15, weight: 3.2, return: 4.5 },
];

const mockBottomContributors = [
  { ticker: 'XOM', name: 'Exxon Mobil', contribution: -0.12, weight: 1.5, return: -8.2 },
  { ticker: 'CVX', name: 'Chevron Corp', contribution: -0.08, weight: 1.2, return: -6.5 },
  { ticker: 'WMT', name: 'Walmart Inc', contribution: -0.05, weight: 0.8, return: -3.2 },
  { ticker: 'KO', name: 'Coca-Cola Co', contribution: -0.04, weight: 0.6, return: -2.8 },
  { ticker: 'PEP', name: 'PepsiCo Inc', contribution: -0.03, weight: 0.5, return: -2.5 },
];

const timePeriods = ['1D', '1W', 'MTD', 'QTD', 'YTD', '1Y', '3Y', 'SI'];

export default function AttributionPage() {
  const [activeTab, setActiveTab] = useState<'brinson' | 'factor' | 'contribution'>('brinson');
  const [selectedPeriod, setSelectedPeriod] = useState('MTD');
  const [expandedSector, setExpandedSector] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Performance Attribution</h1>
          <p className="text-sm text-gray-500 dark:text-[#565674]">
            Brinson Analysis, Factor Attribution, and Return Contribution
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn btn-secondary text-sm">
            <RefreshCw className="h-4 w-4 mr-1.5" />
            Refresh
          </button>
          <button className="btn btn-secondary text-sm">
            <Download className="h-4 w-4 mr-1.5" />
            Export
          </button>
        </div>
      </div>

      {/* Period Selector */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-[#8B949E]" />
          <span className="text-sm text-[#8B949E]">Period:</span>
        </div>
        <div className="flex gap-1 p-0.5 bg-[#1B1B29] rounded-lg">
          {timePeriods.map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={clsx(
                'px-3 py-1.5 rounded text-xs font-medium transition-all',
                selectedPeriod === period
                  ? 'bg-[#FF6B35] text-white'
                  : 'text-[#8B949E] hover:text-white hover:bg-[#21262D]'
              )}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 p-1 bg-[#1B1B29] rounded-lg w-fit">
        {[
          { id: 'brinson', label: 'Brinson Attribution', icon: PieChart },
          { id: 'factor', label: 'Factor Analysis', icon: Layers },
          { id: 'contribution', label: 'Return Contribution', icon: BarChart3 },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={clsx(
              'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
              activeTab === tab.id
                ? 'bg-[#FF6B35] text-white'
                : 'text-[#8B949E] hover:text-white hover:bg-[#21262D]'
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Brinson Tab */}
      {activeTab === 'brinson' && (
        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
            {[
              { label: 'Portfolio', value: mockBrinsonAttribution.totalReturn, color: 'text-white' },
              { label: 'Benchmark', value: mockBrinsonAttribution.benchmarkReturn, color: 'text-[#8B949E]' },
              { label: 'Active Return', value: mockBrinsonAttribution.activeReturn, color: 'text-[#3FB950]' },
              { label: 'Allocation', value: mockBrinsonAttribution.allocation, color: 'text-[#58A6FF]' },
              { label: 'Selection', value: mockBrinsonAttribution.selection, color: 'text-[#FFD700]' },
              { label: 'Interaction', value: mockBrinsonAttribution.interaction, color: 'text-[#A371F7]' },
            ].map((item, idx) => (
              <div key={idx} className="card rounded-lg p-3 text-center">
                <p className="text-xs text-[#565674] uppercase tracking-wider">{item.label}</p>
                <p className={clsx('text-xl font-bold font-mono mt-1', item.color)}>
                  {item.value >= 0 ? '+' : ''}{item.value.toFixed(2)}%
                </p>
              </div>
            ))}
          </div>

          {/* Sector Attribution Table */}
          <div className="card rounded-lg overflow-hidden">
            <div className="bg-[#21262D] px-4 py-3 border-b border-[#30363D]">
              <h3 className="text-sm font-semibold text-white">Sector Attribution</h3>
            </div>
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="border-b border-[#21262D]">
                  <th className="text-left py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Sector</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Port Wt</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Bench Wt</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Active Wt</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Allocation</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Selection</th>
                  <th className="text-right py-2.5 px-3 text-[#FF6B35] font-semibold uppercase text-[11px]">Total</th>
                </tr>
              </thead>
              <tbody>
                {mockSectorAttribution.map((row, idx) => (
                  <tr
                    key={idx}
                    className="border-b border-[#21262D]/50 hover:bg-[#21262D]/30 cursor-pointer"
                    onClick={() => setExpandedSector(expandedSector === row.sector ? null : row.sector)}
                  >
                    <td className="py-2.5 px-3 text-[#E6EDF3]">
                      <div className="flex items-center gap-2">
                        {expandedSector === row.sector ? (
                          <ChevronDown className="h-3 w-3 text-[#565674]" />
                        ) : (
                          <ChevronRight className="h-3 w-3 text-[#565674]" />
                        )}
                        {row.sector}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#E6EDF3]">{row.portfolioWeight.toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-right text-[#8B949E]">{row.benchmarkWeight.toFixed(1)}%</td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right',
                      (row.portfolioWeight - row.benchmarkWeight) >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {(row.portfolioWeight - row.benchmarkWeight) >= 0 ? '+' : ''}
                      {(row.portfolioWeight - row.benchmarkWeight).toFixed(1)}%
                    </td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right',
                      row.allocation >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {row.allocation >= 0 ? '+' : ''}{row.allocation.toFixed(2)}%
                    </td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right',
                      row.selection >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {row.selection >= 0 ? '+' : ''}{row.selection.toFixed(2)}%
                    </td>
                    <td className={clsx(
                      'py-2.5 px-3 text-right font-semibold',
                      row.total >= 0 ? 'text-[#3FB950]' : 'text-[#F85149]'
                    )}>
                      {row.total >= 0 ? '+' : ''}{row.total.toFixed(2)}%
                    </td>
                  </tr>
                ))}
                {/* Total Row */}
                <tr className="bg-[#21262D] font-semibold">
                  <td className="py-2.5 px-3 text-white">Total</td>
                  <td className="py-2.5 px-3 text-right text-white">100.0%</td>
                  <td className="py-2.5 px-3 text-right text-[#8B949E]">100.0%</td>
                  <td className="py-2.5 px-3 text-right text-white">0.0%</td>
                  <td className="py-2.5 px-3 text-right text-[#3FB950]">+{mockBrinsonAttribution.allocation.toFixed(2)}%</td>
                  <td className="py-2.5 px-3 text-right text-[#3FB950]">+{mockBrinsonAttribution.selection.toFixed(2)}%</td>
                  <td className="py-2.5 px-3 text-right text-[#3FB950]">+{mockBrinsonAttribution.activeReturn.toFixed(2)}%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Factor Analysis Tab */}
      {activeTab === 'factor' && (
        <div className="space-y-4">
          {/* Factor Exposure Cards */}
          <div className="grid gap-4 lg:grid-cols-2">
            {/* Factor Exposures */}
            <div className="card rounded-lg p-4">
              <h3 className="text-sm font-semibold text-white mb-4">Factor Exposures & Contributions</h3>
              <div className="space-y-3">
                {mockFactorExposures.map((factor, idx) => (
                  <div key={idx} className="flex items-center gap-4">
                    <div className="w-24 text-sm text-[#E6EDF3]">{factor.factor}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#8B949E]">Exposure: {factor.exposure.toFixed(2)}</span>
                        <span style={{ color: factor.color }}>
                          {factor.contribution >= 0 ? '+' : ''}{factor.contribution.toFixed(2)}%
                        </span>
                      </div>
                      <div className="h-2 bg-[#21262D] rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            backgroundColor: factor.color,
                            width: `${Math.abs(factor.contribution) * 30}%`,
                            marginLeft: factor.contribution < 0 ? 'auto' : 0,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Factor Summary */}
            <div className="card rounded-lg p-4">
              <h3 className="text-sm font-semibold text-white mb-4">Factor Return Attribution</h3>
              <div className="space-y-2">
                <div className="flex justify-between py-2 border-b border-[#21262D]">
                  <span className="text-[#8B949E]">Factor Return</span>
                  <span className="text-[#3FB950] font-mono">
                    +{mockFactorExposures.reduce((sum, f) => sum + f.contribution, 0).toFixed(2)}%
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-[#21262D]">
                  <span className="text-[#8B949E]">Specific Return</span>
                  <span className="text-[#FFD700] font-mono">+0.08%</span>
                </div>
                <div className="flex justify-between py-2 font-semibold">
                  <span className="text-white">Total Return</span>
                  <span className="text-[#3FB950] font-mono">+{mockBrinsonAttribution.totalReturn.toFixed(2)}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Return Contribution Tab */}
      {activeTab === 'contribution' && (
        <div className="grid gap-4 lg:grid-cols-2">
          {/* Top Contributors */}
          <div className="card rounded-lg overflow-hidden">
            <div className="bg-[#3FB950]/10 px-4 py-3 border-b border-[#30363D] flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-[#3FB950]" />
              <h3 className="text-sm font-semibold text-[#3FB950]">Top Contributors</h3>
            </div>
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="border-b border-[#21262D]">
                  <th className="text-left py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Security</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Weight</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Return</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Contrib</th>
                </tr>
              </thead>
              <tbody>
                {mockTopContributors.map((item, idx) => (
                  <tr key={idx} className="border-b border-[#21262D]/50 hover:bg-[#21262D]/30">
                    <td className="py-2 px-3">
                      <div className="text-[#E6EDF3] font-medium">{item.ticker}</div>
                      <div className="text-[#565674] text-[11px]">{item.name}</div>
                    </td>
                    <td className="py-2 px-3 text-right text-[#8B949E]">{item.weight.toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-[#3FB950]">+{item.return.toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-[#3FB950] font-semibold">+{item.contribution.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Bottom Contributors */}
          <div className="card rounded-lg overflow-hidden">
            <div className="bg-[#F85149]/10 px-4 py-3 border-b border-[#30363D] flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-[#F85149]" />
              <h3 className="text-sm font-semibold text-[#F85149]">Bottom Contributors</h3>
            </div>
            <table className="w-full text-[13px] font-mono">
              <thead>
                <tr className="border-b border-[#21262D]">
                  <th className="text-left py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Security</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Weight</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Return</th>
                  <th className="text-right py-2 px-3 text-[#565674] font-medium uppercase text-[10px]">Contrib</th>
                </tr>
              </thead>
              <tbody>
                {mockBottomContributors.map((item, idx) => (
                  <tr key={idx} className="border-b border-[#21262D]/50 hover:bg-[#21262D]/30">
                    <td className="py-2 px-3">
                      <div className="text-[#E6EDF3] font-medium">{item.ticker}</div>
                      <div className="text-[#565674] text-[11px]">{item.name}</div>
                    </td>
                    <td className="py-2 px-3 text-right text-[#8B949E]">{item.weight.toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-[#F85149]">{item.return.toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-[#F85149] font-semibold">{item.contribution.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
