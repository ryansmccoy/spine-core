/**
 * Authentication Store for MarketSpine
 * Manages user session, JWT tokens, and auth state
 * Includes mock authentication fallback for development
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { User, LoginRequest, LoginResponse } from '../types/auth';

interface AuthState {
  // User state
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  
  // Tokens
  accessToken: string | null;
  refreshToken: string | null;
  tokenExpiresAt: number | null;
  
  // Actions
  login: (credentials: LoginRequest) => Promise<void>;
  logout: () => void;
  refreshAccessToken: () => Promise<boolean>;
  setUser: (user: User) => void;
  setTokens: (access: string, refresh: string, expiresIn: number) => void;
  clearAuth: () => void;
  
  // Permission helpers
  hasRole: (role: string) => boolean;
  hasAnyRole: (roles: string[]) => boolean;
}

// API base URL - in production, this would come from env
const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

// Mock users for development when no backend is available
const MOCK_USERS: Record<string, User> = {
  'pm@demo.com': {
    id: 'user-001',
    email: 'pm@demo.com',
    name: 'Portfolio Manager',
    role: 'portfolio_manager',
    permissions: ['read', 'write', 'trade', 'approve'],
    avatar: null,
    created_at: new Date().toISOString(),
    last_login: new Date().toISOString(),
  },
  'trader@demo.com': {
    id: 'user-002',
    email: 'trader@demo.com',
    name: 'Trader',
    role: 'trader',
    permissions: ['read', 'write', 'trade'],
    avatar: null,
    created_at: new Date().toISOString(),
    last_login: new Date().toISOString(),
  },
  'analyst@demo.com': {
    id: 'user-003',
    email: 'analyst@demo.com',
    name: 'Analyst',
    role: 'analyst',
    permissions: ['read', 'write'],
    avatar: null,
    created_at: new Date().toISOString(),
    last_login: new Date().toISOString(),
  },
};

// Mock credentials for development
const MOCK_CREDENTIALS = [
  { email: 'pm@demo.com', password: 'demo123' },
  { email: 'trader@demo.com', password: 'demo123' },
  { email: 'analyst@demo.com', password: 'demo123' },
];

// Check if credentials match mock credentials and return the user
function checkMockCredentials(email: string, password: string): User | null {
  const cred = MOCK_CREDENTIALS.find(
    (c) => c.email === email && c.password === password
  );
  if (cred && MOCK_USERS[cred.email]) {
    return MOCK_USERS[cred.email];
  }
  return null;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      isAuthenticated: false,
      isLoading: false,
      accessToken: null,
      refreshToken: null,
      tokenExpiresAt: null,

      // Login action
      login: async (credentials: LoginRequest) => {
        set({ isLoading: true });
        
        try {
          const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(credentials),
          });

          if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Login failed');
          }

          const data: LoginResponse = await response.json();
          
          const expiresAt = Date.now() + (data.expires_in * 1000);
          
          set({
            user: data.user,
            isAuthenticated: true,
            accessToken: data.access_token,
            refreshToken: data.refresh_token,
            tokenExpiresAt: expiresAt,
            isLoading: false,
          });
        } catch (error) {
          // If fetch failed (network error), try mock authentication
          if (error instanceof TypeError && error.message.includes('fetch')) {
            console.warn('API unavailable, using mock authentication');
            
            const mockUser = checkMockCredentials(credentials.email, credentials.password);
            if (mockUser) {
              const expiresAt = Date.now() + (3600 * 1000); // 1 hour
              
              set({
                user: mockUser,
                isAuthenticated: true,
                accessToken: 'mock-access-token',
                refreshToken: 'mock-refresh-token',
                tokenExpiresAt: expiresAt,
                isLoading: false,
              });
              return;
            } else {
              set({ isLoading: false });
              throw new Error('Invalid credentials. Try pm@demo.com / demo123');
            }
          }
          
          set({ isLoading: false });
          throw error;
        }
      },

      // Logout action
      logout: () => {
        const { accessToken } = get();
        
        // Call logout endpoint (fire and forget)
        if (accessToken) {
          fetch(`${API_BASE}/auth/logout`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${accessToken}`,
            },
          }).catch(() => {
            // Ignore errors on logout
          });
        }
        
        get().clearAuth();
      },

      // Refresh access token
      refreshAccessToken: async () => {
        const { refreshToken } = get();
        
        if (!refreshToken) {
          get().clearAuth();
          return false;
        }

        try {
          const response = await fetch(`${API_BASE}/auth/refresh`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ refresh_token: refreshToken }),
          });

          if (!response.ok) {
            get().clearAuth();
            return false;
          }

          const data = await response.json();
          const expiresAt = Date.now() + (data.expires_in * 1000);
          
          set({
            accessToken: data.access_token,
            refreshToken: data.refresh_token,
            tokenExpiresAt: expiresAt,
          });
          
          return true;
        } catch {
          get().clearAuth();
          return false;
        }
      },

      // Set user
      setUser: (user: User) => {
        set({ user, isAuthenticated: true });
      },

      // Set tokens
      setTokens: (access: string, refresh: string, expiresIn: number) => {
        set({
          accessToken: access,
          refreshToken: refresh,
          tokenExpiresAt: Date.now() + (expiresIn * 1000),
        });
      },

      // Clear all auth state
      clearAuth: () => {
        set({
          user: null,
          isAuthenticated: false,
          accessToken: null,
          refreshToken: null,
          tokenExpiresAt: null,
          isLoading: false,
        });
      },

      // Role check helpers
      hasRole: (role: string) => {
        const { user } = get();
        return user?.role === role;
      },

      hasAnyRole: (roles: string[]) => {
        const { user } = get();
        return user ? roles.includes(user.role) : false;
      },
    }),
    {
      name: 'marketspine-auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        tokenExpiresAt: state.tokenExpiresAt,
      }),
    }
  )
);

// Helper function to check if token is expired (not a hook)
export function isTokenExpired(tokenExpiresAt: number | null): boolean {
  if (!tokenExpiresAt) return true;
  // Consider token expired 30 seconds before actual expiry
  return Date.now() > tokenExpiresAt - 30000;
}

// Helper hook to get token expiry info (stable for render)
export function useTokenExpiry(): { tokenExpiresAt: number | null; checkExpired: () => boolean } {
  const tokenExpiresAt = useAuthStore((state) => state.tokenExpiresAt);
  return {
    tokenExpiresAt,
    checkExpired: () => isTokenExpired(tokenExpiresAt),
  };
}

// Helper hook to get auth headers
export function useAuthHeaders(): Record<string, string> {
  const accessToken = useAuthStore((state) => state.accessToken);
  return accessToken
    ? { Authorization: `Bearer ${accessToken}` }
    : {};
}
